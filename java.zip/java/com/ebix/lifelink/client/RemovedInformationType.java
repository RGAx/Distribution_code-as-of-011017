
package com.ebix.lifelink.client;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for RemovedInformationType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="RemovedInformationType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="Reasons" type="{urn:lifelink-schema}ReasonsType" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "RemovedInformationType", propOrder = {
    "reasons"
})
public class RemovedInformationType {

    @XmlElement(name = "Reasons")
    protected ReasonsType reasons;

    /**
     * Gets the value of the reasons property.
     * 
     * @return
     *     possible object is
     *     {@link ReasonsType }
     *     
     */
    public ReasonsType getReasons() {
        return reasons;
    }

    /**
     * Sets the value of the reasons property.
     * 
     * @param value
     *     allowed object is
     *     {@link ReasonsType }
     *     
     */
    public void setReasons(ReasonsType value) {
        this.reasons = value;
    }

}
