
package com.ebix.lifelink.client;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for LLType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="LLType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="GroupName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="GroupPassword" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="UserName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="UserPassword" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="WFCompanyCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="WFCompanyPassword" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="LOLAKey" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SessionID" type="{urn:lifelink-schema}SessionIDType" minOccurs="0"/>
 *         &lt;element name="InterfaceType" type="{urn:lifelink-schema}InterfaceTypeType"/>
 *         &lt;element name="OutputType" type="{urn:lifelink-schema}OutputTypeType"/>
 *         &lt;element name="Buttons" type="{urn:lifelink-schema}ButtonsType" minOccurs="0"/>
 *         &lt;element name="ReturnButton" type="{urn:lifelink-schema}ReturnButtonType" minOccurs="0"/>
 *         &lt;element name="ReturnRedirURL" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="Logout" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="Tool" type="{urn:lifelink-schema}ToolType" maxOccurs="unbounded"/>
 *         &lt;element name="InterfaceID" type="{http://www.w3.org/2001/XMLSchema}byte" minOccurs="0"/>
 *       &lt;/sequence>
 *       &lt;attribute name="LoginType" type="{urn:lifelink-schema}LoginTypeType" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "LLType", propOrder = {
    "groupName",
    "groupPassword",
    "userName",
    "userPassword",
    "wfCompanyCode",
    "wfCompanyPassword",
    "lolaKey",
    "sessionID",
    "interfaceType",
    "outputType",
    "buttons",
    "returnButton",
    "returnRedirURL",
    "logout",
    "tool",
    "interfaceID"
})
public class LLType {

    @XmlElement(name = "GroupName")
    protected String groupName;
    @XmlElement(name = "GroupPassword")
    protected String groupPassword;
    @XmlElement(name = "UserName")
    protected String userName;
    @XmlElement(name = "UserPassword")
    protected String userPassword;
    @XmlElement(name = "WFCompanyCode")
    protected String wfCompanyCode;
    @XmlElement(name = "WFCompanyPassword")
    protected String wfCompanyPassword;
    @XmlElement(name = "LOLAKey")
    protected String lolaKey;
    @XmlElement(name = "SessionID")
    protected String sessionID;
    @XmlElement(name = "InterfaceType", required = true)
    protected InterfaceTypeType interfaceType;
    @XmlElement(name = "OutputType", required = true)
    protected OutputTypeType outputType;
    @XmlElement(name = "Buttons")
    protected ButtonsType buttons;
    @XmlElement(name = "ReturnButton")
    protected ReturnButtonType returnButton;
    @XmlElement(name = "ReturnRedirURL")
    protected Boolean returnRedirURL;
    @XmlElement(name = "Logout")
    protected Boolean logout;
    @XmlElement(name = "Tool", required = true)
    protected List<ToolType> tool;
    @XmlElement(name = "InterfaceID")
    protected Byte interfaceID;
    @XmlAttribute(name = "LoginType")
    protected LoginTypeType loginType;

    /**
     * Gets the value of the groupName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGroupName() {
        return groupName;
    }

    /**
     * Sets the value of the groupName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGroupName(String value) {
        this.groupName = value;
    }

    /**
     * Gets the value of the groupPassword property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGroupPassword() {
        return groupPassword;
    }

    /**
     * Sets the value of the groupPassword property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGroupPassword(String value) {
        this.groupPassword = value;
    }

    /**
     * Gets the value of the userName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUserName() {
        return userName;
    }

    /**
     * Sets the value of the userName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUserName(String value) {
        this.userName = value;
    }

    /**
     * Gets the value of the userPassword property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUserPassword() {
        return userPassword;
    }

    /**
     * Sets the value of the userPassword property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUserPassword(String value) {
        this.userPassword = value;
    }

    /**
     * Gets the value of the wfCompanyCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWFCompanyCode() {
        return wfCompanyCode;
    }

    /**
     * Sets the value of the wfCompanyCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWFCompanyCode(String value) {
        this.wfCompanyCode = value;
    }

    /**
     * Gets the value of the wfCompanyPassword property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWFCompanyPassword() {
        return wfCompanyPassword;
    }

    /**
     * Sets the value of the wfCompanyPassword property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWFCompanyPassword(String value) {
        this.wfCompanyPassword = value;
    }

    /**
     * Gets the value of the lolaKey property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLOLAKey() {
        return lolaKey;
    }

    /**
     * Sets the value of the lolaKey property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLOLAKey(String value) {
        this.lolaKey = value;
    }

    /**
     * Gets the value of the sessionID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSessionID() {
        return sessionID;
    }

    /**
     * Sets the value of the sessionID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSessionID(String value) {
        this.sessionID = value;
    }

    /**
     * Gets the value of the interfaceType property.
     * 
     * @return
     *     possible object is
     *     {@link InterfaceTypeType }
     *     
     */
    public InterfaceTypeType getInterfaceType() {
        return interfaceType;
    }

    /**
     * Sets the value of the interfaceType property.
     * 
     * @param value
     *     allowed object is
     *     {@link InterfaceTypeType }
     *     
     */
    public void setInterfaceType(InterfaceTypeType value) {
        this.interfaceType = value;
    }

    /**
     * Gets the value of the outputType property.
     * 
     * @return
     *     possible object is
     *     {@link OutputTypeType }
     *     
     */
    public OutputTypeType getOutputType() {
        return outputType;
    }

    /**
     * Sets the value of the outputType property.
     * 
     * @param value
     *     allowed object is
     *     {@link OutputTypeType }
     *     
     */
    public void setOutputType(OutputTypeType value) {
        this.outputType = value;
    }

    /**
     * Gets the value of the buttons property.
     * 
     * @return
     *     possible object is
     *     {@link ButtonsType }
     *     
     */
    public ButtonsType getButtons() {
        return buttons;
    }

    /**
     * Sets the value of the buttons property.
     * 
     * @param value
     *     allowed object is
     *     {@link ButtonsType }
     *     
     */
    public void setButtons(ButtonsType value) {
        this.buttons = value;
    }

    /**
     * Gets the value of the returnButton property.
     * 
     * @return
     *     possible object is
     *     {@link ReturnButtonType }
     *     
     */
    public ReturnButtonType getReturnButton() {
        return returnButton;
    }

    /**
     * Sets the value of the returnButton property.
     * 
     * @param value
     *     allowed object is
     *     {@link ReturnButtonType }
     *     
     */
    public void setReturnButton(ReturnButtonType value) {
        this.returnButton = value;
    }

    /**
     * Gets the value of the returnRedirURL property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isReturnRedirURL() {
        return returnRedirURL;
    }

    /**
     * Sets the value of the returnRedirURL property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setReturnRedirURL(Boolean value) {
        this.returnRedirURL = value;
    }

    /**
     * Gets the value of the logout property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isLogout() {
        return logout;
    }

    /**
     * Sets the value of the logout property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setLogout(Boolean value) {
        this.logout = value;
    }

    /**
     * Gets the value of the tool property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the tool property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getTool().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ToolType }
     * 
     * 
     */
    public List<ToolType> getTool() {
        if (tool == null) {
            tool = new ArrayList<ToolType>();
        }
        return this.tool;
    }

    /**
     * Gets the value of the interfaceID property.
     * 
     * @return
     *     possible object is
     *     {@link Byte }
     *     
     */
    public Byte getInterfaceID() {
        return interfaceID;
    }

    /**
     * Sets the value of the interfaceID property.
     * 
     * @param value
     *     allowed object is
     *     {@link Byte }
     *     
     */
    public void setInterfaceID(Byte value) {
        this.interfaceID = value;
    }

    /**
     * Gets the value of the loginType property.
     * 
     * @return
     *     possible object is
     *     {@link LoginTypeType }
     *     
     */
    public LoginTypeType getLoginType() {
        return loginType;
    }

    /**
     * Sets the value of the loginType property.
     * 
     * @param value
     *     allowed object is
     *     {@link LoginTypeType }
     *     
     */
    public void setLoginType(LoginTypeType value) {
        this.loginType = value;
    }

}
