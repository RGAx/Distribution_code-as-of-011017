
package com.ebix.lifelink.client;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ClientType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ClientType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="Applicant" type="{urn:lifelink-schema}ApplicantType" minOccurs="0"/>
 *         &lt;element name="Spouse" type="{urn:lifelink-schema}SpouseType" minOccurs="0"/>
 *         &lt;element name="StateOfIssue" type="{urn:lifelink-schema}StateAbbrType"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ClientType", propOrder = {
    "applicant",
    "spouse",
    "stateOfIssue"
})
public class ClientType {

    @XmlElement(name = "Applicant")
    protected ApplicantType applicant;
    @XmlElement(name = "Spouse")
    protected SpouseType spouse;
    @XmlElement(name = "StateOfIssue", required = true)
    protected String stateOfIssue;

    /**
     * Gets the value of the applicant property.
     * 
     * @return
     *     possible object is
     *     {@link ApplicantType }
     *     
     */
    public ApplicantType getApplicant() {
        return applicant;
    }

    /**
     * Sets the value of the applicant property.
     * 
     * @param value
     *     allowed object is
     *     {@link ApplicantType }
     *     
     */
    public void setApplicant(ApplicantType value) {
        this.applicant = value;
    }

    /**
     * Gets the value of the spouse property.
     * 
     * @return
     *     possible object is
     *     {@link SpouseType }
     *     
     */
    public SpouseType getSpouse() {
        return spouse;
    }

    /**
     * Sets the value of the spouse property.
     * 
     * @param value
     *     allowed object is
     *     {@link SpouseType }
     *     
     */
    public void setSpouse(SpouseType value) {
        this.spouse = value;
    }

    /**
     * Gets the value of the stateOfIssue property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStateOfIssue() {
        return stateOfIssue;
    }

    /**
     * Sets the value of the stateOfIssue property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStateOfIssue(String value) {
        this.stateOfIssue = value;
    }

}
