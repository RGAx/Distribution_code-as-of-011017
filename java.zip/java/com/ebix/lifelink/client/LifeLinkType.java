
package com.ebix.lifelink.client;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for LifeLinkType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="LifeLinkType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="LL" type="{urn:lifelink-schema}LLType"/>
 *         &lt;element name="UserInformation" type="{urn:lifelink-schema}UserInformationType" minOccurs="0"/>
 *         &lt;element name="Agent" type="{urn:lifelink-schema}AgentType" minOccurs="0"/>
 *         &lt;element name="Client" type="{urn:lifelink-schema}ClientType" minOccurs="0"/>
 *         &lt;element name="Misclaneous" type="{urn:lifelink-schema}MisclaneousType" minOccurs="0"/>
 *         &lt;element name="WinFlex" type="{urn:lifelink-schema}WinFlexType" minOccurs="0"/>
 *         &lt;element name="VitalLTC" type="{urn:lifelink-schema}VitalLTCType" minOccurs="0"/>
 *         &lt;element name="VitalSigns" type="{urn:lifelink-schema}VitalSignsType" minOccurs="0"/>
 *         &lt;element name="VitalTermNet" type="{urn:lifelink-schema}VitalTermNetType" minOccurs="0"/>
 *         &lt;element name="VitalForms" type="{urn:lifelink-schema}VitalFormsType" minOccurs="0"/>
 *         &lt;element name="Notes" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Error" type="{urn:lifelink-schema}ErrorType" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *       &lt;attribute name="LoginType" type="{urn:lifelink-schema}LoginTypeType" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "LifeLinkType", propOrder = {
    "ll",
    "userInformation",
    "agent",
    "client",
    "misclaneous",
    "winFlex",
    "vitalLTC",
    "vitalSigns",
    "vitalTermNet",
    "vitalForms",
    "notes",
    "error"
})
public class LifeLinkType {

    @XmlElement(name = "LL", required = true)
    protected LLType ll;
    @XmlElement(name = "UserInformation")
    protected UserInformationType userInformation;
    @XmlElement(name = "Agent")
    protected AgentType agent;
    @XmlElement(name = "Client")
    protected ClientType client;
    @XmlElement(name = "Misclaneous")
    protected MisclaneousType misclaneous;
    @XmlElement(name = "WinFlex")
    protected WinFlexType winFlex;
    @XmlElement(name = "VitalLTC")
    protected VitalLTCType vitalLTC;
    @XmlElement(name = "VitalSigns")
    protected VitalSignsType vitalSigns;
    @XmlElement(name = "VitalTermNet")
    protected VitalTermNetType vitalTermNet;
    @XmlElement(name = "VitalForms")
    protected VitalFormsType vitalForms;
    @XmlElement(name = "Notes")
    protected String notes;
    @XmlElement(name = "Error")
    protected List<ErrorType> error;
    @XmlAttribute(name = "LoginType")
    protected LoginTypeType loginType;

    /**
     * Gets the value of the ll property.
     * 
     * @return
     *     possible object is
     *     {@link LLType }
     *     
     */
    public LLType getLL() {
        return ll;
    }

    /**
     * Sets the value of the ll property.
     * 
     * @param value
     *     allowed object is
     *     {@link LLType }
     *     
     */
    public void setLL(LLType value) {
        this.ll = value;
    }

    /**
     * Gets the value of the userInformation property.
     * 
     * @return
     *     possible object is
     *     {@link UserInformationType }
     *     
     */
    public UserInformationType getUserInformation() {
        return userInformation;
    }

    /**
     * Sets the value of the userInformation property.
     * 
     * @param value
     *     allowed object is
     *     {@link UserInformationType }
     *     
     */
    public void setUserInformation(UserInformationType value) {
        this.userInformation = value;
    }

    /**
     * Gets the value of the agent property.
     * 
     * @return
     *     possible object is
     *     {@link AgentType }
     *     
     */
    public AgentType getAgent() {
        return agent;
    }

    /**
     * Sets the value of the agent property.
     * 
     * @param value
     *     allowed object is
     *     {@link AgentType }
     *     
     */
    public void setAgent(AgentType value) {
        this.agent = value;
    }

    /**
     * Gets the value of the client property.
     * 
     * @return
     *     possible object is
     *     {@link ClientType }
     *     
     */
    public ClientType getClient() {
        return client;
    }

    /**
     * Sets the value of the client property.
     * 
     * @param value
     *     allowed object is
     *     {@link ClientType }
     *     
     */
    public void setClient(ClientType value) {
        this.client = value;
    }

    /**
     * Gets the value of the misclaneous property.
     * 
     * @return
     *     possible object is
     *     {@link MisclaneousType }
     *     
     */
    public MisclaneousType getMisclaneous() {
        return misclaneous;
    }

    /**
     * Sets the value of the misclaneous property.
     * 
     * @param value
     *     allowed object is
     *     {@link MisclaneousType }
     *     
     */
    public void setMisclaneous(MisclaneousType value) {
        this.misclaneous = value;
    }

    /**
     * Gets the value of the winFlex property.
     * 
     * @return
     *     possible object is
     *     {@link WinFlexType }
     *     
     */
    public WinFlexType getWinFlex() {
        return winFlex;
    }

    /**
     * Sets the value of the winFlex property.
     * 
     * @param value
     *     allowed object is
     *     {@link WinFlexType }
     *     
     */
    public void setWinFlex(WinFlexType value) {
        this.winFlex = value;
    }

    /**
     * Gets the value of the vitalLTC property.
     * 
     * @return
     *     possible object is
     *     {@link VitalLTCType }
     *     
     */
    public VitalLTCType getVitalLTC() {
        return vitalLTC;
    }

    /**
     * Sets the value of the vitalLTC property.
     * 
     * @param value
     *     allowed object is
     *     {@link VitalLTCType }
     *     
     */
    public void setVitalLTC(VitalLTCType value) {
        this.vitalLTC = value;
    }

    /**
     * Gets the value of the vitalSigns property.
     * 
     * @return
     *     possible object is
     *     {@link VitalSignsType }
     *     
     */
    public VitalSignsType getVitalSigns() {
        return vitalSigns;
    }

    /**
     * Sets the value of the vitalSigns property.
     * 
     * @param value
     *     allowed object is
     *     {@link VitalSignsType }
     *     
     */
    public void setVitalSigns(VitalSignsType value) {
        this.vitalSigns = value;
    }

    /**
     * Gets the value of the vitalTermNet property.
     * 
     * @return
     *     possible object is
     *     {@link VitalTermNetType }
     *     
     */
    public VitalTermNetType getVitalTermNet() {
        return vitalTermNet;
    }

    /**
     * Sets the value of the vitalTermNet property.
     * 
     * @param value
     *     allowed object is
     *     {@link VitalTermNetType }
     *     
     */
    public void setVitalTermNet(VitalTermNetType value) {
        this.vitalTermNet = value;
    }

    /**
     * Gets the value of the vitalForms property.
     * 
     * @return
     *     possible object is
     *     {@link VitalFormsType }
     *     
     */
    public VitalFormsType getVitalForms() {
        return vitalForms;
    }

    /**
     * Sets the value of the vitalForms property.
     * 
     * @param value
     *     allowed object is
     *     {@link VitalFormsType }
     *     
     */
    public void setVitalForms(VitalFormsType value) {
        this.vitalForms = value;
    }

    /**
     * Gets the value of the notes property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNotes() {
        return notes;
    }

    /**
     * Sets the value of the notes property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNotes(String value) {
        this.notes = value;
    }

    /**
     * Gets the value of the error property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the error property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getError().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ErrorType }
     * 
     * 
     */
    public List<ErrorType> getError() {
        if (error == null) {
            error = new ArrayList<ErrorType>();
        }
        return this.error;
    }

    /**
     * Gets the value of the loginType property.
     * 
     * @return
     *     possible object is
     *     {@link LoginTypeType }
     *     
     */
    public LoginTypeType getLoginType() {
        return loginType;
    }

    /**
     * Sets the value of the loginType property.
     * 
     * @param value
     *     allowed object is
     *     {@link LoginTypeType }
     *     
     */
    public void setLoginType(LoginTypeType value) {
        this.loginType = value;
    }

}
