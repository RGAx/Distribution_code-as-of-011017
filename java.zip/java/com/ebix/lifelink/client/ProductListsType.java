
package com.ebix.lifelink.client;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ProductListsType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ProductListsType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="ListName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="YearsLevel" type="{http://www.w3.org/2001/XMLSchema}int" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="ProductsRequested" type="{urn:lifelink-schema}ProductRequestType" minOccurs="0"/>
 *         &lt;element name="ProductType" type="{urn:lifelink-schema}ProductTypeType" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="GuaranteedPeriod" type="{http://www.w3.org/2001/XMLSchema}int" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ProductListsType", propOrder = {
    "listName",
    "yearsLevel",
    "productsRequested",
    "productType",
    "guaranteedPeriod"
})
public class ProductListsType {

    @XmlElement(name = "ListName")
    protected String listName;
    @XmlElement(name = "YearsLevel", type = Integer.class)
    protected List<Integer> yearsLevel;
    @XmlElement(name = "ProductsRequested")
    protected ProductRequestType productsRequested;
    @XmlElement(name = "ProductType")
    protected List<ProductTypeType> productType;
    @XmlElement(name = "GuaranteedPeriod", type = Integer.class)
    protected List<Integer> guaranteedPeriod;

    /**
     * Gets the value of the listName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getListName() {
        return listName;
    }

    /**
     * Sets the value of the listName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setListName(String value) {
        this.listName = value;
    }

    /**
     * Gets the value of the yearsLevel property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the yearsLevel property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getYearsLevel().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Integer }
     * 
     * 
     */
    public List<Integer> getYearsLevel() {
        if (yearsLevel == null) {
            yearsLevel = new ArrayList<Integer>();
        }
        return this.yearsLevel;
    }

    /**
     * Gets the value of the productsRequested property.
     * 
     * @return
     *     possible object is
     *     {@link ProductRequestType }
     *     
     */
    public ProductRequestType getProductsRequested() {
        return productsRequested;
    }

    /**
     * Sets the value of the productsRequested property.
     * 
     * @param value
     *     allowed object is
     *     {@link ProductRequestType }
     *     
     */
    public void setProductsRequested(ProductRequestType value) {
        this.productsRequested = value;
    }

    /**
     * Gets the value of the productType property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the productType property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getProductType().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ProductTypeType }
     * 
     * 
     */
    public List<ProductTypeType> getProductType() {
        if (productType == null) {
            productType = new ArrayList<ProductTypeType>();
        }
        return this.productType;
    }

    /**
     * Gets the value of the guaranteedPeriod property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the guaranteedPeriod property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getGuaranteedPeriod().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Integer }
     * 
     * 
     */
    public List<Integer> getGuaranteedPeriod() {
        if (guaranteedPeriod == null) {
            guaranteedPeriod = new ArrayList<Integer>();
        }
        return this.guaranteedPeriod;
    }

}
