
package com.ebix.lifelink.client;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ToolType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ToolType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="Name" type="{urn:lifelink-schema}ToolTypeName"/>
 *         &lt;element name="StartLocation" type="{urn:lifelink-schema}ToolLocationType" minOccurs="0"/>
 *         &lt;element name="FinalLocation" type="{urn:lifelink-schema}ToolLocationType" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ToolType", propOrder = {
    "name",
    "startLocation",
    "finalLocation"
})
public class ToolType {

    @XmlElement(name = "Name", required = true)
    protected ToolTypeName name;
    @XmlElement(name = "StartLocation")
    protected ToolLocationType startLocation;
    @XmlElement(name = "FinalLocation")
    protected ToolLocationType finalLocation;

    /**
     * Gets the value of the name property.
     * 
     * @return
     *     possible object is
     *     {@link ToolTypeName }
     *     
     */
    public ToolTypeName getName() {
        return name;
    }

    /**
     * Sets the value of the name property.
     * 
     * @param value
     *     allowed object is
     *     {@link ToolTypeName }
     *     
     */
    public void setName(ToolTypeName value) {
        this.name = value;
    }

    /**
     * Gets the value of the startLocation property.
     * 
     * @return
     *     possible object is
     *     {@link ToolLocationType }
     *     
     */
    public ToolLocationType getStartLocation() {
        return startLocation;
    }

    /**
     * Sets the value of the startLocation property.
     * 
     * @param value
     *     allowed object is
     *     {@link ToolLocationType }
     *     
     */
    public void setStartLocation(ToolLocationType value) {
        this.startLocation = value;
    }

    /**
     * Gets the value of the finalLocation property.
     * 
     * @return
     *     possible object is
     *     {@link ToolLocationType }
     *     
     */
    public ToolLocationType getFinalLocation() {
        return finalLocation;
    }

    /**
     * Sets the value of the finalLocation property.
     * 
     * @param value
     *     allowed object is
     *     {@link ToolLocationType }
     *     
     */
    public void setFinalLocation(ToolLocationType value) {
        this.finalLocation = value;
    }

}
