
package com.ebix.lifelink.client;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for FilterAvailabilityType.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="FilterAvailabilityType">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="NA"/>
 *     &lt;enumeration value="Optional"/>
 *     &lt;enumeration value="Included"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "FilterAvailabilityType")
@XmlEnum
public enum FilterAvailabilityType {

    NA("NA"),
    @XmlEnumValue("Optional")
    OPTIONAL("Optional"),
    @XmlEnumValue("Included")
    INCLUDED("Included");
    private final String value;

    FilterAvailabilityType(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static FilterAvailabilityType fromValue(String v) {
        for (FilterAvailabilityType c: FilterAvailabilityType.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
