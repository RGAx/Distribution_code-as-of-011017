
package com.ebix.lifelink.client;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for NarrativesType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="NarrativesType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="descriptions" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="band_ranges" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="classes" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="conversion" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="credited_interest" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="death_benefit" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="discounts" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="expense_charges" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="face_amounts" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="illustrations" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="issue_ages" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="maturity_age" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="modal_factors" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="business_submissions" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="policy_exclusions" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="policy_fee" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="policy_form" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="policy_lapse_reinstatement" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="policy_loans" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="premium_calculations" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="premium_payment_options" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="rate_structure" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="reentry" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="renewable" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="substandard_rate_classes" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="surrender_charges" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="target_premium" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="underwriting" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="unisex_rates" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="withdrawals" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="years_level_guarantee" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="miscellaneous" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="riders" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="disclaimer" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "NarrativesType", propOrder = {
    "descriptions",
    "bandRanges",
    "classes",
    "conversion",
    "creditedInterest",
    "deathBenefit",
    "discounts",
    "expenseCharges",
    "faceAmounts",
    "illustrations",
    "issueAges",
    "maturityAge",
    "modalFactors",
    "businessSubmissions",
    "policyExclusions",
    "policyFee",
    "policyForm",
    "policyLapseReinstatement",
    "policyLoans",
    "premiumCalculations",
    "premiumPaymentOptions",
    "rateStructure",
    "reentry",
    "renewable",
    "substandardRateClasses",
    "surrenderCharges",
    "targetPremium",
    "underwriting",
    "unisexRates",
    "withdrawals",
    "yearsLevelGuarantee",
    "miscellaneous",
    "riders",
    "disclaimer"
})
public class NarrativesType {

    protected String descriptions;
    @XmlElement(name = "band_ranges")
    protected String bandRanges;
    protected String classes;
    protected String conversion;
    @XmlElement(name = "credited_interest")
    protected String creditedInterest;
    @XmlElement(name = "death_benefit")
    protected String deathBenefit;
    protected String discounts;
    @XmlElement(name = "expense_charges")
    protected String expenseCharges;
    @XmlElement(name = "face_amounts")
    protected String faceAmounts;
    protected String illustrations;
    @XmlElement(name = "issue_ages")
    protected String issueAges;
    @XmlElement(name = "maturity_age")
    protected String maturityAge;
    @XmlElement(name = "modal_factors")
    protected String modalFactors;
    @XmlElement(name = "business_submissions")
    protected String businessSubmissions;
    @XmlElement(name = "policy_exclusions")
    protected String policyExclusions;
    @XmlElement(name = "policy_fee")
    protected String policyFee;
    @XmlElement(name = "policy_form")
    protected String policyForm;
    @XmlElement(name = "policy_lapse_reinstatement")
    protected String policyLapseReinstatement;
    @XmlElement(name = "policy_loans")
    protected String policyLoans;
    @XmlElement(name = "premium_calculations")
    protected String premiumCalculations;
    @XmlElement(name = "premium_payment_options")
    protected String premiumPaymentOptions;
    @XmlElement(name = "rate_structure")
    protected String rateStructure;
    protected String reentry;
    protected String renewable;
    @XmlElement(name = "substandard_rate_classes")
    protected String substandardRateClasses;
    @XmlElement(name = "surrender_charges")
    protected String surrenderCharges;
    @XmlElement(name = "target_premium")
    protected String targetPremium;
    protected String underwriting;
    @XmlElement(name = "unisex_rates")
    protected String unisexRates;
    protected String withdrawals;
    @XmlElement(name = "years_level_guarantee")
    protected String yearsLevelGuarantee;
    protected String miscellaneous;
    protected String riders;
    protected String disclaimer;

    /**
     * Gets the value of the descriptions property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDescriptions() {
        return descriptions;
    }

    /**
     * Sets the value of the descriptions property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDescriptions(String value) {
        this.descriptions = value;
    }

    /**
     * Gets the value of the bandRanges property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBandRanges() {
        return bandRanges;
    }

    /**
     * Sets the value of the bandRanges property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBandRanges(String value) {
        this.bandRanges = value;
    }

    /**
     * Gets the value of the classes property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getClasses() {
        return classes;
    }

    /**
     * Sets the value of the classes property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setClasses(String value) {
        this.classes = value;
    }

    /**
     * Gets the value of the conversion property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getConversion() {
        return conversion;
    }

    /**
     * Sets the value of the conversion property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setConversion(String value) {
        this.conversion = value;
    }

    /**
     * Gets the value of the creditedInterest property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCreditedInterest() {
        return creditedInterest;
    }

    /**
     * Sets the value of the creditedInterest property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCreditedInterest(String value) {
        this.creditedInterest = value;
    }

    /**
     * Gets the value of the deathBenefit property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDeathBenefit() {
        return deathBenefit;
    }

    /**
     * Sets the value of the deathBenefit property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDeathBenefit(String value) {
        this.deathBenefit = value;
    }

    /**
     * Gets the value of the discounts property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDiscounts() {
        return discounts;
    }

    /**
     * Sets the value of the discounts property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDiscounts(String value) {
        this.discounts = value;
    }

    /**
     * Gets the value of the expenseCharges property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getExpenseCharges() {
        return expenseCharges;
    }

    /**
     * Sets the value of the expenseCharges property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setExpenseCharges(String value) {
        this.expenseCharges = value;
    }

    /**
     * Gets the value of the faceAmounts property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFaceAmounts() {
        return faceAmounts;
    }

    /**
     * Sets the value of the faceAmounts property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFaceAmounts(String value) {
        this.faceAmounts = value;
    }

    /**
     * Gets the value of the illustrations property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIllustrations() {
        return illustrations;
    }

    /**
     * Sets the value of the illustrations property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIllustrations(String value) {
        this.illustrations = value;
    }

    /**
     * Gets the value of the issueAges property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIssueAges() {
        return issueAges;
    }

    /**
     * Sets the value of the issueAges property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIssueAges(String value) {
        this.issueAges = value;
    }

    /**
     * Gets the value of the maturityAge property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMaturityAge() {
        return maturityAge;
    }

    /**
     * Sets the value of the maturityAge property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMaturityAge(String value) {
        this.maturityAge = value;
    }

    /**
     * Gets the value of the modalFactors property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getModalFactors() {
        return modalFactors;
    }

    /**
     * Sets the value of the modalFactors property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setModalFactors(String value) {
        this.modalFactors = value;
    }

    /**
     * Gets the value of the businessSubmissions property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBusinessSubmissions() {
        return businessSubmissions;
    }

    /**
     * Sets the value of the businessSubmissions property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBusinessSubmissions(String value) {
        this.businessSubmissions = value;
    }

    /**
     * Gets the value of the policyExclusions property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPolicyExclusions() {
        return policyExclusions;
    }

    /**
     * Sets the value of the policyExclusions property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPolicyExclusions(String value) {
        this.policyExclusions = value;
    }

    /**
     * Gets the value of the policyFee property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPolicyFee() {
        return policyFee;
    }

    /**
     * Sets the value of the policyFee property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPolicyFee(String value) {
        this.policyFee = value;
    }

    /**
     * Gets the value of the policyForm property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPolicyForm() {
        return policyForm;
    }

    /**
     * Sets the value of the policyForm property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPolicyForm(String value) {
        this.policyForm = value;
    }

    /**
     * Gets the value of the policyLapseReinstatement property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPolicyLapseReinstatement() {
        return policyLapseReinstatement;
    }

    /**
     * Sets the value of the policyLapseReinstatement property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPolicyLapseReinstatement(String value) {
        this.policyLapseReinstatement = value;
    }

    /**
     * Gets the value of the policyLoans property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPolicyLoans() {
        return policyLoans;
    }

    /**
     * Sets the value of the policyLoans property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPolicyLoans(String value) {
        this.policyLoans = value;
    }

    /**
     * Gets the value of the premiumCalculations property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPremiumCalculations() {
        return premiumCalculations;
    }

    /**
     * Sets the value of the premiumCalculations property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPremiumCalculations(String value) {
        this.premiumCalculations = value;
    }

    /**
     * Gets the value of the premiumPaymentOptions property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPremiumPaymentOptions() {
        return premiumPaymentOptions;
    }

    /**
     * Sets the value of the premiumPaymentOptions property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPremiumPaymentOptions(String value) {
        this.premiumPaymentOptions = value;
    }

    /**
     * Gets the value of the rateStructure property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRateStructure() {
        return rateStructure;
    }

    /**
     * Sets the value of the rateStructure property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRateStructure(String value) {
        this.rateStructure = value;
    }

    /**
     * Gets the value of the reentry property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReentry() {
        return reentry;
    }

    /**
     * Sets the value of the reentry property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReentry(String value) {
        this.reentry = value;
    }

    /**
     * Gets the value of the renewable property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRenewable() {
        return renewable;
    }

    /**
     * Sets the value of the renewable property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRenewable(String value) {
        this.renewable = value;
    }

    /**
     * Gets the value of the substandardRateClasses property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSubstandardRateClasses() {
        return substandardRateClasses;
    }

    /**
     * Sets the value of the substandardRateClasses property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSubstandardRateClasses(String value) {
        this.substandardRateClasses = value;
    }

    /**
     * Gets the value of the surrenderCharges property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSurrenderCharges() {
        return surrenderCharges;
    }

    /**
     * Sets the value of the surrenderCharges property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSurrenderCharges(String value) {
        this.surrenderCharges = value;
    }

    /**
     * Gets the value of the targetPremium property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTargetPremium() {
        return targetPremium;
    }

    /**
     * Sets the value of the targetPremium property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTargetPremium(String value) {
        this.targetPremium = value;
    }

    /**
     * Gets the value of the underwriting property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUnderwriting() {
        return underwriting;
    }

    /**
     * Sets the value of the underwriting property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUnderwriting(String value) {
        this.underwriting = value;
    }

    /**
     * Gets the value of the unisexRates property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUnisexRates() {
        return unisexRates;
    }

    /**
     * Sets the value of the unisexRates property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUnisexRates(String value) {
        this.unisexRates = value;
    }

    /**
     * Gets the value of the withdrawals property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWithdrawals() {
        return withdrawals;
    }

    /**
     * Sets the value of the withdrawals property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWithdrawals(String value) {
        this.withdrawals = value;
    }

    /**
     * Gets the value of the yearsLevelGuarantee property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getYearsLevelGuarantee() {
        return yearsLevelGuarantee;
    }

    /**
     * Sets the value of the yearsLevelGuarantee property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setYearsLevelGuarantee(String value) {
        this.yearsLevelGuarantee = value;
    }

    /**
     * Gets the value of the miscellaneous property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMiscellaneous() {
        return miscellaneous;
    }

    /**
     * Sets the value of the miscellaneous property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMiscellaneous(String value) {
        this.miscellaneous = value;
    }

    /**
     * Gets the value of the riders property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRiders() {
        return riders;
    }

    /**
     * Sets the value of the riders property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRiders(String value) {
        this.riders = value;
    }

    /**
     * Gets the value of the disclaimer property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDisclaimer() {
        return disclaimer;
    }

    /**
     * Sets the value of the disclaimer property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDisclaimer(String value) {
        this.disclaimer = value;
    }

}
