
package com.ebix.lifelink.client;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for OutputType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="OutputType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="VLTCQuotes" type="{urn:lifelink-schema}QuotesType" minOccurs="0"/>
 *         &lt;element name="NumberOfProductsReturned" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="PDFFile" type="{urn:lifelink-schema}PDFFileType" minOccurs="0"/>
 *         &lt;element name="Disclaimer" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="Removed" type="{urn:lifelink-schema}RemovedProductsType" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "OutputType", propOrder = {
    "vltcQuotes",
    "numberOfProductsReturned",
    "pdfFile",
    "disclaimer",
    "removed"
})
public class OutputType {

    @XmlElement(name = "VLTCQuotes")
    protected QuotesType vltcQuotes;
    @XmlElement(name = "NumberOfProductsReturned")
    protected Integer numberOfProductsReturned;
    @XmlElement(name = "PDFFile")
    protected PDFFileType pdfFile;
    @XmlElement(name = "Disclaimer", required = true)
    protected String disclaimer;
    @XmlElement(name = "Removed")
    protected RemovedProductsType removed;

    /**
     * Gets the value of the vltcQuotes property.
     * 
     * @return
     *     possible object is
     *     {@link QuotesType }
     *     
     */
    public QuotesType getVLTCQuotes() {
        return vltcQuotes;
    }

    /**
     * Sets the value of the vltcQuotes property.
     * 
     * @param value
     *     allowed object is
     *     {@link QuotesType }
     *     
     */
    public void setVLTCQuotes(QuotesType value) {
        this.vltcQuotes = value;
    }

    /**
     * Gets the value of the numberOfProductsReturned property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getNumberOfProductsReturned() {
        return numberOfProductsReturned;
    }

    /**
     * Sets the value of the numberOfProductsReturned property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setNumberOfProductsReturned(Integer value) {
        this.numberOfProductsReturned = value;
    }

    /**
     * Gets the value of the pdfFile property.
     * 
     * @return
     *     possible object is
     *     {@link PDFFileType }
     *     
     */
    public PDFFileType getPDFFile() {
        return pdfFile;
    }

    /**
     * Sets the value of the pdfFile property.
     * 
     * @param value
     *     allowed object is
     *     {@link PDFFileType }
     *     
     */
    public void setPDFFile(PDFFileType value) {
        this.pdfFile = value;
    }

    /**
     * Gets the value of the disclaimer property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDisclaimer() {
        return disclaimer;
    }

    /**
     * Sets the value of the disclaimer property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDisclaimer(String value) {
        this.disclaimer = value;
    }

    /**
     * Gets the value of the removed property.
     * 
     * @return
     *     possible object is
     *     {@link RemovedProductsType }
     *     
     */
    public RemovedProductsType getRemoved() {
        return removed;
    }

    /**
     * Sets the value of the removed property.
     * 
     * @param value
     *     allowed object is
     *     {@link RemovedProductsType }
     *     
     */
    public void setRemoved(RemovedProductsType value) {
        this.removed = value;
    }

}
