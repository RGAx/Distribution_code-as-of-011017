
package com.ebix.lifelink.client;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for RanTBLRateInfoType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="RanTBLRateInfoType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="RatingRan" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="RatingAges" type="{urn:lifelink-schema}MinMaxInfoType" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "RanTBLRateInfoType", propOrder = {
    "ratingRan",
    "ratingAges"
})
public class RanTBLRateInfoType {

    @XmlElement(name = "RatingRan")
    protected Boolean ratingRan;
    @XmlElement(name = "RatingAges")
    protected MinMaxInfoType ratingAges;

    /**
     * Gets the value of the ratingRan property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isRatingRan() {
        return ratingRan;
    }

    /**
     * Sets the value of the ratingRan property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setRatingRan(Boolean value) {
        this.ratingRan = value;
    }

    /**
     * Gets the value of the ratingAges property.
     * 
     * @return
     *     possible object is
     *     {@link MinMaxInfoType }
     *     
     */
    public MinMaxInfoType getRatingAges() {
        return ratingAges;
    }

    /**
     * Sets the value of the ratingAges property.
     * 
     * @param value
     *     allowed object is
     *     {@link MinMaxInfoType }
     *     
     */
    public void setRatingAges(MinMaxInfoType value) {
        this.ratingAges = value;
    }

}
