
package com.ebix.lifelink.client;

import java.math.BigDecimal;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for QuoteType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="QuoteType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="Product" type="{urn:lifelink-schema}ProductType"/>
 *         &lt;element name="Premium" type="{http://www.w3.org/2001/XMLSchema}decimal"/>
 *         &lt;element name="State" type="{urn:lifelink-schema}StateAbbrType"/>
 *         &lt;element name="Quote" type="{urn:lifelink-schema}BaseQuoteType"/>
 *         &lt;element name="JointQuote" type="{urn:lifelink-schema}BaseQuoteType" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "QuoteType", propOrder = {
    "product",
    "premium",
    "state",
    "quote",
    "jointQuote"
})
public class QuoteType {

    @XmlElement(name = "Product", required = true)
    protected ProductType product;
    @XmlElement(name = "Premium", required = true)
    protected BigDecimal premium;
    @XmlElement(name = "State", required = true)
    protected String state;
    @XmlElement(name = "Quote", required = true)
    protected BaseQuoteType quote;
    @XmlElement(name = "JointQuote")
    protected BaseQuoteType jointQuote;

    /**
     * Gets the value of the product property.
     * 
     * @return
     *     possible object is
     *     {@link ProductType }
     *     
     */
    public ProductType getProduct() {
        return product;
    }

    /**
     * Sets the value of the product property.
     * 
     * @param value
     *     allowed object is
     *     {@link ProductType }
     *     
     */
    public void setProduct(ProductType value) {
        this.product = value;
    }

    /**
     * Gets the value of the premium property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getPremium() {
        return premium;
    }

    /**
     * Sets the value of the premium property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setPremium(BigDecimal value) {
        this.premium = value;
    }

    /**
     * Gets the value of the state property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getState() {
        return state;
    }

    /**
     * Sets the value of the state property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setState(String value) {
        this.state = value;
    }

    /**
     * Gets the value of the quote property.
     * 
     * @return
     *     possible object is
     *     {@link BaseQuoteType }
     *     
     */
    public BaseQuoteType getQuote() {
        return quote;
    }

    /**
     * Sets the value of the quote property.
     * 
     * @param value
     *     allowed object is
     *     {@link BaseQuoteType }
     *     
     */
    public void setQuote(BaseQuoteType value) {
        this.quote = value;
    }

    /**
     * Gets the value of the jointQuote property.
     * 
     * @return
     *     possible object is
     *     {@link BaseQuoteType }
     *     
     */
    public BaseQuoteType getJointQuote() {
        return jointQuote;
    }

    /**
     * Sets the value of the jointQuote property.
     * 
     * @param value
     *     allowed object is
     *     {@link BaseQuoteType }
     *     
     */
    public void setJointQuote(BaseQuoteType value) {
        this.jointQuote = value;
    }

}
