
package com.ebix.lifelink.client;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for VitalLTCType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="VitalLTCType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="ProductOptions" type="{urn:lifelink-schema}ProductOptionsType" minOccurs="0"/>
 *         &lt;element name="Output" type="{urn:lifelink-schema}OutputType" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "VitalLTCType", propOrder = {
    "productOptions",
    "output"
})
public class VitalLTCType {

    @XmlElement(name = "ProductOptions")
    protected ProductOptionsType productOptions;
    @XmlElement(name = "Output")
    protected OutputType output;

    /**
     * Gets the value of the productOptions property.
     * 
     * @return
     *     possible object is
     *     {@link ProductOptionsType }
     *     
     */
    public ProductOptionsType getProductOptions() {
        return productOptions;
    }

    /**
     * Sets the value of the productOptions property.
     * 
     * @param value
     *     allowed object is
     *     {@link ProductOptionsType }
     *     
     */
    public void setProductOptions(ProductOptionsType value) {
        this.productOptions = value;
    }

    /**
     * Gets the value of the output property.
     * 
     * @return
     *     possible object is
     *     {@link OutputType }
     *     
     */
    public OutputType getOutput() {
        return output;
    }

    /**
     * Sets the value of the output property.
     * 
     * @param value
     *     allowed object is
     *     {@link OutputType }
     *     
     */
    public void setOutput(OutputType value) {
        this.output = value;
    }

}
