
package com.ebix.lifelink.client;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for GenericWeeklyHomeCareType.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="GenericWeeklyHomeCareType">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="NO"/>
 *     &lt;enumeration value="YES"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "GenericWeeklyHomeCareType")
@XmlEnum
public enum GenericWeeklyHomeCareType {

    NO,
    YES;

    public String value() {
        return name();
    }

    public static GenericWeeklyHomeCareType fromValue(String v) {
        return valueOf(v);
    }

}
