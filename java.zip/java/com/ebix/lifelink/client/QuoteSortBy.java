
package com.ebix.lifelink.client;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for QuoteSortBy.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="QuoteSortBy">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="Company"/>
 *     &lt;enumeration value="Product"/>
 *     &lt;enumeration value="Premium"/>
 *     &lt;enumeration value="AMBest"/>
 *     &lt;enumeration value="SandP"/>
 *     &lt;enumeration value="Moodys"/>
 *     &lt;enumeration value="Fitch"/>
 *     &lt;enumeration value="Comdex"/>
 *     &lt;enumeration value="Assets"/>
 *     &lt;enumeration value="Liabilities"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "QuoteSortBy")
@XmlEnum
public enum QuoteSortBy {

    @XmlEnumValue("Company")
    COMPANY("Company"),
    @XmlEnumValue("Product")
    PRODUCT("Product"),
    @XmlEnumValue("Premium")
    PREMIUM("Premium"),
    @XmlEnumValue("AMBest")
    AM_BEST("AMBest"),
    @XmlEnumValue("SandP")
    SAND_P("SandP"),
    @XmlEnumValue("Moodys")
    MOODYS("Moodys"),
    @XmlEnumValue("Fitch")
    FITCH("Fitch"),
    @XmlEnumValue("Comdex")
    COMDEX("Comdex"),
    @XmlEnumValue("Assets")
    ASSETS("Assets"),
    @XmlEnumValue("Liabilities")
    LIABILITIES("Liabilities");
    private final String value;

    QuoteSortBy(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static QuoteSortBy fromValue(String v) {
        for (QuoteSortBy c: QuoteSortBy.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
