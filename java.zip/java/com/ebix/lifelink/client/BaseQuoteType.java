
package com.ebix.lifelink.client;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for BaseQuoteType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="BaseQuoteType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="IndivPremium" type="{http://www.w3.org/2001/XMLSchema}decimal"/>
 *         &lt;element name="BenAmt" type="{urn:lifelink-schema}BenAmtType"/>
 *         &lt;element name="Birthdate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
 *         &lt;element name="Age" type="{urn:lifelink-schema}VLTCAgeType"/>
 *         &lt;element name="Option" type="{urn:lifelink-schema}OptionType" maxOccurs="50"/>
 *         &lt;element name="Filters" type="{urn:lifelink-schema}FilterDetailsType" minOccurs="0"/>
 *         &lt;element name="Message" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "BaseQuoteType", propOrder = {
    "indivPremium",
    "benAmt",
    "birthdate",
    "age",
    "option",
    "filters",
    "message"
})
public class BaseQuoteType {

    @XmlElement(name = "IndivPremium", required = true)
    protected BigDecimal indivPremium;
    @XmlElement(name = "BenAmt", required = true)
    protected BenAmtType benAmt;
    @XmlElement(name = "Birthdate")
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar birthdate;
    @XmlElement(name = "Age", required = true)
    protected VLTCAgeType age;
    @XmlElement(name = "Option", required = true)
    protected List<OptionType> option;
    @XmlElement(name = "Filters")
    protected FilterDetailsType filters;
    @XmlElement(name = "Message")
    protected List<String> message;

    /**
     * Gets the value of the indivPremium property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getIndivPremium() {
        return indivPremium;
    }

    /**
     * Sets the value of the indivPremium property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setIndivPremium(BigDecimal value) {
        this.indivPremium = value;
    }

    /**
     * Gets the value of the benAmt property.
     * 
     * @return
     *     possible object is
     *     {@link BenAmtType }
     *     
     */
    public BenAmtType getBenAmt() {
        return benAmt;
    }

    /**
     * Sets the value of the benAmt property.
     * 
     * @param value
     *     allowed object is
     *     {@link BenAmtType }
     *     
     */
    public void setBenAmt(BenAmtType value) {
        this.benAmt = value;
    }

    /**
     * Gets the value of the birthdate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getBirthdate() {
        return birthdate;
    }

    /**
     * Sets the value of the birthdate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setBirthdate(XMLGregorianCalendar value) {
        this.birthdate = value;
    }

    /**
     * Gets the value of the age property.
     * 
     * @return
     *     possible object is
     *     {@link VLTCAgeType }
     *     
     */
    public VLTCAgeType getAge() {
        return age;
    }

    /**
     * Sets the value of the age property.
     * 
     * @param value
     *     allowed object is
     *     {@link VLTCAgeType }
     *     
     */
    public void setAge(VLTCAgeType value) {
        this.age = value;
    }

    /**
     * Gets the value of the option property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the option property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getOption().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link OptionType }
     * 
     * 
     */
    public List<OptionType> getOption() {
        if (option == null) {
            option = new ArrayList<OptionType>();
        }
        return this.option;
    }

    /**
     * Gets the value of the filters property.
     * 
     * @return
     *     possible object is
     *     {@link FilterDetailsType }
     *     
     */
    public FilterDetailsType getFilters() {
        return filters;
    }

    /**
     * Sets the value of the filters property.
     * 
     * @param value
     *     allowed object is
     *     {@link FilterDetailsType }
     *     
     */
    public void setFilters(FilterDetailsType value) {
        this.filters = value;
    }

    /**
     * Gets the value of the message property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the message property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getMessage().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link String }
     * 
     * 
     */
    public List<String> getMessage() {
        if (message == null) {
            message = new ArrayList<String>();
        }
        return this.message;
    }

}
