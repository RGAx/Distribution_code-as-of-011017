
package com.ebix.lifelink.client;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for LoginTypeType.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="LoginTypeType">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="LLP_STANDARD"/>
 *     &lt;enumeration value="LLP_GROUPLOGIN"/>
 *     &lt;enumeration value="LLP_GSLOGIN"/>
 *     &lt;enumeration value="WF_3RDPARTY"/>
 *     &lt;enumeration value="WF_AGENCY"/>
 *     &lt;enumeration value="WF_CARRIER"/>
 *     &lt;enumeration value="WF_LLP"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "LoginTypeType")
@XmlEnum
public enum LoginTypeType {

    LLP_STANDARD("LLP_STANDARD"),
    LLP_GROUPLOGIN("LLP_GROUPLOGIN"),
    LLP_GSLOGIN("LLP_GSLOGIN"),
    @XmlEnumValue("WF_3RDPARTY")
    WF_3_RDPARTY("WF_3RDPARTY"),
    WF_AGENCY("WF_AGENCY"),
    WF_CARRIER("WF_CARRIER"),
    WF_LLP("WF_LLP");
    private final String value;

    LoginTypeType(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static LoginTypeType fromValue(String v) {
        for (LoginTypeType c: LoginTypeType.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
