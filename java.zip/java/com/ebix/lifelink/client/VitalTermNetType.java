
package com.ebix.lifelink.client;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for VitalTermNetType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="VitalTermNetType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="UWClassDetermination" type="{urn:lifelink-schema}ClassDeterminationType" minOccurs="0"/>
 *         &lt;element name="Products" type="{urn:lifelink-schema}ProductsType" minOccurs="0"/>
 *         &lt;element name="PDFFile" type="{urn:lifelink-schema}PDFFileType" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "VitalTermNetType", propOrder = {
    "uwClassDetermination",
    "products",
    "pdfFile"
})
public class VitalTermNetType {

    @XmlElement(name = "UWClassDetermination")
    protected ClassDeterminationType uwClassDetermination;
    @XmlElement(name = "Products")
    protected ProductsType products;
    @XmlElement(name = "PDFFile")
    protected PDFFileType pdfFile;

    /**
     * Gets the value of the uwClassDetermination property.
     * 
     * @return
     *     possible object is
     *     {@link ClassDeterminationType }
     *     
     */
    public ClassDeterminationType getUWClassDetermination() {
        return uwClassDetermination;
    }

    /**
     * Sets the value of the uwClassDetermination property.
     * 
     * @param value
     *     allowed object is
     *     {@link ClassDeterminationType }
     *     
     */
    public void setUWClassDetermination(ClassDeterminationType value) {
        this.uwClassDetermination = value;
    }

    /**
     * Gets the value of the products property.
     * 
     * @return
     *     possible object is
     *     {@link ProductsType }
     *     
     */
    public ProductsType getProducts() {
        return products;
    }

    /**
     * Sets the value of the products property.
     * 
     * @param value
     *     allowed object is
     *     {@link ProductsType }
     *     
     */
    public void setProducts(ProductsType value) {
        this.products = value;
    }

    /**
     * Gets the value of the pdfFile property.
     * 
     * @return
     *     possible object is
     *     {@link PDFFileType }
     *     
     */
    public PDFFileType getPDFFile() {
        return pdfFile;
    }

    /**
     * Sets the value of the pdfFile property.
     * 
     * @param value
     *     allowed object is
     *     {@link PDFFileType }
     *     
     */
    public void setPDFFile(PDFFileType value) {
        this.pdfFile = value;
    }

}
