
package com.ebix.lifelink.client;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for RequestedProductInfoType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="RequestedProductInfoType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="DisplayName" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="NAICCertified" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="RateCard" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="SoftwareVersion" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="PolicyFormNumber" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="AgeNearestLast" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="CalculatedAge" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="ModalFactors" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="ExtraFees" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="YearsLevel" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="GuaranteedPeriod" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="MaturityAge" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="PremiumDiscount" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="IssueAges" type="{urn:lifelink-schema}MinMaxInfoType" minOccurs="0"/>
 *         &lt;element name="FaceAmounts" type="{urn:lifelink-schema}MinMaxInfoType" minOccurs="0"/>
 *         &lt;element name="MinimumPremium" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="Reentry" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="Conversion" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="Narratives" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="UnderwritingClasses" type="{urn:lifelink-schema}DispUWInfoType" minOccurs="0"/>
 *         &lt;element name="RiderInformation" type="{urn:lifelink-schema}DispRidersInfoType" minOccurs="0"/>
 *         &lt;element name="RetrieveStateApprovals" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "RequestedProductInfoType", propOrder = {
    "displayName",
    "naicCertified",
    "rateCard",
    "softwareVersion",
    "policyFormNumber",
    "ageNearestLast",
    "calculatedAge",
    "modalFactors",
    "extraFees",
    "yearsLevel",
    "guaranteedPeriod",
    "maturityAge",
    "premiumDiscount",
    "issueAges",
    "faceAmounts",
    "minimumPremium",
    "reentry",
    "conversion",
    "narratives",
    "underwritingClasses",
    "riderInformation",
    "retrieveStateApprovals"
})
public class RequestedProductInfoType {

    @XmlElement(name = "DisplayName")
    protected Boolean displayName;
    @XmlElement(name = "NAICCertified")
    protected Boolean naicCertified;
    @XmlElement(name = "RateCard")
    protected Boolean rateCard;
    @XmlElement(name = "SoftwareVersion")
    protected Boolean softwareVersion;
    @XmlElement(name = "PolicyFormNumber")
    protected Boolean policyFormNumber;
    @XmlElement(name = "AgeNearestLast")
    protected Boolean ageNearestLast;
    @XmlElement(name = "CalculatedAge")
    protected Boolean calculatedAge;
    @XmlElement(name = "ModalFactors")
    protected Boolean modalFactors;
    @XmlElement(name = "ExtraFees")
    protected Boolean extraFees;
    @XmlElement(name = "YearsLevel")
    protected Boolean yearsLevel;
    @XmlElement(name = "GuaranteedPeriod")
    protected Boolean guaranteedPeriod;
    @XmlElement(name = "MaturityAge")
    protected Boolean maturityAge;
    @XmlElement(name = "PremiumDiscount")
    protected Boolean premiumDiscount;
    @XmlElement(name = "IssueAges")
    protected MinMaxInfoType issueAges;
    @XmlElement(name = "FaceAmounts")
    protected MinMaxInfoType faceAmounts;
    @XmlElement(name = "MinimumPremium")
    protected Boolean minimumPremium;
    @XmlElement(name = "Reentry")
    protected Boolean reentry;
    @XmlElement(name = "Conversion")
    protected Boolean conversion;
    @XmlElement(name = "Narratives")
    protected Boolean narratives;
    @XmlElement(name = "UnderwritingClasses")
    protected DispUWInfoType underwritingClasses;
    @XmlElement(name = "RiderInformation")
    protected DispRidersInfoType riderInformation;
    @XmlElement(name = "RetrieveStateApprovals")
    protected Boolean retrieveStateApprovals;

    /**
     * Gets the value of the displayName property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isDisplayName() {
        return displayName;
    }

    /**
     * Sets the value of the displayName property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setDisplayName(Boolean value) {
        this.displayName = value;
    }

    /**
     * Gets the value of the naicCertified property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isNAICCertified() {
        return naicCertified;
    }

    /**
     * Sets the value of the naicCertified property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setNAICCertified(Boolean value) {
        this.naicCertified = value;
    }

    /**
     * Gets the value of the rateCard property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isRateCard() {
        return rateCard;
    }

    /**
     * Sets the value of the rateCard property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setRateCard(Boolean value) {
        this.rateCard = value;
    }

    /**
     * Gets the value of the softwareVersion property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isSoftwareVersion() {
        return softwareVersion;
    }

    /**
     * Sets the value of the softwareVersion property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setSoftwareVersion(Boolean value) {
        this.softwareVersion = value;
    }

    /**
     * Gets the value of the policyFormNumber property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isPolicyFormNumber() {
        return policyFormNumber;
    }

    /**
     * Sets the value of the policyFormNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setPolicyFormNumber(Boolean value) {
        this.policyFormNumber = value;
    }

    /**
     * Gets the value of the ageNearestLast property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isAgeNearestLast() {
        return ageNearestLast;
    }

    /**
     * Sets the value of the ageNearestLast property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setAgeNearestLast(Boolean value) {
        this.ageNearestLast = value;
    }

    /**
     * Gets the value of the calculatedAge property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isCalculatedAge() {
        return calculatedAge;
    }

    /**
     * Sets the value of the calculatedAge property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setCalculatedAge(Boolean value) {
        this.calculatedAge = value;
    }

    /**
     * Gets the value of the modalFactors property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isModalFactors() {
        return modalFactors;
    }

    /**
     * Sets the value of the modalFactors property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setModalFactors(Boolean value) {
        this.modalFactors = value;
    }

    /**
     * Gets the value of the extraFees property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isExtraFees() {
        return extraFees;
    }

    /**
     * Sets the value of the extraFees property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setExtraFees(Boolean value) {
        this.extraFees = value;
    }

    /**
     * Gets the value of the yearsLevel property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isYearsLevel() {
        return yearsLevel;
    }

    /**
     * Sets the value of the yearsLevel property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setYearsLevel(Boolean value) {
        this.yearsLevel = value;
    }

    /**
     * Gets the value of the guaranteedPeriod property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isGuaranteedPeriod() {
        return guaranteedPeriod;
    }

    /**
     * Sets the value of the guaranteedPeriod property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setGuaranteedPeriod(Boolean value) {
        this.guaranteedPeriod = value;
    }

    /**
     * Gets the value of the maturityAge property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isMaturityAge() {
        return maturityAge;
    }

    /**
     * Sets the value of the maturityAge property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setMaturityAge(Boolean value) {
        this.maturityAge = value;
    }

    /**
     * Gets the value of the premiumDiscount property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isPremiumDiscount() {
        return premiumDiscount;
    }

    /**
     * Sets the value of the premiumDiscount property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setPremiumDiscount(Boolean value) {
        this.premiumDiscount = value;
    }

    /**
     * Gets the value of the issueAges property.
     * 
     * @return
     *     possible object is
     *     {@link MinMaxInfoType }
     *     
     */
    public MinMaxInfoType getIssueAges() {
        return issueAges;
    }

    /**
     * Sets the value of the issueAges property.
     * 
     * @param value
     *     allowed object is
     *     {@link MinMaxInfoType }
     *     
     */
    public void setIssueAges(MinMaxInfoType value) {
        this.issueAges = value;
    }

    /**
     * Gets the value of the faceAmounts property.
     * 
     * @return
     *     possible object is
     *     {@link MinMaxInfoType }
     *     
     */
    public MinMaxInfoType getFaceAmounts() {
        return faceAmounts;
    }

    /**
     * Sets the value of the faceAmounts property.
     * 
     * @param value
     *     allowed object is
     *     {@link MinMaxInfoType }
     *     
     */
    public void setFaceAmounts(MinMaxInfoType value) {
        this.faceAmounts = value;
    }

    /**
     * Gets the value of the minimumPremium property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isMinimumPremium() {
        return minimumPremium;
    }

    /**
     * Sets the value of the minimumPremium property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setMinimumPremium(Boolean value) {
        this.minimumPremium = value;
    }

    /**
     * Gets the value of the reentry property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isReentry() {
        return reentry;
    }

    /**
     * Sets the value of the reentry property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setReentry(Boolean value) {
        this.reentry = value;
    }

    /**
     * Gets the value of the conversion property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isConversion() {
        return conversion;
    }

    /**
     * Sets the value of the conversion property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setConversion(Boolean value) {
        this.conversion = value;
    }

    /**
     * Gets the value of the narratives property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isNarratives() {
        return narratives;
    }

    /**
     * Sets the value of the narratives property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setNarratives(Boolean value) {
        this.narratives = value;
    }

    /**
     * Gets the value of the underwritingClasses property.
     * 
     * @return
     *     possible object is
     *     {@link DispUWInfoType }
     *     
     */
    public DispUWInfoType getUnderwritingClasses() {
        return underwritingClasses;
    }

    /**
     * Sets the value of the underwritingClasses property.
     * 
     * @param value
     *     allowed object is
     *     {@link DispUWInfoType }
     *     
     */
    public void setUnderwritingClasses(DispUWInfoType value) {
        this.underwritingClasses = value;
    }

    /**
     * Gets the value of the riderInformation property.
     * 
     * @return
     *     possible object is
     *     {@link DispRidersInfoType }
     *     
     */
    public DispRidersInfoType getRiderInformation() {
        return riderInformation;
    }

    /**
     * Sets the value of the riderInformation property.
     * 
     * @param value
     *     allowed object is
     *     {@link DispRidersInfoType }
     *     
     */
    public void setRiderInformation(DispRidersInfoType value) {
        this.riderInformation = value;
    }

    /**
     * Gets the value of the retrieveStateApprovals property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isRetrieveStateApprovals() {
        return retrieveStateApprovals;
    }

    /**
     * Sets the value of the retrieveStateApprovals property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setRetrieveStateApprovals(Boolean value) {
        this.retrieveStateApprovals = value;
    }

}
