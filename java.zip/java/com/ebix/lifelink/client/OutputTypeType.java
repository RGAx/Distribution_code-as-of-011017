
package com.ebix.lifelink.client;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for OutputTypeType.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="OutputTypeType">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="XML"/>
 *     &lt;enumeration value="XML_RAW"/>
 *     &lt;enumeration value="XMLPDF"/>
 *     &lt;enumeration value="PDF"/>
 *     &lt;enumeration value="URL"/>
 *     &lt;enumeration value="EMF"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "OutputTypeType")
@XmlEnum
public enum OutputTypeType {

    XML,
    XML_RAW,
    XMLPDF,
    PDF,
    URL,
    EMF;

    public String value() {
        return name();
    }

    public static OutputTypeType fromValue(String v) {
        return valueOf(v);
    }

}
