
package com.ebix.lifelink.client;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for DisplayedInformationType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DisplayedInformationType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="CarrierName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="FullProductName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="StatesApproved" type="{urn:lifelink-schema}StateApprovalType" minOccurs="0"/>
 *         &lt;element name="ProductInformation" type="{urn:lifelink-schema}ProductInformationType" minOccurs="0"/>
 *         &lt;element name="PremiumInformation" type="{urn:lifelink-schema}PremiumInformationType" minOccurs="0"/>
 *         &lt;element name="InfoNotes" type="{urn:lifelink-schema}InfoNotesType" minOccurs="0"/>
 *         &lt;element name="DisplayName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DisplayedInformationType", propOrder = {
    "carrierName",
    "fullProductName",
    "statesApproved",
    "productInformation",
    "premiumInformation",
    "infoNotes",
    "displayName"
})
public class DisplayedInformationType {

    @XmlElement(name = "CarrierName")
    protected String carrierName;
    @XmlElement(name = "FullProductName")
    protected String fullProductName;
    @XmlElement(name = "StatesApproved")
    protected StateApprovalType statesApproved;
    @XmlElement(name = "ProductInformation")
    protected ProductInformationType productInformation;
    @XmlElement(name = "PremiumInformation")
    protected PremiumInformationType premiumInformation;
    @XmlElement(name = "InfoNotes")
    protected InfoNotesType infoNotes;
    @XmlElement(name = "DisplayName")
    protected String displayName;

    /**
     * Gets the value of the carrierName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCarrierName() {
        return carrierName;
    }

    /**
     * Sets the value of the carrierName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCarrierName(String value) {
        this.carrierName = value;
    }

    /**
     * Gets the value of the fullProductName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFullProductName() {
        return fullProductName;
    }

    /**
     * Sets the value of the fullProductName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFullProductName(String value) {
        this.fullProductName = value;
    }

    /**
     * Gets the value of the statesApproved property.
     * 
     * @return
     *     possible object is
     *     {@link StateApprovalType }
     *     
     */
    public StateApprovalType getStatesApproved() {
        return statesApproved;
    }

    /**
     * Sets the value of the statesApproved property.
     * 
     * @param value
     *     allowed object is
     *     {@link StateApprovalType }
     *     
     */
    public void setStatesApproved(StateApprovalType value) {
        this.statesApproved = value;
    }

    /**
     * Gets the value of the productInformation property.
     * 
     * @return
     *     possible object is
     *     {@link ProductInformationType }
     *     
     */
    public ProductInformationType getProductInformation() {
        return productInformation;
    }

    /**
     * Sets the value of the productInformation property.
     * 
     * @param value
     *     allowed object is
     *     {@link ProductInformationType }
     *     
     */
    public void setProductInformation(ProductInformationType value) {
        this.productInformation = value;
    }

    /**
     * Gets the value of the premiumInformation property.
     * 
     * @return
     *     possible object is
     *     {@link PremiumInformationType }
     *     
     */
    public PremiumInformationType getPremiumInformation() {
        return premiumInformation;
    }

    /**
     * Sets the value of the premiumInformation property.
     * 
     * @param value
     *     allowed object is
     *     {@link PremiumInformationType }
     *     
     */
    public void setPremiumInformation(PremiumInformationType value) {
        this.premiumInformation = value;
    }

    /**
     * Gets the value of the infoNotes property.
     * 
     * @return
     *     possible object is
     *     {@link InfoNotesType }
     *     
     */
    public InfoNotesType getInfoNotes() {
        return infoNotes;
    }

    /**
     * Sets the value of the infoNotes property.
     * 
     * @param value
     *     allowed object is
     *     {@link InfoNotesType }
     *     
     */
    public void setInfoNotes(InfoNotesType value) {
        this.infoNotes = value;
    }

    /**
     * Gets the value of the displayName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDisplayName() {
        return displayName;
    }

    /**
     * Sets the value of the displayName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDisplayName(String value) {
        this.displayName = value;
    }

}
