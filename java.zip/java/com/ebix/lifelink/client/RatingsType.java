
package com.ebix.lifelink.client;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for RatingsType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="RatingsType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="AMBest" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SandP" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Fitch" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Moodys" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Comdex" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "RatingsType", propOrder = {
    "amBest",
    "sandP",
    "fitch",
    "moodys",
    "comdex"
})
public class RatingsType {

    @XmlElement(name = "AMBest")
    protected String amBest;
    @XmlElement(name = "SandP")
    protected String sandP;
    @XmlElement(name = "Fitch")
    protected String fitch;
    @XmlElement(name = "Moodys")
    protected String moodys;
    @XmlElement(name = "Comdex")
    protected String comdex;

    /**
     * Gets the value of the amBest property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAMBest() {
        return amBest;
    }

    /**
     * Sets the value of the amBest property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAMBest(String value) {
        this.amBest = value;
    }

    /**
     * Gets the value of the sandP property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSandP() {
        return sandP;
    }

    /**
     * Sets the value of the sandP property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSandP(String value) {
        this.sandP = value;
    }

    /**
     * Gets the value of the fitch property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFitch() {
        return fitch;
    }

    /**
     * Sets the value of the fitch property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFitch(String value) {
        this.fitch = value;
    }

    /**
     * Gets the value of the moodys property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMoodys() {
        return moodys;
    }

    /**
     * Sets the value of the moodys property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMoodys(String value) {
        this.moodys = value;
    }

    /**
     * Gets the value of the comdex property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getComdex() {
        return comdex;
    }

    /**
     * Sets the value of the comdex property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setComdex(String value) {
        this.comdex = value;
    }

}
