
package com.ebix.lifelink.client;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for DispRiderInfoType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DispRiderInfoType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="IssueAges" type="{urn:lifelink-schema}MinMaxInfoType" minOccurs="0"/>
 *         &lt;element name="FaceAmounts" type="{urn:lifelink-schema}MinMaxInfoType" minOccurs="0"/>
 *         &lt;element name="MaturityAge" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="MaturityAgeInsured" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="Units" type="{urn:lifelink-schema}MinMaxValueInfoType" minOccurs="0"/>
 *       &lt;/sequence>
 *       &lt;attribute name="name" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="id" use="required" type="{http://www.w3.org/2001/XMLSchema}long" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DispRiderInfoType", propOrder = {
    "issueAges",
    "faceAmounts",
    "maturityAge",
    "maturityAgeInsured",
    "units"
})
public class DispRiderInfoType {

    @XmlElement(name = "IssueAges")
    protected MinMaxInfoType issueAges;
    @XmlElement(name = "FaceAmounts")
    protected MinMaxInfoType faceAmounts;
    @XmlElement(name = "MaturityAge")
    protected Boolean maturityAge;
    @XmlElement(name = "MaturityAgeInsured")
    protected Boolean maturityAgeInsured;
    @XmlElement(name = "Units")
    protected MinMaxValueInfoType units;
    @XmlAttribute(name = "name")
    protected String name;
    @XmlAttribute(name = "id", required = true)
    protected long id;

    /**
     * Gets the value of the issueAges property.
     * 
     * @return
     *     possible object is
     *     {@link MinMaxInfoType }
     *     
     */
    public MinMaxInfoType getIssueAges() {
        return issueAges;
    }

    /**
     * Sets the value of the issueAges property.
     * 
     * @param value
     *     allowed object is
     *     {@link MinMaxInfoType }
     *     
     */
    public void setIssueAges(MinMaxInfoType value) {
        this.issueAges = value;
    }

    /**
     * Gets the value of the faceAmounts property.
     * 
     * @return
     *     possible object is
     *     {@link MinMaxInfoType }
     *     
     */
    public MinMaxInfoType getFaceAmounts() {
        return faceAmounts;
    }

    /**
     * Sets the value of the faceAmounts property.
     * 
     * @param value
     *     allowed object is
     *     {@link MinMaxInfoType }
     *     
     */
    public void setFaceAmounts(MinMaxInfoType value) {
        this.faceAmounts = value;
    }

    /**
     * Gets the value of the maturityAge property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isMaturityAge() {
        return maturityAge;
    }

    /**
     * Sets the value of the maturityAge property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setMaturityAge(Boolean value) {
        this.maturityAge = value;
    }

    /**
     * Gets the value of the maturityAgeInsured property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isMaturityAgeInsured() {
        return maturityAgeInsured;
    }

    /**
     * Sets the value of the maturityAgeInsured property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setMaturityAgeInsured(Boolean value) {
        this.maturityAgeInsured = value;
    }

    /**
     * Gets the value of the units property.
     * 
     * @return
     *     possible object is
     *     {@link MinMaxValueInfoType }
     *     
     */
    public MinMaxValueInfoType getUnits() {
        return units;
    }

    /**
     * Sets the value of the units property.
     * 
     * @param value
     *     allowed object is
     *     {@link MinMaxValueInfoType }
     *     
     */
    public void setUnits(MinMaxValueInfoType value) {
        this.units = value;
    }

    /**
     * Gets the value of the name property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the value of the name property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setName(String value) {
        this.name = value;
    }

    /**
     * Gets the value of the id property.
     * 
     */
    public long getId() {
        return id;
    }

    /**
     * Sets the value of the id property.
     * 
     */
    public void setId(long value) {
        this.id = value;
    }

}
