
package com.ebix.lifelink.client;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for UnderwritingClassType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="UnderwritingClassType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="ClassIDRan" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="ClassNameRan" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ClassList" type="{urn:lifelink-schema}ClassListType" minOccurs="0"/>
 *         &lt;element name="TableRatings" type="{urn:lifelink-schema}TableRatingsType" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "UnderwritingClassType", propOrder = {
    "classIDRan",
    "classNameRan",
    "classList",
    "tableRatings"
})
public class UnderwritingClassType {

    @XmlElement(name = "ClassIDRan")
    protected Integer classIDRan;
    @XmlElement(name = "ClassNameRan")
    protected String classNameRan;
    @XmlElement(name = "ClassList")
    protected ClassListType classList;
    @XmlElement(name = "TableRatings")
    protected TableRatingsType tableRatings;

    /**
     * Gets the value of the classIDRan property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getClassIDRan() {
        return classIDRan;
    }

    /**
     * Sets the value of the classIDRan property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setClassIDRan(Integer value) {
        this.classIDRan = value;
    }

    /**
     * Gets the value of the classNameRan property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getClassNameRan() {
        return classNameRan;
    }

    /**
     * Sets the value of the classNameRan property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setClassNameRan(String value) {
        this.classNameRan = value;
    }

    /**
     * Gets the value of the classList property.
     * 
     * @return
     *     possible object is
     *     {@link ClassListType }
     *     
     */
    public ClassListType getClassList() {
        return classList;
    }

    /**
     * Sets the value of the classList property.
     * 
     * @param value
     *     allowed object is
     *     {@link ClassListType }
     *     
     */
    public void setClassList(ClassListType value) {
        this.classList = value;
    }

    /**
     * Gets the value of the tableRatings property.
     * 
     * @return
     *     possible object is
     *     {@link TableRatingsType }
     *     
     */
    public TableRatingsType getTableRatings() {
        return tableRatings;
    }

    /**
     * Sets the value of the tableRatings property.
     * 
     * @param value
     *     allowed object is
     *     {@link TableRatingsType }
     *     
     */
    public void setTableRatings(TableRatingsType value) {
        this.tableRatings = value;
    }

}
