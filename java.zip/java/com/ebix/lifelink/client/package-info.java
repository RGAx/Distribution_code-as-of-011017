@javax.xml.bind.annotation.XmlSchema(namespace = "urn:lifelink-schema", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.ebix.lifelink.client;
