
package com.ebix.lifelink.client;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for GenericDiscountType.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="GenericDiscountType">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="NO"/>
 *     &lt;enumeration value="DISC"/>
 *     &lt;enumeration value="DIS5"/>
 *     &lt;enumeration value="DIS10"/>
 *     &lt;enumeration value="DIS15"/>
 *     &lt;enumeration value="DIS20"/>
 *     &lt;enumeration value="D5NB"/>
 *     &lt;enumeration value="D10NB"/>
 *     &lt;enumeration value="D15NB"/>
 *     &lt;enumeration value="D20NB"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "GenericDiscountType")
@XmlEnum
public enum GenericDiscountType {

    NO("NO"),
    DISC("DISC"),
    @XmlEnumValue("DIS5")
    DIS_5("DIS5"),
    @XmlEnumValue("DIS10")
    DIS_10("DIS10"),
    @XmlEnumValue("DIS15")
    DIS_15("DIS15"),
    @XmlEnumValue("DIS20")
    DIS_20("DIS20"),
    @XmlEnumValue("D5NB")
    D_5_NB("D5NB"),
    @XmlEnumValue("D10NB")
    D_10_NB("D10NB"),
    @XmlEnumValue("D15NB")
    D_15_NB("D15NB"),
    @XmlEnumValue("D20NB")
    D_20_NB("D20NB");
    private final String value;

    GenericDiscountType(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static GenericDiscountType fromValue(String v) {
        for (GenericDiscountType c: GenericDiscountType.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
