
package com.ebix.lifelink.client;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.ebix.lifelink.client package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _VitalForms_QNAME = new QName("urn:lifelink-schema", "VitalForms");
    private final static QName _WinFlex_QNAME = new QName("urn:lifelink-schema", "WinFlex");
    private final static QName _LifeLink_QNAME = new QName("urn:lifelink-schema", "LifeLink");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.ebix.lifelink.client
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link LlXMLResponse }
     * 
     */
    public LlXMLResponse createLlXMLResponse() {
        return new LlXMLResponse();
    }

    /**
     * Create an instance of {@link LlxmlInfoResponse }
     * 
     */
    public LlxmlInfoResponse createLlxmlInfoResponse() {
        return new LlxmlInfoResponse();
    }

    /**
     * Create an instance of {@link LLXMLNoValidationResponse }
     * 
     */
    public LLXMLNoValidationResponse createLLXMLNoValidationResponse() {
        return new LLXMLNoValidationResponse();
    }

    /**
     * Create an instance of {@link AddMisclaneousNodesResponse }
     * 
     */
    public AddMisclaneousNodesResponse createAddMisclaneousNodesResponse() {
        return new AddMisclaneousNodesResponse();
    }

    /**
     * Create an instance of {@link VitalFormsType }
     * 
     */
    public VitalFormsType createVitalFormsType() {
        return new VitalFormsType();
    }

    /**
     * Create an instance of {@link GetSessionIDResponse }
     * 
     */
    public GetSessionIDResponse createGetSessionIDResponse() {
        return new GetSessionIDResponse();
    }

    /**
     * Create an instance of {@link LLXMLNoValidation }
     * 
     */
    public LLXMLNoValidation createLLXMLNoValidation() {
        return new LLXMLNoValidation();
    }

    /**
     * Create an instance of {@link LifeLinkType }
     * 
     */
    public LifeLinkType createLifeLinkType() {
        return new LifeLinkType();
    }

    /**
     * Create an instance of {@link LlXMLResponse.LlXMLResult }
     * 
     */
    public LlXMLResponse.LlXMLResult createLlXMLResponseLlXMLResult() {
        return new LlXMLResponse.LlXMLResult();
    }

    /**
     * Create an instance of {@link AddMisclaneousNodes }
     * 
     */
    public AddMisclaneousNodes createAddMisclaneousNodes() {
        return new AddMisclaneousNodes();
    }

    /**
     * Create an instance of {@link WinFlexType }
     * 
     */
    public WinFlexType createWinFlexType() {
        return new WinFlexType();
    }

    /**
     * Create an instance of {@link LlxmlInfoResponse.LlxmlInfoResult }
     * 
     */
    public LlxmlInfoResponse.LlxmlInfoResult createLlxmlInfoResponseLlxmlInfoResult() {
        return new LlxmlInfoResponse.LlxmlInfoResult();
    }

    /**
     * Create an instance of {@link LlxmlInfo }
     * 
     */
    public LlxmlInfo createLlxmlInfo() {
        return new LlxmlInfo();
    }

    /**
     * Create an instance of {@link GetSessionID }
     * 
     */
    public GetSessionID createGetSessionID() {
        return new GetSessionID();
    }

    /**
     * Create an instance of {@link LLXMLNoValidationResponse.LLXMLNoValidationResult }
     * 
     */
    public LLXMLNoValidationResponse.LLXMLNoValidationResult createLLXMLNoValidationResponseLLXMLNoValidationResult() {
        return new LLXMLNoValidationResponse.LLXMLNoValidationResult();
    }

    /**
     * Create an instance of {@link AddMisclaneousNodesResponse.AddMisclaneousNodesResult }
     * 
     */
    public AddMisclaneousNodesResponse.AddMisclaneousNodesResult createAddMisclaneousNodesResponseAddMisclaneousNodesResult() {
        return new AddMisclaneousNodesResponse.AddMisclaneousNodesResult();
    }

    /**
     * Create an instance of {@link LlXML }
     * 
     */
    public LlXML createLlXML() {
        return new LlXML();
    }

    /**
     * Create an instance of {@link ErrorType }
     * 
     */
    public ErrorType createErrorType() {
        return new ErrorType();
    }

    /**
     * Create an instance of {@link FormsTypeType }
     * 
     */
    public FormsTypeType createFormsTypeType() {
        return new FormsTypeType();
    }

    /**
     * Create an instance of {@link RatingsType }
     * 
     */
    public RatingsType createRatingsType() {
        return new RatingsType();
    }

    /**
     * Create an instance of {@link StateApprovalType }
     * 
     */
    public StateApprovalType createStateApprovalType() {
        return new StateApprovalType();
    }

    /**
     * Create an instance of {@link ExtraFeesType }
     * 
     */
    public ExtraFeesType createExtraFeesType() {
        return new ExtraFeesType();
    }

    /**
     * Create an instance of {@link ProdRiderType }
     * 
     */
    public ProdRiderType createProdRiderType() {
        return new ProdRiderType();
    }

    /**
     * Create an instance of {@link DetermiatorAnswerXMLType }
     * 
     */
    public DetermiatorAnswerXMLType createDetermiatorAnswerXMLType() {
        return new DetermiatorAnswerXMLType();
    }

    /**
     * Create an instance of {@link ProductOptionsType }
     * 
     */
    public ProductOptionsType createProductOptionsType() {
        return new ProductOptionsType();
    }

    /**
     * Create an instance of {@link ToolType }
     * 
     */
    public ToolType createToolType() {
        return new ToolType();
    }

    /**
     * Create an instance of {@link FormsType }
     * 
     */
    public FormsType createFormsType() {
        return new FormsType();
    }

    /**
     * Create an instance of {@link VitalTermNetType }
     * 
     */
    public VitalTermNetType createVitalTermNetType() {
        return new VitalTermNetType();
    }

    /**
     * Create an instance of {@link MinMaxType }
     * 
     */
    public MinMaxType createMinMaxType() {
        return new MinMaxType();
    }

    /**
     * Create an instance of {@link RemovedProdType }
     * 
     */
    public RemovedProdType createRemovedProdType() {
        return new RemovedProdType();
    }

    /**
     * Create an instance of {@link VitalLTCType }
     * 
     */
    public VitalLTCType createVitalLTCType() {
        return new VitalLTCType();
    }

    /**
     * Create an instance of {@link ReportType }
     * 
     */
    public ReportType createReportType() {
        return new ReportType();
    }

    /**
     * Create an instance of {@link ClassDeterminationType }
     * 
     */
    public ClassDeterminationType createClassDeterminationType() {
        return new ClassDeterminationType();
    }

    /**
     * Create an instance of {@link RemovedInformationType }
     * 
     */
    public RemovedInformationType createRemovedInformationType() {
        return new RemovedInformationType();
    }

    /**
     * Create an instance of {@link MinMaxValueInfoType }
     * 
     */
    public MinMaxValueInfoType createMinMaxValueInfoType() {
        return new MinMaxValueInfoType();
    }

    /**
     * Create an instance of {@link DetControlsType }
     * 
     */
    public DetControlsType createDetControlsType() {
        return new DetControlsType();
    }

    /**
     * Create an instance of {@link VSCompaniesType }
     * 
     */
    public VSCompaniesType createVSCompaniesType() {
        return new VSCompaniesType();
    }

    /**
     * Create an instance of {@link ReturnType }
     * 
     */
    public ReturnType createReturnType() {
        return new ReturnType();
    }

    /**
     * Create an instance of {@link ReasonsType }
     * 
     */
    public ReasonsType createReasonsType() {
        return new ReasonsType();
    }

    /**
     * Create an instance of {@link NAICType }
     * 
     */
    public NAICType createNAICType() {
        return new NAICType();
    }

    /**
     * Create an instance of {@link CompanyInfoType }
     * 
     */
    public CompanyInfoType createCompanyInfoType() {
        return new CompanyInfoType();
    }

    /**
     * Create an instance of {@link VSCompanyType }
     * 
     */
    public VSCompanyType createVSCompanyType() {
        return new VSCompanyType();
    }

    /**
     * Create an instance of {@link RequestType }
     * 
     */
    public RequestType createRequestType() {
        return new RequestType();
    }

    /**
     * Create an instance of {@link ReturnButtonType }
     * 
     */
    public ReturnButtonType createReturnButtonType() {
        return new ReturnButtonType();
    }

    /**
     * Create an instance of {@link VLTCAgeType }
     * 
     */
    public VLTCAgeType createVLTCAgeType() {
        return new VLTCAgeType();
    }

    /**
     * Create an instance of {@link RiderRequestInfoType }
     * 
     */
    public RiderRequestInfoType createRiderRequestInfoType() {
        return new RiderRequestInfoType();
    }

    /**
     * Create an instance of {@link ClassListType }
     * 
     */
    public ClassListType createClassListType() {
        return new ClassListType();
    }

    /**
     * Create an instance of {@link NoteType }
     * 
     */
    public NoteType createNoteType() {
        return new NoteType();
    }

    /**
     * Create an instance of {@link VSReportsType }
     * 
     */
    public VSReportsType createVSReportsType() {
        return new VSReportsType();
    }

    /**
     * Create an instance of {@link RidersType }
     * 
     */
    public RidersType createRidersType() {
        return new RidersType();
    }

    /**
     * Create an instance of {@link RiderPremiumsType }
     * 
     */
    public RiderPremiumsType createRiderPremiumsType() {
        return new RiderPremiumsType();
    }

    /**
     * Create an instance of {@link DetAnswersType }
     * 
     */
    public DetAnswersType createDetAnswersType() {
        return new DetAnswersType();
    }

    /**
     * Create an instance of {@link ChildAgeType }
     * 
     */
    public ChildAgeType createChildAgeType() {
        return new ChildAgeType();
    }

    /**
     * Create an instance of {@link VTFilterType }
     * 
     */
    public VTFilterType createVTFilterType() {
        return new VTFilterType();
    }

    /**
     * Create an instance of {@link VTProductType }
     * 
     */
    public VTProductType createVTProductType() {
        return new VTProductType();
    }

    /**
     * Create an instance of {@link SearchType }
     * 
     */
    public SearchType createSearchType() {
        return new SearchType();
    }

    /**
     * Create an instance of {@link ButtonType }
     * 
     */
    public ButtonType createButtonType() {
        return new ButtonType();
    }

    /**
     * Create an instance of {@link RanTBLRateInfoType }
     * 
     */
    public RanTBLRateInfoType createRanTBLRateInfoType() {
        return new RanTBLRateInfoType();
    }

    /**
     * Create an instance of {@link ProductRequestType }
     * 
     */
    public ProductRequestType createProductRequestType() {
        return new ProductRequestType();
    }

    /**
     * Create an instance of {@link VSReportType }
     * 
     */
    public VSReportType createVSReportType() {
        return new VSReportType();
    }

    /**
     * Create an instance of {@link RiderInfoType }
     * 
     */
    public RiderInfoType createRiderInfoType() {
        return new RiderInfoType();
    }

    /**
     * Create an instance of {@link DispUWInfoType }
     * 
     */
    public DispUWInfoType createDispUWInfoType() {
        return new DispUWInfoType();
    }

    /**
     * Create an instance of {@link LLType }
     * 
     */
    public LLType createLLType() {
        return new LLType();
    }

    /**
     * Create an instance of {@link MisclaneousType }
     * 
     */
    public MisclaneousType createMisclaneousType() {
        return new MisclaneousType();
    }

    /**
     * Create an instance of {@link UnderwritingClassType }
     * 
     */
    public UnderwritingClassType createUnderwritingClassType() {
        return new UnderwritingClassType();
    }

    /**
     * Create an instance of {@link ListType }
     * 
     */
    public ListType createListType() {
        return new ListType();
    }

    /**
     * Create an instance of {@link ProductScenariosType }
     * 
     */
    public ProductScenariosType createProductScenariosType() {
        return new ProductScenariosType();
    }

    /**
     * Create an instance of {@link ModalExtraType }
     * 
     */
    public ModalExtraType createModalExtraType() {
        return new ModalExtraType();
    }

    /**
     * Create an instance of {@link DispRidersInfoType }
     * 
     */
    public DispRidersInfoType createDispRidersInfoType() {
        return new DispRidersInfoType();
    }

    /**
     * Create an instance of {@link DeterminatorOutputType }
     * 
     */
    public DeterminatorOutputType createDeterminatorOutputType() {
        return new DeterminatorOutputType();
    }

    /**
     * Create an instance of {@link RequestedProductsType }
     * 
     */
    public RequestedProductsType createRequestedProductsType() {
        return new RequestedProductsType();
    }

    /**
     * Create an instance of {@link VSOutputType }
     * 
     */
    public VSOutputType createVSOutputType() {
        return new VSOutputType();
    }

    /**
     * Create an instance of {@link AddressType }
     * 
     */
    public AddressType createAddressType() {
        return new AddressType();
    }

    /**
     * Create an instance of {@link ProdType }
     * 
     */
    public ProdType createProdType() {
        return new ProdType();
    }

    /**
     * Create an instance of {@link DispRiderInfoType }
     * 
     */
    public DispRiderInfoType createDispRiderInfoType() {
        return new DispRiderInfoType();
    }

    /**
     * Create an instance of {@link TableRatingsType }
     * 
     */
    public TableRatingsType createTableRatingsType() {
        return new TableRatingsType();
    }

    /**
     * Create an instance of {@link SpouseType }
     * 
     */
    public SpouseType createSpouseType() {
        return new SpouseType();
    }

    /**
     * Create an instance of {@link PremiumDiscountType }
     * 
     */
    public PremiumDiscountType createPremiumDiscountType() {
        return new PremiumDiscountType();
    }

    /**
     * Create an instance of {@link VTPremiumType }
     * 
     */
    public VTPremiumType createVTPremiumType() {
        return new VTPremiumType();
    }

    /**
     * Create an instance of {@link ModalValueType }
     * 
     */
    public ModalValueType createModalValueType() {
        return new ModalValueType();
    }

    /**
     * Create an instance of {@link FactorType }
     * 
     */
    public FactorType createFactorType() {
        return new FactorType();
    }

    /**
     * Create an instance of {@link NarrativesType }
     * 
     */
    public NarrativesType createNarrativesType() {
        return new NarrativesType();
    }

    /**
     * Create an instance of {@link PremiumsType }
     * 
     */
    public PremiumsType createPremiumsType() {
        return new PremiumsType();
    }

    /**
     * Create an instance of {@link VTAvailRidersType }
     * 
     */
    public VTAvailRidersType createVTAvailRidersType() {
        return new VTAvailRidersType();
    }

    /**
     * Create an instance of {@link AgentType }
     * 
     */
    public AgentType createAgentType() {
        return new AgentType();
    }

    /**
     * Create an instance of {@link FirstYearModalsType }
     * 
     */
    public FirstYearModalsType createFirstYearModalsType() {
        return new FirstYearModalsType();
    }

    /**
     * Create an instance of {@link RatingClassAvailType }
     * 
     */
    public RatingClassAvailType createRatingClassAvailType() {
        return new RatingClassAvailType();
    }

    /**
     * Create an instance of {@link RemovedProductsType }
     * 
     */
    public RemovedProductsType createRemovedProductsType() {
        return new RemovedProductsType();
    }

    /**
     * Create an instance of {@link ProdScenarioType }
     * 
     */
    public ProdScenarioType createProdScenarioType() {
        return new ProdScenarioType();
    }

    /**
     * Create an instance of {@link ButtonsType }
     * 
     */
    public ButtonsType createButtonsType() {
        return new ButtonsType();
    }

    /**
     * Create an instance of {@link ApplicantType }
     * 
     */
    public ApplicantType createApplicantType() {
        return new ApplicantType();
    }

    /**
     * Create an instance of {@link ProductListsType }
     * 
     */
    public ProductListsType createProductListsType() {
        return new ProductListsType();
    }

    /**
     * Create an instance of {@link FiltersType }
     * 
     */
    public FiltersType createFiltersType() {
        return new FiltersType();
    }

    /**
     * Create an instance of {@link PDFFileTypeType }
     * 
     */
    public PDFFileTypeType createPDFFileTypeType() {
        return new PDFFileTypeType();
    }

    /**
     * Create an instance of {@link ConceptType }
     * 
     */
    public ConceptType createConceptType() {
        return new ConceptType();
    }

    /**
     * Create an instance of {@link DisplayedInformationType }
     * 
     */
    public DisplayedInformationType createDisplayedInformationType() {
        return new DisplayedInformationType();
    }

    /**
     * Create an instance of {@link OutputType }
     * 
     */
    public OutputType createOutputType() {
        return new OutputType();
    }

    /**
     * Create an instance of {@link ReportsType }
     * 
     */
    public ReportsType createReportsType() {
        return new ReportsType();
    }

    /**
     * Create an instance of {@link VitalSignsType }
     * 
     */
    public VitalSignsType createVitalSignsType() {
        return new VitalSignsType();
    }

    /**
     * Create an instance of {@link FilterDetailType }
     * 
     */
    public FilterDetailType createFilterDetailType() {
        return new FilterDetailType();
    }

    /**
     * Create an instance of {@link UserInformationType }
     * 
     */
    public UserInformationType createUserInformationType() {
        return new UserInformationType();
    }

    /**
     * Create an instance of {@link ScenarioType }
     * 
     */
    public ScenarioType createScenarioType() {
        return new ScenarioType();
    }

    /**
     * Create an instance of {@link ProductsType }
     * 
     */
    public ProductsType createProductsType() {
        return new ProductsType();
    }

    /**
     * Create an instance of {@link ModalFactorType }
     * 
     */
    public ModalFactorType createModalFactorType() {
        return new ModalFactorType();
    }

    /**
     * Create an instance of {@link YearValueType }
     * 
     */
    public YearValueType createYearValueType() {
        return new YearValueType();
    }

    /**
     * Create an instance of {@link ProductInformationType }
     * 
     */
    public ProductInformationType createProductInformationType() {
        return new ProductInformationType();
    }

    /**
     * Create an instance of {@link CompanyType }
     * 
     */
    public CompanyType createCompanyType() {
        return new CompanyType();
    }

    /**
     * Create an instance of {@link TextType }
     * 
     */
    public TextType createTextType() {
        return new TextType();
    }

    /**
     * Create an instance of {@link AltClassType }
     * 
     */
    public AltClassType createAltClassType() {
        return new AltClassType();
    }

    /**
     * Create an instance of {@link VTProductOptionsType }
     * 
     */
    public VTProductOptionsType createVTProductOptionsType() {
        return new VTProductOptionsType();
    }

    /**
     * Create an instance of {@link ScenariosType }
     * 
     */
    public ScenariosType createScenariosType() {
        return new ScenariosType();
    }

    /**
     * Create an instance of {@link ProductType }
     * 
     */
    public ProductType createProductType() {
        return new ProductType();
    }

    /**
     * Create an instance of {@link OptionType }
     * 
     */
    public OptionType createOptionType() {
        return new OptionType();
    }

    /**
     * Create an instance of {@link FilterDetailsType }
     * 
     */
    public FilterDetailsType createFilterDetailsType() {
        return new FilterDetailsType();
    }

    /**
     * Create an instance of {@link UWClassInfoType }
     * 
     */
    public UWClassInfoType createUWClassInfoType() {
        return new UWClassInfoType();
    }

    /**
     * Create an instance of {@link PremiumInformationType }
     * 
     */
    public PremiumInformationType createPremiumInformationType() {
        return new PremiumInformationType();
    }

    /**
     * Create an instance of {@link QuotesType }
     * 
     */
    public QuotesType createQuotesType() {
        return new QuotesType();
    }

    /**
     * Create an instance of {@link MinMaxValueType }
     * 
     */
    public MinMaxValueType createMinMaxValueType() {
        return new MinMaxValueType();
    }

    /**
     * Create an instance of {@link BenAmtType }
     * 
     */
    public BenAmtType createBenAmtType() {
        return new BenAmtType();
    }

    /**
     * Create an instance of {@link ClientType }
     * 
     */
    public ClientType createClientType() {
        return new ClientType();
    }

    /**
     * Create an instance of {@link DetQuestionType }
     * 
     */
    public DetQuestionType createDetQuestionType() {
        return new DetQuestionType();
    }

    /**
     * Create an instance of {@link RiderPremType }
     * 
     */
    public RiderPremType createRiderPremType() {
        return new RiderPremType();
    }

    /**
     * Create an instance of {@link MinMaxInfoType }
     * 
     */
    public MinMaxInfoType createMinMaxInfoType() {
        return new MinMaxInfoType();
    }

    /**
     * Create an instance of {@link InfoNotesType }
     * 
     */
    public InfoNotesType createInfoNotesType() {
        return new InfoNotesType();
    }

    /**
     * Create an instance of {@link MinType }
     * 
     */
    public MinType createMinType() {
        return new MinType();
    }

    /**
     * Create an instance of {@link RatingsListType }
     * 
     */
    public RatingsListType createRatingsListType() {
        return new RatingsListType();
    }

    /**
     * Create an instance of {@link QuoteType }
     * 
     */
    public QuoteType createQuoteType() {
        return new QuoteType();
    }

    /**
     * Create an instance of {@link FlatExtrasType }
     * 
     */
    public FlatExtrasType createFlatExtrasType() {
        return new FlatExtrasType();
    }

    /**
     * Create an instance of {@link ValueTypeAttributeType }
     * 
     */
    public ValueTypeAttributeType createValueTypeAttributeType() {
        return new ValueTypeAttributeType();
    }

    /**
     * Create an instance of {@link BaseQuoteType }
     * 
     */
    public BaseQuoteType createBaseQuoteType() {
        return new BaseQuoteType();
    }

    /**
     * Create an instance of {@link RequestedProductInfoType }
     * 
     */
    public RequestedProductInfoType createRequestedProductInfoType() {
        return new RequestedProductInfoType();
    }

    /**
     * Create an instance of {@link CalcYearsType }
     * 
     */
    public CalcYearsType createCalcYearsType() {
        return new CalcYearsType();
    }

    /**
     * Create an instance of {@link RiderType }
     * 
     */
    public RiderType createRiderType() {
        return new RiderType();
    }

    /**
     * Create an instance of {@link PDFFileType }
     * 
     */
    public PDFFileType createPDFFileType() {
        return new PDFFileType();
    }

    /**
     * Create an instance of {@link WFProductType }
     * 
     */
    public WFProductType createWFProductType() {
        return new WFProductType();
    }

    /**
     * Create an instance of {@link FilteringType }
     * 
     */
    public FilteringType createFilteringType() {
        return new FilteringType();
    }

    /**
     * Create an instance of {@link ClassType }
     * 
     */
    public ClassType createClassType() {
        return new ClassType();
    }

    /**
     * Create an instance of {@link MiscNodeType }
     * 
     */
    public MiscNodeType createMiscNodeType() {
        return new MiscNodeType();
    }

    /**
     * Create an instance of {@link SortType }
     * 
     */
    public SortType createSortType() {
        return new SortType();
    }

    /**
     * Create an instance of {@link SortingType }
     * 
     */
    public SortingType createSortingType() {
        return new SortingType();
    }

    /**
     * Create an instance of {@link DetProductType }
     * 
     */
    public DetProductType createDetProductType() {
        return new DetProductType();
    }

    /**
     * Create an instance of {@link VitalFormsType.LOB }
     * 
     */
    public VitalFormsType.LOB createVitalFormsTypeLOB() {
        return new VitalFormsType.LOB();
    }

    /**
     * Create an instance of {@link VitalFormsType.Carrier }
     * 
     */
    public VitalFormsType.Carrier createVitalFormsTypeCarrier() {
        return new VitalFormsType.Carrier();
    }

    /**
     * Create an instance of {@link VitalFormsType.Product }
     * 
     */
    public VitalFormsType.Product createVitalFormsTypeProduct() {
        return new VitalFormsType.Product();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link VitalFormsType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:lifelink-schema", name = "VitalForms")
    public JAXBElement<VitalFormsType> createVitalForms(VitalFormsType value) {
        return new JAXBElement<VitalFormsType>(_VitalForms_QNAME, VitalFormsType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link WinFlexType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:lifelink-schema", name = "WinFlex")
    public JAXBElement<WinFlexType> createWinFlex(WinFlexType value) {
        return new JAXBElement<WinFlexType>(_WinFlex_QNAME, WinFlexType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link LifeLinkType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:lifelink-schema", name = "LifeLink")
    public JAXBElement<LifeLinkType> createLifeLink(LifeLinkType value) {
        return new JAXBElement<LifeLinkType>(_LifeLink_QNAME, LifeLinkType.class, null, value);
    }

}
