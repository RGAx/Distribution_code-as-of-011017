
package com.ebix.lifelink.client;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ProductOptionsType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ProductOptionsType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="BenAmt" type="{urn:lifelink-schema}BenAmtType" minOccurs="0"/>
 *         &lt;element name="PM" type="{urn:lifelink-schema}GenericPaymentModeType" minOccurs="0"/>
 *         &lt;element name="TQ" type="{urn:lifelink-schema}GenericTaxQualifiedType" minOccurs="0"/>
 *         &lt;element name="CL" type="{urn:lifelink-schema}GenericCoverageLevelType" minOccurs="0"/>
 *         &lt;element name="BP" type="{urn:lifelink-schema}GenericBenefitPeriodType" minOccurs="0"/>
 *         &lt;element name="IP" type="{urn:lifelink-schema}GenericInflationProtectionType" minOccurs="0"/>
 *         &lt;element name="EP" type="{urn:lifelink-schema}GenericEliminationPeriodType" minOccurs="0"/>
 *         &lt;element name="RC" type="{urn:lifelink-schema}GenericRateClassType" minOccurs="0"/>
 *         &lt;element name="JRC" type="{urn:lifelink-schema}GenericRateClassType" minOccurs="0"/>
 *         &lt;element name="JP" type="{urn:lifelink-schema}GenericJointPolicyType" minOccurs="0"/>
 *         &lt;element name="ALTC" type="{urn:lifelink-schema}GenericAlternateCareType" minOccurs="0"/>
 *         &lt;element name="DISC" type="{urn:lifelink-schema}GenericDiscountType" minOccurs="0"/>
 *         &lt;element name="PO" type="{urn:lifelink-schema}GenericPaymentOptionType" minOccurs="0"/>
 *         &lt;element name="WHC" type="{urn:lifelink-schema}GenericWeeklyHomeCareType" minOccurs="0"/>
 *         &lt;element name="WOP" type="{urn:lifelink-schema}GenericWaiverOfPremiumType" minOccurs="0"/>
 *         &lt;element name="SHAREDBEN" type="{urn:lifelink-schema}GenericSharedBenefitType" minOccurs="0"/>
 *         &lt;element name="ROP" type="{urn:lifelink-schema}GenericReturnOfPremiumType" minOccurs="0"/>
 *         &lt;element name="ROB" type="{urn:lifelink-schema}GenericRestorationOfBenefitsType" minOccurs="0"/>
 *         &lt;element name="INDEM" type="{urn:lifelink-schema}GenericIndemnityType" minOccurs="0"/>
 *         &lt;element name="PP" type="{urn:lifelink-schema}GenericPaymentPlanType" minOccurs="0"/>
 *         &lt;element name="NF" type="{urn:lifelink-schema}GenericNonForfeitureType" minOccurs="0"/>
 *         &lt;element name="HHCEP" type="{urn:lifelink-schema}GenericHHCEPType" minOccurs="0"/>
 *         &lt;element name="HWEP" type="{urn:lifelink-schema}GenericHWEPType" minOccurs="0"/>
 *         &lt;element name="EEP" type="{urn:lifelink-schema}GenericEnhancedEliminationPeriodType" minOccurs="0"/>
 *         &lt;element name="EP1X" type="{urn:lifelink-schema}GenericEP1XType" minOccurs="0"/>
 *         &lt;element name="RATG" type="{urn:lifelink-schema}GenericRATGType" minOccurs="0"/>
 *         &lt;element name="INTL" type="{urn:lifelink-schema}GenericINTLType" minOccurs="0"/>
 *         &lt;element name="UPG" type="{urn:lifelink-schema}GenericUPGType" minOccurs="0"/>
 *         &lt;element name="NFCT" type="{urn:lifelink-schema}GenericNFCTType" minOccurs="0"/>
 *         &lt;element name="FSA" type="{urn:lifelink-schema}GenericFSAType" minOccurs="0"/>
 *         &lt;element name="CC" type="{urn:lifelink-schema}GenericCCType" minOccurs="0"/>
 *         &lt;element name="CPLN" type="{urn:lifelink-schema}GenericCPLNType" minOccurs="0"/>
 *         &lt;element name="ASTL" type="{urn:lifelink-schema}GenericASTLType" minOccurs="0"/>
 *         &lt;element name="CGTR" type="{urn:lifelink-schema}GenericCGTRType" minOccurs="0"/>
 *         &lt;element name="MEDE" type="{urn:lifelink-schema}GenericMEDEType" minOccurs="0"/>
 *         &lt;element name="INFC" type="{urn:lifelink-schema}GenericINFCType" minOccurs="0"/>
 *         &lt;element name="HMSV" type="{urn:lifelink-schema}GenericHMSVType" minOccurs="0"/>
 *         &lt;element name="HOSC" type="{urn:lifelink-schema}GenericHOSCType" minOccurs="0"/>
 *         &lt;element name="BEDR" type="{urn:lifelink-schema}GenericBEDRType" minOccurs="0"/>
 *         &lt;element name="ICS" type="{urn:lifelink-schema}GenericICSType" minOccurs="0"/>
 *         &lt;element name="PART" type="{urn:lifelink-schema}GenericPARTType" minOccurs="0"/>
 *         &lt;element name="HMOD" type="{urn:lifelink-schema}GenericHMODType" minOccurs="0"/>
 *         &lt;element name="NPRI" type="{urn:lifelink-schema}GenericNPRIType" minOccurs="0"/>
 *         &lt;element name="FPAY" type="{urn:lifelink-schema}GenericFPAYType" minOccurs="0"/>
 *         &lt;element name="ProductList" type="{urn:lifelink-schema}ProductListType"/>
 *         &lt;element name="Products" type="{urn:lifelink-schema}RequestedProductsType" minOccurs="0"/>
 *         &lt;element name="Filters" type="{urn:lifelink-schema}FiltersType" minOccurs="0"/>
 *         &lt;element name="IncludeFiltersWithQuotes" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="IncludeRemovedProducts" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="EnableRidersNoFiltering" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="MinFilterMatches" type="{http://www.w3.org/2001/XMLSchema}integer" minOccurs="0"/>
 *         &lt;element name="SortBy" type="{urn:lifelink-schema}QuoteSortBy" minOccurs="0"/>
 *         &lt;element name="SortOrder" type="{urn:lifelink-schema}QuoteSortOrder" minOccurs="0"/>
 *         &lt;element name="MaxQuotes" type="{http://www.w3.org/2001/XMLSchema}integer" minOccurs="0"/>
 *         &lt;element name="Report" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="5" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ProductOptionsType", propOrder = {
    "benAmt",
    "pm",
    "tq",
    "cl",
    "bp",
    "ip",
    "ep",
    "rc",
    "jrc",
    "jp",
    "altc",
    "disc",
    "po",
    "whc",
    "wop",
    "sharedben",
    "rop",
    "rob",
    "indem",
    "pp",
    "nf",
    "hhcep",
    "hwep",
    "eep",
    "ep1X",
    "ratg",
    "intl",
    "upg",
    "nfct",
    "fsa",
    "cc",
    "cpln",
    "astl",
    "cgtr",
    "mede",
    "infc",
    "hmsv",
    "hosc",
    "bedr",
    "ics",
    "part",
    "hmod",
    "npri",
    "fpay",
    "productList",
    "products",
    "filters",
    "includeFiltersWithQuotes",
    "includeRemovedProducts",
    "enableRidersNoFiltering",
    "minFilterMatches",
    "sortBy",
    "sortOrder",
    "maxQuotes",
    "report"
})
public class ProductOptionsType {

    @XmlElement(name = "BenAmt")
    protected BenAmtType benAmt;
    @XmlElement(name = "PM")
    protected GenericPaymentModeType pm;
    @XmlElement(name = "TQ")
    protected GenericTaxQualifiedType tq;
    @XmlElement(name = "CL")
    protected String cl;
    @XmlElement(name = "BP")
    protected String bp;
    @XmlElement(name = "IP")
    protected String ip;
    @XmlElement(name = "EP")
    protected String ep;
    @XmlElement(name = "RC")
    protected GenericRateClassType rc;
    @XmlElement(name = "JRC")
    protected GenericRateClassType jrc;
    @XmlElement(name = "JP")
    protected GenericJointPolicyType jp;
    @XmlElement(name = "ALTC")
    protected GenericAlternateCareType altc;
    @XmlElement(name = "DISC")
    protected GenericDiscountType disc;
    @XmlElement(name = "PO")
    protected String po;
    @XmlElement(name = "WHC")
    protected GenericWeeklyHomeCareType whc;
    @XmlElement(name = "WOP")
    protected GenericWaiverOfPremiumType wop;
    @XmlElement(name = "SHAREDBEN")
    protected GenericSharedBenefitType sharedben;
    @XmlElement(name = "ROP")
    protected GenericReturnOfPremiumType rop;
    @XmlElement(name = "ROB")
    protected GenericRestorationOfBenefitsType rob;
    @XmlElement(name = "INDEM")
    protected GenericIndemnityType indem;
    @XmlElement(name = "PP")
    protected GenericPaymentPlanType pp;
    @XmlElement(name = "NF")
    protected GenericNonForfeitureType nf;
    @XmlElement(name = "HHCEP")
    protected GenericHHCEPType hhcep;
    @XmlElement(name = "HWEP")
    protected GenericHWEPType hwep;
    @XmlElement(name = "EEP")
    protected GenericEnhancedEliminationPeriodType eep;
    @XmlElement(name = "EP1X")
    protected GenericEP1XType ep1X;
    @XmlElement(name = "RATG")
    protected GenericRATGType ratg;
    @XmlElement(name = "INTL")
    protected GenericINTLType intl;
    @XmlElement(name = "UPG")
    protected GenericUPGType upg;
    @XmlElement(name = "NFCT")
    protected GenericNFCTType nfct;
    @XmlElement(name = "FSA")
    protected GenericFSAType fsa;
    @XmlElement(name = "CC")
    protected GenericCCType cc;
    @XmlElement(name = "CPLN")
    protected GenericCPLNType cpln;
    @XmlElement(name = "ASTL")
    protected GenericASTLType astl;
    @XmlElement(name = "CGTR")
    protected GenericCGTRType cgtr;
    @XmlElement(name = "MEDE")
    protected GenericMEDEType mede;
    @XmlElement(name = "INFC")
    protected GenericINFCType infc;
    @XmlElement(name = "HMSV")
    protected GenericHMSVType hmsv;
    @XmlElement(name = "HOSC")
    protected GenericHOSCType hosc;
    @XmlElement(name = "BEDR")
    protected GenericBEDRType bedr;
    @XmlElement(name = "ICS")
    protected GenericICSType ics;
    @XmlElement(name = "PART")
    protected GenericPARTType part;
    @XmlElement(name = "HMOD")
    protected GenericHMODType hmod;
    @XmlElement(name = "NPRI")
    protected GenericNPRIType npri;
    @XmlElement(name = "FPAY")
    protected GenericFPAYType fpay;
    @XmlElement(name = "ProductList", required = true)
    protected ProductListType productList;
    @XmlElement(name = "Products")
    protected RequestedProductsType products;
    @XmlElement(name = "Filters")
    protected FiltersType filters;
    @XmlElement(name = "IncludeFiltersWithQuotes")
    protected Boolean includeFiltersWithQuotes;
    @XmlElement(name = "IncludeRemovedProducts")
    protected Boolean includeRemovedProducts;
    @XmlElement(name = "EnableRidersNoFiltering")
    protected Boolean enableRidersNoFiltering;
    @XmlElement(name = "MinFilterMatches")
    protected BigInteger minFilterMatches;
    @XmlElement(name = "SortBy")
    protected QuoteSortBy sortBy;
    @XmlElement(name = "SortOrder")
    protected QuoteSortOrder sortOrder;
    @XmlElement(name = "MaxQuotes")
    protected BigInteger maxQuotes;
    @XmlElement(name = "Report")
    protected List<String> report;

    /**
     * Gets the value of the benAmt property.
     * 
     * @return
     *     possible object is
     *     {@link BenAmtType }
     *     
     */
    public BenAmtType getBenAmt() {
        return benAmt;
    }

    /**
     * Sets the value of the benAmt property.
     * 
     * @param value
     *     allowed object is
     *     {@link BenAmtType }
     *     
     */
    public void setBenAmt(BenAmtType value) {
        this.benAmt = value;
    }

    /**
     * Gets the value of the pm property.
     * 
     * @return
     *     possible object is
     *     {@link GenericPaymentModeType }
     *     
     */
    public GenericPaymentModeType getPM() {
        return pm;
    }

    /**
     * Sets the value of the pm property.
     * 
     * @param value
     *     allowed object is
     *     {@link GenericPaymentModeType }
     *     
     */
    public void setPM(GenericPaymentModeType value) {
        this.pm = value;
    }

    /**
     * Gets the value of the tq property.
     * 
     * @return
     *     possible object is
     *     {@link GenericTaxQualifiedType }
     *     
     */
    public GenericTaxQualifiedType getTQ() {
        return tq;
    }

    /**
     * Sets the value of the tq property.
     * 
     * @param value
     *     allowed object is
     *     {@link GenericTaxQualifiedType }
     *     
     */
    public void setTQ(GenericTaxQualifiedType value) {
        this.tq = value;
    }

    /**
     * Gets the value of the cl property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCL() {
        return cl;
    }

    /**
     * Sets the value of the cl property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCL(String value) {
        this.cl = value;
    }

    /**
     * Gets the value of the bp property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBP() {
        return bp;
    }

    /**
     * Sets the value of the bp property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBP(String value) {
        this.bp = value;
    }

    /**
     * Gets the value of the ip property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIP() {
        return ip;
    }

    /**
     * Sets the value of the ip property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIP(String value) {
        this.ip = value;
    }

    /**
     * Gets the value of the ep property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEP() {
        return ep;
    }

    /**
     * Sets the value of the ep property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEP(String value) {
        this.ep = value;
    }

    /**
     * Gets the value of the rc property.
     * 
     * @return
     *     possible object is
     *     {@link GenericRateClassType }
     *     
     */
    public GenericRateClassType getRC() {
        return rc;
    }

    /**
     * Sets the value of the rc property.
     * 
     * @param value
     *     allowed object is
     *     {@link GenericRateClassType }
     *     
     */
    public void setRC(GenericRateClassType value) {
        this.rc = value;
    }

    /**
     * Gets the value of the jrc property.
     * 
     * @return
     *     possible object is
     *     {@link GenericRateClassType }
     *     
     */
    public GenericRateClassType getJRC() {
        return jrc;
    }

    /**
     * Sets the value of the jrc property.
     * 
     * @param value
     *     allowed object is
     *     {@link GenericRateClassType }
     *     
     */
    public void setJRC(GenericRateClassType value) {
        this.jrc = value;
    }

    /**
     * Gets the value of the jp property.
     * 
     * @return
     *     possible object is
     *     {@link GenericJointPolicyType }
     *     
     */
    public GenericJointPolicyType getJP() {
        return jp;
    }

    /**
     * Sets the value of the jp property.
     * 
     * @param value
     *     allowed object is
     *     {@link GenericJointPolicyType }
     *     
     */
    public void setJP(GenericJointPolicyType value) {
        this.jp = value;
    }

    /**
     * Gets the value of the altc property.
     * 
     * @return
     *     possible object is
     *     {@link GenericAlternateCareType }
     *     
     */
    public GenericAlternateCareType getALTC() {
        return altc;
    }

    /**
     * Sets the value of the altc property.
     * 
     * @param value
     *     allowed object is
     *     {@link GenericAlternateCareType }
     *     
     */
    public void setALTC(GenericAlternateCareType value) {
        this.altc = value;
    }

    /**
     * Gets the value of the disc property.
     * 
     * @return
     *     possible object is
     *     {@link GenericDiscountType }
     *     
     */
    public GenericDiscountType getDISC() {
        return disc;
    }

    /**
     * Sets the value of the disc property.
     * 
     * @param value
     *     allowed object is
     *     {@link GenericDiscountType }
     *     
     */
    public void setDISC(GenericDiscountType value) {
        this.disc = value;
    }

    /**
     * Gets the value of the po property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPO() {
        return po;
    }

    /**
     * Sets the value of the po property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPO(String value) {
        this.po = value;
    }

    /**
     * Gets the value of the whc property.
     * 
     * @return
     *     possible object is
     *     {@link GenericWeeklyHomeCareType }
     *     
     */
    public GenericWeeklyHomeCareType getWHC() {
        return whc;
    }

    /**
     * Sets the value of the whc property.
     * 
     * @param value
     *     allowed object is
     *     {@link GenericWeeklyHomeCareType }
     *     
     */
    public void setWHC(GenericWeeklyHomeCareType value) {
        this.whc = value;
    }

    /**
     * Gets the value of the wop property.
     * 
     * @return
     *     possible object is
     *     {@link GenericWaiverOfPremiumType }
     *     
     */
    public GenericWaiverOfPremiumType getWOP() {
        return wop;
    }

    /**
     * Sets the value of the wop property.
     * 
     * @param value
     *     allowed object is
     *     {@link GenericWaiverOfPremiumType }
     *     
     */
    public void setWOP(GenericWaiverOfPremiumType value) {
        this.wop = value;
    }

    /**
     * Gets the value of the sharedben property.
     * 
     * @return
     *     possible object is
     *     {@link GenericSharedBenefitType }
     *     
     */
    public GenericSharedBenefitType getSHAREDBEN() {
        return sharedben;
    }

    /**
     * Sets the value of the sharedben property.
     * 
     * @param value
     *     allowed object is
     *     {@link GenericSharedBenefitType }
     *     
     */
    public void setSHAREDBEN(GenericSharedBenefitType value) {
        this.sharedben = value;
    }

    /**
     * Gets the value of the rop property.
     * 
     * @return
     *     possible object is
     *     {@link GenericReturnOfPremiumType }
     *     
     */
    public GenericReturnOfPremiumType getROP() {
        return rop;
    }

    /**
     * Sets the value of the rop property.
     * 
     * @param value
     *     allowed object is
     *     {@link GenericReturnOfPremiumType }
     *     
     */
    public void setROP(GenericReturnOfPremiumType value) {
        this.rop = value;
    }

    /**
     * Gets the value of the rob property.
     * 
     * @return
     *     possible object is
     *     {@link GenericRestorationOfBenefitsType }
     *     
     */
    public GenericRestorationOfBenefitsType getROB() {
        return rob;
    }

    /**
     * Sets the value of the rob property.
     * 
     * @param value
     *     allowed object is
     *     {@link GenericRestorationOfBenefitsType }
     *     
     */
    public void setROB(GenericRestorationOfBenefitsType value) {
        this.rob = value;
    }

    /**
     * Gets the value of the indem property.
     * 
     * @return
     *     possible object is
     *     {@link GenericIndemnityType }
     *     
     */
    public GenericIndemnityType getINDEM() {
        return indem;
    }

    /**
     * Sets the value of the indem property.
     * 
     * @param value
     *     allowed object is
     *     {@link GenericIndemnityType }
     *     
     */
    public void setINDEM(GenericIndemnityType value) {
        this.indem = value;
    }

    /**
     * Gets the value of the pp property.
     * 
     * @return
     *     possible object is
     *     {@link GenericPaymentPlanType }
     *     
     */
    public GenericPaymentPlanType getPP() {
        return pp;
    }

    /**
     * Sets the value of the pp property.
     * 
     * @param value
     *     allowed object is
     *     {@link GenericPaymentPlanType }
     *     
     */
    public void setPP(GenericPaymentPlanType value) {
        this.pp = value;
    }

    /**
     * Gets the value of the nf property.
     * 
     * @return
     *     possible object is
     *     {@link GenericNonForfeitureType }
     *     
     */
    public GenericNonForfeitureType getNF() {
        return nf;
    }

    /**
     * Sets the value of the nf property.
     * 
     * @param value
     *     allowed object is
     *     {@link GenericNonForfeitureType }
     *     
     */
    public void setNF(GenericNonForfeitureType value) {
        this.nf = value;
    }

    /**
     * Gets the value of the hhcep property.
     * 
     * @return
     *     possible object is
     *     {@link GenericHHCEPType }
     *     
     */
    public GenericHHCEPType getHHCEP() {
        return hhcep;
    }

    /**
     * Sets the value of the hhcep property.
     * 
     * @param value
     *     allowed object is
     *     {@link GenericHHCEPType }
     *     
     */
    public void setHHCEP(GenericHHCEPType value) {
        this.hhcep = value;
    }

    /**
     * Gets the value of the hwep property.
     * 
     * @return
     *     possible object is
     *     {@link GenericHWEPType }
     *     
     */
    public GenericHWEPType getHWEP() {
        return hwep;
    }

    /**
     * Sets the value of the hwep property.
     * 
     * @param value
     *     allowed object is
     *     {@link GenericHWEPType }
     *     
     */
    public void setHWEP(GenericHWEPType value) {
        this.hwep = value;
    }

    /**
     * Gets the value of the eep property.
     * 
     * @return
     *     possible object is
     *     {@link GenericEnhancedEliminationPeriodType }
     *     
     */
    public GenericEnhancedEliminationPeriodType getEEP() {
        return eep;
    }

    /**
     * Sets the value of the eep property.
     * 
     * @param value
     *     allowed object is
     *     {@link GenericEnhancedEliminationPeriodType }
     *     
     */
    public void setEEP(GenericEnhancedEliminationPeriodType value) {
        this.eep = value;
    }

    /**
     * Gets the value of the ep1X property.
     * 
     * @return
     *     possible object is
     *     {@link GenericEP1XType }
     *     
     */
    public GenericEP1XType getEP1X() {
        return ep1X;
    }

    /**
     * Sets the value of the ep1X property.
     * 
     * @param value
     *     allowed object is
     *     {@link GenericEP1XType }
     *     
     */
    public void setEP1X(GenericEP1XType value) {
        this.ep1X = value;
    }

    /**
     * Gets the value of the ratg property.
     * 
     * @return
     *     possible object is
     *     {@link GenericRATGType }
     *     
     */
    public GenericRATGType getRATG() {
        return ratg;
    }

    /**
     * Sets the value of the ratg property.
     * 
     * @param value
     *     allowed object is
     *     {@link GenericRATGType }
     *     
     */
    public void setRATG(GenericRATGType value) {
        this.ratg = value;
    }

    /**
     * Gets the value of the intl property.
     * 
     * @return
     *     possible object is
     *     {@link GenericINTLType }
     *     
     */
    public GenericINTLType getINTL() {
        return intl;
    }

    /**
     * Sets the value of the intl property.
     * 
     * @param value
     *     allowed object is
     *     {@link GenericINTLType }
     *     
     */
    public void setINTL(GenericINTLType value) {
        this.intl = value;
    }

    /**
     * Gets the value of the upg property.
     * 
     * @return
     *     possible object is
     *     {@link GenericUPGType }
     *     
     */
    public GenericUPGType getUPG() {
        return upg;
    }

    /**
     * Sets the value of the upg property.
     * 
     * @param value
     *     allowed object is
     *     {@link GenericUPGType }
     *     
     */
    public void setUPG(GenericUPGType value) {
        this.upg = value;
    }

    /**
     * Gets the value of the nfct property.
     * 
     * @return
     *     possible object is
     *     {@link GenericNFCTType }
     *     
     */
    public GenericNFCTType getNFCT() {
        return nfct;
    }

    /**
     * Sets the value of the nfct property.
     * 
     * @param value
     *     allowed object is
     *     {@link GenericNFCTType }
     *     
     */
    public void setNFCT(GenericNFCTType value) {
        this.nfct = value;
    }

    /**
     * Gets the value of the fsa property.
     * 
     * @return
     *     possible object is
     *     {@link GenericFSAType }
     *     
     */
    public GenericFSAType getFSA() {
        return fsa;
    }

    /**
     * Sets the value of the fsa property.
     * 
     * @param value
     *     allowed object is
     *     {@link GenericFSAType }
     *     
     */
    public void setFSA(GenericFSAType value) {
        this.fsa = value;
    }

    /**
     * Gets the value of the cc property.
     * 
     * @return
     *     possible object is
     *     {@link GenericCCType }
     *     
     */
    public GenericCCType getCC() {
        return cc;
    }

    /**
     * Sets the value of the cc property.
     * 
     * @param value
     *     allowed object is
     *     {@link GenericCCType }
     *     
     */
    public void setCC(GenericCCType value) {
        this.cc = value;
    }

    /**
     * Gets the value of the cpln property.
     * 
     * @return
     *     possible object is
     *     {@link GenericCPLNType }
     *     
     */
    public GenericCPLNType getCPLN() {
        return cpln;
    }

    /**
     * Sets the value of the cpln property.
     * 
     * @param value
     *     allowed object is
     *     {@link GenericCPLNType }
     *     
     */
    public void setCPLN(GenericCPLNType value) {
        this.cpln = value;
    }

    /**
     * Gets the value of the astl property.
     * 
     * @return
     *     possible object is
     *     {@link GenericASTLType }
     *     
     */
    public GenericASTLType getASTL() {
        return astl;
    }

    /**
     * Sets the value of the astl property.
     * 
     * @param value
     *     allowed object is
     *     {@link GenericASTLType }
     *     
     */
    public void setASTL(GenericASTLType value) {
        this.astl = value;
    }

    /**
     * Gets the value of the cgtr property.
     * 
     * @return
     *     possible object is
     *     {@link GenericCGTRType }
     *     
     */
    public GenericCGTRType getCGTR() {
        return cgtr;
    }

    /**
     * Sets the value of the cgtr property.
     * 
     * @param value
     *     allowed object is
     *     {@link GenericCGTRType }
     *     
     */
    public void setCGTR(GenericCGTRType value) {
        this.cgtr = value;
    }

    /**
     * Gets the value of the mede property.
     * 
     * @return
     *     possible object is
     *     {@link GenericMEDEType }
     *     
     */
    public GenericMEDEType getMEDE() {
        return mede;
    }

    /**
     * Sets the value of the mede property.
     * 
     * @param value
     *     allowed object is
     *     {@link GenericMEDEType }
     *     
     */
    public void setMEDE(GenericMEDEType value) {
        this.mede = value;
    }

    /**
     * Gets the value of the infc property.
     * 
     * @return
     *     possible object is
     *     {@link GenericINFCType }
     *     
     */
    public GenericINFCType getINFC() {
        return infc;
    }

    /**
     * Sets the value of the infc property.
     * 
     * @param value
     *     allowed object is
     *     {@link GenericINFCType }
     *     
     */
    public void setINFC(GenericINFCType value) {
        this.infc = value;
    }

    /**
     * Gets the value of the hmsv property.
     * 
     * @return
     *     possible object is
     *     {@link GenericHMSVType }
     *     
     */
    public GenericHMSVType getHMSV() {
        return hmsv;
    }

    /**
     * Sets the value of the hmsv property.
     * 
     * @param value
     *     allowed object is
     *     {@link GenericHMSVType }
     *     
     */
    public void setHMSV(GenericHMSVType value) {
        this.hmsv = value;
    }

    /**
     * Gets the value of the hosc property.
     * 
     * @return
     *     possible object is
     *     {@link GenericHOSCType }
     *     
     */
    public GenericHOSCType getHOSC() {
        return hosc;
    }

    /**
     * Sets the value of the hosc property.
     * 
     * @param value
     *     allowed object is
     *     {@link GenericHOSCType }
     *     
     */
    public void setHOSC(GenericHOSCType value) {
        this.hosc = value;
    }

    /**
     * Gets the value of the bedr property.
     * 
     * @return
     *     possible object is
     *     {@link GenericBEDRType }
     *     
     */
    public GenericBEDRType getBEDR() {
        return bedr;
    }

    /**
     * Sets the value of the bedr property.
     * 
     * @param value
     *     allowed object is
     *     {@link GenericBEDRType }
     *     
     */
    public void setBEDR(GenericBEDRType value) {
        this.bedr = value;
    }

    /**
     * Gets the value of the ics property.
     * 
     * @return
     *     possible object is
     *     {@link GenericICSType }
     *     
     */
    public GenericICSType getICS() {
        return ics;
    }

    /**
     * Sets the value of the ics property.
     * 
     * @param value
     *     allowed object is
     *     {@link GenericICSType }
     *     
     */
    public void setICS(GenericICSType value) {
        this.ics = value;
    }

    /**
     * Gets the value of the part property.
     * 
     * @return
     *     possible object is
     *     {@link GenericPARTType }
     *     
     */
    public GenericPARTType getPART() {
        return part;
    }

    /**
     * Sets the value of the part property.
     * 
     * @param value
     *     allowed object is
     *     {@link GenericPARTType }
     *     
     */
    public void setPART(GenericPARTType value) {
        this.part = value;
    }

    /**
     * Gets the value of the hmod property.
     * 
     * @return
     *     possible object is
     *     {@link GenericHMODType }
     *     
     */
    public GenericHMODType getHMOD() {
        return hmod;
    }

    /**
     * Sets the value of the hmod property.
     * 
     * @param value
     *     allowed object is
     *     {@link GenericHMODType }
     *     
     */
    public void setHMOD(GenericHMODType value) {
        this.hmod = value;
    }

    /**
     * Gets the value of the npri property.
     * 
     * @return
     *     possible object is
     *     {@link GenericNPRIType }
     *     
     */
    public GenericNPRIType getNPRI() {
        return npri;
    }

    /**
     * Sets the value of the npri property.
     * 
     * @param value
     *     allowed object is
     *     {@link GenericNPRIType }
     *     
     */
    public void setNPRI(GenericNPRIType value) {
        this.npri = value;
    }

    /**
     * Gets the value of the fpay property.
     * 
     * @return
     *     possible object is
     *     {@link GenericFPAYType }
     *     
     */
    public GenericFPAYType getFPAY() {
        return fpay;
    }

    /**
     * Sets the value of the fpay property.
     * 
     * @param value
     *     allowed object is
     *     {@link GenericFPAYType }
     *     
     */
    public void setFPAY(GenericFPAYType value) {
        this.fpay = value;
    }

    /**
     * Gets the value of the productList property.
     * 
     * @return
     *     possible object is
     *     {@link ProductListType }
     *     
     */
    public ProductListType getProductList() {
        return productList;
    }

    /**
     * Sets the value of the productList property.
     * 
     * @param value
     *     allowed object is
     *     {@link ProductListType }
     *     
     */
    public void setProductList(ProductListType value) {
        this.productList = value;
    }

    /**
     * Gets the value of the products property.
     * 
     * @return
     *     possible object is
     *     {@link RequestedProductsType }
     *     
     */
    public RequestedProductsType getProducts() {
        return products;
    }

    /**
     * Sets the value of the products property.
     * 
     * @param value
     *     allowed object is
     *     {@link RequestedProductsType }
     *     
     */
    public void setProducts(RequestedProductsType value) {
        this.products = value;
    }

    /**
     * Gets the value of the filters property.
     * 
     * @return
     *     possible object is
     *     {@link FiltersType }
     *     
     */
    public FiltersType getFilters() {
        return filters;
    }

    /**
     * Sets the value of the filters property.
     * 
     * @param value
     *     allowed object is
     *     {@link FiltersType }
     *     
     */
    public void setFilters(FiltersType value) {
        this.filters = value;
    }

    /**
     * Gets the value of the includeFiltersWithQuotes property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIncludeFiltersWithQuotes() {
        return includeFiltersWithQuotes;
    }

    /**
     * Sets the value of the includeFiltersWithQuotes property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIncludeFiltersWithQuotes(Boolean value) {
        this.includeFiltersWithQuotes = value;
    }

    /**
     * Gets the value of the includeRemovedProducts property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIncludeRemovedProducts() {
        return includeRemovedProducts;
    }

    /**
     * Sets the value of the includeRemovedProducts property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIncludeRemovedProducts(Boolean value) {
        this.includeRemovedProducts = value;
    }

    /**
     * Gets the value of the enableRidersNoFiltering property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isEnableRidersNoFiltering() {
        return enableRidersNoFiltering;
    }

    /**
     * Sets the value of the enableRidersNoFiltering property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setEnableRidersNoFiltering(Boolean value) {
        this.enableRidersNoFiltering = value;
    }

    /**
     * Gets the value of the minFilterMatches property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getMinFilterMatches() {
        return minFilterMatches;
    }

    /**
     * Sets the value of the minFilterMatches property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setMinFilterMatches(BigInteger value) {
        this.minFilterMatches = value;
    }

    /**
     * Gets the value of the sortBy property.
     * 
     * @return
     *     possible object is
     *     {@link QuoteSortBy }
     *     
     */
    public QuoteSortBy getSortBy() {
        return sortBy;
    }

    /**
     * Sets the value of the sortBy property.
     * 
     * @param value
     *     allowed object is
     *     {@link QuoteSortBy }
     *     
     */
    public void setSortBy(QuoteSortBy value) {
        this.sortBy = value;
    }

    /**
     * Gets the value of the sortOrder property.
     * 
     * @return
     *     possible object is
     *     {@link QuoteSortOrder }
     *     
     */
    public QuoteSortOrder getSortOrder() {
        return sortOrder;
    }

    /**
     * Sets the value of the sortOrder property.
     * 
     * @param value
     *     allowed object is
     *     {@link QuoteSortOrder }
     *     
     */
    public void setSortOrder(QuoteSortOrder value) {
        this.sortOrder = value;
    }

    /**
     * Gets the value of the maxQuotes property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getMaxQuotes() {
        return maxQuotes;
    }

    /**
     * Sets the value of the maxQuotes property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setMaxQuotes(BigInteger value) {
        this.maxQuotes = value;
    }

    /**
     * Gets the value of the report property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the report property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getReport().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link String }
     * 
     * 
     */
    public List<String> getReport() {
        if (report == null) {
            report = new ArrayList<String>();
        }
        return this.report;
    }

}
