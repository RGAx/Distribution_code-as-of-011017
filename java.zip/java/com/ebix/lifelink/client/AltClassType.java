
package com.ebix.lifelink.client;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for AltClassType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="AltClassType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="Above" type="{http://www.w3.org/2001/XMLSchema}short" minOccurs="0"/>
 *         &lt;element name="Below" type="{http://www.w3.org/2001/XMLSchema}short" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "AltClassType", propOrder = {
    "above",
    "below"
})
public class AltClassType {

    @XmlElement(name = "Above")
    protected Short above;
    @XmlElement(name = "Below")
    protected Short below;

    /**
     * Gets the value of the above property.
     * 
     * @return
     *     possible object is
     *     {@link Short }
     *     
     */
    public Short getAbove() {
        return above;
    }

    /**
     * Sets the value of the above property.
     * 
     * @param value
     *     allowed object is
     *     {@link Short }
     *     
     */
    public void setAbove(Short value) {
        this.above = value;
    }

    /**
     * Gets the value of the below property.
     * 
     * @return
     *     possible object is
     *     {@link Short }
     *     
     */
    public Short getBelow() {
        return below;
    }

    /**
     * Sets the value of the below property.
     * 
     * @param value
     *     allowed object is
     *     {@link Short }
     *     
     */
    public void setBelow(Short value) {
        this.below = value;
    }

}
