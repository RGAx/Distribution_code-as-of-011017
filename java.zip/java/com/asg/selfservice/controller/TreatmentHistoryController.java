/**
 * 
 */
package com.asg.selfservice.controller;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.asg.selfservice.common.logger.LogFactory;
import com.asg.selfservice.common.logger.SelfServiceLogger;
import com.asg.selfservice.common.utils.ApplicationConstants;
import com.asg.selfservice.domain.TreatmentHistory;
import com.asg.selfservice.domain.UserProfile;
import com.asg.selfservice.exception.ServiceException;
import com.asg.selfservice.services.ProfileService;
import com.asg.selfservice.services.TreatmentService;
import com.asg.selfservice.services.impl.EBIXServiceImpl;

/**
 * This controller has been used for implementing the Treatment History(Substance Abuse) functionalities
 * such as loading the Treatment page with the updated DB details, updating the
 * Treatment info into the DB which the user has entered from the UI before
 * proceeding into the next page.
 * 
 * @author M1027376
 *
 */
@Controller
public class TreatmentHistoryController {

	private static final SelfServiceLogger logger = LogFactory.getInstance(TreatmentHistoryController.class);
	
	@Autowired
	private TreatmentService treatmentService;
	
	@Autowired
    private ServletContext context;
	
	@Autowired
	private HttpSession session;
	
	@Autowired
	private ProfileService profileService;
	
	@Autowired
	private EBIXServiceImpl ebixService;
	
	@ModelAttribute("userProfile")
	public UserProfile createUserProfileModel() {
		return new UserProfile();
	}
	
	/*
	 * This method has been used for loading the Treatment History(Substance Abuse) page based on the
	 * request url. Before loading the page the user session availability has been checked.
	 */
	@RequestMapping("/treatment")
	public ModelAndView loadTreatmentHistInfo() throws Exception {
		
		final long startTime = logger.logMethodEntry();
		if (session.getAttribute("sessionUser") == null
				|| (session.getAttribute(ApplicationConstants.PAGE_FROM) != ApplicationConstants.DRIVING
				&& session.getAttribute(ApplicationConstants.PAGE_FROM) != ApplicationConstants.QUOTE
				&& session.getAttribute(ApplicationConstants.PAGE_FROM) != ApplicationConstants.EMAIL
				&& session.getAttribute(ApplicationConstants.PAGE_FROM) != ApplicationConstants.PROFILE)) {
			return new ModelAndView("redirect:"+ApplicationConstants.LOGIN+".html");
		}
		if(session.getAttribute(ApplicationConstants.PAGE_FROM) != ApplicationConstants.PROFILE)
			session.setAttribute(ApplicationConstants.PAGE_FROM, ApplicationConstants.PAGE_FROM);
		
		ModelAndView model = new ModelAndView("treatmentHistory");
		UserProfile userProfile = null;
		
		if(session.getAttribute("sessionUser") != null) {
			userProfile = (UserProfile) session.getAttribute("sessionUser");
		} else {
			return new ModelAndView("login");
		}
		try {
			model = treatmentService.loadTreatmentHistInfo(model, userProfile);
			model.addObject("selectedQuote", session.getAttribute("selectedQuote"));
		} catch (ServiceException e) {
			logger.error("ERROR : " + e.getMessage());
			throw new Exception(e.getMessage());
		} catch (Exception e) {
			logger.error("ERROR : " + e.getMessage());
			throw new Exception(e.getMessage());
		}
		logger.logMethodExit(startTime);
		return model;
	}
	
	/*
	 * This method has been used for updating the Treatment History information before
	 * loading the Quote page.
	 */
	@RequestMapping(value = "/treatment", method = RequestMethod.POST, params = "requestParam")
	public String saveUpdateTreatmentInfo(@ModelAttribute("treatment") TreatmentHistory treatment,
			@RequestParam String requestParam) throws Exception {
		final long startTime = logger.logMethodEntry();

		session.setAttribute(ApplicationConstants.PAGE_FROM, ApplicationConstants.TREATMENT);
		
		if(session.getAttribute("sessionUser") == null) {
			return "redirect:login.html";
		} else if("back".equalsIgnoreCase(requestParam)) {
			session.setAttribute(ApplicationConstants.AJAX_PAGE_FROM, ApplicationConstants.AJAX_PAGE_CALL);
			logger.logMethodExit(startTime);
			return "redirect:"+ApplicationConstants.DRIVING+".html";
		}
		
		UserProfile userProfile = (UserProfile) session.getAttribute("sessionUser");
		if("next".equalsIgnoreCase(requestParam) && userProfile.getProfileStatusFlag() > 2) {
			return "redirect:"+ApplicationConstants.QUOTE+".html";
		}
		try {
			treatmentService.saveUpdateTreatmentInfo(userProfile, treatment);
			
			if("save".equalsIgnoreCase(requestParam)) {
				userProfile = profileService.saveUserProfile(userProfile);
				session.setAttribute("sessionUser", userProfile);
				
				logger.logMethodExit(startTime);
				return "redirect:"+ApplicationConstants.CUSTOMERCALLBACK+".html";
			} else {
				
				logger.logMethodExit(startTime);
				return "redirect:"+ApplicationConstants.QUOTE+".html";
			}
		} catch (ServiceException e) {
			logger.error("ERROR : " + e.getMessage());
			throw new Exception(e.getMessage());
		} catch (Exception e) {
			logger.error("ERROR : " + e.getMessage());
			throw new Exception(e.getMessage());
		}
	}
}
