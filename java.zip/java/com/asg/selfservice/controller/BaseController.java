package com.asg.selfservice.controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.asg.selfservice.common.logger.LogFactory;
import com.asg.selfservice.common.logger.SelfServiceLogger;
import com.asg.selfservice.common.utils.ApplicationConstants;
import com.asg.selfservice.domain.Legalstmt;
import com.asg.selfservice.domain.PinneyDetails;
import com.asg.selfservice.domain.QuestionAnswer;
import com.asg.selfservice.domain.Quote;
import com.asg.selfservice.domain.UserProfile;
import com.asg.selfservice.exception.ServiceException;
import com.asg.selfservice.pinney.services.impl.PinneyRequestProcessor;
import com.asg.selfservice.pinney.services.impl.PinneyServiceHelperImpl;
import com.asg.selfservice.services.LegalStatementService;
import com.asg.selfservice.services.impl.EBIXServiceImpl;
import com.google.gson.Gson;

/**
 * This class has been used as a base controller where all the common methods
 * such as logout, footer methods can be mapped.
 * 
 * @author M1030133
 *
 */
@Controller
public class BaseController {
	
	private static final SelfServiceLogger logger = LogFactory.getInstance(BaseController.class);
	
	@Autowired
	private HttpSession session;
	
	@Autowired
	private Legalstmt legalstmt;
	
	@Autowired
	private LegalStatementService legalstmtservice;
	
	@Autowired
	private EBIXServiceImpl ebixService;
	
	@ModelAttribute("userProfile")
	public UserProfile createUserProfileModel() {
		return new UserProfile();
	}
	
	/*
	 * This method has been used to load the error page in customized form.
	 */
	@RequestMapping("/" + ApplicationConstants.ERROR)
	public String loadErrorPage() throws Exception {
		return ApplicationConstants.ERROR;
	}
	
	/*
	 * This method has been used to load the error page in customized form.
	 */
	@RequestMapping("/campaignover")
	public String loadCampaignOverPage() throws Exception {
		return "redirect:campaignover.html";
	}
	
	/*
	 * This method has been used for logging out the user from the application.
	 * This in-turn sets the session attributes to null.
	 */
	@RequestMapping("/"+ApplicationConstants.LOGOUT)
	public String onUserLogout() throws Exception {
		session.invalidate();
		return "redirect:"+ApplicationConstants.LOGIN+".html";
	}
	
	
	/*
	 * This method has been used to load the landing page on click of URL.
	 */
	@RequestMapping("/"+ApplicationConstants.LEGAL_STMT)
	public String loadLegalStmtPage(@RequestParam(value = "agencyName") String agencyName, Model model) throws Exception {
		final long startTime = logger.logMethodEntry();
		try {
			String strAgencyName = (String) session.getAttribute("agencyName");
			if(null == strAgencyName) {
				strAgencyName = agencyName;
			}
			if (strAgencyName.equalsIgnoreCase("William_Raveis")
					|| strAgencyName.equalsIgnoreCase("William Raveis")) {
				return "legal_williamraveis";
			}
			legalstmt =legalstmtservice.getFIName_Type(strAgencyName);
			
		} catch (ServiceException e) {
			logger.error("ERROR : " + e.getMessage());
			throw new Exception(e.getMessage());
		} catch (Exception e) {
			logger.error("ERROR : " + e.getMessage());
			throw new Exception(e.getMessage());
		}
		model.addAttribute("legalstmt", legalstmt);
		
		logger.logMethodExit(startTime);
		return ApplicationConstants.LEGAL_STMT;
	}
	
	/*
	 * This method invokes Terms and Condition
	 */
	@RequestMapping("/"+ApplicationConstants.TERMS_CONDN)
	public String loadTermsAndConditions() throws Exception {
		return ApplicationConstants.TERMS_CONDN;
	}
	
	/*
	 * This method loads default login page
	 */
	@RequestMapping("/")
	public String loadDefaultPage() throws Exception {
		return "redirect:"+ApplicationConstants.LOGIN+".html";
	}
	
	/*
	 * This method invokes Privacy Info
	 */
	@RequestMapping("/"+ApplicationConstants.PRIVACY_INFO)
	public String loadprivacyInformation() throws Exception {
		return ApplicationConstants.PRIVACY_INFO;
	}
	
	@Autowired
	private PinneyRequestProcessor pinneyRequestProcessor;
	
	@Autowired
	private PinneyServiceHelperImpl pinneyServiceHelperImpl;
	
	@RequestMapping("/verifyPinneyRequestResponse")
	public ModelAndView loadPinney() throws Exception {
		ModelAndView model = new ModelAndView("pinney");
		PinneyDetails pinneyDetails = new PinneyDetails();
		UserProfile userProfile = (UserProfile) session.getAttribute("sessionUser");
		
		if(userProfile == null) {
			pinneyDetails.setErrorMessage("Session expired. Please login again to see the response.");
			model.addObject("pinneyDetails", pinneyDetails);
			return model;
		}
		try {
			List<QuestionAnswer> questAnsList = pinneyRequestProcessor.loadUserQuestionAnswers(userProfile);
			
			String json = pinneyRequestProcessor.constructJsonRequest(questAnsList, userProfile);
			pinneyDetails.setRequest(json);
			logger.info("Request in Json : "+ json);
			
			JSONObject response  = pinneyServiceHelperImpl.executePinneyRequest(json);
			pinneyDetails.setResponse(response);
			logger.info("Response : "+ response);

		} catch (ServiceException e) {
			logger.error("ERROR : " + e.getMessage());
			pinneyDetails.setErrorMessage(e.getMessage());
		} catch (Exception e) {
			logger.error("ERROR : " + e.getMessage());
			pinneyDetails.setErrorMessage(e.getMessage());
		}
		model.addObject("pinneyDetails", pinneyDetails);
		return model;
	}
	
	@RequestMapping(value="/monthlyEstimates",method=RequestMethod.POST)
	public @ResponseBody String loadmonthlyEstimates() throws Exception {
		
		String jsonString="";
		try {
			UserProfile userProfile=null;
			if(null != session.getAttribute("sessionUser") && !"".equals(session.getAttribute("sessionUser"))){
				userProfile = (UserProfile) session.getAttribute("sessionUser");				
			}
			if(userProfile != null && userProfile.getProfileStatusFlag() <= 2 
					&& session.getAttribute(ApplicationConstants.AJAX_PAGE_FROM) != ApplicationConstants.AJAX_PAGE_CALL){
				
				Quote quote = ebixService.getBestQuote(userProfile);
				if(quote != null && quote.isValidQuote()) {
					jsonString = new Gson().toJson(quote);
					session.setAttribute("selectedQuote", quote);
					
					session.setAttribute(ApplicationConstants.AJAX_PAGE_FROM, ApplicationConstants.AJAX_PAGE_FROM);
					return jsonString;
				}
			} 
			Quote quote = (Quote) session.getAttribute("selectedQuote");
			if(quote != null) {
				jsonString = new Gson().toJson(quote);
			}
		} catch (Exception e) {
			logger.error("ERROR due to EBIX call: " + e.getMessage());			
		}
		session.setAttribute(ApplicationConstants.AJAX_PAGE_FROM, ApplicationConstants.AJAX_PAGE_FROM);
		return jsonString;
	}
	/*
	 * This Method is used to load the Disclaimer Page onclick of Disclaimer in footer page
	 * 
	 */
	@RequestMapping("/"+ApplicationConstants.DISCLAIMER)
	public String loadDisclaimerPage() throws Exception{
		
		return ApplicationConstants.DISCLAIMER;
	}
	
}
