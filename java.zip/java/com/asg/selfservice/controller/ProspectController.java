package com.asg.selfservice.controller;

import java.util.List;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.asg.selfservice.common.logger.LogFactory;
import com.asg.selfservice.common.logger.SelfServiceLogger;
import com.asg.selfservice.common.utils.ApplicationConstants;
import com.asg.selfservice.domain.Prospect;
import com.asg.selfservice.domain.UserProfile;
import com.asg.selfservice.exception.ServiceException;
import com.asg.selfservice.services.ProspectService;
import com.google.gson.Gson;


/**
 * This controller class has been used for implementing the landing page functionality
 * such as loading the landing page, updating the prospect details, 
 * inserting prospect details into the user profile table and
 * displaying the checkbox hit report as well.
 * @author M1027376
 *
 */

@Controller
public class ProspectController {
	
	private static final SelfServiceLogger logger = LogFactory.getInstance(ProspectController.class);

	@Autowired
	private ProspectService prosService;

	private String selectedAgency;
	
	@Autowired
	private HttpSession session;
	
	@Autowired
    private ServletContext context;
	
	@ModelAttribute("userProfile")
	public UserProfile createUserProfileModel() {
		return new UserProfile();
	}

	/*
	 * This method has been used to load the landing page on click of URL.
	 */
	@RequestMapping(value = "/home", method=RequestMethod.GET)
	public String onClickUrl(@RequestParam(value = "userID") String encryptedUId, Model model) throws Exception {
		final long startTime = logger.logMethodEntry();
		logger.info("On clicking link url... : encryptedUId - " +encryptedUId);
		session.invalidate();
		Prospect prospect;
		try {
			prospect = prosService.getProspectData(encryptedUId);
		} catch (ServiceException e) {
			logger.error("ERROR : " + e.getMessage());
			throw new Exception(e.getMessage());
		} catch (Exception e) {
			logger.error("ERROR : " + e.getMessage());
			throw new Exception(e.getMessage());
		}
		model.addAttribute("userID", encryptedUId);
		model.addAttribute("campaignID", prospect.getCampaignId());
		model.addAttribute("prospect", prospect);

		logger.logMethodExit(startTime);
		// returns the view name
		if(ApplicationConstants.LOGIN.equalsIgnoreCase(prospect.getNavigationPage())){
			return "redirect:"+ApplicationConstants.LOGIN+".html";
		}
		return prospect.getNavigationPage();
	}

	/*
	 * This method has been used to update the checkbox hits in prospect detail.
	 */
	@RequestMapping(value = "/checkbox", method = RequestMethod.POST)
	public String checkbox(Model model, HttpServletRequest request) throws Exception {
		logger.info("Updating checkbox hits..");
		
		session.invalidate();
		try {
			String encryptedUId = request.getParameter("encryptedUId");
			
			Prospect prospect = prosService.loadProspectData(encryptedUId);
			prosService.updateCheckboxHits(prospect);
		} catch (ServiceException e) {
			logger.error("ERROR : " + e.getMessage());
			throw new Exception(e.getMessage());
		} catch (Exception e) {
			logger.error("ERROR : " + e.getMessage());
			throw new Exception(e.getMessage());
		}
		session.setAttribute(ApplicationConstants.PAGE_FROM, ApplicationConstants.URL_CLICK);
		session.setAttribute(ApplicationConstants.AJAX_PAGE_FROM, ApplicationConstants.AJAX_PAGE_CALL);
		
		return "redirect:landingPage.html";
	}

	/*
	 * This method has been used to load the list of agency names and display checkbox hit report.
	 */
	@RequestMapping(value = "/userHistory")
	public String search(Model model) throws Exception {
		logger.info("Displaying checkboxhit report");
		String json = null;
		if(this.selectedAgency == null || this.selectedAgency.isEmpty()) {
			this.selectedAgency = "none";
		}
		List<Prospect> listOfCheckboxHitRecords;
		try {
			listOfCheckboxHitRecords = prosService.getUserHistory(this.selectedAgency);
			json = new Gson().toJson(listOfCheckboxHitRecords);
		} catch (ServiceException e) {
			logger.error("ERROR : " + e.getMessage());
			throw new Exception(e.getMessage());
		} catch (Exception e) {
			logger.error("ERROR : " + e.getMessage());
			throw new Exception(e.getMessage());
		}		
			
		model.addAttribute("listOfAgencies", prosService.getListOfAgencies());
		model.addAttribute("listOfCheckboxHitRecords", listOfCheckboxHitRecords);
		model.addAttribute("totalRows", listOfCheckboxHitRecords.size());
		model.addAttribute("selectedAgencyName", this.selectedAgency);
		model.addAttribute("JsoncheckboxRecordsObject", json);
		
		return ApplicationConstants.SEARCH;
	}

	/*
	 * This method has been used to display checkbox hit report based on agency name.
	 */
	@RequestMapping(value = "/searchUsers", method = RequestMethod.POST, params={"search"})
	public String searchUsers(@RequestParam(value = "selectedAgencyName") String selectedAgencyName, Model model) throws Exception {
		logger.info("Displaying checkboxhit report based on selected agency name :"+selectedAgencyName);
		this.selectedAgency = selectedAgencyName;
		try {
			return this.search(model);
		} catch (ServiceException e) {
			logger.error("ERROR : " + e.getMessage());
			throw new Exception(e.getMessage());
		} catch (Exception e) {
			logger.error("ERROR : " + e.getMessage());
			throw new Exception(e.getMessage());
		}
	}

	/*
	 * This method has been used to Handle request to download Excel document
	 */
	@RequestMapping(value = "/searchUsers", method = RequestMethod.POST, params={"download"})
	public ModelAndView downloadExcel(@RequestParam(value = "selectedAgencyName") String selectedAgencyName,
			Model model) throws Exception {
		logger.info("Download checkboxhit report");
		session.setAttribute("selectedAgencyName", selectedAgencyName);
		
		try {
			return new ModelAndView("excelView", "listOfCheckboxHitRecords", prosService.getUserHistory(selectedAgencyName));
		} catch (ServiceException e) {
			logger.error("ERROR : " + e.getMessage());
			throw new Exception(e.getMessage());
		} catch (Exception e) {
			logger.error("ERROR : " + e.getMessage());
			throw new Exception(e.getMessage());
		}
	}

	/*
	 * This method has been used to Handle request to download Excel document for Campaign and Pinney Report
	 */
	@RequestMapping(value = "/campaignReport", method = RequestMethod.POST, params={"download"})
	public ModelAndView downloadCampaignreport(Model model) throws Exception {
		logger.info("Download campaign report");
		
		try {
			return new ModelAndView("reportView", "campaignReport", prosService.getCampaignReport());
		} catch (ServiceException e) {
			logger.error("ERROR : " + e.getMessage());
			throw new Exception(e.getMessage());
		} catch (Exception e) {
			logger.error("ERROR : " + e.getMessage());
			throw new Exception(e.getMessage());
		}
	}
}