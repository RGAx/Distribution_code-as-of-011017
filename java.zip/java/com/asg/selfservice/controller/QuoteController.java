package com.asg.selfservice.controller;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.asg.selfservice.common.logger.LogFactory;
import com.asg.selfservice.common.logger.SelfServiceLogger;
import com.asg.selfservice.common.utils.ApplicationConstants;
import com.asg.selfservice.domain.Quote;
import com.asg.selfservice.domain.UserProfile;
import com.asg.selfservice.exception.ServiceException;
import com.asg.selfservice.services.ProfileService;
import com.asg.selfservice.services.QuoteService;

/**
 * This class has been used for implementing the quotes operation such as 
 * loading the quote page with all the 3 quotes, updating the selected quote into the db
 * and updating the policy info back into the DB.
 * 
 * @author M1030133
 *
 */
@Controller
public class QuoteController {
	private static final SelfServiceLogger logger = LogFactory.getInstance(QuoteController.class);
	
	@Autowired
	private QuoteService quoteService;
	
	@Autowired
	private HttpSession session;
	
	@Autowired
    private ServletContext context;
	
	@Autowired
	private ProfileService profileService;
	
	@ModelAttribute("userProfile")
	public UserProfile createUserProfileModel() {
		return new UserProfile();
	}
	
	/*
	 * This method has been used for loading the quote page with the all 3 quotes got from 
	 * EBIX response.
	 */
	@RequestMapping("/"+ApplicationConstants.QUOTE)
	public ModelAndView loadQuotes() throws Exception {
		final long startTime = logger.logMethodEntry();
		
		if (session.getAttribute("sessionUser") == null
				|| (session.getAttribute(ApplicationConstants.PAGE_FROM) != ApplicationConstants.TREATMENT
						&& session.getAttribute(ApplicationConstants.PAGE_FROM) != ApplicationConstants.APPLICATION
						&& session.getAttribute(ApplicationConstants.PAGE_FROM) != ApplicationConstants.EMAIL
						&& session.getAttribute(ApplicationConstants.PAGE_FROM) != ApplicationConstants.PROFILE)) {
			return new ModelAndView("redirect:" + ApplicationConstants.LOGIN + ".html");
		}
		if(session.getAttribute(ApplicationConstants.PAGE_FROM) != ApplicationConstants.PROFILE)
			session.setAttribute(ApplicationConstants.PAGE_FROM, ApplicationConstants.PAGE_FROM);
		
		UserProfile userProfile = (UserProfile) session.getAttribute("sessionUser");
		ModelAndView model = new ModelAndView(ApplicationConstants.QUOTE);
		
		logger.logMethodExit(startTime);
		try {
			model = quoteService.loadQuotes(model, userProfile);
			//model.addObject("selectedQuote", session.getAttribute("selectedQuote"));
			return model;
		} catch(ServiceException e) {
			logger.error("ERROR : "+e.getMessage());
			throw new Exception(e.getMessage());
		} catch (Exception e) {
			logger.error("ERROR : " + e.getMessage());
			throw new Exception(e.getMessage());
		}
	}
	
	/*
	 * This method has been used for managing the quote page such as updating the 
	 * quote infos into the DB.
	 */
	@RequestMapping(value="/"+ApplicationConstants.QUOTE, method = RequestMethod.POST, params="buttonClick")
	public String manageQuotePage(@ModelAttribute("quote") Quote quote, @RequestParam String buttonClick) throws Exception{
		final long startTime = logger.logMethodEntry();
		
		session.setAttribute(ApplicationConstants.PAGE_FROM, ApplicationConstants.QUOTE);
		if(session.getAttribute("sessionUser") == null) {
			return "redirect:login.html";
		}
		UserProfile userProfile = (UserProfile) session.getAttribute("sessionUser");
		if("next".equalsIgnoreCase(buttonClick) && userProfile.getProfileStatusFlag() > 2) {
			return "redirect:"+ApplicationConstants.APPLICATION+".html";
		}
		try {
			if("back".equalsIgnoreCase(buttonClick)) {
				session.setAttribute(ApplicationConstants.AJAX_PAGE_FROM, ApplicationConstants.AJAX_PAGE_CALL);
				return "redirect:treatment.html";
			} else if("needMoreTime".equalsIgnoreCase(buttonClick)) {
				userProfile = profileService.saveUserProfile(userProfile);
				session.setAttribute("sessionUser", userProfile);
				return "redirect:"+ApplicationConstants.CUSTOMERCALLBACK+".html";
			}
			quoteService.updateQuote(Integer.parseInt(buttonClick), userProfile);
		} catch (ServiceException e) {
			logger.error("ERROR : " + e.getMessage());
			throw new Exception(e.getMessage());
		} catch (Exception e) {
			logger.error("ERROR : " + e.getMessage());
			throw new Exception(e.getMessage());
		}
		logger.logMethodExit(startTime);
		return "redirect:"+ApplicationConstants.APPLICATION+".html";
	}	
	
	/*
	 * This method has been used for updating the policy info into the DB.
	 */
	@RequestMapping(value="updateQuote", method = RequestMethod.POST)
	public String updatePolicy(@ModelAttribute("userProfile") UserProfile userProfile) throws Exception {
		final long startTime = logger.logMethodEntry();
		
		session.setAttribute(ApplicationConstants.PAGE_FROM, ApplicationConstants.TREATMENT);
		
		if(session.getAttribute("sessionUser") == null) {
			return "redirect:login.html";
		}
		ModelAndView model = new ModelAndView(ApplicationConstants.QUOTE);
		try {
			UserProfile sessionUser = (UserProfile) session.getAttribute("sessionUser");
			sessionUser = quoteService.updatePolicy(userProfile, sessionUser);
			session.setAttribute("sessionUser", sessionUser);
			quoteService.loadQuotes(model, sessionUser);
		} catch(ServiceException e) {
			logger.error("ERROR : "+e.getMessage());
			throw new Exception(e.getMessage());
		} catch (Exception e) {
			logger.error("ERROR : " + e.getMessage());
			throw new Exception(e.getMessage());
		}
		logger.logMethodExit(startTime);
		return "redirect:"+ApplicationConstants.QUOTE+".html";
	}
}
