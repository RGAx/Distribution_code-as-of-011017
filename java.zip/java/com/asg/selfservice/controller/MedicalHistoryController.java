package com.asg.selfservice.controller;

/**
 * 
 * This controller has been used for implementing the Cholestrol,BP,Family functionalities such as loading the
 * Health2 page with the updated DB details, updating the Health2 details into the DB which the user has 
 * entered from the UI before proceeding into the next page.
 * 
 * @return 
 * Navigate to corresponding view based on called event
 * 
 * @author 1029563
 *
 */
import java.util.List;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.asg.selfservice.common.logger.LogFactory;
import com.asg.selfservice.common.logger.SelfServiceLogger;
import com.asg.selfservice.common.utils.ApplicationConstants;
import com.asg.selfservice.domain.MedicalHistoryAnswer;
import com.asg.selfservice.domain.Question;
import com.asg.selfservice.domain.UserProfile;
import com.asg.selfservice.exception.ServiceException;
import com.asg.selfservice.services.HealthService;
import com.asg.selfservice.services.MedicalHistoryService;
import com.asg.selfservice.services.ProfileService;
import com.asg.selfservice.services.impl.EBIXServiceImpl;

@Controller
public class MedicalHistoryController {
	
	private static final SelfServiceLogger logger = LogFactory.getInstance(MedicalHistoryController.class);
	
	@Autowired
	private MedicalHistoryService medicalhistoryService;
	
	@Autowired
	private HttpSession session;

	@Autowired
	private ServletContext context;
	
	@Autowired
	private HealthService healthService;
	
	@Autowired
	private ProfileService profileService;
	
	@Autowired
	private EBIXServiceImpl ebixService;
	
	@ModelAttribute("userProfile")
	public UserProfile createUserProfileModel() {
		return new UserProfile();
	}
	
	/*
	 * This method is used to construct Model object with all the medical details fetched from DB
	 * @param 
	 * @return Model Attributes Navigate to medical profile view
	 */
	@RequestMapping("/"+ApplicationConstants.MEDICAL_PROFILE)
	public String loadmedicalInfo(Model model) throws Exception{
		
		logger.info("In Loading Cholestrol Details");
		
		List<String> cholestrolLevels = null;
		List<String> hdlratios = null,syspressureLevels = null,diaspressureLevels = null;
		List<Question> medicalhistoryQuestion=null;
		MedicalHistoryAnswer medicalHistoryAnswer = null;
		UserProfile userProfile = null;
		int userId=0;
		
		try {
			if (session.getAttribute("sessionUser") == null
					|| (session.getAttribute(ApplicationConstants.PAGE_FROM) != ApplicationConstants.SMOKING
					&& session.getAttribute(ApplicationConstants.PAGE_FROM) != ApplicationConstants.FAMILY
					&& session.getAttribute(ApplicationConstants.PAGE_FROM) != ApplicationConstants.EMAIL
					&& session.getAttribute(ApplicationConstants.PAGE_FROM) != ApplicationConstants.PROFILE)) {
				return "redirect:"+ApplicationConstants.LOGIN+".html";
			}
			if(session.getAttribute(ApplicationConstants.PAGE_FROM) != ApplicationConstants.PROFILE)
				session.setAttribute(ApplicationConstants.PAGE_FROM, ApplicationConstants.PAGE_FROM);
			
			userProfile = (UserProfile) session.getAttribute("sessionUser");
			userId = userProfile.getUserId();
			
			medicalHistoryAnswer = medicalhistoryService.loadMedicalInfo(userId, ApplicationConstants.medicalhistoryQuestionSetID);
			medicalhistoryQuestion = medicalhistoryService.loadQuestions();
			cholestrolLevels = medicalhistoryService.loadcholestrolLevels(ApplicationConstants.QuestionIDForcholestrolLevel);
			hdlratios  = medicalhistoryService.loadhdlRatios(ApplicationConstants.QuestionIDForhdlLevel);
			syspressureLevels = medicalhistoryService.loadsystolicpressureLevels(ApplicationConstants.QuestionID_bp_syspressureLevel);
			diaspressureLevels = medicalhistoryService.loaddiastolicpressureLevels(ApplicationConstants.QuestionID_bp_diaspressureLevel);
			
		} catch (ServiceException e) {
			logger.error("ERROR : " + e.getMessage());
			throw new Exception(e.getMessage());
		}
		catch(Exception e){
			logger.error("ERROR : " + e.getMessage());
			throw new Exception(e.getMessage());
		}
		
		model.addAttribute("medicalprofile",medicalHistoryAnswer);
		model.addAttribute("medicalquestionsList", medicalhistoryQuestion);
		model.addAttribute("cholestrollevels",cholestrolLevels);
		model.addAttribute("hdlratioslevel",hdlratios);
		model.addAttribute("syspressurelevels",syspressureLevels);
		model.addAttribute("diastolicpressurelevels",diaspressureLevels);
		model.addAttribute("userProfile", userProfile);
		model.addAttribute("selectedQuote", session.getAttribute("selectedQuote"));
		
		return ApplicationConstants.MEDICAL_PROFILE;
	}
	/*
	 * This method is used to Save/Update details in to DB
	 * @param MedicalHistoryAnswer domain class containing cholestrol,BP details
	 * @throws BaseException
	 */
	@RequestMapping(value="/"+ApplicationConstants.MEDICAL_PROFILE,method = RequestMethod.POST,params={"action"})
	public String saveUpdateMedicalInfo(@ModelAttribute("MedicalHistoryAnswer") MedicalHistoryAnswer medicalHistoryAnswer,@RequestParam("action")String action) throws Exception{
		logger.info("In Save Service");
		UserProfile userProfile = null;
		
		session.setAttribute(ApplicationConstants.PAGE_FROM, ApplicationConstants.MEDICAL_PROFILE);
		try {
			if(null != session.getAttribute("sessionUser") && !"".equals(session.getAttribute("sessionUser"))){
				userProfile = (UserProfile) session.getAttribute("sessionUser");
				
			}
			else{
				return "redirect:"+ApplicationConstants.LOGIN+".html";
			}
			if("next".equalsIgnoreCase(action) && userProfile.getProfileStatusFlag() > 2) {
				return "redirect:"+ApplicationConstants.FAMILY+".html";
			}
			if(null != action && action.equalsIgnoreCase("back")){
				String page = healthService.loadTobaccoPageBasedOnUserAnswer(userProfile);
				if(page != null && ApplicationConstants.HEALTH.equalsIgnoreCase(page)) {
					session.setAttribute(ApplicationConstants.PAGE_FROM, ApplicationConstants.SMOKING);
				}
				session.setAttribute(ApplicationConstants.AJAX_PAGE_FROM, ApplicationConstants.AJAX_PAGE_CALL);
				return "redirect:"+page+".html";
			}
			if (null != medicalHistoryAnswer) {
				medicalhistoryService.saveUpdateMedicalInfo(userProfile, medicalHistoryAnswer);
			}
			if(null != action && action.equalsIgnoreCase("save")){
				userProfile = profileService.saveUserProfile(userProfile);
				session.setAttribute("sessionUser", userProfile);
			}
		} catch (ServiceException e) {
			logger.error("ERROR : " + e.getMessage());
			throw new Exception(e.getMessage());
		} catch (Exception e) {
			logger.error("ERROR : " + e.getMessage());
			throw new Exception(e.getMessage());
		}

		if ("next".equalsIgnoreCase(action)) {			
			
			return "redirect:"+ApplicationConstants.FAMILY+".html";
		}
		return "redirect:"+ApplicationConstants.CUSTOMERCALLBACK+".html";
	}
	
}
