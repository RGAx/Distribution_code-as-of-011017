package com.asg.selfservice.controller.pinney;

import com.asg.selfservice.domain.pinney.Client;

public class PinneyClient {

	private int userId;
	private Client crm_connection;
	private String response;

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public Client getCrm_connection() {
		return crm_connection;
	}

	public void setCrm_connection(Client crm_connection) {
		this.crm_connection = crm_connection;
	}

	public String getResponse() {
		return response;
	}

	public void setResponse(String response) {
		this.response = response;
	}
}
