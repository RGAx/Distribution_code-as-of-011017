package com.asg.selfservice.controller;

/************
 * 
 * @author M1029563
 * 
 * Application controller class has been used to implement application details data saved in to the USER_QUESTON_ANSWER TABLE IN THE DB and retrieving details from the DB
 * with user entered details. 
 *
 */
import java.util.List;
import java.util.Map;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.asg.selfservice.common.logger.LogFactory;
import com.asg.selfservice.common.logger.SelfServiceLogger;
import com.asg.selfservice.common.utils.ApplicationConstants;
import com.asg.selfservice.domain.Question;
import com.asg.selfservice.domain.Quote;
import com.asg.selfservice.domain.UserApplicationDetail;
import com.asg.selfservice.domain.UserProfile;
import com.asg.selfservice.exception.ServiceException;
import com.asg.selfservice.services.ApplicationService;
import com.asg.selfservice.services.ProfileService;

@Controller
public class ApplicationController {
	
	private static final SelfServiceLogger logger = LogFactory.getInstance(ApplicationController.class);
	
	@Autowired
	private ApplicationService appService;
	
	@Autowired
    private ServletContext context;
	
	@Autowired
	private HttpSession session;
	
	@Autowired
	private ProfileService profileService;
	
	@ModelAttribute("userProfile")
	public UserProfile createUserProfileModel() {
		return new UserProfile();
	}
	
	/*
	 * This method is used to load Application Page with the application data saved in the DB
	 * @param model contains model attribute with all the details of Application related questions,Answers,states,relationships,User Application details.
	 * @return Application views
	 * @throws ServiceException and BaseException
	 */
	@RequestMapping("/"+ApplicationConstants.APPLICATION)
	public String applicationPage(Model model) throws Exception{
		
		Map<Integer,String> userappDetails= null;
		List<String> relationships=null;
		List<String> reasoninsurance=null;
		List<String> paymentperiod=null;
		List<String> percentages =null;
		Quote quote = null;
		UserProfile userProfile = null;
		int userId=0;
		
		List<Question> applicationQuestion;
		
		if (session.getAttribute("sessionUser") == null
				|| (session.getAttribute(ApplicationConstants.PAGE_FROM) != ApplicationConstants.QUOTE
						&& session.getAttribute(ApplicationConstants.PAGE_FROM) != ApplicationConstants.MEDICALCONDITIONS
						&& session.getAttribute(ApplicationConstants.PAGE_FROM) != ApplicationConstants.EMAIL
						&& session.getAttribute(ApplicationConstants.PAGE_FROM) != ApplicationConstants.PROFILE)) {
			return "redirect:" + ApplicationConstants.LOGIN + ".html";
		}
		if(session.getAttribute(ApplicationConstants.PAGE_FROM) != ApplicationConstants.PROFILE)
			session.setAttribute(ApplicationConstants.PAGE_FROM, ApplicationConstants.PAGE_FROM);
		
		if(null != session.getAttribute("selectedQuote") && !"".equals(session.getAttribute("selectedQuote"))){
			
			quote = (Quote) session.getAttribute("selectedQuote");
		}
		if(null != session.getAttribute("sessionUser") && !"".equals(session.getAttribute("sessionUser"))){
			
			userProfile = (UserProfile) session.getAttribute("sessionUser");
			userId = userProfile.getUserId();
		}
		logger.info("Retrieving Application details Page");
		try{
			applicationQuestion = appService.loadQuestions();
			relationships = appService.getrelations(ApplicationConstants.QuestionID_Beneficiary_RelationShips);
			reasoninsurance = appService.getreasonForInsurance(ApplicationConstants.QuestionID_Reason_Insurance);
			paymentperiod = appService.getpaymentPeriod(ApplicationConstants.QuestionID_Pref_Payment_Period);
			percentages = appService.getPercentages(ApplicationConstants.QuestionID_Beneficiary_Percentages);
			userappDetails = appService.loadApplicationInfo(userId,ApplicationConstants.applicationQuestionSetID);
		}
		catch (ServiceException e) {
			logger.error("ERROR : " + e.getMessage());
			throw new Exception(e.getMessage());
		}
		catch(Exception e){
			logger.error("ERROR : " + e.getMessage());
			throw new Exception(e.getMessage());
		}
		
		model.addAttribute("userappMap", userappDetails);
		model.addAttribute("applicationQuestions", applicationQuestion);
		model.addAttribute("relationships", relationships);
		model.addAttribute("percentages", percentages);
		model.addAttribute("reasonInsurances", reasoninsurance);
		model.addAttribute("paymentPeriods", paymentperiod);
		model.addAttribute("quote", quote);
		model.addAttribute("userProfile", userProfile);
		model.addAttribute("selectedQuote", session.getAttribute("selectedQuote"));
		
		return ApplicationConstants.APPLICATION;
		
	}

	/*
	 * This method is used to save data in to DB with user entered application details
	 * @param userappDetail POJO contains user application details
	 * @return 
	 * @throws BaseException
	 * @throws ServiceException
	 */
	@RequestMapping(value ="/"+ApplicationConstants.APPLICATION,params={"action"},method = RequestMethod.POST)
	public String saveapplicationDetails(@ModelAttribute("userapplicationForm") UserApplicationDetail userappDetail,@RequestParam("action")String action) throws Exception{
			
		logger.info("In Save Service");
		UserProfile userProfile=null;
		
		session.setAttribute(ApplicationConstants.PAGE_FROM, ApplicationConstants.APPLICATION);
		
		if("back".equalsIgnoreCase(action)){
			return "redirect:"+ApplicationConstants.QUOTE+".html";
		}

		if(null  != session.getAttribute("sessionUser") && !"".equals(session.getAttribute("sessionUser"))){
			
			userProfile = (UserProfile) session.getAttribute("sessionUser");
			if("next".equalsIgnoreCase(action) && userProfile.getProfileStatusFlag() > 2) {
				return "redirect:"+ApplicationConstants.MEDICALCONDITIONS+".html";
			}
			if(null != userappDetail){
				try{
					appService.saveUpdateApplicationInfo(userProfile,userappDetail);
					if(null != action && action.equalsIgnoreCase("save")){
						userProfile = profileService.saveUserProfile(userProfile);
						session.setAttribute("sessionUser", userProfile);
					}
				}
				catch (ServiceException e) {
					logger.error("ERROR : " + e.getMessage());
					throw new Exception(e.getMessage());
				}
				catch(Exception e){
					logger.error("ERROR : " + e.getMessage());
					throw new Exception(e.getMessage());
				}
			}
		}
		else{
			return "redirect:"+ApplicationConstants.LOGIN+".html";
		}

		if("next".equalsIgnoreCase(action)){
			return "redirect:"+ApplicationConstants.MEDICALCONDITIONS+".html";
		}

		return "redirect:"+ApplicationConstants.CUSTOMERCALLBACK+".html";
	}
}
