/**
 * 
 */
package com.asg.selfservice.controller;

import java.util.List;
import java.util.Map;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.asg.selfservice.common.logger.LogFactory;
import com.asg.selfservice.common.logger.SelfServiceLogger;
import com.asg.selfservice.common.utils.ApplicationConstants;
import com.asg.selfservice.domain.FamilyAnswer;
import com.asg.selfservice.domain.Question;
import com.asg.selfservice.domain.UserProfile;
import com.asg.selfservice.exception.ServiceException;
import com.asg.selfservice.services.FamilyService;
import com.asg.selfservice.services.ProfileService;
import com.asg.selfservice.services.impl.EBIXServiceImpl;

/**
 * This controller has been used for implementing the Family functionalities such as loading the
 * Family page with the updated DB details, updating the Family details into the DB which the user has 
 * entered from the UI before proceeding into the next page.
 * 
 * @return 
 * Navigate to corresponding view based on called event
 * 
 * @author M1029563
 *
 */
@Controller
public class FamilyController {
	
	private static final SelfServiceLogger logger = LogFactory.getInstance(FamilyController.class);
	
	@Autowired
	private FamilyService familyService;
	
	@Autowired
	private HttpSession session;

	@Autowired
	private ServletContext context;
	
	@Autowired
	private ProfileService profileService;
	
	@Autowired
	private EBIXServiceImpl ebixService;
	
	@ModelAttribute("userProfile")
	public UserProfile createUserProfileModel() {
		return new UserProfile();
	}
	
	/*
	 * This method is used to construct Model object with all the Family details fetched from DB
	 * @param 
	 * @return Model Attributes Navigate to Family view
	 */
	@RequestMapping("/"+ApplicationConstants.FAMILY)
	public String loadFamilyInfo(Model model) throws Exception{	
		
		logger.info("Loading Family History Details");
		
		List<Question> familyQuestions = null;
		List<String> ages = null;
		List<String> relations = null;
		
		UserProfile userProfile = null;
		Map<Integer,String> familyAnswer = null;
		int userId=0;
		
		try {
			if (session.getAttribute("sessionUser") == null
					|| (session.getAttribute(ApplicationConstants.PAGE_FROM) != ApplicationConstants.MEDICAL_PROFILE
					&& session.getAttribute(ApplicationConstants.PAGE_FROM) != ApplicationConstants.DRIVING
					&& session.getAttribute(ApplicationConstants.PAGE_FROM) != ApplicationConstants.EMAIL
					&& session.getAttribute(ApplicationConstants.PAGE_FROM) != ApplicationConstants.PROFILE)) {
				return "redirect:"+ApplicationConstants.LOGIN+".html";
			}
			if(session.getAttribute(ApplicationConstants.PAGE_FROM) != ApplicationConstants.PROFILE)
				session.setAttribute(ApplicationConstants.PAGE_FROM, ApplicationConstants.PAGE_FROM);

			userProfile = (UserProfile) session.getAttribute("sessionUser");
			userId = userProfile.getUserId();
			
			familyQuestions = familyService.loadfamilyhistoryQuestions();
			ages  = familyService.loadages(ApplicationConstants.QuestionID_Family_Ages);
			relations = familyService.loadrelationShips(ApplicationConstants.QuestionID_Family_Relations);
			familyAnswer = familyService.loadfamilyPage(userId, ApplicationConstants.familyhistoryQuestionSetID);
			
		} catch (ServiceException e) {
			logger.error("ERROR : " + e.getMessage());
			throw new Exception(e.getMessage());
		}
		catch(Exception e){
			logger.error("ERROR : " + e.getMessage());
			throw new Exception(e.getMessage());
		}
		logger.info(userId);
		
		model.addAttribute("Ages", ages);
		model.addAttribute("familyhistroyQuestion", familyQuestions);
		model.addAttribute("relationShips", relations);
		model.addAttribute("family", familyAnswer);
		model.addAttribute("userProfile", userProfile);
		model.addAttribute("selectedQuote", session.getAttribute("selectedQuote"));
		
		return ApplicationConstants.FAMILY;
	}
	
	/*
	 * This method is used to Save/Update details in to DB
	 * @param FamilyAnswer domain class containing Family details
	 * @throws BaseException
	 */
	@RequestMapping(value="/"+ApplicationConstants.FAMILY,method=RequestMethod.POST,params={"action"})
	public String saveUpdateFamilyInfo(@ModelAttribute("family") FamilyAnswer familyAnswer,@RequestParam("action") String action) throws Exception{
		
		logger.info("In Save Service");
		UserProfile userProfile=null;

		session.setAttribute(ApplicationConstants.PAGE_FROM, ApplicationConstants.FAMILY);
		if(null != action && action.equalsIgnoreCase("back")){
			session.setAttribute(ApplicationConstants.AJAX_PAGE_FROM, ApplicationConstants.AJAX_PAGE_CALL);
			return "redirect:"+ApplicationConstants.MEDICAL_PROFILE+".html";
		}
		if(null != session.getAttribute("sessionUser") && !"".equals(session.getAttribute("sessionUser"))){
			userProfile = (UserProfile) session.getAttribute("sessionUser");
		}
		else{
			return "redirect:"+ApplicationConstants.LOGIN+".html";
		}
		if("next".equalsIgnoreCase(action) && userProfile.getProfileStatusFlag() > 2) {
			return "redirect:"+ApplicationConstants.DRIVING+".html";
		}
		try{
			if(null != familyAnswer){

				familyService.saveUpdateFamilyInfo(userProfile,familyAnswer);
			}
			if(null != action && action.equalsIgnoreCase("save")){
				userProfile = profileService.saveUserProfile(userProfile);
				session.setAttribute("sessionUser", userProfile);
			}
			
		}
		catch (ServiceException e) {
			logger.error("ERROR : " + e.getMessage());
			throw new Exception(e.getMessage());
		}
		catch(Exception e){
			logger.error("ERROR : " + e.getMessage());
			throw new Exception(e.getMessage());
		}

		if("next".equalsIgnoreCase(action)){
						
			return "redirect:"+ApplicationConstants.DRIVING+".html";
		}

		return "redirect:"+ApplicationConstants.CUSTOMERCALLBACK+".html";
			
	}

}
