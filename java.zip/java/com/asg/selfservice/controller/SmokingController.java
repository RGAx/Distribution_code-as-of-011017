package com.asg.selfservice.controller;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.asg.selfservice.common.logger.LogFactory;
import com.asg.selfservice.common.logger.SelfServiceLogger;
import com.asg.selfservice.common.utils.ApplicationConstants;
import com.asg.selfservice.domain.Smoking;
import com.asg.selfservice.domain.UserProfile;
import com.asg.selfservice.exception.ServiceException;
import com.asg.selfservice.services.ProfileService;
import com.asg.selfservice.services.SmokingService;
import com.asg.selfservice.services.impl.EBIXServiceImpl;

/**
 * This controller has been used for implementing the tobacco(smoking) functionalities
 * such as loading the tobacco page with the updated DB details, updating the
 * tobacco info into the DB which the user has entered from the UI before
 * proceeding into the next page.
 * 
 * @author M1030133
 *
 */
@Controller
public class SmokingController {

	private static final SelfServiceLogger logger = LogFactory.getInstance(SmokingController.class);

	@Autowired
	private SmokingService smokingService;
	
	@Autowired
	private ProfileService profileService;

	@Autowired
	private HttpSession session;

	@Autowired
	private ServletContext context;
	
	@Autowired
	private EBIXServiceImpl ebixService;
	
	@ModelAttribute("userProfile")
	public UserProfile createUserProfileModel() {
		return new UserProfile();
	}
	
	/*
	 * This method has been used for loading the tobacco(smoking) page based on the
	 * request url. Before loading the page the user session availability has
	 * been checked
	 */
	@RequestMapping(value = "/smoking")
	public ModelAndView loadSmokingInfo() throws Exception {
		final long startTime = logger.logMethodEntry();

		if (session.getAttribute("sessionUser") == null
				|| (session.getAttribute(ApplicationConstants.PAGE_FROM) != ApplicationConstants.HEALTH
						&& session.getAttribute(ApplicationConstants.PAGE_FROM) != ApplicationConstants.MEDICAL_PROFILE
						&& session.getAttribute(ApplicationConstants.PAGE_FROM) != ApplicationConstants.EMAIL
						&& session.getAttribute(ApplicationConstants.PAGE_FROM) != ApplicationConstants.PROFILE)) {
			return new ModelAndView("redirect:" + ApplicationConstants.LOGIN + ".html");
		}
		if(session.getAttribute(ApplicationConstants.PAGE_FROM) != ApplicationConstants.PROFILE)
			session.setAttribute(ApplicationConstants.PAGE_FROM, ApplicationConstants.PAGE_FROM);
		
		UserProfile userProfile = (UserProfile) session.getAttribute("sessionUser");
		ModelAndView model = new ModelAndView("smoking");
		try {
			model = smokingService.loadSmokingInfo(model, userProfile);
			model.addObject("selectedQuote", session.getAttribute("selectedQuote"));
		} catch (ServiceException e) {
			logger.error("ERROR : " + e.getMessage());
			throw new Exception(e.getMessage());
		} catch (Exception e) {
			logger.error("ERROR : " + e.getMessage());
			throw new Exception(e.getMessage());
		}
		logger.logMethodExit(startTime);
		return model;
	}
	
	/*
	 * This method has been used for updating the tobacco(smoking) informations.
	 */
	@RequestMapping(value = "/smoking", method = RequestMethod.POST, params = "requestParam")
	public String saveUpdateSmokingInfo(@ModelAttribute("smoking") Smoking smoking,
			@RequestParam String requestParam) throws Exception {
		final long startTime = logger.logMethodEntry();

		session.setAttribute(ApplicationConstants.PAGE_FROM, ApplicationConstants.SMOKING);
		
		if(session.getAttribute("sessionUser") == null) {
			return "redirect:login.html";
		} else if("back".equalsIgnoreCase(requestParam)) {
			session.setAttribute(ApplicationConstants.AJAX_PAGE_FROM, ApplicationConstants.AJAX_PAGE_CALL);
			logger.logMethodExit(startTime);
			return "redirect:health.html";
		}
		UserProfile userProfile = (UserProfile) session.getAttribute("sessionUser");
		if("next".equalsIgnoreCase(requestParam) && userProfile.getProfileStatusFlag() > 2) {
			return "redirect:medicalprofile.html";
		}
		try {
			smokingService.saveUpdateSmokingInfo(userProfile, smoking);
			
			if("save".equalsIgnoreCase(requestParam)) {
				userProfile = profileService.saveUserProfile(userProfile);
				session.setAttribute("sessionUser", userProfile);
				
				logger.logMethodExit(startTime);
				return "redirect:"+ApplicationConstants.CUSTOMERCALLBACK+".html";
			} else {
				
				logger.logMethodExit(startTime);
				return "redirect:medicalprofile.html";
			}
		} catch (ServiceException e) {
			logger.error("ERROR : " + e.getMessage());
			throw new Exception(e.getMessage());
		} catch (Exception e) {
			logger.error("ERROR : " + e.getMessage());
			throw new Exception(e.getMessage());
		}
	}
}
