package com.asg.selfservice.controller;

/*****
 * @author M1029563
 * MedicalConditionsController class is used to submit the application when details to Pinney part by saving the details of Medical Conditions Page and prepopulate the
 * fields when user relaunches the page while login to selfservicePortal
 */
import javax.servlet.ServletContext;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.asg.selfservice.common.logger.LogFactory;
import com.asg.selfservice.common.logger.SelfServiceLogger;
import com.asg.selfservice.common.utils.ApplicationConstants;
import com.asg.selfservice.domain.MedicalConditionsAnswer;
import com.asg.selfservice.domain.UserProfile;
import com.asg.selfservice.exception.ServiceException;
import com.asg.selfservice.pinney.services.impl.PinneyServiceHelperImpl;
import com.asg.selfservice.services.MedicalConditionsService;
import com.asg.selfservice.services.ProfileService;

@Controller
public class MedicalConditionsController {


	private static final SelfServiceLogger logger = LogFactory.getInstance(MedicalConditionsController.class);

	@Autowired
	private MedicalConditionsService medicalconditionsService;

	@Autowired
	private ServletContext context;

	@Autowired
	private HttpSession session;
	
	@Autowired
	private ProfileService profileService;
	
	@Autowired
	private PinneyServiceHelperImpl pinneyServiceHelperImpl;
	
	@ModelAttribute("userProfile")
	public UserProfile createUserProfileModel() {
		return new UserProfile();
	}
	
	/*
	 * This method is used to prepopulate the fields or saved data while user login again through selfserviceportal.
	 * @return returns Model object to respective view
	 * 
	 */
	@RequestMapping(value="/"+ApplicationConstants.MEDICALCONDITIONS)
	public ModelAndView loadMedicalConditionsSecondPage() throws Exception
	{
		if (session.getAttribute("sessionUser") == null
				|| (session.getAttribute(ApplicationConstants.PAGE_FROM) != ApplicationConstants.APPLICATION
						&& session.getAttribute(ApplicationConstants.PAGE_FROM) != ApplicationConstants.EMAIL
						&& session.getAttribute(ApplicationConstants.PAGE_FROM) != ApplicationConstants.PROFILE)) {
			return new ModelAndView("redirect:" + ApplicationConstants.LOGIN + ".html");
		}
		if(session.getAttribute(ApplicationConstants.PAGE_FROM) != ApplicationConstants.PROFILE)
			session.setAttribute(ApplicationConstants.PAGE_FROM, ApplicationConstants.PAGE_FROM);
		
		logger.info("Loading MEDICAL CONDITIONS SECOND page...");

		ModelAndView model = new ModelAndView(ApplicationConstants.MEDICALCONDITIONS);
		try{
			model=medicalconditionsService.loadMedicalConditionsPage(model);
			model.addObject("selectedQuote", session.getAttribute("selectedQuote"));
		}
		catch (ServiceException e) {
			logger.error("ERROR : " + e.getMessage());
			throw new Exception(e.getMessage());
		}
		catch(Exception e){
			logger.error("ERROR : " + e.getMessage());
			throw new Exception(e.getMessage());
		}

		return model;
	}	

	/*
	 * This method is used to save the medical conditions page details in to the User_Question_Answer Table.
	 * 
	 * @param Model Attribute MedicalConditionsAnswer
	 * @param RequestParam Respective action
	 * @return CustomerCallbackPage
	 * @see
	 */
	@RequestMapping(value="/"+ApplicationConstants.MEDICALCONDITIONS, method = RequestMethod.POST ,params="buttonClick")
	public String updateMedicalConditionsInfoPage(@ModelAttribute("medicalConditions") MedicalConditionsAnswer medicalConditions,@RequestParam String buttonClick) throws Exception {

		UserProfile userProfile = null;

		session.setAttribute(ApplicationConstants.PAGE_FROM, ApplicationConstants.MEDICALCONDITIONS);
		if(session.getAttribute("sessionUser") == null) {
			logger.info("End of MedicalConditions :: updateMedicalConditionsSecond : Session timed out");
			return "redirect:"+ApplicationConstants.LOGIN+".html";
		}

		else if(buttonClick.equalsIgnoreCase("back")) {

			return "redirect:"+ApplicationConstants.APPLICATION+".html";
		}

		else{
			if(null != session.getAttribute("sessionUser") && !"".equals(session.getAttribute("sessionUser")) ){

				userProfile = (UserProfile) session.getAttribute("sessionUser");
				UserProfile adminUser = (UserProfile) session.getAttribute("sessionAdminUser");
				boolean adminUserFlag = (adminUser != null && adminUser.getEmailAddress() != null 
						&& !adminUser.getEmailAddress().isEmpty()) ? true : false;

				if(null != medicalConditions) {
					try{
						medicalconditionsService.saveUpdateMedicalConditionsInfo(userProfile, medicalConditions);

						userProfile = profileService.saveUserProfile(userProfile);
						session.setAttribute("sessionUser", userProfile);
						
						if(buttonClick.equalsIgnoreCase("Submit Application")) {
							boolean pinneyStatus = pinneyServiceHelperImpl.pinneyRequest(userProfile);
							if(userProfile.getProfileStatusFlag()==ApplicationConstants.QUOTE_SUBMITTED_STATUS){
								userProfile.setProfileStatusFlag(pinneyStatus ? ApplicationConstants.APPLICATION_SUBMITTED_SUCCESS : ApplicationConstants.APPLICATION_SUBMITTED_FAILED);
								profileService.updateUserProfileStatusWithAdminCheck(userProfile, adminUserFlag);
							}
							medicalconditionsService.sendsubmittedapplicationNotificationMail(userProfile);
							
							return "redirect:customercallbacksecond.html";
						}
					}
					catch (ServiceException e) {
						logger.error("ERROR : " + e.getMessage());
						throw new Exception(e.getMessage());
					}
					catch (Exception e) {
						logger.error("ERROR : " + e.getMessage());
						throw new Exception(e.getMessage());
					}
				}					 
			}
		}		
		
		return "redirect:"+ApplicationConstants.CUSTOMERCALLBACK+".html";	
	}

}


