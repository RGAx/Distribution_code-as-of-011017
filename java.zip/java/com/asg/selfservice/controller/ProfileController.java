package com.asg.selfservice.controller;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.validation.Validator;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.asg.selfservice.common.logger.LogFactory;
import com.asg.selfservice.common.logger.SelfServiceLogger;
import com.asg.selfservice.common.utils.ApplicationConstants;
import com.asg.selfservice.common.utils.Utils;
import com.asg.selfservice.domain.UserProfile;
import com.asg.selfservice.exception.ServiceException;
import com.asg.selfservice.services.ProfileService;

/**
 * This controller class has been used for handling the user profile operations
 * such as loading the user profile infos, updating the user profile infos into
 * the DB etc.
 * 
 * @author M1030133
 *
 */
@Controller
public class ProfileController {

	private static final SelfServiceLogger logger = LogFactory.getInstance(ProfileController.class);

	@Autowired
	private HttpSession session;

	@Autowired
	private ServletContext context;
	
	@Autowired
	private ProfileService profileService;
	
	@Autowired
	@Qualifier("userValidator")
	private Validator validator;
	
	@InitBinder
	private void initBinder(WebDataBinder binder) {
		binder.setValidator(validator);
	}
	
	@ModelAttribute("userProfile")
	public UserProfile createUserProfileModel() {
		return new UserProfile();
	}
	
	/*
	 * This method has been used for updating the user profile details and 
	 * redirecting to the same page.
	 */
	@RequestMapping(value="/"+ApplicationConstants.PROFILE, method = RequestMethod.POST)
	public String updateUserProfileInfo(@ModelAttribute("userProfile") @Validated UserProfile userProfile, 
			BindingResult result, HttpServletRequest request) throws Exception {
		
		final long startTime = logger.logMethodEntry();
		
		session.setAttribute(ApplicationConstants.PAGE_FROM, ApplicationConstants.PROFILE);
		if(session.getAttribute("sessionUser") == null) {
			logger.info("End of WelcomeController :: updateUserProfile : Session timed out");
			return "redirect:login.html";
		} 
		String refererPage = this.loadRefererPage(request.getHeader("referer"));
		
		try {
			UserProfile sessionUser = (UserProfile) session.getAttribute("sessionUser");
			if(profileService.validateEmail(userProfile.getEmailAddress(), sessionUser)) {
				return "duplicateEmailId";
			}
			sessionUser.setEmailAddress(userProfile.getEmailAddress());
			sessionUser.setPhoneNumber(userProfile.getPhoneNumber());
			
			if(userProfile.getNewPassword() != null && !userProfile.getNewPassword().isEmpty()) {
				if(!Utils.passwordMatches(userProfile.getPassword(), sessionUser.getPassword())) {
					result.rejectValue("oldPwdErrMsg", "incorrectOldPassword.msg");
					logger.info("The entered old password is incorrect.");
					
					return "incorrectPassword";
				} else {
					sessionUser.setPassword(Utils.encryptPassword(userProfile.getNewPassword()));
					profileService.updateUserProfilePassword(sessionUser);
					session.setAttribute("sessionUser", sessionUser);
				}
			}
			profileService.updateUserProfileInfo(sessionUser);
		} catch (ServiceException e) {
			logger.error("ERROR : " + e.getMessage());
			throw new Exception(e.getMessage());
		} catch (Exception e) {
			logger.error("ERROR : " + e.getMessage());
			throw new Exception(e.getMessage());
		}
		logger.logMethodExit(startTime);
		return "redirect:"+refererPage+".html";
	}
	
	/*
	 * This is a private method to load the referrer page based on the request
	 * header referer parameter.
	 */
	private String loadRefererPage(String refererPage) {
		if(refererPage != null && !refererPage.isEmpty() && refererPage.lastIndexOf("/") > 0) {
			if(refererPage.lastIndexOf(".") > 0) {
				refererPage = refererPage.substring(refererPage.lastIndexOf("/") + 1, refererPage.lastIndexOf("."));
			} else {
				refererPage = refererPage.substring(refererPage.lastIndexOf("/") + 1, refererPage.length());
			}
		} else {
			refererPage = ApplicationConstants.HEALTH;
		}
		return refererPage;
	}
}
