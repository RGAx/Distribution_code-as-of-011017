package com.asg.selfservice.controller;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.asg.selfservice.common.logger.LogFactory;
import com.asg.selfservice.common.logger.SelfServiceLogger;
import com.asg.selfservice.common.utils.ApplicationConstants;
import com.asg.selfservice.domain.Health;
import com.asg.selfservice.domain.Prospect;
import com.asg.selfservice.domain.UserProfile;
import com.asg.selfservice.exception.ServiceException;
import com.asg.selfservice.services.HealthService;
import com.asg.selfservice.services.ProfileService;
import com.asg.selfservice.services.ProspectService;
import com.asg.selfservice.services.impl.EBIXServiceImpl;

/**
 * This controller has been used for implementing the tobacco(health) functionalities
 * such as loading the tobacco page with the updated DB details, updating the
 * tobacco info into the DB which the user has entered from the UI before
 * proceeding into the next page.
 * 
 * @author M1030133
 *
 */
@Controller
public class HealthController {

	private static final SelfServiceLogger logger = LogFactory.getInstance(HealthController.class);

	@Autowired
	private HealthService healthService;

	@Autowired
	private HttpSession session;

	@Autowired
	private ServletContext context;
	
	@Autowired
	private ProfileService profileService;
	
	@Autowired
	private ProspectService prosService;

	@Autowired
	private EBIXServiceImpl ebixService;
	
	@ModelAttribute("userProfile")
	public UserProfile createUserProfileModel() {
		return new UserProfile();
	}
	
	/*
	 * This method has been used for loading the tobacco(health) page based on the
	 * request url. Before loading the page the user session availability has
	 * been checked
	 */
	@RequestMapping(value = "/health")
	public ModelAndView loadHealthInfo() throws Exception {
		final long startTime = logger.logMethodEntry();

		if (session.getAttribute("sessionUser") == null
				|| (session.getAttribute(ApplicationConstants.PAGE_FROM) != ApplicationConstants.URL_CLICK
						&& session.getAttribute(ApplicationConstants.PAGE_FROM) != ApplicationConstants.LOGIN
						&& session.getAttribute(ApplicationConstants.PAGE_FROM) != ApplicationConstants.SMOKING
						&& session.getAttribute(ApplicationConstants.PAGE_FROM) != ApplicationConstants.EMAIL
						&& session.getAttribute(ApplicationConstants.PAGE_FROM) != ApplicationConstants.PROFILE
						&& session.getAttribute(ApplicationConstants.PAGE_FROM) != ApplicationConstants.NEW_LANDING_PAGE)) {
			return new ModelAndView("redirect:"+ApplicationConstants.LOGIN+".html");
		}
		if(session.getAttribute(ApplicationConstants.PAGE_FROM) != ApplicationConstants.PROFILE
				&& session.getAttribute(ApplicationConstants.PAGE_FROM) != ApplicationConstants.NEW_LANDING_PAGE)
			session.setAttribute(ApplicationConstants.PAGE_FROM, ApplicationConstants.PAGE_FROM);
		
		UserProfile userProfile = (UserProfile) session.getAttribute("sessionUser");
		ModelAndView model = new ModelAndView("health");
		try {
			session.setAttribute("questAnsUIdQSetIdSeqIdMap", null);
			
			model = healthService.loadHealthInfo(model, userProfile);
			model.addObject("selectedQuote", session.getAttribute("selectedQuote"));
			
			Prospect prospect = prosService.loadProspectData(userProfile.getEncryptedUid());
			session.setAttribute("agencyName", prospect != null ? prospect.getAgencyName() : "");
		} catch (ServiceException e) {
			logger.error("ERROR : " + e.getMessage());
			throw new Exception(e.getMessage());
		} catch (Exception e) {
			logger.error("ERROR : " + e.getMessage());
			throw new Exception(e.getMessage());
		}
		logger.logMethodExit(startTime);
		return model;
	}

	/*
	 * This method has been used for updating the tobacco(health) informations before
	 * loading the smoking page.
	 */
	@RequestMapping(value = "/health", method = RequestMethod.POST, params = "requestParam")
	public String saveUpdateHealthInfo(@ModelAttribute("health") Health health,
			@RequestParam String requestParam) throws Exception {
		final long startTime = logger.logMethodEntry();

		session.setAttribute(ApplicationConstants.PAGE_FROM, ApplicationConstants.HEALTH);
		if(session.getAttribute("sessionUser") == null) {
			return "redirect:login.html";
		}
		UserProfile userProfile = (UserProfile) session.getAttribute("sessionUser");
		if("next".equalsIgnoreCase(requestParam) && userProfile.getProfileStatusFlag() > 2) {
			Health dbhealth = healthService.constructHealthAnswer(userProfile, ApplicationConstants.healthQuestionSetID);
			
			if("1".equalsIgnoreCase(dbhealth.getHealthSeq6())) {
				return "redirect:smoking.html";
			} else {
				session.setAttribute(ApplicationConstants.PAGE_FROM, ApplicationConstants.SMOKING);
				return "redirect:medicalprofile.html";
			}
		}
		try {
			healthService.saveUpdateHealthInfo(userProfile, health);
			userProfile = profileService.updateUserProfileWithHealthDetails(userProfile, health);
			session.setAttribute("sessionUser", userProfile);
			
			if("save".equalsIgnoreCase(requestParam)) {
				userProfile = profileService.saveUserProfile(userProfile);
				session.setAttribute("sessionUser", userProfile);
				logger.logMethodExit(startTime);
				return "redirect:"+ApplicationConstants.CUSTOMERCALLBACK+".html";
			} else {
				
				if("1".equalsIgnoreCase(health.getHealthSeq6())) {
					logger.logMethodExit(startTime);
					return "redirect:smoking.html";
				} else {
					session.setAttribute(ApplicationConstants.PAGE_FROM, ApplicationConstants.SMOKING);
					logger.logMethodExit(startTime);
					return "redirect:medicalprofile.html";
				}
			}
		} catch (ServiceException e) {
			logger.error("ERROR : " + e.getMessage());
			throw new Exception(e.getMessage());
		} catch (Exception e) {
			logger.error("ERROR : " + e.getMessage());
			throw new Exception(e.getMessage());
		}
	}
}
