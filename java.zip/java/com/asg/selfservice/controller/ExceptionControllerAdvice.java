package com.asg.selfservice.controller;

import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.ModelAndView;

import com.asg.selfservice.common.utils.ApplicationConstants;
 
@ControllerAdvice
public class ExceptionControllerAdvice {
 
    @ExceptionHandler(Exception.class)
    public String exception(Exception e) {
        ModelAndView mav = new ModelAndView(ApplicationConstants.ERROR);
        mav.addObject("name", e.getClass().getSimpleName());
        mav.addObject("message", e.getMessage());
 
        return "redirect:"+ApplicationConstants.ERROR+".html";
    }
}