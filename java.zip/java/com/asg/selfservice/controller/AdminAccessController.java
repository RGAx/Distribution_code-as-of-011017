package com.asg.selfservice.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.asg.selfservice.common.logger.LogFactory;
import com.asg.selfservice.common.logger.SelfServiceLogger;
import com.asg.selfservice.common.utils.ApplicationConstants;
import com.asg.selfservice.domain.Prospect;
import com.asg.selfservice.domain.UserProfile;
import com.asg.selfservice.exception.ServiceException;
import com.asg.selfservice.services.AdminAccessService;
import com.asg.selfservice.services.HealthService;
import com.asg.selfservice.services.ProfileService;
import com.asg.selfservice.services.ProspectService;

/**
 * This controller has been used for the operations such as loading the admin
 * page where the admin user can search for the prospect user and can do the
 * further operation.
 * 
 * @author M1030133
 *
 */
@Controller
public class AdminAccessController {

	private static final SelfServiceLogger LOGGER = LogFactory
			.getInstance(AdminAccessController.class);

	@Autowired
	private AdminAccessService adminAccessService;

	@Autowired
	private HttpSession session;

	@Autowired
	private HealthService healthService;

	@Autowired
	private ProspectService prosService;

	@Autowired
	private ProfileService profileService;

	@RequestMapping("/" + ApplicationConstants.ADMIN_PAGE)
	public String loadAdminPage(Model m) throws Exception {
		if (session.getAttribute("sessionUser") == null
				|| session.getAttribute(ApplicationConstants.PAGE_FROM) != ApplicationConstants.LOGIN) {
			return "redirect:"+ApplicationConstants.LOGIN+".html";
		}
		return ApplicationConstants.ADMIN_PAGE;
	}

	/*
	 * This method has been used for loading the users based on the input email
	 * address provided.
	 */
	@RequestMapping(value = "/" + ApplicationConstants.ADMIN_PAGE, method = RequestMethod.POST)
	public ModelAndView searchUser(
			@RequestParam("emailAddress") String emailAddress) throws Exception {
		ModelAndView model = new ModelAndView(ApplicationConstants.ADMIN_PAGE);
		try {
			return adminAccessService.loadUsers(model, emailAddress);
		} catch (ServiceException e) {
			LOGGER.error("ERROR:" + e.getMessage());
			throw new Exception(e.getMessage());
		} catch (Exception e) {
			LOGGER.error("ERROR:" + e.getMessage());
			throw new Exception(e.getMessage());
		}
	}

	/*
	 * Used to load the health page.
	 */
	@RequestMapping(value = "/" + ApplicationConstants.ADMIN_HEALTH)
	public ModelAndView loadHealthPageFromAdmin(HttpServletRequest request)
			throws Exception {
		ModelAndView model = new ModelAndView(ApplicationConstants.HEALTH);

		String userId = request.getParameter("userId");
		if (userId == null || userId.isEmpty()) {
			return new ModelAndView(ApplicationConstants.ADMIN_PAGE);
		}
		try {
			UserProfile userProfile = profileService.loadUserProfileById(Integer.parseInt(userId));
			session.setAttribute("sessionUser", userProfile);
			session.setAttribute("questAnsUIdQSetIdSeqIdMap", null);

			model = healthService.loadHealthInfo(model, userProfile);
			model.addObject("selectedQuote",
					session.getAttribute("selectedQuote"));

			Prospect prospect = prosService.loadProspectData(userProfile
					.getEncryptedUid());
			session.setAttribute("agencyName",
					prospect != null ? prospect.getAgencyName() : "");
		} catch (ServiceException e) {
			LOGGER.error("ERROR : " + e.getMessage());
			throw new Exception(e.getMessage());
		} catch (Exception e) {
			LOGGER.error("ERROR : " + e.getMessage());
			throw new Exception(e.getMessage());
		}
		return model;
	}
}
