package com.asg.selfservice.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.asg.selfservice.common.logger.LogFactory;
import com.asg.selfservice.common.logger.SelfServiceLogger;
import com.asg.selfservice.domain.CustomerCallback;
import com.asg.selfservice.domain.UserProfile;
import com.asg.selfservice.exception.ServiceException;
import com.asg.selfservice.services.CustomerCallBackService;

/**
 * This controller class is used for fetching the customer callback details for thankyoupage
 * and thankyoupagesecond and to save the customer callback details into customer_callback table
 * 
 */
@Controller
public class CustomerCallbackController {	
	
	
	@Autowired
	private CustomerCallBackService callBackService;
	
	private static final SelfServiceLogger logger = LogFactory.getInstance(CustomerCallbackController.class);
	
	@Autowired
	private HttpSession session;

	@ModelAttribute("userProfile")
	public UserProfile createUserProfileModel() {
		return new UserProfile();
	}
	
	/*
	 * This method is used to load the customer callback details based on userId.
	 */
	@RequestMapping("/customercallback")
	public ModelAndView loadThankYouPage() throws Exception {
		
		ModelAndView model = new ModelAndView("customercallback");
		try {
			model = callBackService.loadThankYouPage(model);
			model.addObject("selectedQuote", session.getAttribute("selectedQuote"));
			return model;
		} catch (ServiceException e) {
			logger.error("ERROR : " + e.getMessage());
			throw new Exception(e.getMessage());
		} catch (Exception e) {
			logger.error("ERROR : " + e.getMessage());
			throw new Exception(e.getMessage());
		}
	}
	
	/*
	 * This method is used to save the customer callback details.
	 */
	@RequestMapping(value="/customercallback.html", method=RequestMethod.POST)
	public ModelAndView saveCustomerCallBackInfo(@ModelAttribute("CustomerCallback") CustomerCallback callback, @RequestParam("requestParam")String requestParam) throws Exception
	{
		ModelAndView model = new ModelAndView("customercallback");
		try {
			return callBackService.saveCustomerCallBackDetailsInfo(callback, model);
		} catch (ServiceException e) {
			logger.error("ERROR : " + e.getMessage());
			throw new Exception(e.getMessage());
		} catch (Exception e) {
			logger.error("ERROR : " + e.getMessage());
			throw new Exception(e.getMessage());
		}
	}
	
	/*
	 * This method is used to load the customer callback details based on userId for thankyoupagesecond.
	 */
	@RequestMapping("/customercallbacksecond")
	public ModelAndView loadThankYouPage2() throws Exception {
		ModelAndView model = new ModelAndView("customercallbacksecond");
		try {
			model = callBackService.loadThankYouPage2(model);
			model.addObject("selectedQuote", session.getAttribute("selectedQuote"));
			return model;
		} catch (ServiceException e) {
			logger.error("ERROR : " + e.getMessage());
			throw new Exception(e.getMessage());
		} catch (Exception e) {
			logger.error("ERROR : " + e.getMessage());
			throw new Exception(e.getMessage());
		}
	}
	
	/*
	 * This method is used to save the customer callback details for thankyoupagesecond.
	 */
	@RequestMapping(value="/customercallbacksecond.html", method=RequestMethod.POST)
	public ModelAndView saveCustomerCallBackInfoSecond(@ModelAttribute("CustomerCallback") CustomerCallback callback, @RequestParam("requestParam")String requestParam) throws Exception
	{
		ModelAndView model = new ModelAndView("customercallbacksecond");
		try {
			return callBackService.saveCustomerCallBackInfoSecond(callback, model);
		} catch (ServiceException e) {
			logger.error("ERROR : " + e.getMessage());
			throw new Exception(e.getMessage());
		} catch (Exception e) {
			logger.error("ERROR : " + e.getMessage());
			throw new Exception(e.getMessage());
		}
	}
	
	/*
	 * This method is used to save the CUSTOMERCALLBACK details if user gets no QUOTES from EBIX RESPONSE and continues to SUBMIT the APPLICATION OR PINNEY.
	 */
	@RequestMapping(value="/quotepagecustomercallback",method=RequestMethod.POST)
	public @ResponseBody String QuotepagesaveCustomerCallBackInfo(@ModelAttribute("CustomerCallback") CustomerCallback callback, @RequestParam("requestParam")String requestParam,Model model) throws Exception
	{
		
		try {
			return callBackService.saveQuotePageCustomercallBackdetails(callback, model,requestParam);
		} catch (ServiceException e) {
			logger.error("ERROR : " + e.getMessage());
			throw new Exception(e.getMessage());
		} catch (Exception e) {
			logger.error("ERROR : " + e.getMessage());
			throw new Exception(e.getMessage());
		}
		
		
	}
	
}
