/**
 * 
 */
package com.asg.selfservice.controller;

import java.util.List;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.asg.selfservice.common.logger.LogFactory;
import com.asg.selfservice.common.logger.SelfServiceLogger;
import com.asg.selfservice.common.utils.ApplicationConstants;
import com.asg.selfservice.domain.DrivingHistory;
import com.asg.selfservice.domain.Question;
import com.asg.selfservice.domain.UserProfile;
import com.asg.selfservice.exception.ServiceException;
import com.asg.selfservice.services.DrivingService;
import com.asg.selfservice.services.ProfileService;
import com.asg.selfservice.services.impl.EBIXServiceImpl;

/**
 * This controller has been used for implementing the Driving Histroy functionalities such as loading the
 * Driving page with the updated DB details, updating the Driving History details into the DB which the user has 
 * entered from the UI before proceeding into the next page.
 * 
 * @return 
 * Navigate to corresponding view based on called event
 * 
 * @author M1029563
 *
 */
@Controller
public class DrivingController {

	private static final SelfServiceLogger logger = LogFactory.getInstance(DrivingController.class);

	@Autowired
	private DrivingService drivingService;

	@Autowired
	private HttpSession session;

	@Autowired
	private ServletContext context;
	
	@Autowired
	private ProfileService profileService;
	
	@Autowired
	private EBIXServiceImpl ebixService;
	
	@ModelAttribute("userProfile")
	public UserProfile createUserProfileModel() {
		return new UserProfile();
	}
	
	/*
	 * This method is used to construct Model object with all the Driving details fetched from DB
	 * @param 
	 * @return Model Attributes Navigate to driving view
	 */
	@RequestMapping("/"+ApplicationConstants.DRIVING)
	public String loadmedicalInfo(Model model) throws Exception{

		logger.info("In Loading Driving Details");

		UserProfile userProfile = null;
		List<Question> drivingquestionList = null;
		int userId=0;
		DrivingHistory drivingHistory = null;

		if (session.getAttribute("sessionUser") == null
				|| (session.getAttribute(ApplicationConstants.PAGE_FROM) != ApplicationConstants.FAMILY
				&& session.getAttribute(ApplicationConstants.PAGE_FROM) != ApplicationConstants.TREATMENT
				&& session.getAttribute(ApplicationConstants.PAGE_FROM) != ApplicationConstants.EMAIL
				&& session.getAttribute(ApplicationConstants.PAGE_FROM) != ApplicationConstants.PROFILE)) {
			return "redirect:"+ApplicationConstants.LOGIN+".html";
		}
		if(session.getAttribute(ApplicationConstants.PAGE_FROM) != ApplicationConstants.PROFILE)
			session.setAttribute(ApplicationConstants.PAGE_FROM, ApplicationConstants.PAGE_FROM);
		
		userProfile = (UserProfile) session.getAttribute("sessionUser");
		userId = userProfile.getUserId();

		try{
			drivingHistory = drivingService.loadDrivingPage(userId, ApplicationConstants.drivinghistoryQuestionSetID);
			drivingquestionList = drivingService.loadQuestions();
		}
		catch(ServiceException e){
			logger.error("ERROR : " + e.getMessage());
			throw new Exception(e.getMessage());
		}
		catch(Exception e){			
			logger.error("ERROR : " + e.getMessage());
			throw new Exception(e.getMessage());
		}
		model.addAttribute("driving", drivingHistory);
		model.addAttribute("drivingquestionList", drivingquestionList);
		model.addAttribute("userProfile", userProfile);
		model.addAttribute("selectedQuote", session.getAttribute("selectedQuote"));

		return ApplicationConstants.DRIVING;
	}
	/*
	 * This method is used to Save/Update details in to DB
	 * @param DrivingHistory domain class containing driving history details
	 * @throws BaseException
	 */
	@RequestMapping(value="/"+ApplicationConstants.DRIVING,method = RequestMethod.POST,params={"action"})
	public String saveUpdateDrivingInfo(@ModelAttribute("driving") DrivingHistory drivingHistory,@RequestParam("action")String action) throws Exception{

		logger.info("In Save Service");
		UserProfile userProfile=null;

		session.setAttribute(ApplicationConstants.PAGE_FROM, ApplicationConstants.DRIVING);
		
		if(null != action && action.equalsIgnoreCase("back")){
			session.setAttribute(ApplicationConstants.AJAX_PAGE_FROM, ApplicationConstants.AJAX_PAGE_CALL);
			return "redirect:"+ApplicationConstants.FAMILY+".html";
		}
		if(null != session.getAttribute("sessionUser") && !"".equals(session.getAttribute("sessionUser"))){
			userProfile = (UserProfile) session.getAttribute("sessionUser");
		}
		else{
			return "redirect:"+ApplicationConstants.LOGIN+".html";
		}
		if("next".equalsIgnoreCase(action) && userProfile.getProfileStatusFlag() > 2) {
			return "redirect:"+ApplicationConstants.TREATMENT+".html";
		}
		try{
			if(null != drivingHistory){

				drivingService.saveUpdateDrivingInfo(userProfile, drivingHistory);
			}
			if(null != action && action.equalsIgnoreCase("save")){
				userProfile = profileService.saveUserProfile(userProfile);
				session.setAttribute("sessionUser", userProfile);
			}
		}
		catch (ServiceException e) {
			logger.error("ERROR : " + e.getMessage());
			throw new Exception(e.getMessage());
		}
		catch(Exception e){
			logger.error("ERROR : " + e.getMessage());
			throw new Exception(e.getMessage());
		}

		if("next".equalsIgnoreCase(action)){
						
			return "redirect:"+ApplicationConstants.TREATMENT+".html";
		}

		return "redirect:"+ApplicationConstants.CUSTOMERCALLBACK+".html";

	}

}
