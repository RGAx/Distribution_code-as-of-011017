package com.asg.selfservice.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.asg.selfservice.common.utils.ApplicationConstants;
import com.asg.selfservice.domain.UserProfile;

/**
 * To load the new landing pages
 * 
 * @author M1033984
 * 
 */
@Controller
public class LandingPageController {

	@Autowired
	private HttpSession session;

	@RequestMapping(value = "/landingPage")
	public ModelAndView loadLandingPage(HttpServletRequest request, Model model)
			throws Exception {
		if (session.getAttribute("sessionUser") == null) {
			return new ModelAndView("redirect:" + ApplicationConstants.LOGIN
					+ ".html");
		}
		UserProfile userProfile = (UserProfile) session
				.getAttribute("sessionUser");
		model.addAttribute("userProfile", userProfile);
		session.setAttribute(ApplicationConstants.PAGE_FROM, ApplicationConstants.NEW_LANDING_PAGE);
		ModelAndView modelAndView = new ModelAndView("newLandingPage");

		return modelAndView;
	}

	@RequestMapping(value = "/snapshot1")
	public ModelAndView loadSnapshot1(Model model) throws Exception {
		if (session.getAttribute("sessionUser") == null) {
			return new ModelAndView("redirect:" + ApplicationConstants.LOGIN
					+ ".html");
		}
		UserProfile userProfile = (UserProfile) session
				.getAttribute("sessionUser");
		model.addAttribute("userProfile", userProfile);
		session.setAttribute(ApplicationConstants.PAGE_FROM, ApplicationConstants.NEW_LANDING_PAGE);
		ModelAndView modelAndView = new ModelAndView("snapshot1");

		return modelAndView;
	}

	@RequestMapping(value = "/snapshot2")
	public ModelAndView loadSnapshot2(Model model) throws Exception {
		if (session.getAttribute("sessionUser") == null) {
			return new ModelAndView("redirect:" + ApplicationConstants.LOGIN
					+ ".html");
		}
		UserProfile userProfile = (UserProfile) session
				.getAttribute("sessionUser");
		model.addAttribute("userProfile", userProfile);
		ModelAndView modelAndView = new ModelAndView("snapshot2");

		return modelAndView;
	}

	@RequestMapping(value = "/snapshot3")
	public ModelAndView loadSnapshot3(Model model) throws Exception {
		if (session.getAttribute("sessionUser") == null) {
			return new ModelAndView("redirect:" + ApplicationConstants.LOGIN
					+ ".html");
		}
		UserProfile userProfile = (UserProfile) session
				.getAttribute("sessionUser");
		model.addAttribute("userProfile", userProfile);
		session.setAttribute(ApplicationConstants.PAGE_FROM, ApplicationConstants.NEW_LANDING_PAGE);
		ModelAndView modelAndView = new ModelAndView("snapshot3");

		return modelAndView;
	}

	@RequestMapping(value = "/snapshot4")
	public ModelAndView loadSnapshot4(Model model) throws Exception {
		if (session.getAttribute("sessionUser") == null) {
			return new ModelAndView("redirect:" + ApplicationConstants.LOGIN
					+ ".html");
		}
		UserProfile userProfile = (UserProfile) session
				.getAttribute("sessionUser");
		model.addAttribute("userProfile", userProfile);
		session.setAttribute(ApplicationConstants.PAGE_FROM, ApplicationConstants.NEW_LANDING_PAGE);
		ModelAndView modelAndView = new ModelAndView("snapshot4");

		return modelAndView;
	}

	@RequestMapping(value = "/snapshot5")
	public ModelAndView loadSnapshot5(Model model) throws Exception {
		if (session.getAttribute("sessionUser") == null) {
			return new ModelAndView("redirect:" + ApplicationConstants.LOGIN
					+ ".html");
		}
		UserProfile userProfile = (UserProfile) session
				.getAttribute("sessionUser");
		model.addAttribute("userProfile", userProfile);
		session.setAttribute(ApplicationConstants.PAGE_FROM, ApplicationConstants.NEW_LANDING_PAGE);
		ModelAndView modelAndView = new ModelAndView("snapshot5");

		return modelAndView;
	}

}
