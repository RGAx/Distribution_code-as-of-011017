/**
 * 
 */
package com.asg.selfservice.controller;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.Validator;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.asg.selfservice.common.logger.LogFactory;
import com.asg.selfservice.common.logger.SelfServiceLogger;
import com.asg.selfservice.common.utils.ApplicationConstants;
import com.asg.selfservice.domain.UserProfile;
import com.asg.selfservice.exception.ServiceException;
import com.asg.selfservice.services.AdminAccessService;
import com.asg.selfservice.services.LoginService;

/**
 * This class has been used for as a controller for handling the user operations
 * such as loading the login page, logging the user, forgot password etc.
 * 
 * @author M1030133
 *
 */
@Controller
public class LoginController {
	private static final SelfServiceLogger logger = LogFactory.getInstance(LoginController.class);

	@Autowired
	private LoginService loginService;
	 
	@Autowired
	@Qualifier("userValidator")
	private Validator validator;
	
	@Autowired
    private ServletContext context;
	
	@Autowired
	private HttpSession session;
	
	@Autowired
	private AdminAccessService adminAccessService;
	
	/*
	 * This method has been used for loading the login page.
	 */
	@RequestMapping(value="/"+ApplicationConstants.LOGIN)
	public String loadLoginPage() {
		session.invalidate();
		return ApplicationConstants.LOGIN;
	}
	
	@InitBinder
	private void initBinder(WebDataBinder binder) {
		binder.setValidator(validator);
	}
	
	@ModelAttribute("userProfile")
	public UserProfile createUserProfileModel() {
		return new UserProfile();
	}
	
	/*
	 * This method has been used for validating the username and password for logging and
	 *  redirecting the page accordingly.
	 */
	@RequestMapping(value="/"+ApplicationConstants.LOGIN, method = RequestMethod.POST, params={"login"})
	public String onUserLogin(Model model, @ModelAttribute("userProfile") @Validated UserProfile user, BindingResult result) throws Exception {
		final long startTime = logger.logMethodEntry();
		
	    //Check validation errors
	    if (result.hasErrors()) {
	        return ApplicationConstants.LOGIN;
	    }
	    UserProfile userProfile;
		int validUserFlag = 0;
		try {
			userProfile = loginService.validateUser(user);
			validUserFlag = userProfile.getValidCount();
		} catch (ServiceException e) {
			logger.error("ERROR : " + e.getMessage());
			throw new Exception(e.getMessage());
		} catch (Exception e) {
			logger.error("ERROR : " + e.getMessage());
			throw new Exception(e.getMessage());
		}
		if(validUserFlag == 1) {
			logger.info("-----VALID USER-----");
			session.setAttribute("sessionUser", userProfile);
			session.setAttribute(ApplicationConstants.PAGE_FROM, ApplicationConstants.LOGIN);
			session.setAttribute(ApplicationConstants.AJAX_PAGE_FROM, ApplicationConstants.AJAX_PAGE_CALL);
			
			logger.logMethodExit(startTime);
			if(ApplicationConstants.ADMIN_USER.equalsIgnoreCase(userProfile.getUserType())) {
				session.setAttribute("sessionAdminUser", userProfile);
				return "redirect:"+ApplicationConstants.ADMIN_PAGE+".html";
			}
			session.setAttribute("sessionAdminUser", null);
			return "redirect:health.html";
		} else {
			logger.info("-----INVALID USER-----");
			session.setAttribute("sessionUser", null);
			if(validUserFlag == 0) {
				result.rejectValue("loginFailErrorMsg", "loginFailErrorMsg.msg");
			} else if(validUserFlag == 2) {
				result.rejectValue("loginFailErrorMsg", "loginLockMsg.msg");
			}
			logger.logMethodExit(startTime);
			return ApplicationConstants.LOGIN;
		}
	}
	
	/*
	 * This method has been used for validating the user with the email address presence in the db
	 * and on successful validation sending a mail to the user with the newly created password.
	 */
	@RequestMapping(value="/forgotPassword", method = RequestMethod.POST)
	public String onForgotPassword(@RequestParam("username") String username, @ModelAttribute("userProfile") @Validated UserProfile user, BindingResult result) throws Exception {
		final long startTime = logger.logMethodEntry();
		boolean validUsername = loginService.isUserExists(username);
		if(validUsername) {
			logger.info("-----VALID USERNAME-----");
			//Send mail
			try {
				UserProfile userProfile = loginService.updateUserAndSendMail(username);
				session.setAttribute("sessionUser", userProfile);
			} catch (ServiceException e) {
				logger.error("ERROR : " + e.getMessage());
				throw new Exception(e.getMessage());
			} catch (Exception e) {
				logger.error("ERROR : " + e.getMessage());
				throw new Exception(e.getMessage());
			}
		} else {
			boolean adminUser = adminAccessService.isAdminUser(username);
			if(adminUser) {
				result.rejectValue("forgotPwdErrorMsg", "forgotPwdErrorMsg.msg");
				return "admin";
			}
			result.rejectValue("forgotPwdErrorMsg", "forgotPwdErrorMsg.msg");
			return "";
		}
		logger.logMethodExit(startTime);
		return "redirect:"+ApplicationConstants.LOGIN+".html";
	}
}
