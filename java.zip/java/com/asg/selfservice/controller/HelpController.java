package com.asg.selfservice.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.asg.selfservice.common.logger.LogFactory;
import com.asg.selfservice.common.logger.SelfServiceLogger;
import com.asg.selfservice.common.utils.ApplicationConstants;
import com.asg.selfservice.domain.UserProfile;
import com.asg.selfservice.exception.ServiceException;
import com.asg.selfservice.services.impl.HelpServiceImpl;

/**
 * This controller has been used for HELP icon functionality.
 * Where the user enters Name, Email ID and the query(Help).
 * 
 * @author M1027376
 *
 */
@Controller
public class HelpController {
	
	private static final SelfServiceLogger logger = LogFactory.getInstance(HelpController.class);
	
	@Autowired
	HelpServiceImpl helpService;
	
	@Autowired
	private HttpSession session;
	
	@ModelAttribute("userProfile")
	public UserProfile createUserProfileModel() {
		return new UserProfile();
	}
	
	/*
	 * This method has been used for sending the request object to fetch
	 * the user details and send email.
	 */
	@RequestMapping(value = "/help", method = RequestMethod.POST)
	public String help(HttpServletRequest request) throws Exception {
		String refererPage;
		try {
			refererPage = this.loadRefererPage(request.getHeader("referer"));
			session.setAttribute(ApplicationConstants.PAGE_FROM, ApplicationConstants.EMAIL);
			helpService.help(request);
		} catch (ServiceException e) {
			logger.error("ERROR : " + e.getMessage());
			throw new Exception(e.getMessage());
		} catch (Exception e) {
			logger.error("ERROR : " + e.getMessage());
			throw new Exception(e.getMessage());
		}
		session.setAttribute(ApplicationConstants.AJAX_PAGE_FROM, ApplicationConstants.AJAX_PAGE_CALL);
		return "redirect:"+refererPage+".html";
	}
	
	/*
	 * This is a private method to load the referrer page based on the request
	 * header referer parameter.
	 */
	private String loadRefererPage(String refererPage) {
		if(refererPage != null && !refererPage.isEmpty() && refererPage.lastIndexOf("/") > 0) {
			if(refererPage.lastIndexOf(".") > 0) {
				refererPage = refererPage.substring(refererPage.lastIndexOf("/") + 1, refererPage.lastIndexOf("."));
			} else {
				refererPage = refererPage.substring(refererPage.lastIndexOf("/") + 1, refererPage.length());
			}
		} else {
			refererPage = ApplicationConstants.HEALTH;
		}
		return refererPage;
	}
}