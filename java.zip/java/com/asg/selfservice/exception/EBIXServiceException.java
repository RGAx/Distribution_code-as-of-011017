package com.asg.selfservice.exception;

public class EBIXServiceException extends BaseException {
	/**
	 * declaring serialVersionUID.
	 */
	private static final long serialVersionUID = -6173445095797188369L;

	/**
	 * @param errorCode
	 *            - error code id for specific error
	 * @param errorDesc
	 *            - error description for specific error	
	 */
	public EBIXServiceException(final String errorCode, final String errorDesc) {
		super(errorCode, errorDesc);

	}
}