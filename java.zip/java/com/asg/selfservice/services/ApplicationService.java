package com.asg.selfservice.services;

/**
 * This interface has been used for defining the Application details Page such as loading the Application page,
 * loading the questions and saving/updating the application info into the DB.
 * 	Implemented in ApplicationServiceImpl class.
 *  @author M1029563
 *
 */
import java.util.List;
import java.util.Map;

import com.asg.selfservice.domain.Question;
import com.asg.selfservice.domain.UserApplicationDetail;
import com.asg.selfservice.domain.UserProfile;
import com.asg.selfservice.exception.ServiceException;

public interface ApplicationService extends BaseService{
	
	public String saveUpdateApplicationInfo(UserProfile userProfile,UserApplicationDetail userdetails) throws ServiceException;
	
	public Map<Integer,String> loadApplicationInfo(int userId,int qsetId) throws ServiceException;
	
	public List<Question> loadQuestions() throws ServiceException;
		
	public List<String> getreasonForInsurance(int qId) throws ServiceException;
	
	public List<String> getpaymentPeriod(int qId) throws ServiceException;
	
	public List<String> getrelations(int qId) throws ServiceException;
	
	public List<String> getPercentages(int qId) throws ServiceException;
		
}
