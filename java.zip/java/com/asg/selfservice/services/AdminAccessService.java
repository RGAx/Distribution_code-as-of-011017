package com.asg.selfservice.services;

import org.springframework.web.servlet.ModelAndView;

import com.asg.selfservice.domain.UserProfile;
import com.asg.selfservice.exception.ServiceException;

/**
 * This interface has been used for defining the operations such as loading the
 * users based on email address.
 * 
 * @author M1030133
 *
 */
public interface AdminAccessService {
	public ModelAndView loadUsers(ModelAndView model, String emailAddress)
			throws ServiceException;

	public UserProfile loadAdminUser(String emailAddress) throws ServiceException;

	public boolean isAdminUser(String username) throws ServiceException;
}
