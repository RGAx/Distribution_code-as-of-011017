package com.asg.selfservice.services;

/**
 * This interface has been used for defining the MedicalConditions details Page such as loading the Medical Conditions page,
 * loading the questions and saving/updating the medicalConditions info into the DB.
 * 	Implemented in MedicalConditionsServiceImpl class.
 *  @author M1029563
 *
 */
import org.springframework.web.servlet.ModelAndView;

import com.asg.selfservice.domain.MedicalConditionsAnswer;
import com.asg.selfservice.domain.UserProfile;
import com.asg.selfservice.exception.ServiceException;

public interface MedicalConditionsService extends BaseService{
	

	public ModelAndView loadMedicalConditionsPage(ModelAndView model) throws ServiceException;
	
	public void saveUpdateMedicalConditionsInfo(UserProfile user, MedicalConditionsAnswer medicalConditions) throws ServiceException;
	
	public void sendsubmittedapplicationNotificationMail(UserProfile user) throws ServiceException;
	
}
