/**
 * 
 */
package com.asg.selfservice.services;

import com.asg.selfservice.domain.UserProfile;
import com.asg.selfservice.exception.ServiceException;

/**
 * This interface has been used for defining the login operations such as
 * validating the user, validating the username etc. This has been implemented
 * in LoginServiceImpl class.
 * 
 * @author M1030133
 *
 */
public interface LoginService extends BaseService {
	public UserProfile validateUser(UserProfile user) throws ServiceException;

	public boolean isUserExists(String username) throws ServiceException;

	public UserProfile updateUserAndSendMail(String username) throws ServiceException;
}
