/**
 * 
 */
package com.asg.selfservice.services;

import org.springframework.web.servlet.ModelAndView;

import com.asg.selfservice.domain.TreatmentHistory;
import com.asg.selfservice.domain.UserProfile;
import com.asg.selfservice.exception.ServiceException;

/**
 * @author M1027376
 *
 */
public interface TreatmentService extends BaseService {

	public ModelAndView loadTreatmentHistInfo(ModelAndView model, UserProfile userProfile) throws ServiceException;
	
	public void saveUpdateTreatmentInfo(UserProfile userProfile, TreatmentHistory treatment) throws ServiceException;
}
