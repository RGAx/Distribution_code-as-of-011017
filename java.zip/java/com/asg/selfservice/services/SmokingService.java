package com.asg.selfservice.services;

import org.springframework.web.servlet.ModelAndView;

import com.asg.selfservice.domain.Smoking;
import com.asg.selfservice.domain.UserProfile;
import com.asg.selfservice.exception.ServiceException;

/**
 * This interface has been used for defining the smoking operations such as
 * loading the smoking page, loading the questions and saving/updating the
 * smoking info into the DB. This has been implemented in SmokingServiceImpl
 * class.
 * 
 * @author M1030133
 *
 */
public interface SmokingService extends BaseService {
	public ModelAndView loadSmokingInfo(ModelAndView model,
			UserProfile userProfile) throws ServiceException;

	public void saveUpdateSmokingInfo(UserProfile userProfile, Smoking smoking)
			throws ServiceException;
}
