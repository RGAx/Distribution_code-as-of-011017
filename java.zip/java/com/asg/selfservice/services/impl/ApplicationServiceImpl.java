package com.asg.selfservice.services.impl;

/*********************
 * 
 * 
 * @author M1029563
 * 
 * Service Level implementation for Application COntroller which handles service Methods saveuserDetails,getuserappDetails,loading countries,staes,Question from DB
 */
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;

import com.asg.selfservice.common.logger.LogFactory;
import com.asg.selfservice.common.logger.SelfServiceLogger;
import com.asg.selfservice.common.utils.ApplicationConstants;
import com.asg.selfservice.domain.Answer;
import com.asg.selfservice.domain.Question;
import com.asg.selfservice.domain.QuestionAnswer;
import com.asg.selfservice.domain.UserApplicationDetail;
import com.asg.selfservice.domain.UserProfile;
import com.asg.selfservice.exception.ServiceException;
import com.asg.selfservice.services.ApplicationService;
import com.asg.selfservice.services.GenericService;

public class ApplicationServiceImpl implements ApplicationService{

	private static final SelfServiceLogger logger = LogFactory.getInstance(ApplicationServiceImpl.class);
		
	@Autowired
	private GenericService genericService;
	
	@Autowired
	private ServletContext context;
	
	@Autowired
	private HttpSession session;
	
	/*
	 * This method is used to Save/Update data in to the Table for the respective userid
	 * @param  UserProfile user,UserApplicationDetail userdetails
	 * @Exception BaseException
	 * @see com.asg.selfservice.services.ApplicationService#saveuserDetails(com.asg.selfservice.domain.UserProfile, com.asg.selfservice.domain.UserApplicationDetail)
	 */
	public String saveUpdateApplicationInfo(UserProfile userProfile,UserApplicationDetail userdetails) throws ServiceException {
		
		try{
			Map<String, Integer> questAnsUIdQSetIdSeqIdMap = genericService.loadQuestAnsUIdQSetIdSeqIdMap(userProfile);
			int questionId=0;
			
			if(null != userdetails.getCountry() && !"".equals(userdetails.getCountry()) ){
				questionId = questAnsUIdQSetIdSeqIdMap.get(userProfile.getUserId()+"-"+ApplicationConstants.applicationQuestionSetID+"-"+ApplicationConstants.ONE);
				genericService.saveUpdateInfo(userProfile, this.constructQuestionAnswer(userProfile, questionId, userdetails.getCountry()));
			}
			if(null != userdetails.getState() && !"".equals(userdetails.getState()) && !userdetails.getState().equalsIgnoreCase("select")){
				questionId = questAnsUIdQSetIdSeqIdMap.get(userProfile.getUserId()+"-"+ApplicationConstants.applicationQuestionSetID+"-"+ApplicationConstants.TWO);
				genericService.saveUpdateInfo(userProfile, this.constructQuestionAnswer(userProfile, questionId, userdetails.getState()));
			}
			if(null != userdetails.getResidencyStatus() && !"".equals(userdetails.getResidencyStatus())){
				questionId = questAnsUIdQSetIdSeqIdMap.get(userProfile.getUserId()+"-"+ApplicationConstants.applicationQuestionSetID+"-"+ApplicationConstants.THREE);
				genericService.saveUpdateInfo(userProfile, this.constructQuestionAnswer(userProfile, questionId, userdetails.getResidencyStatus().equalsIgnoreCase("true") ? "1" : "0"));
			}
			if(userdetails.getGrossIncome()!=null && !"".equals(userdetails.getGrossIncome())){
				questionId = questAnsUIdQSetIdSeqIdMap.get(userProfile.getUserId()+"-"+ApplicationConstants.applicationQuestionSetID+"-"+ApplicationConstants.FOUR);
				genericService.saveUpdateInfo(userProfile, this.constructQuestionAnswer(userProfile, questionId, String.valueOf(userdetails.getGrossIncome())));
			}
			else{
				questionId = questAnsUIdQSetIdSeqIdMap.get(userProfile.getUserId()+"-"+ApplicationConstants.applicationQuestionSetID+"-"+ApplicationConstants.FOUR);
				genericService.deleteAnswers(userProfile, new Integer[]{questionId});
			}
			if(null != userdetails.getReaInsurance() && !"".equals(userdetails.getReaInsurance())){
				questionId = questAnsUIdQSetIdSeqIdMap.get(userProfile.getUserId()+"-"+ApplicationConstants.applicationQuestionSetID+"-"+ApplicationConstants.FIVE);
				genericService.saveUpdateInfo(userProfile, this.constructQuestionAnswer(userProfile, questionId, userdetails.getReaInsurance()));
			}
			if(null != userdetails.getPrefpaymentPeriod() && !"".equals(userdetails.getPrefpaymentPeriod())){
				questionId = questAnsUIdQSetIdSeqIdMap.get(userProfile.getUserId()+"-"+ApplicationConstants.applicationQuestionSetID+"-"+ApplicationConstants.SIX);
				genericService.saveUpdateInfo(userProfile, this.constructQuestionAnswer(userProfile, questionId, userdetails.getPrefpaymentPeriod()));
			}
			if(null != userdetails.getBeneficiaryfullName() && !"".equals(userdetails.getBeneficiaryfullName())){
				questionId = questAnsUIdQSetIdSeqIdMap.get(userProfile.getUserId()+"-"+ApplicationConstants.applicationQuestionSetID+"-"+ApplicationConstants.SEVEN);
				genericService.saveUpdateInfo(userProfile, this.constructQuestionAnswer(userProfile, questionId, userdetails.getBeneficiaryfullName()));
			}
			else{
				questionId = questAnsUIdQSetIdSeqIdMap.get(userProfile.getUserId()+"-"+ApplicationConstants.applicationQuestionSetID+"-"+ApplicationConstants.SEVEN);
				genericService.deleteAnswers(userProfile, new Integer[]{questionId});
			}
			if(null != userdetails.getBeneficiaryrelShip() && !"".equals(userdetails.getBeneficiaryrelShip())){
				questionId = questAnsUIdQSetIdSeqIdMap.get(userProfile.getUserId()+"-"+ApplicationConstants.applicationQuestionSetID+"-"+ApplicationConstants.EIGHT);
				genericService.saveUpdateInfo(userProfile, this.constructQuestionAnswer(userProfile, questionId, userdetails.getBeneficiaryrelShip()));
			}
			else{
				questionId = questAnsUIdQSetIdSeqIdMap.get(userProfile.getUserId()+"-"+ApplicationConstants.applicationQuestionSetID+"-"+ApplicationConstants.EIGHT);
				genericService.deleteAnswers(userProfile, new Integer[]{questionId});
			}
			if(null != userdetails.getBeneficiaryPercentage() && !"".equals(userdetails.getBeneficiaryPercentage())){
				questionId = questAnsUIdQSetIdSeqIdMap.get(userProfile.getUserId()+"-"+ApplicationConstants.applicationQuestionSetID+"-"+ApplicationConstants.NINE);
				genericService.saveUpdateInfo(userProfile, this.constructQuestionAnswer(userProfile, questionId, userdetails.getBeneficiaryPercentage()));
			}
			else{
				questionId = questAnsUIdQSetIdSeqIdMap.get(userProfile.getUserId()+"-"+ApplicationConstants.applicationQuestionSetID+"-"+ApplicationConstants.NINE);
				genericService.deleteAnswers(userProfile, new Integer[]{questionId});
			}
		}
		catch (ServiceException e) {
			logger.error("ERROR : " + e.getMessage());
			throw new ServiceException(e.getMessage());
		}
		
		return null;
	}
	/*
	 * This method is used to retrieve application details from the DB and constructs Application details Map and return to controller.
	 * @param UserId
	 * @return constructs Map with qid as key and asnwer as value
	 * @Exception BaseException
	 * @see com.asg.selfservice.services.ApplicationService#getuserappDetails(int)
	 */
	public Map<Integer, String> loadApplicationInfo(int userId,int qsetId) throws ServiceException {
		Map<Integer, String> applicationdetailsMap =null; 
		
		try{
			List<QuestionAnswer> questionanswerList = genericService.loadQuestionAnswerPerPage(userId, qsetId);
			applicationdetailsMap = new HashMap<Integer, String>();
			
			for(QuestionAnswer questionAnswer : questionanswerList) {
				if(questionAnswer.getSequence() == ApplicationConstants.ONE) {
					applicationdetailsMap.put(questionAnswer.getqId(), questionAnswer.getAnswer());
				}
				if(questionAnswer.getSequence() == ApplicationConstants.TWO) {
					applicationdetailsMap.put(questionAnswer.getqId(), questionAnswer.getAnswer());
				}
				if(questionAnswer.getSequence() == ApplicationConstants.THREE) {
					applicationdetailsMap.put(questionAnswer.getqId(), questionAnswer.getAnswer());
				}
				if(questionAnswer.getSequence() == ApplicationConstants.FOUR) {
					applicationdetailsMap.put(questionAnswer.getqId(), questionAnswer.getAnswer());
				}
				if(questionAnswer.getSequence() == ApplicationConstants.FIVE) {
					applicationdetailsMap.put(questionAnswer.getqId(), questionAnswer.getAnswer());
				}
				if(questionAnswer.getSequence() == ApplicationConstants.SIX) {
					applicationdetailsMap.put(questionAnswer.getqId(), questionAnswer.getAnswer());
				}
				if(questionAnswer.getSequence() == ApplicationConstants.SEVEN) {
					applicationdetailsMap.put(questionAnswer.getqId(), questionAnswer.getAnswer());
				}
				if(questionAnswer.getSequence()== ApplicationConstants.EIGHT) {
					applicationdetailsMap.put(questionAnswer.getqId(), questionAnswer.getAnswer());
				}
				if(questionAnswer.getSequence() == ApplicationConstants.NINE) {
					applicationdetailsMap.put(questionAnswer.getqId(), questionAnswer.getAnswer());
				}
			}
		}
		catch (ServiceException e) {
			logger.error("ERROR : " + e.getMessage());
			throw new ServiceException(e.getMessage());
		}		
		return applicationdetailsMap;
	}
	/*
	 * This Method is used to load Questions from QUESTIONS Table
	 * based on the question id
	 * @return List<Question> applicationQuestion
	 */
	@SuppressWarnings("unchecked")
	public List<Question> loadQuestions() throws ServiceException {
		List<Question> questionList = null;
		
		List<Question> applicationQuestion = new ArrayList<Question>();
		
		try {
				questionList = genericService.loadQuestions();
			
			for (Question question : questionList) {
				
				if(question.getQsetId() == ApplicationConstants.applicationQuestionSetID) {
					applicationQuestion.add(question);
				}
			}
		} catch (ServiceException e) {
			logger.error("ERROR : " + e.getMessage());
			throw new ServiceException(e.getMessage());
		}
		return applicationQuestion;
	}
	
	/*
	 * This Method is used to load reasonforInsurance from ANSWERS Table
	 * based on the question id
	 * @param qId
	 * @return List<String> reasonInsurance
	 */
	public List<String> getreasonForInsurance(int qId) throws ServiceException {
		
		List<String> reasonInsurance= new ArrayList<String>();
		try{
			List<Answer> answers = genericService.loadAnswers();
			
			for(Answer answer : answers) {
				if(answer.getqId() == qId) {
					reasonInsurance.add(answer.getAnswerValue());
				}
			}
		}
		catch (ServiceException e) {
			logger.error("ERROR : " + e.getMessage());
			throw new ServiceException(e.getMessage());
		}
		
		return reasonInsurance;
	}
	/*
	 * This Method is used to load paymentPeriod from ANSWERS Table
	 * based on the question id
	 * @param qId
	 * @return List<String> paymentPeriod
	 */
	public List<String> getpaymentPeriod(int qId) throws ServiceException {
		
		List<String> paymentPeriod= new ArrayList<String>();
		try{
			List<Answer> answers = genericService.loadAnswers();
			
			for(Answer answer : answers) {
				if(answer.getqId() == qId) {
					paymentPeriod.add(answer.getAnswerValue());
				}
			}
		}
		catch (ServiceException e) {
			logger.error("ERROR : " + e.getMessage());
			throw new ServiceException(e.getMessage());
		}
		
		return paymentPeriod;
	}
	/*
	 * This Method is used to load relations from ANSWERS Table
	 * based on the question id
	 * @param qId
	 * @return List<String> relations
	 */
	public List<String> getrelations(int qId) throws ServiceException {
		
		List<String> relations= new ArrayList<String>();
		try{
			List<Answer> answers = genericService.loadAnswers();
			
			for(Answer answer : answers) {
				if(answer.getqId() == qId) {
					relations.add(answer.getAnswerValue());
				}
			}
		}
		catch (ServiceException e) {
			logger.error("ERROR : " + e.getMessage());
			throw new ServiceException(e.getMessage());
		}
		return relations;
	}
	/*
	 * This Method is used to load percentages from ANSWERS Table
	 * based on the question id
	 * @param qId
	 * @return List<String> percentages
	 */
	public List<String> getPercentages(int qId) throws ServiceException {
		
		List<String> percentages= new ArrayList<String>();
		try{
			List<Answer> answers = genericService.loadAnswers();
			
			for(Answer answer : answers) {
				if(answer.getqId() == qId) {
					String percentageRange = answer.getAnswerValue();
					
					int percentage1 = Integer.parseInt(percentageRange.split("-")[0]);
			        int percentage2 = Integer.parseInt(percentageRange.split("-")[1].split("\\+")[0]);
			        int lastElement = 0;
			        
			        for(int count = percentage1; count < percentage2; count +=10) {
			        	lastElement = count + 10;
			        	percentages.add(count+"");
			        }
			        percentages.add(lastElement+"");
				}
			}
		}
		catch (ServiceException e) {
			logger.error("ERROR : " + e.getMessage());
			throw new ServiceException(e.getMessage());
		}
		
		return percentages;
	}
	/*
	 * This is an internal method used inside this service code where question answer has been constructed
	 * based on the question id, user and ans value.
	 */
	private QuestionAnswer constructQuestionAnswer(UserProfile user, int questionId, String ansValue) {
		QuestionAnswer quesAnswer = new QuestionAnswer();
		
		quesAnswer.setqId(questionId);
		quesAnswer.setUserId(user.getUserId());
		quesAnswer.setAnswer(ansValue);
		quesAnswer.setCreatedDate(new java.sql.Date((new Date()).getTime()));
		quesAnswer.setCreatedBy(user.getFirstName() + " " + (user.getLastName() != null ? user.getLastName() : ""));
		
		return quesAnswer;
	}

}
