package com.asg.selfservice.services.impl;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.ui.Model;
import org.springframework.web.servlet.ModelAndView;

import com.asg.selfservice.common.logger.LogFactory;
import com.asg.selfservice.common.logger.SelfServiceLogger;
import com.asg.selfservice.common.utils.ApplicationConstants;
import com.asg.selfservice.dao.impl.CustomerCallbackDAOImpl;
import com.asg.selfservice.domain.CustomerCallback;
import com.asg.selfservice.domain.Quote;
import com.asg.selfservice.domain.UserProfile;
import com.asg.selfservice.exception.DAOException;
import com.asg.selfservice.exception.ServiceException;
import com.asg.selfservice.pinney.services.impl.PinneyServiceHelperImpl;
import com.asg.selfservice.services.CustomerCallBackService;
import com.asg.selfservice.services.ProfileService;
import com.asg.selfservice.services.QuoteService;

/**
 * This class Implements the CustomerCallBackService Interface, and has methods to fetch
 * the customer callback details and to save the customer callback details.
 */
public class CustomerCallbackServiceImpl implements CustomerCallBackService {

	private static final SelfServiceLogger logger = LogFactory.getInstance(CustomerCallbackServiceImpl.class);
	
	@Autowired
	public CustomerCallbackDAOImpl callBackDaoObj;
		
	@Autowired
	private HttpSession session;
	
	@Autowired
	private ProfileService profileService;
	
	@Autowired
	private QuoteService quoteService;
	
	@Autowired
	private PinneyServiceHelperImpl pinneyServiceHelperImpl;
	
	@Autowired
	private EmailServiceImpl emailService;
	
	@Value("#{'${selfservice.list.Time}'.split(',')}") 
	private List<String> Time;
	
	@Value("#{'${application.context.url}'}") 
	private String contextURL;
	
	
	
	public ModelAndView loadThankYouPage(ModelAndView model) throws ServiceException {

		CustomerCallback customerCallback = null;

		if(null != session.getAttribute("sessionUser")) {
			UserProfile sessionUser = (UserProfile) session.getAttribute("sessionUser");
			try {
				logger.info("Fetching customer callback details based on userId:"+sessionUser.getUserId());
				customerCallback = callBackDaoObj.getUserDetails(sessionUser.getUserId());
			} catch (DAOException e) {
				logger.error("ERROR : " + e.getMessage());
				throw new ServiceException(e.getMessage());
			}
		} else {
			return new ModelAndView("redirect:" + ApplicationConstants.LOGIN+ ".html");
		}
		model.addObject("userProfileDetails", customerCallback);
		model.addObject("timeSlots", Time);
		model.addObject("loginURL", contextURL);
		model.addObject("userProfile", session.getAttribute("sessionUser"));
		return model;
	}
	
	public ModelAndView loadThankYouPage2(ModelAndView model) throws ServiceException {

		CustomerCallback customerCallback = null;
		Quote quote = null;

		if(null != session.getAttribute("sessionUser")) {
			UserProfile sessionUser = (UserProfile) session.getAttribute("sessionUser");
			try {
				logger.info("Fetching customer callback details based on userId:"+sessionUser.getUserId());
				customerCallback = callBackDaoObj.getUserDetails(sessionUser.getUserId());
			} catch (DAOException e) {
				logger.error("ERROR : " + e.getMessage());
				throw new ServiceException(e.getMessage());
			}
		} else {
			return new ModelAndView("redirect:" + ApplicationConstants.LOGIN+ ".html");
		}
		
		if(null != session.getAttribute("selectedQuote") && !"".equals(session.getAttribute("selectedQuote"))){
			quote = (Quote) session.getAttribute("selectedQuote");
		}
		model.addObject("userProfileDetails", customerCallback);
		model.addObject("timeSlots", Time);
		model.addObject("quote",quote);
		model.addObject("userProfile", session.getAttribute("sessionUser"));
		return model;
	}
	
	/*
	 * This method is used to save the customer callback details.
	 */
	public ModelAndView saveCustomerCallBackDetailsInfo(CustomerCallback callBack, ModelAndView model) throws ServiceException {
		
		UserProfile userProfile = null;
		boolean flag=false; 
		
		if(null != session.getAttribute("sessionUser")) {
			userProfile = (UserProfile) session.getAttribute("sessionUser");
			try {				
				flag = callBackDaoObj.saveCustomerCallBackDetailsInfo(callBack, userProfile);
			} catch (DAOException e) {
				logger.error("ERROR : " + e.getMessage());
				throw new ServiceException(e.getMessage());
			}
			
			if(flag == true)
			{
				String callBackDate = callBack.getCallBackDate();
				String callBackTime = callBack.getGetBackTime();
				logger.info("callBackDate["+callBackDate+"]");
				logger.info("callBackTime["+callBackTime+"]");
				String msg = "";
				if(null != callBackDate && null != callBackTime) {
					if(callBackDate.isEmpty() && callBackTime.isEmpty()) {
						msg = "Thank you for submitting your application. We look forward to working with you.";
					} else if(callBackDate.isEmpty() && !callBackTime.isEmpty()) {
						msg = "Thank you for submitting your application. Our agent will call you at the time "+callBackTime+" as per your request. We look forward to working with you.";
					} else if(!callBackDate.isEmpty() && callBackTime.isEmpty()) {
						msg = "Thank you for submitting your application. Our agent will call you on "+callBackDate+" as per your request. We look forward to working with you.";
					} else {
						msg = "Thank you for submitting your application. Our agent will call you on "+callBackDate+" at the time "+callBackTime+" as per your request. We look forward to working with you.";
					}
				}
				model.addObject("msg",msg);
				model.addObject("variable",false );
				model.addObject("userProfileDetails",callBack);
				model.addObject("loginURL", contextURL);
				model.addObject("timeSlots", Time);
				model.addObject("userProfile", userProfile);
			}
			return model;
			
		} else {
			return new ModelAndView("redirect:" + ApplicationConstants.LOGIN+ ".html");
		}
	}
	
	/*
	 * This method is used to save the customer callback details.
	 */
	public ModelAndView saveCustomerCallBackInfoSecond(CustomerCallback callBack, ModelAndView model) throws ServiceException {
		
		UserProfile userProfile = null;
		boolean flag=false;
		Quote quote = null;
		
		if(null != session.getAttribute("sessionUser")) {
			userProfile = (UserProfile) session.getAttribute("sessionUser");
			try {				
				flag = callBackDaoObj.saveCustomerCallBackDetailsInfo(callBack, userProfile);
			} catch (DAOException e) {
				logger.error("ERROR : " + e.getMessage());
				throw new ServiceException(e.getMessage());
			}
			if(null != session.getAttribute("selectedQuote") && !"".equals(session.getAttribute("selectedQuote"))){
				quote = (Quote) session.getAttribute("selectedQuote");
			}
			
			if(flag == true)
			{
				String callBackDate = callBack.getCallBackDate();
				String callBackTime = callBack.getGetBackTime();
				String msg = "";
				msg = "Thank you for submitting your application. Our agent will call you on "+callBackDate+" at the time "+callBackTime+" as per your request. We look forward to working with you.";
				
				model.addObject("msg",msg);
				model.addObject("variable",false );
				model.addObject("userProfileDetails",callBack);
				model.addObject("quote",quote);
				model.addObject("timeSlots", Time);
				model.addObject("userProfile", userProfile);
			}
			return model;
		} else {
			return new ModelAndView("redirect:" + ApplicationConstants.LOGIN+ ".html");
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public String saveQuotePageCustomercallBackdetails(
			CustomerCallback callBack, Model model,String pageFrom) throws ServiceException {
		
		UserProfile userProfile = null;
		boolean flag=false; 
		String json = "";
		int userId = 0;
		JSONObject jsonObject = new JSONObject();
		if(null != session.getAttribute("sessionUser")) {
			userProfile = (UserProfile) session.getAttribute("sessionUser");
			userId = userProfile.getUserId();
			try {				
				flag = callBackDaoObj.saveCustomerCallBackDetailsInfo(callBack, userProfile);
				if(pageFrom != null && pageFrom.equalsIgnoreCase("quote")){
					userProfile = profileService.saveUserProfileOnSubmitApplication(userProfile);
					quoteService.deleteprevSavedQuoteOnSubmitwithEmptyQuote(userId);
					try{
						boolean pinneyStatus = pinneyServiceHelperImpl.pinneyRequest(userProfile);						
						userProfile.setProfileStatusFlag(pinneyStatus ? ApplicationConstants.APPLICATION_SUBMITTED_SUCCESS : ApplicationConstants.APPLICATION_SUBMITTED_FAILED);
						profileService.updateUserProfileStatus(userProfile);
						
					}
					catch(Exception e){
						logger.error("ERROR : " + e.getMessage());
					}
					session.setAttribute("sessionUser", userProfile);
					session.setAttribute("selectedQuote", null);
					
					emailService.sendSubmitMail(userProfile);
				}
			} catch (DAOException e) {
				logger.error("ERROR : " + e.getMessage());
				throw new ServiceException(e.getMessage());
			}
			
			if(flag == true)
			{
				String callBackDate = callBack.getCallBackDate();
				String callBackTime = callBack.getGetBackTime();
				String msg = "";
				if(callBackDate=="" && callBackTime=="") {
					msg = "Thank you for submitting your application. We look forward to working with you.";
				} else if(callBackDate=="" && callBackTime!="") {
					msg = "Thank you for submitting your application. Our agent will call you at the time "+callBackTime+" as per your request. We look forward to working with you.";
				} else if(callBackDate!="" && callBackTime=="") {
					msg = "Thank you for submitting your application. Our agent will call you on "+callBackDate+" as per your request. We look forward to working with you.";
				} else {
					msg = "Thank you for submitting your application. Our agent will call you on "+callBackDate+" at the time "+callBackTime+" as per your request. We look forward to working with you.";
				}												
				jsonObject.put("Message", msg);
				jsonObject.put("submitstatus", "true");
				jsonObject.put("callbackphoneNumber", callBack.getCallbackphoneNumber());
				
				json = jsonObject.toString();
			}
			return json;
		}
		else{
			return "redirect:"+ApplicationConstants.LOGIN+".html";
		}
	}
}
