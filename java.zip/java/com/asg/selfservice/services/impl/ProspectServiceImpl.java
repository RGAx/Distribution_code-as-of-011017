package com.asg.selfservice.services.impl;

import java.awt.image.BufferedImage;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.StringTokenizer;

import javax.imageio.ImageIO;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.asg.selfservice.common.logger.LogFactory;
import com.asg.selfservice.common.logger.SelfServiceLogger;
import com.asg.selfservice.common.utils.ApplicationConstants;
import com.asg.selfservice.common.utils.Utils;
import com.asg.selfservice.dao.ProspectDAO;
import com.asg.selfservice.domain.CampaignReport;
import com.asg.selfservice.domain.Prospect;
import com.asg.selfservice.domain.UserProfile;
import com.asg.selfservice.exception.DAOException;
import com.asg.selfservice.exception.ServiceException;
import com.asg.selfservice.services.ProspectService;


/**
 * This class Implements the ProspectService Interface, and has methods to fetch 
 * Prospect details based on the encryptedUId obtained from the URL. 
 * Also, this class is used to update the prospect details, Insert into User Profile table,
 * To calculate Price expression, Check if the image exists and To get the User History for Checkbox Hit Report
 * 
 * 
 */
@Service
public class ProspectServiceImpl implements ProspectService {
	
	private static final SelfServiceLogger logger = LogFactory.getInstance(ProspectServiceImpl.class);

	@Autowired
	private ProspectDAO prosDaoObj;
	
	@Autowired
	private HttpSession session;
	
	@Value("${application.context.url}")
	private String IMAGE_URL; 
	
	@Value("${limit.landingpage.hits}")
	private int landingPageHits;
	
	@Value("${limit.url.days}")
	private int UrlLimit;
	
	/*
	 * This method has been used to fetch prospect details based on encryptedUId.
	 */
	public Prospect getProspectData(String encryptedUId) throws ServiceException {
		logger.info("Fetching prospect details for encryptedUId..:"+encryptedUId);
		final int userProfileCreated;
		final String trimmedUrl;
		final String imageSource;
		Prospect prospect = null;

		try {
			prospect = this.loadProspectData(encryptedUId);
		} catch (ServiceException e) {
			logger.error("ERROR : " + e.getMessage());
			throw new ServiceException(e.getMessage());
		}		
		userProfileCreated = isUserProfileCreated(encryptedUId);
		prospect.setUpCreated(userProfileCreated);

		// create a new method to trim the Video URL to set it.

		trimmedUrl = trimVideoUrl(prospect.getVideoUrl());
		prospect.setVideoUrl(trimmedUrl);

		if (ValidateProspect(prospect)) {
			// Price Expression calculation
			prospect = PECalculation(prospect);

		}

		/*
		 * logic for agency logos. based on the png, jpg, and gif images
		 * extension
		 */
		imageSource = addAgencyLogo(prospect.getAgencyName());
		prospect.setLogoName(imageSource);

		return prospect;
	}

	
	/*
	 * logic for agency logos. based on the png, jpg, and gif images
	 * extension
	 * @param agencyName
	 * @return
	 */
	private String addAgencyLogo(String agencyName) throws ServiceException {
		String imageSource = null;
		if(agencyName != null && agencyName != "") {
			agencyName = agencyName.replaceAll(" ", "_");
		
			/* setting the agency name in session to show the legal statement*/
			session.setAttribute("agencyName", agencyName);
			String agency_logo_png = "resources/agencylogos/" + agencyName.concat(".png");
			String agency_logo_jpg = "resources/agencylogos/" + agencyName.concat(".jpg");
			String agency_logo_gif = "resources/agencylogos/" + agencyName.concat(".gif");
	
			if (checkImageExists(agency_logo_png)) {
				imageSource = agency_logo_png;
			} else if (checkImageExists(agency_logo_jpg)) {
				imageSource = agency_logo_jpg;
			} else if (checkImageExists(agency_logo_gif)) {
				imageSource = agency_logo_gif;
			} else {
				imageSource = agencyName;
			}
		}
		return imageSource;
	}

	/*
	 * Price Expression calculation and setting the values back to prospect after
	 * the user validation returns true
	 *
	 * @param prospect2
	 */
	private Prospect PECalculation(Prospect prospect) throws ServiceException {
		String salutation = prospect.getSalutation();
		if ("Mr.".equalsIgnoreCase(salutation) || "Mr".equalsIgnoreCase(salutation)
				|| "Master".equalsIgnoreCase(salutation)) {
			prospect.setGender("M");
		} else {
			prospect.setGender("F");
		}

		String dateOfBirth = prospect.getDob();

		int years;

		if (null == dateOfBirth || "".equals(dateOfBirth) || "null".equalsIgnoreCase(dateOfBirth)) {
			years = 40;
		}

		else {
			DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
			try {
				logger.debug("dateOfBirth: " + dateFormat.parse(dateOfBirth));
				years = Utils.getDiffYears(dateFormat.parse(dateOfBirth), new Date());
				logger.debug("age: "+years);
			} catch (ParseException e) {
				throw new ServiceException();
			}
			if (years < 20) {
				years = 20;
			} else if (years > 60) {
				years = 60;
			}
		}
		prospect.setAge(years);
		String gender = prospect.getGender();
		
		try {
			List<Integer> minValues = prosDaoObj.getPriceData(gender, years);
			prospect.setMinEstimate(minValues.get(0));
			prospect.setSecondMinEstimate(minValues.get(1));
			
			return prospect;
		} catch (DAOException e) {
			logger.error("ERROR : " + e.getMessage());
			throw new ServiceException(e.getMessage());
		}
	}

	/*
	 * Trim the Video URL to play the video in Browser.
	 *
	 */
	/**
	 * @param videoUrl
	 * @return
	 */
	private String trimVideoUrl(String videoUrl) {
		String trimmedUrl = null;
		StringTokenizer st = new StringTokenizer(videoUrl, "?");

		while (st.hasMoreTokens()) {
			trimmedUrl = st.nextToken();
			trimmedUrl = StringUtils.replace(trimmedUrl, "id=", "").trim();
		}
		return trimmedUrl;
	}

	/*
	 * This method checks if the User profile is created in USER_PROFILE based on encryptedUId.
	 */
	private int isUserProfileCreated(String encryptedUId) throws ServiceException {
		logger.info("Checking if the user profile is created for encryptedUId..:"+encryptedUId);
		try {
			return prosDaoObj.getUserProfileData(encryptedUId);

		} catch (DAOException e) {
			logger.error("ERROR : " + e.getMessage());
			throw new ServiceException(e.getMessage());
		}
	}

	/**
	 * @param fileName
	 * @return
	 * @throws ServiceException 
	 */
	private boolean checkImageExists(String fileName) throws ServiceException {
		boolean imageExists = false;
		StringBuilder sbuilder = new StringBuilder(IMAGE_URL);
		sbuilder.append(fileName);

		try {
			BufferedImage image = ImageIO.read(new URL(sbuilder.toString()));
			if (null != image) {
				imageExists = true;

			} 
		} catch (MalformedURLException e) {
			logger.error("ERROR : "+e.getMessage());
		} catch (IOException e) {
			logger.error("ERROR : "+e.getMessage());
		}
		return imageExists;
	}

	/**
	 * @param prospect
	 * @return
	 * @throws ServiceException 
	 */
	private boolean ValidateProspect(Prospect prospect) throws ServiceException {
		logger.info("Validating prospect details..");
		boolean isValid = true;
		// Get the Userprofile is created
		int check = prospect.getUpCreated();
		// Get the count of Landing Page Hits //
		int count = prospect.getLandingpageHits();

		// To find difference between current date and Email sent date //

		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		Date date = new Date();
		String currentDate = dateFormat.format(date);

		String sentDate = prospect.getSentDate();

		Date d1 = null;
		Date d2 = null;

		try {
			d1 = dateFormat.parse(currentDate);
			d2 = dateFormat.parse(sentDate);

			long diff = d1.getTime() - d2.getTime();
			long days = diff / (24 * 60 * 60 * 1000);

			// Check if landing page hits is > 6 and URL lifetime is > 75 days
			
			if (count >= landingPageHits || days > UrlLimit) {
				logger.info("Navigate to campaign over page..");
				isValid = false;
				prospect.setNavigationPage("campaignover");
			}
			/*
			 * Check if User Profile is created which is '0' If >='1' User Profile
			 * created then Navigate to Login Page
			 */
			else if (ApplicationConstants.USER_PROFILE_CREATED <= check) {
				logger.info("Navigate to login page..");
				prospect.setNavigationPage("login");
				isValid = false;

			}  else {
				logger.info("Navigate to landing page and Update landing page hits..");
				// update landing page Hits //
				int landingPageCtr = count + 1;
				int userID = prospect.getId();
				prosDaoObj.updateLandingPageHits(landingPageCtr, userID);
				prospect.setNavigationPage("landingPage");
			}
		} catch (ParseException e) {
			logger.error("ERROR : " + e.getMessage());
			throw new ServiceException(e.getMessage());
		} catch (DAOException e) {
			logger.error("ERROR : " + e.getMessage());
			throw new ServiceException(e.getMessage());
		}
		return isValid;
	}

	/* (non-Javadoc)
	 * @see com.asg.selfservice.services.ProspectService#updateCheckboxHits(com.asg.selfservice.domain.Prospect)
	 */
	public void updateCheckboxHits(Prospect prospect) throws ServiceException {
		logger.info("Updating checkbox hits..");
		try {
			int userID = prospect.getId();
			int checkboxHits = prospect.getCheckboxHits();
			
			prospect = PECalculation(prospect);

			String imageSource = addAgencyLogo(prospect.getAgencyName());
			prospect.setLogoName(imageSource);
		
			if (checkboxHits == 0) {
				String randomPassword = Utils.generateRandomPassword();
				// Added temporarily
				logger.info("randomPassword : " + randomPassword);
				prospect.setPassword(randomPassword);

				logger.info("Inserting prospect details into user profile..");
				prosDaoObj.insertIntoUserProfile(prospect);
			}
			
			//Put the user data into session
			UserProfile userProfile;

			userProfile = prosDaoObj.loadUserProfileBasedEncryptedUID(prospect.getEncryptedUId());
			if(userProfile != null)
				userProfile.setEncryptedUid(prospect.getEncryptedUId());
			
			session.setAttribute("sessionUser", userProfile);

			checkboxHits = checkboxHits + 1;

			prosDaoObj.updateCheckboxHits(checkboxHits, userID);
			prospect.setCheckboxHits(checkboxHits);
		} catch (DAOException e) {
			logger.error("ERROR : " + e.getMessage());
			throw new ServiceException(e.getMessage());
		}
	}

	/* (non-Javadoc)
	 * @see com.asg.selfservice.services.ProspectService#getListOfAgencies()
	 */
	public List<String> getListOfAgencies() throws ServiceException {
		logger.info("Fetching the list of agencies..");
		List<String> listOfAgencies;
		try {
			listOfAgencies = prosDaoObj.getListOfAgencies();
		} catch (DAOException e) {
			logger.error("ERROR : " + e.getMessage());
			throw new ServiceException(e.getMessage());
		}
		return listOfAgencies;
	}

	/* (non-Javadoc)
	 * @see com.asg.selfservice.services.ProspectService#getUserHistory(java.lang.String)
	 */
	public List<Prospect> getUserHistory(String selectedAgencyName) throws ServiceException {
		logger.info("Fetching checkbox hit report based on selected agency name..:"+selectedAgencyName);
		List<Prospect> users;
		String[] agency=null;
		
		if(null != selectedAgencyName) {
			agency = selectedAgencyName.split("_");
		}
		String agencyName = agency != null ? agency[0] : "";
		if (agencyName.equalsIgnoreCase("none")) {
			try {
				users = prosDaoObj.getListOfCheckboxHitRecords();
			} catch (DAOException e) {
				logger.error("ERROR : " + e.getMessage());
				throw new ServiceException(e.getMessage());
			}
		}
		
		else {
			String processedDate =  agency != null ? agency[1] : null;
			try {
				users = prosDaoObj.getUserHistory(agencyName, processedDate);
			} catch (DAOException e) {
				logger.error("ERROR : " + e.getMessage());
				throw new ServiceException(e.getMessage());
			}
		}

		return users;
	}
	
	/*
	 * Used for loading the prospect data based on encrypted id.
	 */
	public Prospect loadProspectData(String encryptedUId) throws ServiceException {
		Prospect prospect;
		try {
			prospect = prosDaoObj.getProspectData(encryptedUId);
		} catch (DAOException e) {
			logger.error("ERROR : " + e.getMessage());
			throw new ServiceException(e.getMessage());
		}
		return prospect;
	}

	/*
	 * This method is used for fetching the Campaign & Pinney Report.
	 */
	@Override
	public List<CampaignReport> getCampaignReport() throws ServiceException {
		logger.info("Fetching campaign and pinney report");
		List<CampaignReport> report;
		try {
			report = prosDaoObj.getCampaignreport();
		} catch (DAOException e) {
			logger.error("ERROR : " + e.getMessage());
			throw new ServiceException(e.getMessage());
		}
		
		return report;
	}
}
