/**
 * 
 */
package com.asg.selfservice.services.impl;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.asg.selfservice.common.logger.LogFactory;
import com.asg.selfservice.common.logger.SelfServiceLogger;
import com.asg.selfservice.common.utils.ApplicationConstants;
import com.asg.selfservice.common.utils.Utils;
import com.asg.selfservice.dao.LoginDAO;
import com.asg.selfservice.domain.UserProfile;
import com.asg.selfservice.exception.DAOException;
import com.asg.selfservice.exception.ServiceException;
import com.asg.selfservice.services.AdminAccessService;
import com.asg.selfservice.services.LoginService;
import com.asg.selfservice.services.ProfileService;

/**
 * This class has been used to implement all the login page operations such as validating the user
 * based on username and password and update the page hits accordingly into the DB etc, 
 * verifying the user existence based on the username from the DB.
 * 
 * @author M1030133
 *
 */
@Service
public class LoginServiceImpl implements LoginService {
	private static final SelfServiceLogger logger = LogFactory.getInstance(LoginServiceImpl.class);

	@Autowired
	private LoginDAO loginDao;
	
	@Autowired
	private ProfileService profileService;
	
	@Autowired
	private EmailServiceImpl emailService;
	
	@Autowired
	private AdminAccessService adminAccessService;
	
	/*
	 * This method has been used for validating the user based on username and password and 
	 * update the page hits accordingly into the DB
	 * @see com.asg.selfservice.services.LoginService#isValidateUser(com.asg.selfservice.domain.UserProfile)
	 */
	public UserProfile validateUser(UserProfile user) throws ServiceException {
		final long startTime = logger.logMethodEntry();
		
		String email = user.getEmailAddress();
		logger.info("USERNAME :" +email);
		
		user.setValidCount(0);
		UserProfile dbUser;
		try {
			dbUser = profileService.loadUserProfileByEmail(email);
			if(dbUser == null) {
				dbUser = adminAccessService.loadAdminUser(email);
				if(dbUser == null) {
					return user;
				}
				dbUser.setUserType(ApplicationConstants.ADMIN_USER);
			}
			
		} catch (ServiceException e) {
			logger.error("ERROR : " + e.getMessage());
			throw new ServiceException(e.getMessage());
		}
		int isValid = dbUser.getValidCount();
		int changeTime = (int) Utils.getTimeDifferenceInMinutes(dbUser.getLastUnsuccessfulDate(), new Date());
		
		int loginUnsuccessfulAttemptCount = dbUser.getUnsuccessfulAttemptCtr();
		
		boolean passwordMatchFlag = Utils.passwordMatches(user.getPassword(), dbUser.getPassword());
		
		try {
			if(loginUnsuccessfulAttemptCount < ApplicationConstants.LOGIN_UNSUCCESSFUL_ATTEMPTS_COUNT) {
				if(passwordMatchFlag) {
					loginUnsuccessfulAttemptCount = 0;

					if(ApplicationConstants.ADMIN_USER.equalsIgnoreCase(dbUser.getUserType())) {
						loginDao.updateAdminCounter(loginUnsuccessfulAttemptCount, email);
					} else {
						loginDao.updateCounter(loginUnsuccessfulAttemptCount, email);
					}
					isValid = 1;
				} else {
					loginUnsuccessfulAttemptCount = loginUnsuccessfulAttemptCount + 1;
					logger.info("COUNT: "+loginUnsuccessfulAttemptCount);
					
					if(ApplicationConstants.ADMIN_USER.equalsIgnoreCase(dbUser.getUserType())) {
						loginDao.updateAdminCounter(loginUnsuccessfulAttemptCount, email);
					} else {
						loginDao.updateCounter(loginUnsuccessfulAttemptCount, email);
					}
					
					if(loginUnsuccessfulAttemptCount == ApplicationConstants.LOGIN_UNSUCCESSFUL_ATTEMPTS_COUNT)
						isValid = 2;
				}
			} else {
				if(changeTime < ApplicationConstants.ACCOUNT_UNLOCK_TIME) {
					isValid = 2;
					logger.info("ACCOUNT LOCKED..TRY AFTER 15 MINUTES!!");
				} else if(passwordMatchFlag) {
					loginUnsuccessfulAttemptCount = 0;
					loginDao.updateCounter(loginUnsuccessfulAttemptCount, email);
					
					isValid = 1;
					logger.info("ACCOUNT UN-LOCKED..!!");
				} else {
					logger.info("Password not matching..!!");
				}
			}
		} catch (DAOException e) {
			logger.error("ERROR : " + e.getMessage());
			throw new ServiceException(e.getMessage());
		}
		dbUser.setValidCount(isValid);
		logger.logMethodExit(startTime);
		return dbUser;
	}

	/*
	 * This method has been used for verifying the existence of the user in the DB based 
	 * on the username.
	 * 
	 * @see com.asg.selfservice.services.LoginService#isUserExists(java.lang.String)
	 */
	public boolean isUserExists(String username) throws ServiceException {
		try {
			return loginDao.isUserExists(username);
		} catch (DAOException e) {
			logger.error("ERROR : " + e.getMessage());
			throw new ServiceException(e.getMessage());
		}
	}

	/*
	 * This method has been used to update the user profile with the password
	 * and send the email back to the user.
	 * 
	 * @see
	 * com.asg.selfservice.services.LoginService#updateUserAndSendMail(java.
	 * lang.String)
	 */
	@Override
	public UserProfile updateUserAndSendMail(String username) throws ServiceException {
		try {
			UserProfile userProfile = profileService.loadUserProfileByEmail(username);

			if(userProfile.getProfileStatusFlag() > 0) {
				String randomPassword = Utils.generateRandomPassword();
				emailService.sendMail(userProfile, randomPassword);
				
				userProfile.setPassword(Utils.encryptPassword(randomPassword));
				profileService.updateUserProfilePassword(userProfile);
			}
			return userProfile;
		} catch (ServiceException e) {
			logger.error("ERROR : " + e.getMessage());
			throw new ServiceException(e.getMessage());
		}
	}
}
