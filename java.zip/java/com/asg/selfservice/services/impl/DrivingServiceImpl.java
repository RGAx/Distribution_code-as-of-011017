/**
 * 
 */
package com.asg.selfservice.services.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;

import com.asg.selfservice.common.logger.LogFactory;
import com.asg.selfservice.common.logger.SelfServiceLogger;
import com.asg.selfservice.common.utils.ApplicationConstants;
import com.asg.selfservice.domain.DrivingHistory;
import com.asg.selfservice.domain.Question;
import com.asg.selfservice.domain.QuestionAnswer;
import com.asg.selfservice.domain.UserProfile;
import com.asg.selfservice.exception.ServiceException;
import com.asg.selfservice.services.DrivingService;
import com.asg.selfservice.services.GenericService;

/*****
 * 
 * Service Level implementation for Driving related details to save into the DB and retreiving details from the DB
 * @author M1029563
 */
public class DrivingServiceImpl implements DrivingService{
	
	private static final SelfServiceLogger logger = LogFactory.getInstance(DrivingServiceImpl.class);
	
	@Autowired
	private GenericService genericService;
	
	/*
	 * This method is used to retrieve details from USER_QUESTION_ASNWER TABLE
	 * @param userId,qSetId;
	 * @return DrivingHistoryAnswer contains driving history answers object
	 */
	public DrivingHistory loadDrivingPage(int userId,int qsetId) throws ServiceException {
	
		DrivingHistory drivingHistory = null;
		try {
			List<QuestionAnswer> questionAnswerList = genericService.loadQuestionAnswerPerPage(userId,qsetId);
			drivingHistory= new DrivingHistory();
			
			for(QuestionAnswer questionAnswer : questionAnswerList) {
				
				if(questionAnswer.getSequence() == 1) {
					drivingHistory.setDrivingSeq1(questionAnswer.getAnswer());
				}
				if(questionAnswer.getSequence() == 2) {
					drivingHistory.setDrivingSeq2(questionAnswer.getAnswer());
				} 
				if(questionAnswer.getSequence() == 3) {
					drivingHistory.setDrivingSeq3(questionAnswer.getAnswer());
				}
				if(questionAnswer.getSequence() == 4) {
					
					drivingHistory.setDrivingSeq4(questionAnswer.getAnswer());
				} 
				if(questionAnswer.getSequence() == 5) {
					drivingHistory.setDrivingSeq5(questionAnswer.getAnswer());
				} 
				if(questionAnswer.getSequence() == 6) {
					drivingHistory.setDrivingSeq6(questionAnswer.getAnswer());
				} 
				if(questionAnswer.getSequence() == 7) {
					drivingHistory.setDrivingSeq7(questionAnswer.getAnswer());
				} 
				if(questionAnswer.getSequence() == 8) {
					drivingHistory.setDrivingSeq8(questionAnswer.getAnswer());
				} 
				if(questionAnswer.getSequence() == 9) {
					drivingHistory.setDrivingSeq9(questionAnswer.getAnswer());
				} 
				if(questionAnswer.getSequence() == 10) {
					drivingHistory.setDrivingSeq10(questionAnswer.getAnswer());
				} 
				if(questionAnswer.getSequence() == 11) {
					drivingHistory.setDrivingSeq11(questionAnswer.getAnswer());
				} 
				if(questionAnswer.getSequence() == 12) {
					drivingHistory.setDrivingSeq12(questionAnswer.getAnswer());
				} 
				if(questionAnswer.getSequence() == 13) {
					drivingHistory.setDrivingSeq13(questionAnswer.getAnswer());
				} 
				if(questionAnswer.getSequence() == 14) {
					drivingHistory.setDrivingSeq14(questionAnswer.getAnswer());
				} 
				if(questionAnswer.getSequence() == 15) {
					drivingHistory.setDrivingSeq15(questionAnswer.getAnswer());
				} 
			}
		} catch (ServiceException e) {
			logger.error("ERROR : " + e.getMessage());
			throw new ServiceException(e.getMessage());
		}
				
		return drivingHistory;
	}
	
	/*This method is used to construct Driving related questions loading from the context path. If it is null loaded from the Questions Table
	 * @param QId
	 * @return List<Question> drivingQuestions
	 */
	public List<Question> loadQuestions() throws ServiceException {

		List<Question> drivingQuestion = new ArrayList<Question>();
		
		try {
			List<Question> questionList = genericService.loadQuestions();
			
			for (Question question : questionList) {
				
				if(question.getQsetId() == ApplicationConstants.drivinghistoryQuestionSetID) {
					
					drivingQuestion.add(question);
				}
			}
		} catch (ServiceException e) {
			logger.error("ERROR : " + e.getMessage());
			throw new ServiceException(e.getMessage());
		}
		return drivingQuestion;
	}
	
	/*
	 * This method is used to save Driving details in the USER_QUESTION_ANSWER Table
	 *  @param UserProfile userProfile,DrivingHistory drivingHistory
	 *  @Exception ServiceException
	 */
	public void saveUpdateDrivingInfo(UserProfile userProfile,
			DrivingHistory drivingHistory) throws ServiceException {
		
		try{
			Map<String, Integer> questAnsUIdQSetIdSeqIdMap = genericService.loadQuestAnsUIdQSetIdSeqIdMap(userProfile);
			Map<Integer,List<Integer>> reflexivequestionMap = genericService.loadReflexiveQuestions();
			List<Integer> qid=null;
			List<Integer> reflexiveQid = null;
			int questionId=0;
			int qIdSize = 0;
			if(null != drivingHistory.getDrivingSeq1() && !drivingHistory.getDrivingSeq1().isEmpty()){
				
				if(drivingHistory.getDrivingSeq1().equals("0")){
					questionId = questAnsUIdQSetIdSeqIdMap.get(userProfile.getUserId()+"-"+ApplicationConstants.drivinghistoryQuestionSetID+"-"+ApplicationConstants.ONE);
					qid = reflexivequestionMap.get(questionId);
					genericService.saveUpdateInfo(userProfile, this.constructQuestionAnswer(userProfile, questionId, drivingHistory.getDrivingSeq1()));
					if(null != qid && !qid.isEmpty()){
						genericService.deleteAnswers(userProfile, qid.toArray(new Integer[qid.size()]));
						qIdSize = qid.size();
						for(int i=0;i < qIdSize;i++){
							reflexiveQid = reflexivequestionMap.get(qid.get(i));
							if(null != reflexiveQid && !reflexiveQid.isEmpty()){
								genericService.deleteAnswers(userProfile, reflexiveQid.toArray(new Integer[reflexiveQid.size()]));
							}
						}
					}
				}
				else{
					if(null != drivingHistory.getDrivingSeq1() && !drivingHistory.getDrivingSeq1().isEmpty()){
						questionId = questAnsUIdQSetIdSeqIdMap.get(userProfile.getUserId()+"-"+ApplicationConstants.drivinghistoryQuestionSetID+"-"+ApplicationConstants.ONE);
						genericService.saveUpdateInfo(userProfile, this.constructQuestionAnswer(userProfile, questionId, drivingHistory.getDrivingSeq1()));
					}
					if(null != drivingHistory.getDrivingSeq2() && !drivingHistory.getDrivingSeq2().isEmpty()){
						questionId = questAnsUIdQSetIdSeqIdMap.get(userProfile.getUserId()+"-"+ApplicationConstants.drivinghistoryQuestionSetID+"-"+ApplicationConstants.TWO);
						genericService.saveUpdateInfo(userProfile, this.constructQuestionAnswer(userProfile, questionId, drivingHistory.getDrivingSeq2()));
						
						if(drivingHistory.getDrivingSeq2().equals("0")){
							
							qid = reflexivequestionMap.get(questionId);
							if(null != qid && !qid.isEmpty()){
								genericService.deleteAnswers(userProfile, qid.toArray(new Integer[qid.size()]));
							}
						}
						else{
							if(null != drivingHistory.getDrivingSeq7() && !drivingHistory.getDrivingSeq7().isEmpty() && !drivingHistory.getDrivingSeq7().contains("-1")){
								questionId = questAnsUIdQSetIdSeqIdMap.get(userProfile.getUserId()+"-"+ApplicationConstants.drivinghistoryQuestionSetID+"-"+ApplicationConstants.SEVEN);
								genericService.saveUpdateInfo(userProfile, this.constructQuestionAnswer(userProfile, questionId, drivingHistory.getDrivingSeq7().replace(",", "-")));
							}
						}						
					}
					if(null != drivingHistory.getDrivingSeq3() && !drivingHistory.getDrivingSeq3().isEmpty()){
						questionId = questAnsUIdQSetIdSeqIdMap.get(userProfile.getUserId()+"-"+ApplicationConstants.drivinghistoryQuestionSetID+"-"+ApplicationConstants.THREE);
						genericService.saveUpdateInfo(userProfile, this.constructQuestionAnswer(userProfile, questionId, drivingHistory.getDrivingSeq3()));
						
						if(drivingHistory.getDrivingSeq3().equals("0")){
							qid = reflexivequestionMap.get(questionId);
							if(null != qid && !qid.isEmpty()){
								genericService.deleteAnswers(userProfile, qid.toArray(new Integer[qid.size()]));
							}
						}
						else{
							if(null != drivingHistory.getDrivingSeq8() && !drivingHistory.getDrivingSeq8().isEmpty() && !drivingHistory.getDrivingSeq8().contains("-1")){
								questionId = questAnsUIdQSetIdSeqIdMap.get(userProfile.getUserId()+"-"+ApplicationConstants.drivinghistoryQuestionSetID+"-"+ApplicationConstants.EIGHT);
								genericService.saveUpdateInfo(userProfile, this.constructQuestionAnswer(userProfile, questionId, drivingHistory.getDrivingSeq8().replace(",", "-")));
							}
						}
					}
					if(null != drivingHistory.getDrivingSeq4() && !drivingHistory.getDrivingSeq4().isEmpty()){
						questionId = questAnsUIdQSetIdSeqIdMap.get(userProfile.getUserId()+"-"+ApplicationConstants.drivinghistoryQuestionSetID+"-"+ApplicationConstants.FOUR);
						genericService.saveUpdateInfo(userProfile, this.constructQuestionAnswer(userProfile, questionId, drivingHistory.getDrivingSeq4()));
						
						if(drivingHistory.getDrivingSeq4().equals("0")){
							qid = reflexivequestionMap.get(questionId);
							if(null != qid && !qid.isEmpty()){
								genericService.deleteAnswers(userProfile, qid.toArray(new Integer[qid.size()]));
							}
						}
						else{
							if(null != drivingHistory.getDrivingSeq9() && !drivingHistory.getDrivingSeq9().isEmpty() && !drivingHistory.getDrivingSeq9().contains("-1")){
								questionId = questAnsUIdQSetIdSeqIdMap.get(userProfile.getUserId()+"-"+ApplicationConstants.drivinghistoryQuestionSetID+"-"+ApplicationConstants.NINE);
								genericService.saveUpdateInfo(userProfile, this.constructQuestionAnswer(userProfile, questionId, drivingHistory.getDrivingSeq9().replace(",", "-")));
							}
						}
						
					}
					if(null != drivingHistory.getDrivingSeq5() && !drivingHistory.getDrivingSeq5().isEmpty()){
						questionId = questAnsUIdQSetIdSeqIdMap.get(userProfile.getUserId()+"-"+ApplicationConstants.drivinghistoryQuestionSetID+"-"+ApplicationConstants.FIVE);
						genericService.saveUpdateInfo(userProfile, this.constructQuestionAnswer(userProfile, questionId, drivingHistory.getDrivingSeq5()));
						if(drivingHistory.getDrivingSeq5().equals("0")){
							qid = reflexivequestionMap.get(questionId);
							if(null != qid && !qid.isEmpty()){
								genericService.deleteAnswers(userProfile, qid.toArray(new Integer[qid.size()]));
							}
						}
						else{
							if(null != drivingHistory.getDrivingSeq10() && !drivingHistory.getDrivingSeq10().isEmpty() && !drivingHistory.getDrivingSeq10().contains("-1")){
								questionId = questAnsUIdQSetIdSeqIdMap.get(userProfile.getUserId()+"-"+ApplicationConstants.drivinghistoryQuestionSetID+"-"+ApplicationConstants.TEN);
								genericService.saveUpdateInfo(userProfile, this.constructQuestionAnswer(userProfile, questionId, drivingHistory.getDrivingSeq10().replace(",", "-")));
							}
						}
					}
					if(null != drivingHistory.getDrivingSeq6() && !drivingHistory.getDrivingSeq6().isEmpty()){
						
						if(drivingHistory.getDrivingSeq6().equals("0")){
							questionId = questAnsUIdQSetIdSeqIdMap.get(userProfile.getUserId()+"-"+ApplicationConstants.drivinghistoryQuestionSetID+"-"+ApplicationConstants.SIX);
							qid = reflexivequestionMap.get(questionId);
							genericService.saveUpdateInfo(userProfile, this.constructQuestionAnswer(userProfile, questionId, drivingHistory.getDrivingSeq6()));
							if(null != qid && !qid.isEmpty()){
								genericService.deleteAnswers(userProfile, qid.toArray(new Integer[qid.size()]));
							}
						}
						else{
							if(null != drivingHistory.getDrivingSeq6() && !drivingHistory.getDrivingSeq6().isEmpty()){
								questionId = questAnsUIdQSetIdSeqIdMap.get(userProfile.getUserId()+"-"+ApplicationConstants.drivinghistoryQuestionSetID+"-"+ApplicationConstants.SIX);
								genericService.saveUpdateInfo(userProfile, this.constructQuestionAnswer(userProfile, questionId, drivingHistory.getDrivingSeq6()));
							}
							if(null != drivingHistory.getDrivingSeq11() && !drivingHistory.getDrivingSeq11().isEmpty() && !drivingHistory.getDrivingSeq11().contains("-1")){
								questionId = questAnsUIdQSetIdSeqIdMap.get(userProfile.getUserId()+"-"+ApplicationConstants.drivinghistoryQuestionSetID+"-"+ApplicationConstants.ELEVEN);
								genericService.saveUpdateInfo(userProfile, this.constructQuestionAnswer(userProfile, questionId, drivingHistory.getDrivingSeq11()));
							}else{
								questionId = questAnsUIdQSetIdSeqIdMap.get(userProfile.getUserId()+"-"+ApplicationConstants.drivinghistoryQuestionSetID+"-"+ApplicationConstants.ELEVEN);
								genericService.deleteAnswers(userProfile, new Integer[]{questionId});
							}
							if(null != drivingHistory.getDrivingSeq12() && !drivingHistory.getDrivingSeq12().isEmpty() && !drivingHistory.getDrivingSeq12().contains("-1")){
								questionId = questAnsUIdQSetIdSeqIdMap.get(userProfile.getUserId()+"-"+ApplicationConstants.drivinghistoryQuestionSetID+"-"+ApplicationConstants.TWELVE);
								genericService.saveUpdateInfo(userProfile, this.constructQuestionAnswer(userProfile, questionId, drivingHistory.getDrivingSeq12()));
							}else{
								questionId = questAnsUIdQSetIdSeqIdMap.get(userProfile.getUserId()+"-"+ApplicationConstants.drivinghistoryQuestionSetID+"-"+ApplicationConstants.TWELVE);
								genericService.deleteAnswers(userProfile, new Integer[]{questionId});
							}
							if(null != drivingHistory.getDrivingSeq13() && !drivingHistory.getDrivingSeq13().isEmpty() && !drivingHistory.getDrivingSeq13().contains("-1")){
								questionId = questAnsUIdQSetIdSeqIdMap.get(userProfile.getUserId()+"-"+ApplicationConstants.drivinghistoryQuestionSetID+"-"+ApplicationConstants.THIRTEEN);
								genericService.saveUpdateInfo(userProfile, this.constructQuestionAnswer(userProfile, questionId, drivingHistory.getDrivingSeq13()));
							}else{
								questionId = questAnsUIdQSetIdSeqIdMap.get(userProfile.getUserId()+"-"+ApplicationConstants.drivinghistoryQuestionSetID+"-"+ApplicationConstants.THIRTEEN);
								genericService.deleteAnswers(userProfile, new Integer[]{questionId});
							}
							if(null != drivingHistory.getDrivingSeq14() && !drivingHistory.getDrivingSeq14().isEmpty() && !drivingHistory.getDrivingSeq14().contains("-1")){
								questionId = questAnsUIdQSetIdSeqIdMap.get(userProfile.getUserId()+"-"+ApplicationConstants.drivinghistoryQuestionSetID+"-"+ApplicationConstants.FOURTEEN);
								genericService.saveUpdateInfo(userProfile, this.constructQuestionAnswer(userProfile, questionId, drivingHistory.getDrivingSeq14()));
							}else{
								questionId = questAnsUIdQSetIdSeqIdMap.get(userProfile.getUserId()+"-"+ApplicationConstants.drivinghistoryQuestionSetID+"-"+ApplicationConstants.FOURTEEN);
								genericService.deleteAnswers(userProfile, new Integer[]{questionId});
							}
							if(null != drivingHistory.getDrivingSeq15() && !drivingHistory.getDrivingSeq15().isEmpty() && !drivingHistory.getDrivingSeq15().contains("-1")){
								questionId = questAnsUIdQSetIdSeqIdMap.get(userProfile.getUserId()+"-"+ApplicationConstants.drivinghistoryQuestionSetID+"-"+ApplicationConstants.FIFTEEN);
								genericService.saveUpdateInfo(userProfile, this.constructQuestionAnswer(userProfile, questionId, drivingHistory.getDrivingSeq15()));
							}else{
								questionId = questAnsUIdQSetIdSeqIdMap.get(userProfile.getUserId()+"-"+ApplicationConstants.drivinghistoryQuestionSetID+"-"+ApplicationConstants.FIFTEEN);
								genericService.deleteAnswers(userProfile, new Integer[]{questionId});
							}
						}				
					}
				}					
			}
					
		}
		catch(ServiceException e){
			logger.error("ERROR : " + e.getMessage());
			throw new ServiceException(e.getMessage());
		}
		
	}
	
	/*
	 * This is an internal method used inside this service code where question answer has been constructed
	 * based on the question id, user and answer value.
	 * 
	 */
	private QuestionAnswer constructQuestionAnswer(UserProfile user, int questionId, String ansValue) {
		final long startTime = logger.logMethodEntry();
		
		QuestionAnswer questAns = new QuestionAnswer();
		
		questAns.setqId(questionId);
		questAns.setUserId(user.getUserId());
		questAns.setAnswer(ansValue);
		questAns.setCreatedDate(new java.sql.Date((new Date()).getTime()));
		questAns.setCreatedBy(user.getFirstName() + " " + (user.getLastName() != null ? user.getLastName() : ""));
		
		logger.logMethodExit(startTime);
		return questAns;
	}

}
