package com.asg.selfservice.services.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.servlet.ModelAndView;

import com.asg.selfservice.common.logger.LogFactory;
import com.asg.selfservice.common.logger.SelfServiceLogger;
import com.asg.selfservice.common.utils.ApplicationConstants;
import com.asg.selfservice.common.utils.Utils;
import com.asg.selfservice.domain.Question;
import com.asg.selfservice.domain.QuestionAnswer;
import com.asg.selfservice.domain.Smoking;
import com.asg.selfservice.domain.UserProfile;
import com.asg.selfservice.exception.ServiceException;
import com.asg.selfservice.services.GenericService;
import com.asg.selfservice.services.ProfileService;
import com.asg.selfservice.services.SmokingService;

/**
 * This class has been used to implement all the services such as loading the
 * tobacco(smoking) page infos, calling the dao method to save/update the tobacco info
 * into db, updating the model with all the updated infos to load the tobacco
 * page.
 * 
 * @author M1030133
 *
 */
@Service
public class SmokingServiceImpl implements SmokingService {

	private static final SelfServiceLogger logger = LogFactory.getInstance(SmokingServiceImpl.class);
	
	@Value("#{'${selfservice.list.months}'.split(',')}") 
	private List<String> months;
	
	@Value("#{'${selfservice.list.tobacco.perday}'.split(',')}") 
	private List<String> tobacosPerDay;
	
	@Autowired
	private GenericService genericService;
	
	@Autowired
	private ProfileService profileService;
	
	/*
	 * This method has been used to load the model object with the corresponding
	 * details such as questions, answers, drop-down field values etc.
	 * 
	 * @see com.asg.selfservice.services.SmokingService#loadSmokingInfo(org.
	 * springframework.web.servlet.ModelAndView,
	 * com.asg.selfservice.domain.UserProfile)
	 */
	public ModelAndView loadSmokingInfo(ModelAndView model, UserProfile userProfile) throws ServiceException {
		final long startTime = logger.logMethodEntry();
		
		model.addObject("smokingQuestions", this.loadSmokingQuestions());
		model.addObject("userProfile", userProfile);
		
		model.addObject("months", months);
		model.addObject("years", Utils.loadLastTenYears());
		model.addObject("tobacosPerDay", tobacosPerDay);
		
		model.addObject("smoking", this.constructSmokingAnswer(userProfile.getUserId(), ApplicationConstants.smokingQuestionSetID));
		model.addObject("profileStatusFlagForAdmin", profileService.loadProfileStatusFlag(userProfile.getUserId()));
		
		logger.logMethodExit(startTime);
		return model;
	}

	/*
	 * This method has been used to save/update the smoking into into the DB.
	 * @see com.asg.selfservice.services.SmokingService#saveUpdateSmokingInfo(com.asg.selfservice.domain.UserProfile, com.asg.selfservice.domain.Smoking)
	 */
	public void saveUpdateSmokingInfo(UserProfile user, Smoking smoking) throws ServiceException {
		final long startTime = logger.logMethodEntry();
		
		Map<String, Integer> questAnsUIdQSetIdSeqIdMap = genericService.loadQuestAnsUIdQSetIdSeqIdMap(user);
		Integer[] qIds = new Integer[3];
		try {
			qIds = this.loadQIdsForSequences(questAnsUIdQSetIdSeqIdMap, user.getUserId(), new Integer[]{2, 9, 10});
			if(smoking.getSmokingSeq2() != null && !smoking.getSmokingSeq2().isEmpty()) {
				genericService.saveUpdateInfo(user, this.constructQuestionAnswer(user, qIds[0], smoking.getSmokingSeq2()));
				
				if("1".equalsIgnoreCase(smoking.getSmokingSeq2())) {
					if(smoking.getSmokingSeq9() != null && !smoking.getSmokingSeq9().isEmpty()) {
						genericService.saveUpdateInfo(user, this.constructQuestionAnswer(user, qIds[1], smoking.getSmokingSeq9().replace(",", "-")));
					}
					if(smoking.getSmokingSeq10() != null && !smoking.getSmokingSeq10().isEmpty()) {
						genericService.saveUpdateInfo(user, this.constructQuestionAnswer(user, qIds[2], smoking.getSmokingSeq10()));
					}
				} else {
					genericService.deleteAnswers(user, qIds);
				}
			} else {
				genericService.deleteAnswers(user, qIds);
			}
			
			qIds = this.loadQIdsForSequences(questAnsUIdQSetIdSeqIdMap, user.getUserId(), new Integer[]{3, 11, 12});
			if(smoking.getSmokingSeq3() != null && !smoking.getSmokingSeq3().isEmpty()) {
				genericService.saveUpdateInfo(user, this.constructQuestionAnswer(user, qIds[0], smoking.getSmokingSeq3()));
				
				if("1".equalsIgnoreCase(smoking.getSmokingSeq3())) {
					if(smoking.getSmokingSeq11() != null && !smoking.getSmokingSeq11().isEmpty()) {
						genericService.saveUpdateInfo(user, this.constructQuestionAnswer(user, qIds[1], smoking.getSmokingSeq11().replace(",", "-")));
					}
					if(smoking.getSmokingSeq12() != null && !smoking.getSmokingSeq12().isEmpty()) {
						genericService.saveUpdateInfo(user, this.constructQuestionAnswer(user, qIds[2], smoking.getSmokingSeq12()));
					}
				} else {
					genericService.deleteAnswers(user, qIds);
				}
			} else {
				genericService.deleteAnswers(user, qIds);
			}
			
			qIds = this.loadQIdsForSequences(questAnsUIdQSetIdSeqIdMap, user.getUserId(), new Integer[]{4, 13, 14});
			if(smoking.getSmokingSeq4() != null && !smoking.getSmokingSeq4().isEmpty()) {
				genericService.saveUpdateInfo(user, this.constructQuestionAnswer(user, qIds[0], smoking.getSmokingSeq4()));
				
				if("1".equalsIgnoreCase(smoking.getSmokingSeq4())) {
					if(smoking.getSmokingSeq13() != null && !smoking.getSmokingSeq13().isEmpty()) {
						genericService.saveUpdateInfo(user, this.constructQuestionAnswer(user, qIds[1], smoking.getSmokingSeq13().replace(",", "-")));
					}
					if(smoking.getSmokingSeq14() != null && !smoking.getSmokingSeq14().isEmpty()) {
						genericService.saveUpdateInfo(user, this.constructQuestionAnswer(user, qIds[2], smoking.getSmokingSeq14()));
					}
				} else {
					genericService.deleteAnswers(user, qIds);
				}
			} else {
				genericService.deleteAnswers(user, qIds);
			}
			
			qIds = this.loadQIdsForSequences(questAnsUIdQSetIdSeqIdMap, user.getUserId(), new Integer[]{5, 15, 16});
			if(smoking.getSmokingSeq5() != null && !smoking.getSmokingSeq5().isEmpty()) {
				genericService.saveUpdateInfo(user, this.constructQuestionAnswer(user, qIds[0], smoking.getSmokingSeq5()));

				if("1".equalsIgnoreCase(smoking.getSmokingSeq5())) {
					if(smoking.getSmokingSeq15() != null && !smoking.getSmokingSeq15().isEmpty()) {
						genericService.saveUpdateInfo(user, this.constructQuestionAnswer(user, qIds[1], smoking.getSmokingSeq15().replace(",", "-")));
					}
					if(smoking.getSmokingSeq16() != null && !smoking.getSmokingSeq16().isEmpty()) {
						genericService.saveUpdateInfo(user, this.constructQuestionAnswer(user, qIds[2], smoking.getSmokingSeq16()));
					}
				} else {
					genericService.deleteAnswers(user, qIds);
				}
			} else {
				genericService.deleteAnswers(user, qIds);
			}
			
			qIds = this.loadQIdsForSequences(questAnsUIdQSetIdSeqIdMap, user.getUserId(), new Integer[]{6, 17, 18});
			if(smoking.getSmokingSeq6() != null && !smoking.getSmokingSeq6().isEmpty()) {
				genericService.saveUpdateInfo(user, this.constructQuestionAnswer(user, qIds[0], smoking.getSmokingSeq6()));
				
				if("1".equalsIgnoreCase(smoking.getSmokingSeq6())) {
					if(smoking.getSmokingSeq17() != null && !smoking.getSmokingSeq17().isEmpty()) {
						genericService.saveUpdateInfo(user, this.constructQuestionAnswer(user, qIds[1], smoking.getSmokingSeq17().replace(",", "-")));
					}
					if(smoking.getSmokingSeq18() != null && !smoking.getSmokingSeq18().isEmpty()) {
						genericService.saveUpdateInfo(user, this.constructQuestionAnswer(user, qIds[2], smoking.getSmokingSeq18()));
					}
				} else {
					genericService.deleteAnswers(user, qIds);
				}
			} else {
				genericService.deleteAnswers(user, qIds);
			}
			
			qIds = this.loadQIdsForSequences(questAnsUIdQSetIdSeqIdMap, user.getUserId(), new Integer[]{7, 19, 20});
			if(smoking.getSmokingSeq7() != null && !smoking.getSmokingSeq7().isEmpty()) {
				genericService.saveUpdateInfo(user, this.constructQuestionAnswer(user, qIds[0], smoking.getSmokingSeq7()));

				if("1".equalsIgnoreCase(smoking.getSmokingSeq7())) {
					if(smoking.getSmokingSeq19() != null && !smoking.getSmokingSeq19().isEmpty()) {
						genericService.saveUpdateInfo(user, this.constructQuestionAnswer(user, qIds[1], smoking.getSmokingSeq19().replace(",", "-")));
					}
					if(smoking.getSmokingSeq20() != null && !smoking.getSmokingSeq20().isEmpty()) {
						genericService.saveUpdateInfo(user, this.constructQuestionAnswer(user, qIds[2], smoking.getSmokingSeq20()));
					}
				} else {
					genericService.deleteAnswers(user, qIds);
				}
			} else {
				genericService.deleteAnswers(user, qIds);
			}
			
			/*int questionId = this.loadQuestionIdFromMap(questAnsUIdQSetIdSeqIdMap, user.getUserId(), 8);
			if(smoking.getSmokingSeq8() != null && !smoking.getSmokingSeq8().isEmpty()) {
				genericService.saveUpdateInfo(user, this.constructQuestionAnswer(user, questionId, smoking.getSmokingSeq8()));
			} else {
				genericService.deleteAnswer(user, this.constructQuestionAnswer(user, questionId, smoking.getSmokingSeq8()));
			}*/
		} catch (ServiceException e) {
			logger.error("ERROR : " + e.getMessage());
			throw new ServiceException(e.getMessage());
		}
		logger.logMethodExit(startTime);
	}
	
	/*
	 * An internal method to load the qIds array from list of sequences.
	 */
	private Integer[] loadQIdsForSequences(Map<String, Integer> questAnsUIdQSetIdSeqIdMap, int userId,  Integer[] sequenceIds) {
		Integer[] qIds = new Integer[3];
		qIds[0] = this.loadQuestionIdFromMap(questAnsUIdQSetIdSeqIdMap, userId, sequenceIds[0]);
		qIds[1] = this.loadQuestionIdFromMap(questAnsUIdQSetIdSeqIdMap, userId, sequenceIds[1]);
		qIds[2] = this.loadQuestionIdFromMap(questAnsUIdQSetIdSeqIdMap, userId, sequenceIds[2]);
		
		return qIds;
	}
	
	/*
	 * This is an internal method for loading the smoking questions from all the questions.
	 */
	private List<Question> loadSmokingQuestions() throws ServiceException {
		final long startTime = logger.logMethodEntry();
		
		List<Question> smokingQuestions = new ArrayList<Question>();
		List<Question> questionList;
		try {
			questionList = genericService.loadQuestions();
		} catch (ServiceException e) {
			logger.error("ERROR : " + e.getMessage());
			throw new ServiceException(e.getMessage());
		}
		
		for (Question question : questionList) {
			if(question.getQsetId() == ApplicationConstants.smokingQuestionSetID) {
				smokingQuestions.add(question);
			}
		}
		logger.logMethodExit(startTime);
		return smokingQuestions;
	}
	
	/*
	 * This is an internal method used inside this service code where smoking answer has been constructed
	 * based on the question set id and user id.
	 */
	public Smoking constructSmokingAnswer(int userId, int smokingQuestionsetId) throws ServiceException {
		final long startTime = logger.logMethodEntry();
		
		Smoking smoking = new Smoking();
		try {
			List<QuestionAnswer> questionAnswerList = genericService.loadQuestionAnswerPerPage(userId, smokingQuestionsetId);
			
			for(QuestionAnswer questionAnswer : questionAnswerList) {
				if(questionAnswer.getSequence() == 1) {
					smoking.setSmokingSeq1(questionAnswer.getAnswer());
				} else if(questionAnswer.getSequence() == 2) {
					smoking.setSmokingSeq2(questionAnswer.getAnswer());
				} else if(questionAnswer.getSequence() == 3) {
					smoking.setSmokingSeq3(questionAnswer.getAnswer());
				} else if(questionAnswer.getSequence() == 4) {
					smoking.setSmokingSeq4(questionAnswer.getAnswer());
				} else if(questionAnswer.getSequence() == 5) {
					smoking.setSmokingSeq5(questionAnswer.getAnswer());
				} else if(questionAnswer.getSequence() == 6) {
					smoking.setSmokingSeq6(questionAnswer.getAnswer());
				} else if(questionAnswer.getSequence() == 7) {
					smoking.setSmokingSeq7(questionAnswer.getAnswer());
				} /*else if(questionAnswer.getSequence() == 8) {
					smoking.setSmokingSeq8(questionAnswer.getAnswer());
				}*/ else if(questionAnswer.getSequence() == 9) {
					smoking.setSmokingSeq9(questionAnswer.getAnswer());
				} else if(questionAnswer.getSequence() == 10) {
					smoking.setSmokingSeq10(questionAnswer.getAnswer());
				} else if(questionAnswer.getSequence() == 11) {
					smoking.setSmokingSeq11(questionAnswer.getAnswer());
				} else if(questionAnswer.getSequence() == 12) {
					smoking.setSmokingSeq12(questionAnswer.getAnswer());
				} else if(questionAnswer.getSequence() == 13) {
					smoking.setSmokingSeq13(questionAnswer.getAnswer());
				} else if(questionAnswer.getSequence() == 14) {
					smoking.setSmokingSeq14(questionAnswer.getAnswer());
				} else if(questionAnswer.getSequence() == 15) {
					smoking.setSmokingSeq15(questionAnswer.getAnswer());
				} else if(questionAnswer.getSequence() == 16) {
					smoking.setSmokingSeq16(questionAnswer.getAnswer());
				} else if(questionAnswer.getSequence() == 17) {
					smoking.setSmokingSeq17(questionAnswer.getAnswer());
				} else if(questionAnswer.getSequence() == 18) {
					smoking.setSmokingSeq18(questionAnswer.getAnswer());
				} else if(questionAnswer.getSequence() == 19) {
					smoking.setSmokingSeq19(questionAnswer.getAnswer());
				} else if(questionAnswer.getSequence() == 20) {
					smoking.setSmokingSeq20(questionAnswer.getAnswer());
				}
			}
		} catch (ServiceException e) {
			logger.error("ERROR : " + e.getMessage());
			throw new ServiceException(e.getMessage());
		}
		logger.logMethodExit(startTime);
		return smoking;
	}
	
	private Map<Integer, List<Integer>> loadReflexiveQuestionsMap() throws ServiceException {
		Map<Integer, List<Integer>> reflexiveQuestionsMap;
		try {
			reflexiveQuestionsMap = genericService.loadReflexiveQuestions();
		} catch (ServiceException e) {
			logger.error("ERROR : " + e.getMessage());
			throw new ServiceException(e.getMessage());
		}
		return reflexiveQuestionsMap;
	}
	
	/*
	 * This is an internal method used for loading the question Id from the context map.
	 */
	private int loadQuestionIdFromMap(Map<String, Integer> questAnsUIdQSetIdSeqIdMap, int userId, int sequence) {
		int questionId = 0;
		try {
			questionId = questAnsUIdQSetIdSeqIdMap.get(userId+"-"+ApplicationConstants.smokingQuestionSetID+"-"+sequence);
		} catch (Exception e) {
			questionId = 0;
		}
		return questionId;
	}
	
	/*
	 * This is an internal method used inside this service code where question answer has been constructed
	 * based on the question id, user and ans value.
	 */
	private QuestionAnswer constructQuestionAnswer(UserProfile user, int questionId, String ansValue) {
		final long startTime = logger.logMethodEntry();
		
		QuestionAnswer questAns = new QuestionAnswer();
		
		questAns.setqId(questionId);
		questAns.setUserId(user.getUserId());
		questAns.setAnswer(ansValue);
		questAns.setCreatedDate(new java.sql.Date((new Date()).getTime()));
		questAns.setCreatedBy(user.getFirstName() + " " + (user.getLastName() != null ? user.getLastName() : ""));
		
		logger.logMethodExit(startTime);
		return questAns;
	}
}
