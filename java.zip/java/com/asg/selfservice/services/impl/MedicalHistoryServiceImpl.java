package com.asg.selfservice.services.impl;

/*****
 * 
 * Service Level implementation for Cholestrol and blood pressure related details to save into the DB and retreiving details from the DB
 * @author M1029563
 */
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;

import com.asg.selfservice.common.logger.LogFactory;
import com.asg.selfservice.common.logger.SelfServiceLogger;
import com.asg.selfservice.common.utils.ApplicationConstants;
import com.asg.selfservice.domain.Answer;
import com.asg.selfservice.domain.MedicalHistoryAnswer;
import com.asg.selfservice.domain.Question;
import com.asg.selfservice.domain.QuestionAnswer;
import com.asg.selfservice.domain.UserProfile;
import com.asg.selfservice.exception.ServiceException;
import com.asg.selfservice.services.GenericService;
import com.asg.selfservice.services.MedicalHistoryService;

public class MedicalHistoryServiceImpl implements MedicalHistoryService{

	private static final SelfServiceLogger logger = LogFactory.getInstance(MedicalHistoryServiceImpl.class);
	
	@Autowired
	private GenericService genericService;
	
	public List<Question> loadQuestions() throws ServiceException {
		
		List<Question> medicalhistoryQuestion = new ArrayList<Question>();
		
		try {
			List<Question> questionList = genericService.loadQuestions();
			
			for (Question question : questionList) {
				
				if(question.getQsetId() == ApplicationConstants.medicalhistoryQuestionSetID) {
					medicalhistoryQuestion.add(question);
				}
			}
		} catch (ServiceException e) {
			logger.error("ERROR : " + e.getMessage());
			throw new ServiceException(e.getMessage());
		}
		return medicalhistoryQuestion;
	}
	
	/*
	 * This method is used to save Cholestrol and Blood Pressure details in the USER_QUESTION_ANSWER Table
	 *  @param UserProfile user,CholestrolAnswer cholAnswer
	 *  @Exception ServiceException
	 */
	public String saveUpdateMedicalInfo(UserProfile user,MedicalHistoryAnswer medAnswer) throws ServiceException{
		
		try {
			Map<String, Integer> questAnsUIdQSetIdSeqIdMap = genericService.loadQuestAnsUIdQSetIdSeqIdMap(user);
			Map<Integer,List<Integer>> reflexivequestionMap = genericService.loadReflexiveQuestions();
			List<Integer> qid=null;
			if(null != medAnswer.getCholestrolSeq1() && !medAnswer.getCholestrolSeq1().isEmpty()
					&& medAnswer.getCholestrolSeq1().equalsIgnoreCase("no")){
				int questionId = questAnsUIdQSetIdSeqIdMap.get(user.getUserId()+"-"+ApplicationConstants.medicalhistoryQuestionSetID+"-"+ApplicationConstants.ONE);
				qid = reflexivequestionMap.get(questionId);
				genericService.saveUpdateInfo(user, this.constructQuestionAnswer(user, questionId, medAnswer.getCholestrolSeq1().equalsIgnoreCase("yes") ? "1" : "0"));
				if(null != qid && !qid.isEmpty()){
					genericService.deleteAnswers(user, qid.toArray(new Integer[qid.size()]));
				}
			}
			
			else{
				if(medAnswer.getCholestrolSeq1() != null && !medAnswer.getCholestrolSeq1().isEmpty()) {
					int questionId = questAnsUIdQSetIdSeqIdMap.get(user.getUserId()+"-"+ApplicationConstants.medicalhistoryQuestionSetID+"-"+ApplicationConstants.ONE);
					genericService.saveUpdateInfo(user, this.constructQuestionAnswer(user, questionId, medAnswer.getCholestrolSeq1().equalsIgnoreCase("yes") ? "1" : "0"));
				}
				if(medAnswer.getCholestrolSeq2() != null && !medAnswer.getCholestrolSeq2().isEmpty()) {
					int questionId = questAnsUIdQSetIdSeqIdMap.get(user.getUserId()+"-"+ApplicationConstants.medicalhistoryQuestionSetID+"-"+ApplicationConstants.TWO);
					genericService.saveUpdateInfo(user, this.constructQuestionAnswer(user, questionId, medAnswer.getCholestrolSeq2()));
				}
				if(medAnswer.getCholestrolSeq3() != null && !medAnswer.getCholestrolSeq3().isEmpty()) {
					int questionId = questAnsUIdQSetIdSeqIdMap.get(user.getUserId()+"-"+ApplicationConstants.medicalhistoryQuestionSetID+"-"+ApplicationConstants.THREE);
					genericService.saveUpdateInfo(user, this.constructQuestionAnswer(user, questionId, medAnswer.getCholestrolSeq3()));
				}
				if(medAnswer.getCholestrolSeq4() != null && !medAnswer.getCholestrolSeq4().isEmpty() && !medAnswer.getCholestrolSeq4().contains("select")) {
					int questionId = questAnsUIdQSetIdSeqIdMap.get(user.getUserId()+"-"+ApplicationConstants.medicalhistoryQuestionSetID+"-"+ApplicationConstants.FOUR);
					genericService.saveUpdateInfo(user, this.constructQuestionAnswer(user, questionId, medAnswer.getCholestrolSeq4().replace(",", "-")));
				}
				if(medAnswer.getCholestrolSeq5() != null && !medAnswer.getCholestrolSeq5().isEmpty() && !medAnswer.getCholestrolSeq5().contains("select")) {
					int questionId = questAnsUIdQSetIdSeqIdMap.get(user.getUserId()+"-"+ApplicationConstants.medicalhistoryQuestionSetID+"-"+ApplicationConstants.FIVE);
					genericService.saveUpdateInfo(user, this.constructQuestionAnswer(user, questionId, medAnswer.getCholestrolSeq5().replace(",", "-")));
				}
			}
			if(null != medAnswer.getBloodpressureSeq6() && !medAnswer.getBloodpressureSeq6().isEmpty() && 
					medAnswer.getBloodpressureSeq6().equalsIgnoreCase("no")){
				int questionId = questAnsUIdQSetIdSeqIdMap.get(user.getUserId()+"-"+ApplicationConstants.medicalhistoryQuestionSetID+"-"+ApplicationConstants.SIX);
				qid = reflexivequestionMap.get(questionId);
				genericService.saveUpdateInfo(user, this.constructQuestionAnswer(user, questionId, medAnswer.getBloodpressureSeq6().equalsIgnoreCase("yes") ? "1" : "0"));
				if(null != qid && !qid.isEmpty()){
					genericService.deleteAnswers(user, qid.toArray(new Integer[qid.size()]));
				}
			}
			else{
				if(medAnswer.getBloodpressureSeq6() != null && !medAnswer.getBloodpressureSeq6().isEmpty()) {
					int questionId = questAnsUIdQSetIdSeqIdMap.get(user.getUserId()+"-"+ApplicationConstants.medicalhistoryQuestionSetID+"-"+ApplicationConstants.SIX);
					genericService.saveUpdateInfo(user, this.constructQuestionAnswer(user, questionId, medAnswer.getBloodpressureSeq6().equalsIgnoreCase("yes") ? "1" : "0"));
				}
				if(medAnswer.getBloodpressureSeq7() != null && !medAnswer.getBloodpressureSeq7().isEmpty()) {
					int questionId = questAnsUIdQSetIdSeqIdMap.get(user.getUserId()+"-"+ApplicationConstants.medicalhistoryQuestionSetID+"-"+ApplicationConstants.SEVEN);
					genericService.saveUpdateInfo(user, this.constructQuestionAnswer(user, questionId, medAnswer.getBloodpressureSeq7()));
				}
				if(medAnswer.getBloodpressureSeq8() != null && !medAnswer.getBloodpressureSeq8().isEmpty()) {
					int questionId = questAnsUIdQSetIdSeqIdMap.get(user.getUserId()+"-"+ApplicationConstants.medicalhistoryQuestionSetID+"-"+ApplicationConstants.EIGHT);
					genericService.saveUpdateInfo(user, this.constructQuestionAnswer(user, questionId, medAnswer.getBloodpressureSeq8()));
				}
				if(medAnswer.getBloodpressureSeq9() != null && !medAnswer.getBloodpressureSeq9().isEmpty() && !medAnswer.getBloodpressureSeq9().contains("select")) {
					int questionId = questAnsUIdQSetIdSeqIdMap.get(user.getUserId()+"-"+ApplicationConstants.medicalhistoryQuestionSetID+"-"+ApplicationConstants.NINE);
					genericService.saveUpdateInfo(user, this.constructQuestionAnswer(user, questionId, medAnswer.getBloodpressureSeq9().replace(",", "-")));
				}
				if(medAnswer.getBloodpressureSeq10() != null && !medAnswer.getBloodpressureSeq10().isEmpty() && !medAnswer.getBloodpressureSeq10().contains("select")) {
					int questionId = questAnsUIdQSetIdSeqIdMap.get(user.getUserId()+"-"+ApplicationConstants.medicalhistoryQuestionSetID+"-"+ApplicationConstants.TEN);
					genericService.saveUpdateInfo(user, this.constructQuestionAnswer(user, questionId, medAnswer.getBloodpressureSeq10().replace(",", "-")));
				}
			}
			
		} catch (ServiceException e) {
			logger.error("ERROR : " + e.getMessage());
			throw new ServiceException(e.getMessage());
		}
		
		return null;
	}
	/*
	 * This method is used to retrieve details from USER_QUESTION_ASNWER TABLE
	 * @param userId,qSetId;
	 * @return MedicalHistoryAnswer contains medical history answers object
	 */
	public MedicalHistoryAnswer loadMedicalInfo(int userId,int qsetId) throws ServiceException {
		
		MedicalHistoryAnswer medicalHistoryAnswer = new MedicalHistoryAnswer();
		try {
			List<QuestionAnswer> questionAnswerList = genericService.loadQuestionAnswerPerPage(userId,qsetId);
			
			for(QuestionAnswer questionAnswer : questionAnswerList) {
				if(questionAnswer.getSequence() == 1) {
					medicalHistoryAnswer.setCholestrolSeq1(questionAnswer.getAnswer());
				}
				if(questionAnswer.getSequence() == 2) {
					medicalHistoryAnswer.setCholestrolSeq2(questionAnswer.getAnswer());
				} 
				if(questionAnswer.getSequence() == 3) {
					medicalHistoryAnswer.setCholestrolSeq3(questionAnswer.getAnswer());
				}
				if(questionAnswer.getSequence() == 4) {
					
					medicalHistoryAnswer.setCholestrolSeq4(questionAnswer.getAnswer());
				} 
				if(questionAnswer.getSequence() == 5) {
					medicalHistoryAnswer.setCholestrolSeq5(questionAnswer.getAnswer());
				} 
				if(questionAnswer.getSequence() == 6) {
					medicalHistoryAnswer.setBloodpressureSeq6(questionAnswer.getAnswer());
				} 
				if(questionAnswer.getSequence() == 7) {
					medicalHistoryAnswer.setBloodpressureSeq7(questionAnswer.getAnswer());
				} 
				if(questionAnswer.getSequence() == 8) {
					medicalHistoryAnswer.setBloodpressureSeq8(questionAnswer.getAnswer());
				} 
				if(questionAnswer.getSequence() == 9) {
					medicalHistoryAnswer.setBloodpressureSeq9(questionAnswer.getAnswer());
				} 
				if(questionAnswer.getSequence() == 10) {
					medicalHistoryAnswer.setBloodpressureSeq10(questionAnswer.getAnswer());
				} 
			}
		} catch (ServiceException e) {
			logger.error("ERROR : " + e.getMessage());
			throw new ServiceException(e.getMessage());
		}
				
		return medicalHistoryAnswer;
	}
	/*This method is used to fetch Cholestrol level's for the questionid from the ANSWERS table in the DB and returns List<String> cholestrolLevel
	 * @param QId
	 * @return List<String> cholestrolLevel
	 */
	public List<String> loadcholestrolLevels(int qId) throws ServiceException {
		List<String> cholestrolLevels = new ArrayList<String>();
		
		try {
			List<Answer> answers = genericService.loadAnswers();
			for(Answer answer : answers) {
				if(answer.getqId() == qId) {
					String weight = answer.getAnswerValue();
					
					int temp1 = Integer.parseInt(weight.split("-")[0]);
			        int temp2 = Integer.parseInt(weight.split("-")[1].split("\\+")[0]);
			        int lastElement = 0;
			        
			        for(int count = temp1; count < temp2; count ++) {
			        	lastElement = count + 1;
			        	cholestrolLevels.add(""+count);
			        }
			        cholestrolLevels.add(lastElement+"+");
				}
			}
		} catch (ServiceException e) {
			logger.error("ERROR : " + e.getMessage());
			throw new ServiceException(e.getMessage());
		}
		
		return cholestrolLevels;
	}
	/*
	 * This method is used to fetch HDL ratio level for the question id from the ANSWERS table in the DB and returns List<String> HDL ratio levels
	 * @param QID
	 * @return List<String> HDLLevels
	 */
	public List<String> loadhdlRatios(int qId) throws ServiceException {

		List<String> hdlLevels = new ArrayList<String>();
		List<Answer> answers;
		try {
			answers = genericService.loadAnswers();
			float lastElement2=0.0f;
			for(Answer answer : answers) {
				if(answer.getqId() == qId) {
					String hdlRatios = answer.getAnswerValue();
					
					int temp1 = (int) (Float.parseFloat(hdlRatios.split("-")[0]) * 10);
			        int temp2 = (int) (Float.parseFloat(hdlRatios.split("-")[1].split("\\+")[0]) * 10);
			        int lastElement = 0;
			        
			        for(int count = temp1 ; count < temp2 ; count ++) {
			        	lastElement =  (count + 1);
			        	float count2 = count/10.0f;
			        	lastElement2 = lastElement/10.0f;
			        	hdlLevels.add(""+count2);
			        }
			        hdlLevels.add(lastElement2+"");
				}
			}
		} catch (ServiceException e) {
			
			logger.error("ERROR : " + e.getMessage());
			throw new ServiceException(e.getMessage());
		}
		
		return hdlLevels;
	}
	
	/*
	 * This method is used to retrieve systolic pressures from the ANSWER table in the DB 
	 * @param qId
	 * @return List<String> systolicPressures
	 * @see com.asg.selfservice.services.BloodPressureService#loadsystolicpressureLevels(int)
	 */
	public List<String> loadsystolicpressureLevels(int qId) throws ServiceException {
		
		List<String> systolicPressures = new ArrayList<String>();
		try{
			List<Answer> answers = genericService.loadAnswers();
			
			for(Answer answer : answers) {
				if(answer.getqId() == qId) {
					String sPressures = answer.getAnswerValue();
					
					int temp1 = Integer.parseInt(sPressures.split("-")[0]);
			        int temp2 = Integer.parseInt(sPressures.split("-")[1].split("\\+")[0]);
			        int lastElement = 0;
			        
			        for(int count = temp1; count < temp2; count ++) {
			        	lastElement = count + 1;
			        	systolicPressures.add(""+count);
			        }
			        systolicPressures.add(lastElement+"");
				}
			}
		}
		catch (ServiceException e) {
			logger.error("ERROR : " + e.getMessage());
			throw new ServiceException(e.getMessage());
		}
		
		return systolicPressures;
	}
	
	/*
	 * This method is used to retrieve diastolic pressures from the ANSWERS TABLE in the DB
	 * @param qid
	 * @return List<String> diastolicPressures
	 * @Exception BaseException
	 * @see com.asg.selfservice.services.BloodPressureService#loaddiastolicpressureLevels(int)
	 */
	public List<String> loaddiastolicpressureLevels(int qId) throws ServiceException {
		
		List<String> diastolicPressures = new ArrayList<String>();
		try{
			List<Answer> answers = genericService.loadAnswers();
			
			for(Answer answer : answers) {
				if(answer.getqId() == qId) {
					String dPressures = answer.getAnswerValue();
					
					int temp1 = Integer.parseInt(dPressures.split("-")[0]);
			        int temp2 = Integer.parseInt(dPressures.split("-")[1].split("\\+")[0]);
			        int lastElement = 0;
			        
			        for(int count = temp1; count < temp2; count ++) {
			        	lastElement = count + 1;
			        	diastolicPressures.add(""+count);
			        }
			        diastolicPressures.add(lastElement+"");
				}
			}
		}
		catch (ServiceException e) {
			logger.error("ERROR : " + e.getMessage());
			throw new ServiceException(e.getMessage());
		}
		return diastolicPressures;
	}
	
	/*
	 * This is an internal method used inside this service code where question answer has been constructed
	 * based on the question id, user and answer value.
	 * 
	 */
	private QuestionAnswer constructQuestionAnswer(UserProfile user, int questionId, String ansValue) {
		final long startTime = logger.logMethodEntry();
		
		QuestionAnswer questAns = new QuestionAnswer();
		
		questAns.setqId(questionId);
		questAns.setUserId(user.getUserId());
		questAns.setAnswer(ansValue);
		questAns.setCreatedDate(new java.sql.Date((new Date()).getTime()));
		questAns.setCreatedBy(user.getFirstName() + " " + (user.getLastName() != null ? user.getLastName() : ""));
		
		logger.logMethodExit(startTime);
		return questAns;
	}

}
