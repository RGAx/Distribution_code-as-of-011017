package com.asg.selfservice.services.impl;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.servlet.ModelAndView;

import com.asg.selfservice.common.logger.LogFactory;
import com.asg.selfservice.common.logger.SelfServiceLogger;
import com.asg.selfservice.dao.QuoteDAO;
import com.asg.selfservice.domain.QuestionAnswer;
import com.asg.selfservice.domain.Quote;
import com.asg.selfservice.domain.UserProfile;
import com.asg.selfservice.exception.DAOException;
import com.asg.selfservice.exception.ServiceException;
import com.asg.selfservice.services.EBIXService;
import com.asg.selfservice.services.GenericService;
import com.asg.selfservice.services.ProfileService;
import com.asg.selfservice.services.QuoteService;
import com.asg.selfservice.ws.service.EBIXWebServiceImpl;

public class QuoteServiceImpl implements QuoteService {
	private static final SelfServiceLogger logger = LogFactory.getInstance(QuoteServiceImpl.class);
	
	@Autowired
	private QuoteDAO quoteDao;
	
	@Value("#{'${selfservice.list.coverages}'.split('\\|')}") 
	private List<String> coverages;
	
	@Value("#{'${selfservice.list.terms}'.split(',')}") 
	private List<Integer> terms;
	
	@Value("#{'${profile.status.applyquote}'}")
	private int applyQuoteStatusFlag;
	
	@Value("#{'${profile.status.firsttimeuser.save}'}")
	private int firstTymUsrSave;
	
	@Value("#{'${selfservice.list.Time}'.split(',')}") 
	private List<String> Time;
	
	@Autowired
	private EBIXService ebixService;
	
	@Autowired
	private GenericService genericService;
	
	@Autowired
	private EBIXWebServiceImpl ebixWebService;
	
	@Autowired
	private ProfileService profileService;
	
	@Autowired
	private HttpSession session;
	
	public ModelAndView loadQuotes(ModelAndView model, UserProfile userProf) throws ServiceException {
		final long startTime = logger.logMethodEntry();
		
		List<Quote> quoteList = new ArrayList<Quote>();
		if(userProf.getProfileStatusFlag() <= 2) {
			List<QuestionAnswer> questAnsList;
			try {
				questAnsList = genericService.loadQuestionAnswersForEBIX(userProf.getUserId());
	
				quoteList = ebixWebService.loadQuotes(userProf, questAnsList);
				
				for(int i = 0; i < quoteList.size(); i++) {
					if(quoteList.get(i) != null && quoteList.get(i).getMonthlyPremium() != null
							&& !quoteList.get(i).getMonthlyPremium().isEmpty()) {
						String premiumValue = quoteList.get(i).getMonthlyPremium();
						premiumValue = premiumValue.replace("$", "");
						premiumValue = premiumValue.replace(".", "");
						premiumValue = premiumValue.replace(",", "");
						if(premiumValue != null && !premiumValue.isEmpty()
								&& Integer.parseInt(premiumValue) > 0) {
							quoteList.get(i).setValidQuote(true);
						}
					}
				}
			} catch(ServiceException e) {
				logger.error("ERROR : "+e.getMessage());
				throw new ServiceException(e.getMessage());
			}
		}
		Quote dbQuote;
		try {
			dbQuote = quoteDao.getQuote(userProf.getUserId());
		} catch (NumberFormatException e) {
			logger.error("ERROR : " + e.getMessage());
			throw new ServiceException(e.getMessage());
		} catch (DAOException e) {
			logger.error("ERROR : " + e.getMessage());
			throw new ServiceException(e.getMessage());
		}
		if(userProf.getProfileStatusFlag() > 2 && dbQuote != null && dbQuote.getMonthlyPremium() != null
				&& !dbQuote.getMonthlyPremium().isEmpty()) {
			String premiumValue = dbQuote.getMonthlyPremium();
			premiumValue = premiumValue.replace("$", "");
			premiumValue = premiumValue.replace(".", "");
			premiumValue = premiumValue.replace(",", "");
			if(premiumValue != null && !premiumValue.isEmpty()
					&& Integer.parseInt(premiumValue) > 0) {
				dbQuote.setValidQuote(true);
			}
			quoteList.add(dbQuote);
		}
		model.addObject("quoteList", quoteList);
		session.setAttribute("quoteList", quoteList);
		
		if(quoteList != null && !quoteList.isEmpty() && quoteList.get(0) != null) {
			session.setAttribute("selectedQuote", quoteList.get(0));
		}
		model.addObject("userProfile", userProf);
		model.addObject("selectedDBQuote", dbQuote);
		model.addObject("timeSlots", Time);
		model.addObject("coverages", coverages);
		model.addObject("terms", terms);
		
		logger.logMethodExit(startTime);
		return model;
	}
	
		
	public UserProfile updatePolicy(UserProfile userProfile, UserProfile sessionUser) throws ServiceException {
		final long startTime = logger.logMethodEntry();
		
		if(sessionUser != null) {
			userProfile.setUserId(sessionUser.getUserId());
			try {
				quoteDao.updatePolicy(userProfile);
			} catch (DAOException e) {
				logger.error("ERROR : " + e.getMessage());
				throw new ServiceException(e.getMessage());
			}
			
			//Set the coverage and term for displaying in the quote page
			sessionUser.setInsuranceCoverage(userProfile.getInsuranceCoverage());
			sessionUser.setInsuranceTerm(userProfile.getInsuranceTerm());
		}
		logger.logMethodExit(startTime);
		return sessionUser;
	}

	@SuppressWarnings("unchecked")
	public void updateQuote(int quoteIndex, UserProfile sessionUser) throws ServiceException {
		final long startTime = logger.logMethodEntry();
		Quote quote = null;
		
		List<Quote> quoteList;
		List<QuestionAnswer> questAnsList;
		try {
			if(session.getAttribute("quoteList") != null) {
				quoteList = (List<Quote>) session.getAttribute("quoteList");
			} else {
				questAnsList = genericService.loadQuestionAnswersForEBIX(sessionUser.getUserId());
				quoteList = ebixWebService.loadQuotes(sessionUser, questAnsList);
			}
		} catch(ServiceException e) {
			logger.error("ERROR : "+e.getMessage());
			throw new ServiceException(e.getMessage());
		}
		if(quoteList != null && !quoteList.isEmpty()) {
			quote = quoteList.get(quoteIndex);
		}
		if(quote == null) {
			return;
		}
		Quote dbQuote = null;
		try {
			dbQuote = quoteDao.getQuote(sessionUser.getUserId());
		} catch (NumberFormatException e) {
			logger.error("ERROR : " + e.getMessage());
			throw new ServiceException(e.getMessage());
		} catch (DAOException e) {
			logger.error("ERROR : " + e.getMessage());
			throw new ServiceException(e.getMessage());
		}
		try {
			if(dbQuote != null && dbQuote.getQuoteId() > 0) {
				quote.setQuoteId(dbQuote.getQuoteId());
				quote.setUpdatedBy(sessionUser.getFirstName()+" "+ sessionUser.getLastName());
				quoteDao.updateQuote(quote);
			} else {
				//Insert quote
				quote.setUserId(sessionUser.getUserId());
				quote.setCreatedBy(sessionUser.getFirstName()+" "+ sessionUser.getLastName());
				quoteDao.insertQuote(quote);
			}
		} catch (DAOException e) {
			logger.error("ERROR : " + e.getMessage());
			throw new ServiceException(e.getMessage());
		}
		session.setAttribute("selectedQuote", quote);
		
		if(quote.getMonthlyPremium() != null) {
			sessionUser.setInitialMonthlyEstimate(quote.getMonthlyPremium());
			profileService.updateUserProfileInitialMonthlyEstimate(sessionUser);
		}
		sessionUser = profileService.saveUserProfileOnApplyNow(sessionUser);
		session.setAttribute("sessionUser", sessionUser);
		logger.logMethodExit(startTime);
	}

	/*
	 * used to load the quote from db;
	 * @see com.asg.selfservice.services.QuoteService#getQuote(int)
	 */
	public Quote getQuote(int userId) throws ServiceException {
		try {
			return quoteDao.getQuote(userId);
		} catch (DAOException e) {
			logger.error("ERROR : " + e.getMessage());
			throw new ServiceException(e.getMessage());
		}
	}


	/* (non-Javadoc)
	 * Used to delete the previously saved Quote from PRODUCT_QUOTE TABLE if gets an empty Quote next time, and user didn't submit the application.
	 * @see com.asg.selfservice.services.QuoteService#deleteprevSavedQuoteOnSubmitwithEmptyQuote(int)
	 */
	@Override
	public void deleteprevSavedQuoteOnSubmitwithEmptyQuote(int userId)
			throws ServiceException {		
		try{
			 quoteDao.deleteSavedQuoteafterpinneySubmitWithEmptyQuote(userId);
		}
		catch (DAOException e) {
			logger.error("ERROR : " + e.getMessage());
			throw new ServiceException(e.getMessage());
		}
	}
}
