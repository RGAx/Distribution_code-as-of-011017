package com.asg.selfservice.services.impl;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;

import com.asg.selfservice.common.logger.LogFactory;
import com.asg.selfservice.common.logger.SelfServiceLogger;
import com.asg.selfservice.common.utils.Utils;
import com.asg.selfservice.domain.UserProfile;
import com.asg.selfservice.exception.ServiceException;


public class SendEmailServiceImpl {
	private static final SelfServiceLogger logger = LogFactory.getInstance(SendEmailServiceImpl.class);

	@Value("${email.forgotpassword.from}") 
	private String from;
	
	@Value("${email.forgotpassword.msg}") 
	private String msg;
	
	@Autowired
	private JavaMailSender  mailSender;
	//private MailSender mailSender;
	
		 
	/*public void setMailSender(MailSender mailSender) {
		this.mailSender = mailSender;
	}*/
	
	public void setMailSender(JavaMailSender mailSender) {
		this.mailSender = mailSender;
	}
 
	public void sendMail(String username) throws ServiceException {
		
		//Construct all the fields
		//String replce = MessageFormat.format(this.msg, "Richard", "school", "Ramesh");
		
		String from = this.from;
		String to = username;
		String subject = "Your life insurance profile";
		this.msg = "Your login username is : " + username + " and password : " + Utils.generateRandomPassword() +". We've created a profile for you. Please log in whenever you would like to change your contact information. You can easily change the password after you log in.";
		
		try {
			this.sendMail(from, to, subject, msg);
		} catch (ServiceException e) {
			logger.error("ERROR : " + e.getMessage());
			throw new ServiceException(e.getMessage());
		}
	}
	
	public void sendMail(String from, String to, String subject, String msg) throws ServiceException {
		//creating message
/*		SimpleMailMessage message = new SimpleMailMessage();
 		message.setFrom(from);
		message.setTo(to);
		message.setSubject(subject);
		message.setText(msg);*/
		
		try { 

 			MimeMessage message = mailSender.createMimeMessage(); 
 //		SimpleMailMessage message = new SimpleMailMessage(); 
 //		message.setFrom(from); 
 			message.setSubject(subject); 
 			MimeMessageHelper helper; 
 			helper = new MimeMessageHelper(message, true); 
 			helper.setFrom(from); 
 			helper.setTo(to); 
 			helper.setText(msg, true); 
 			mailSender.send(message); 
 		} catch (MessagingException ex) { 
 			logger.error("ERROR : " + ex.getMessage());
 		} 



		
		
/*        //sending message
		try{
			mailSender.send(message);
		} catch (MailException e) {
			logger.error("ERROR : " + e.getMessage());
			throw new ServiceException(e.getMessage());
		} catch (Exception e) {
			logger.error("ERROR : " + e.getMessage());
			throw new ServiceException(e.getMessage());
		}*/
	}

	public void sendMail(UserProfile userProfile, String randomPassword) throws ServiceException {
		String from = this.from;
		String to = userProfile.getEmailAddress();
		String subject = "Your life insurance profile";
		this.msg = "Your login username is : " + to + " and password : " + randomPassword +". We've created a profile for you. Please log in whenever you would like to change your contact information. You can easily change the password after you log in.";
		
		try {
			this.sendMail(from, to, subject, msg);
		} catch (ServiceException e) {
			logger.error("ERROR : " + e.getMessage());
			throw new ServiceException(e.getMessage());
		}
	}
}
