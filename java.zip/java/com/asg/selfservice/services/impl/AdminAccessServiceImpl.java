package com.asg.selfservice.services.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.servlet.ModelAndView;

import com.asg.selfservice.common.logger.LogFactory;
import com.asg.selfservice.common.logger.SelfServiceLogger;
import com.asg.selfservice.dao.AdminAccessDAO;
import com.asg.selfservice.domain.UserDetails;
import com.asg.selfservice.domain.UserProfile;
import com.asg.selfservice.exception.DAOException;
import com.asg.selfservice.exception.ServiceException;
import com.asg.selfservice.services.AdminAccessService;

/**
 * This service has been used for performing the operations such
 * 
 * @author M1030133
 *
 */
@Service
public class AdminAccessServiceImpl implements AdminAccessService {

	private static final SelfServiceLogger LOGGER = LogFactory
			.getInstance(AdminAccessServiceImpl.class);
	
	@Autowired
	private AdminAccessDAO adminAccessDao;

	/*
	 * (non-Javadoc)
	 * @see com.asg.selfservice.services.AdminAccessService#loadUsers(org.springframework.web.servlet.ModelAndView, java.lang.String)
	 */
	@Override
	public ModelAndView loadUsers(ModelAndView model, String emailAddress)
			throws ServiceException {
		List<UserDetails> users;
		try {
			users = adminAccessDao.loadUsers(emailAddress);
		} catch (DAOException e) {
			LOGGER.error("ERROR:" + e.getMessage());
			throw new ServiceException(e.getMessage());
		}
		model.addObject("userDetails", users);
		return model;
	}

	/*
	 * (non-Javadoc)
	 * @see com.asg.selfservice.services.AdminAccessService#loadAdminUser(java.lang.String)
	 */
	@Override
	public UserProfile loadAdminUser(String emailAddress) throws ServiceException {
		try {
			return adminAccessDao.loadAdminUser(emailAddress);
		} catch (DAOException e) {
			LOGGER.error("ERROR:" + e.getMessage());
			throw new ServiceException(e.getMessage());
		}
	}

	/*
	 * (non-Javadoc)
	 * @see com.asg.selfservice.services.AdminAccessService#isAdminUser(java.lang.String)
	 */
	@Override
	public boolean isAdminUser(String username) throws ServiceException {
		try {
			UserProfile dbUser = adminAccessDao.loadAdminUser(username);
			if(dbUser != null && dbUser.getEmailAddress() != null && !dbUser.getEmailAddress().isEmpty()) {
				return true;
			}
		} catch (DAOException e) {
			LOGGER.error("ERROR:" + e.getMessage());
			throw new ServiceException(e.getMessage());
		}
		return false;
	}
}
