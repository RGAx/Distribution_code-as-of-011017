/**
 * 
 */
package com.asg.selfservice.services.impl;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;

import com.asg.selfservice.common.logger.LogFactory;
import com.asg.selfservice.common.logger.SelfServiceLogger;
import com.asg.selfservice.exception.ServiceException;

/**
 * This class has been used to implement the HELP icon service
 *  Where the user enters Name, Email ID and the query(Help).
 *  
 * @author M1027376
 *
 */
public class HelpServiceImpl {
	
	private static final SelfServiceLogger logger = LogFactory.getInstance(HelpServiceImpl.class);

	@Autowired
	private EmailServiceImpl emailservice;
	
	/*
	 * This method has been used for fetching the user details
	 * entered by the user on click of HELP icon for sending the email.
	 */
	public void help(HttpServletRequest request) throws ServiceException {
		String toAddress = "";
		String userName = "";
		String email = "";
		String to = null, name = null, from = null;
		
		if(null!=request.getParameter("to")) {
			toAddress = request.getParameter("to");
			String[] substring = toAddress.split(" ");
			to = substring[1];
			logger.info("TO: " +to);
		}
		if(null!=request.getParameter("name")) {
			userName = request.getParameter("name");
			String[] substring1 = userName.split(" ");
			name = substring1[1]+" "+substring1[2];
			logger.info("SUBJECT: " +name);
		}
		if(null!=request.getParameter("email")) {
			email = request.getParameter("email");
			String[] substring2 = email.split(" ");
			from = substring2[1];
			logger.info("FROM: " +from);
		}
		
		String userQuery = request.getParameter("userQuery");
		logger.info("MESSAGE: " +userQuery);
		try {
			if(to != null && name != null && from != null) {
				emailservice.sendMail(from, to, name, userQuery);
			}
		} catch (ServiceException e) {
			logger.error("ERROR : " + e.getMessage());
			throw new ServiceException(e.getMessage());
		}
	}
}
