package com.asg.selfservice.services.impl;

import javax.mail.internet.MimeMessage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;

import com.asg.selfservice.common.logger.LogFactory;
import com.asg.selfservice.common.logger.SelfServiceLogger;
import com.asg.selfservice.domain.UserProfile;
import com.asg.selfservice.exception.ServiceException;

public class EmailServiceImpl {
	private static final SelfServiceLogger logger = LogFactory.getInstance(EmailServiceImpl.class);

	
	@Value("${email.forgotpassword.subject}")
	private String forgotpswd;
	
	@Value ("${email.forgotpassword.from}")
	private  String mailaddress;
	
	@Value("${email.profilecreated.subject}")
	private String profilecreated;
	
	@Value("${email.thankyou.subject}")
	private  String submitapp;
	
	@Value("${application.context.url}")
	private String contextUrl;

	@Autowired
	private JavaMailSender mailSender;

	public void setMailSender(JavaMailSender mailSender) {
		this.mailSender = mailSender;
	}



	/*
	 * This is generic method to call Email send service
	 *  HTML message is accepted
	 */
	
	public void sendMail(String from, String to, String subject, String msg)
			throws ServiceException {
		try {

			MimeMessage message = mailSender.createMimeMessage();
			message.setSubject(subject);
			MimeMessageHelper helper;
			helper = new MimeMessageHelper(message, true);
			helper.setFrom(from);
			helper.setTo(to);
			helper.setText(msg, true);
			mailSender.send(message);
			
		} catch (Exception e) {
			logger.error("ERROR : " + e.getMessage());
			throw new ServiceException(e.getMessage());
		}
	}

	/* 
	 * Forgot password sushant TODO add Agency name in user profile.
	 * 
	 */
	
	public void sendMail(UserProfile userProfile, String randomPassword) throws ServiceException {
		
		String agency_name= null;
		if(null != userProfile.getAgency_name()){
			agency_name = userProfile.getAgency_name();
			
			//agency_name = "Denali Alaskan";//userProfile.getAgency_name();
			agency_name = agency_name.replace(" ","");
			String from = agency_name.concat(mailaddress);
			String to = userProfile.getEmailAddress();
			String subject = this.forgotpswd;
			String firstName = userProfile.getFirstName();
			
			 String msg = "Hi " +firstName+ ",<br><br>" 
						+ "Your Application password has been reset to the following:  <br><br>"
						+ "User Name: "+ to +"<br>"
						+ "Password: "+ randomPassword +"<br><br>"
						+ "Regards,<br>"
						+ agency_name;
	
			try {
				this.sendMail(from, to, subject, msg);
			} catch (ServiceException e) {
				logger.error("ERROR : " + e.getMessage());
				throw new ServiceException(e.getMessage());
			}
		}
	}
	
	
	/*
	 * This method is called when user profile is created in Arch application.
	 * The user will be sent user creation info. like username and password.
	 *  TODO
	 */

	
	public void sendProfileCreateMail(UserProfile userProfile, String randomPassword) throws ServiceException {
		
		String agency_name = null;//userProfile.getAgency_name();
		if(null != userProfile.getAgency_name()){
		agency_name = userProfile.getAgency_name();
		agency_name = agency_name.replace(" ","");
		String from = agency_name.concat(mailaddress);
		String to = userProfile.getEmailAddress();
		String subject = this.profilecreated;
		String firstName = userProfile.getFirstName();
		
		 String msg = "Hi " +firstName+ ",<br><br>" 
					+ "We\'ve created a profile for you. Please log in whenever you would like to change your contact information. You can easily change the password after you log in. <br><br>"
					+"URL: "+ contextUrl +"<br>"
					+ "User Name: "+ to +"<br>"
					+ "Password: "+ randomPassword +"<br><br>"
					+ "Regards,<br>"
					+ agency_name;

		try {
			sendMail(from, to, subject, msg);
		} catch (ServiceException e) {
			logger.error("ERROR : " + e.getMessage());
			throw new ServiceException(e.getMessage());
		}
		}
	}
	
	
	/* This method is called when user Submits the final page.
	 * This will trigger a email to user on sucessfull submission of the application.
	 * Thank you page
	 * TODO
	 */

	public  void sendSubmitMail(UserProfile userProfile)throws ServiceException {
		String agency_name = null;//userProfile.getAgency_name();
		if(null != userProfile.getAgency_name()){
			agency_name = userProfile.getAgency_name();
			agency_name = agency_name.replace(" ","");
		String from = agency_name.concat(mailaddress);
		String to = userProfile.getEmailAddress();
		String subject = this.submitapp;
		String firstName = userProfile.getFirstName();
				
		 String msg = "Hi " +firstName+ ",<br><br>" 
					+ "We appreciate you taking the time to answer a few questions to receive your life insurance policy.  <br><br>"
					+ "Regards,<br>"
					+ agency_name;

			try {
				this.sendMail(from, to, subject, msg);
			} catch (ServiceException e) {
				logger.error("ERROR : " + e.getMessage());
				throw new ServiceException(e.getMessage());
			}
		}
		
	}
	
	
	
}
