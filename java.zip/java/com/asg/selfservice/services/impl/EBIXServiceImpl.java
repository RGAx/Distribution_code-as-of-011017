package com.asg.selfservice.services.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.asg.selfservice.common.logger.LogFactory;
import com.asg.selfservice.common.logger.SelfServiceLogger;
import com.asg.selfservice.domain.QuestionAnswer;
import com.asg.selfservice.domain.Quote;
import com.asg.selfservice.domain.UserProfile;
import com.asg.selfservice.exception.ServiceException;
import com.asg.selfservice.services.EBIXService;
import com.asg.selfservice.services.GenericService;
import com.asg.selfservice.ws.service.EBIXWebServiceImpl;

/**
 * This class has been used for implementing the operations such as loading the
 * user question answer, getting the best quote etc.
 * 
 * @author M1030133
 *
 */
public class EBIXServiceImpl implements EBIXService {
	private static final SelfServiceLogger logger = LogFactory.getInstance(EBIXServiceImpl.class);

	@Autowired
	private EBIXWebServiceImpl ebixWebService;
	
	@Autowired
	private GenericService genericService;

	/*
	 * Getting the best quote.
	 * 
	 * @see com.asg.selfservice.services.EBIXService#getBestQuote(int)
	 */
	public Quote getBestQuote(UserProfile userProfile) throws ServiceException {
		final long startTime = logger.logMethodEntry();
		Quote product = null;

		List<QuestionAnswer> questAnsList = genericService.loadQuestionAnswersForEBIX(userProfile.getUserId());

		try {
			product = ebixWebService.getBestQuote(userProfile, questAnsList);
			
			if(product != null && product.getMonthlyPremium() != null && !product.getMonthlyPremium().isEmpty()) {
				String premiumValue = product.getMonthlyPremium();
				premiumValue = premiumValue.replace("$", "");
				premiumValue = premiumValue.replace(".", "");
				premiumValue = premiumValue.replace(",", "");
				
				if(premiumValue != null && !premiumValue.isEmpty()
						&& Integer.parseInt(premiumValue) > 0) {
					product.setValidQuote(true);
				}
			}
		} catch (ServiceException e) {
			logger.error("ERROR : " + e.getMessage());
			throw new ServiceException(e.getMessage());
		}
		logger.logMethodExit(startTime);
		return product;
	}
}