package com.asg.selfservice.services.impl;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.MailException;
import org.springframework.stereotype.Service;

import com.asg.selfservice.common.logger.LogFactory;
import com.asg.selfservice.common.logger.SelfServiceLogger;
import com.asg.selfservice.common.utils.Utils;
import com.asg.selfservice.dao.ProfileDAO;
import com.asg.selfservice.domain.Health;
import com.asg.selfservice.domain.UserProfile;
import com.asg.selfservice.exception.DAOException;
import com.asg.selfservice.exception.ServiceException;
import com.asg.selfservice.services.ProfileService;

/**
 * This class has been used to implement the operations such as
 * loading/saving/updating the user profile infos from/into the DB.
 * 
 * @author M1030133
 *
 */
@Service
public class ProfileServiceImpl implements ProfileService {
	
	private static final SelfServiceLogger logger = LogFactory.getInstance(ProfileServiceImpl.class);
	
	@Autowired
	private ProfileDAO profileDao;
	
	@Autowired
	private EmailServiceImpl emailService;
	
	/*
	 * This method has been used to call the profile dao to load the profile
	 * based on email address.
	 * 
	 * @see
	 * com.asg.selfservice.services.ProfileService#loadUserProfileByEmail(java.
	 * lang.String)
	 */
	public UserProfile loadUserProfileByEmail(String emailAddress) throws ServiceException {
		try {
			return profileDao.loadUserProfileByEmail(emailAddress);
		} catch (DAOException e) {
			logger.error("ERROR : "+ e.getMessage());
			throw new ServiceException(e.getMessage());
		}
	}

	/*
	 * This method has been used to call the profile dao layer to laod the user
	 * profile based on user id.
	 * 
	 * @see com.asg.selfservice.services.ProfileService#loadUserProfileById(int)
	 */
	public UserProfile loadUserProfileById(int userId) throws ServiceException {
		try {
			return profileDao.loadUserProfileById(userId);
		} catch (DAOException e) {
			logger.error("ERROR : "+ e.getMessage());
			throw new ServiceException(e.getMessage());
		}
	}
	
	/*
	 * This method has been used for updating the user profile initial monthly estimate.
	 * @see com.asg.selfservice.services.ProfileService#updateUserProfileInitialMonthlyEstimate(com.asg.selfservice.domain.UserProfile)
	 */
	public void updateUserProfileInitialMonthlyEstimate(UserProfile userProfile) throws ServiceException {
		final long startTime = logger.logMethodEntry();
		try {
			profileDao.updateUserProfileInitialMonthlyEstimate(userProfile);
		} catch (DAOException e) {
			logger.error("ERROR : " + e.getMessage());
			throw new ServiceException(e.getMessage());
		}
		logger.logMethodExit(startTime);
	}

	/*
	 * This method has been used for updating the user profile along with the
	 * password into the DB.
	 * 
	 * @see
	 * com.asg.selfservice.services.ProfileService#updateUserProfileWithPassword
	 * (com.asg.selfservice.domain.UserProfile)
	 */
	public void updateUserProfileWithPassword(UserProfile userProfile) throws ServiceException {
		try {
			profileDao.updateUserProfileWithPassword(userProfile);
		} catch (DAOException e) {
			logger.error("ERROR : " + e.getMessage());
			throw new ServiceException(e.getMessage());
		}
	}

	/*
	 * This method has been used for updating the user profile password into the
	 * DB.
	 * 
	 * @see
	 * com.asg.selfservice.services.ProfileService#updateUserProfilePassword(com
	 * .asg.selfservice.domain.UserProfile)
	 */
	public void updateUserProfilePassword(UserProfile userProfile) throws ServiceException {
		try {
			profileDao.updateUserProfilePassword(userProfile);
		} catch (DAOException e) {
			logger.error("ERROR : " + e.getMessage());
			throw new ServiceException(e.getMessage());
		}
	}

	/*
	 * This method has been used for updating the user profile status into the
	 * DB.
	 * 
	 * @see
	 * com.asg.selfservice.services.ProfileService#updateUserProfileStatus(com.
	 * asg.selfservice.domain.UserProfile)
	 */
	public void updateUserProfileStatus(UserProfile userProfile) throws ServiceException {
		try {
			profileDao.updateUserProfileStatus(userProfile);
		} catch (DAOException e) {
			logger.error("ERROR : " + e.getMessage());
			throw new ServiceException(e.getMessage());
		}
	}
	
	 /*
	 * (non-Javadoc)
	 * @see com.asg.selfservice.services.EmailScheduler#fetching User answered some questions and left the application.
	 * (profileStatus = 0)
	 */
	@Override
	public List<UserProfile> fetchSavedData() throws ServiceException {
		final long startTime = logger.logMethodEntry();
		List<UserProfile> list;
		try{
			list = profileDao.getuserDetails();
		} catch (DAOException e) {
			logger.error("ERROR : " + e.getMessage());
			throw new ServiceException(e.getMessage());
		}
		logger.logMethodExit(startTime);
		return list;
	}
	
	/*
	 * This method has been used to save the user profile details into the DB with the profile status flag
	 * if saved for the first time.
	 * 
	 * @see com.asg.selfservice.services.ProfileService#saveUserProfile(com.asg.selfservice.domain.UserProfile)
	 */
	public UserProfile saveUserProfile(UserProfile userProfile) throws ServiceException {
		final long startTime = logger.logMethodEntry();
		boolean sendEmail = false;
		
		String randomPassword = "";
		if(userProfile.getProfileStatusFlag() == 0) {
			sendEmail = true;
			userProfile.setProfileStatusFlag(1);
			
			randomPassword = Utils.generateRandomPassword();
			//Added temporarily
			logger.info("randomPassword : "+ randomPassword);
			userProfile.setPassword(Utils.encryptPassword(randomPassword));
		}
		
		if(sendEmail) {
			//Send email to the user with username and password
			try {
				emailService.sendProfileCreateMail(userProfile, randomPassword);
				
				this.updateUserProfileStatus(userProfile);
				this.updateUserProfilePassword(userProfile);
				
				logger.logMethodExit(startTime);
			} catch (MailException e) {
				logger.error("ERROR : " + e.getMessage());
				throw new ServiceException(e.getMessage());
			} catch (ServiceException e) {
				logger.error("ERROR : " + e.getMessage());
				throw new ServiceException(e.getMessage());
			} catch (Exception e) {
				logger.error("ERROR : " + e.getMessage());
				throw new ServiceException(e.getMessage());
			}
		}
		return userProfile;
	}
	
	/*
	 * This method has been used to save the user profile details into the DB with the profile status flag
	 * if saved for the first time.
	 * 
	 * @see com.asg.selfservice.services.ProfileService#saveUserProfileOnApplyNow(com.asg.selfservice.domain.UserProfile)
	 */
	public UserProfile saveUserProfileOnApplyNow(UserProfile userProfile) throws ServiceException {
		final long startTime = logger.logMethodEntry();
		boolean sendEmail = false;
		boolean profileStatus = false;
		
		String randomPassword = "";
		if(userProfile.getProfileStatusFlag() == 0) {
			sendEmail = true;
			profileStatus = true;
			userProfile.setProfileStatusFlag(2);
			
			randomPassword = Utils.generateRandomPassword();
			//Added temporarily
			logger.info("randomPassword : "+ randomPassword);
			userProfile.setPassword(Utils.encryptPassword(randomPassword));
		}
		if(userProfile.getProfileStatusFlag() == 1) {
			profileStatus = true;
			userProfile.setProfileStatusFlag(2);
		}
		
		if(sendEmail) {
			//Send email to the user with username and password
			try {
				emailService.sendProfileCreateMail(userProfile, randomPassword);
				
				this.updateUserProfilePassword(userProfile);
			} catch (MailException e) {
				logger.error("ERROR : " + e.getMessage());
				throw new ServiceException(e.getMessage());
			} catch (ServiceException e) {
				logger.error("ERROR : " + e.getMessage());
				throw new ServiceException(e.getMessage());
			} catch (Exception e) {
				logger.error("ERROR : " + e.getMessage());
				throw new ServiceException(e.getMessage());
			}
		}
		if(profileStatus) {
			this.updateUserProfileStatus(userProfile);
		}
		logger.logMethodExit(startTime);
		return userProfile;
	}
	
	/*
	 * This method has been used for validating the password one that got from db with the one got from UI.
	 * 
	 * @see com.asg.selfservice.services.ProfileService#validatePassword(com.asg.selfservice.domain.UserProfile)
	 */
	public boolean validatePassword(UserProfile userProfile) throws ServiceException {
		final long startTime = logger.logMethodEntry();
		
		if (userProfile.getPassword() != null && !userProfile.getPassword().isEmpty()
				&& userProfile.getNewPassword() != null && !userProfile.getNewPassword().isEmpty()
				&& userProfile.getConfPassword() != null && !userProfile.getConfPassword().isEmpty()) {
			UserProfile dbUser;
			try {
				dbUser = this.loadUserProfileById(userProfile.getUserId());
			} catch (ServiceException e) {
				logger.error("ERROR : " + e.getMessage());
				throw new ServiceException(e.getMessage());
			}
			if(Utils.passwordMatches(userProfile.getPassword(), dbUser.getPassword())) {
				logger.info("Password matches successfully...");
				logger.logMethodExit(startTime);
				return true;
			} else {
				logger.logMethodExit(startTime);
				return false;
			}
		}
		logger.logMethodExit(startTime);
		return false;
	}

	/*
	 * Used for updating the user profile infos into the DB.
	 * 
	 * @see
	 * com.asg.selfservice.services.ProfileService#updateUserProfileDetails(
	 * com.asg.selfservice.domain.UserProfile)
	 */
	public void updateUserProfileInfo(UserProfile userProfile)
			throws ServiceException {
		try {
			profileDao.updateUserProfileInfo(userProfile);
		} catch (DAOException e) {
			logger.error("ERROR : " + e.getMessage());
			throw new ServiceException(e.getMessage());
		}
	}

	/*
	 * Used for updating the user profile infos with the fields entered from health page into the DB.
	 * 
	 * @see
	 * com.asg.selfservice.services.ProfileService#updateUserProfileWithHealthDetails(
	 * com.asg.selfservice.domain.UserProfile)
	 */
	public UserProfile updateUserProfileWithHealthDetails(
			UserProfile userProfile, Health health) throws ServiceException {
		try {
			if (health.getHealthSeq1() != null && !health.getHealthSeq1().isEmpty()) {
				userProfile.setGender(health.getHealthSeq1());
			}
			if(health.getHealthSeq2() != null && !health.getHealthSeq2().isEmpty()
					&& !(health.getHealthSeq2().contains("m") || health.getHealthSeq2().contains("d") || health.getHealthSeq2().contains("y"))) {
				userProfile.setDob(new SimpleDateFormat("MM/dd/yyyy").parse(health.getHealthSeq2()));
			}
			if(health.getHealthSeq3() != null && !health.getHealthSeq3().isEmpty()) {
				Map<String, String> states = Utils.loadStates();
				for(Entry<String, String> state : states.entrySet()) {
					if(state.getValue().equalsIgnoreCase(health.getHealthSeq3())) {
						userProfile.setAddressState(state.getKey());
					}
				}
			}
			profileDao.updateUserProfileWithHealthDetails(userProfile);
		} catch (ParseException e) {
			logger.error("ERROR : "+e.getMessage());
			throw new ServiceException(e.getMessage());
		}  catch (DAOException e) {
			logger.error("ERROR : "+e.getMessage());
			throw new ServiceException(e.getMessage());
		} catch (Exception e) {
			logger.error("ERROR : "+e.getMessage());
			throw new ServiceException(e.getMessage());
		}
		return userProfile;
	}

	/*
	 * This method returns if the email id is present or not in the DB.
	 * @see com.asg.selfservice.services.ProfileService#validateEmail(java.lang.String)
	 */
	@Override
	public boolean validateEmail(String emailAddress, UserProfile sessionUser) throws ServiceException {
		try {
			UserProfile userProfile = profileDao.loadUserProfileByEmail(emailAddress);
			if(userProfile != null && userProfile.getUserId() > 0
					&& userProfile.getUserId() != sessionUser.getUserId())
				return true;
		} catch (DAOException e) {
			logger.error("ERROR : " + e.getMessage());
			throw new ServiceException(e.getMessage());
		}
		return false;
	}
	
	/* (non-Javadoc)
	 * This method has been used to save the user profile details into the DB with the profile status flag
	 * if saved for the first time from SubmitApplication.
	 * @see com.asg.selfservice.services.ProfileService#saveUserProfileOnSubmitApplication(com.asg.selfservice.domain.UserProfile)
	 */
	@Override
	public UserProfile saveUserProfileOnSubmitApplication(
			UserProfile userProfile) throws ServiceException {
		final long startTime = logger.logMethodEntry();
		boolean sendEmail = false;
		boolean profileStatus = false;
		
		String randomPassword = "";
		if(userProfile.getProfileStatusFlag() == 0) {
			sendEmail = true;
			profileStatus = true;
			userProfile.setProfileStatusFlag(3);
			
			randomPassword = Utils.generateRandomPassword();
			//Added temporarily
			logger.info("randomPassword : "+ randomPassword);
			userProfile.setPassword(Utils.encryptPassword(randomPassword));
		}
		if(userProfile.getProfileStatusFlag() == 1) {
			profileStatus = true;
			userProfile.setProfileStatusFlag(3);
		}
		if(userProfile.getProfileStatusFlag() == 2) {
			profileStatus = true;
			userProfile.setProfileStatusFlag(3);
		}
		
		if(sendEmail) {
			//Send email to the user with username and password
			try {
				emailService.sendProfileCreateMail(userProfile, randomPassword);
				
				this.updateUserProfilePassword(userProfile);
			} catch (MailException e) {
				logger.error("ERROR : " + e.getMessage());
				throw new ServiceException(e.getMessage());
			} catch (ServiceException e) {
				logger.error("ERROR : " + e.getMessage());
				throw new ServiceException(e.getMessage());
			} catch (Exception e) {
				logger.error("ERROR : " + e.getMessage());
				throw new ServiceException(e.getMessage());
			}
		}
		if(profileStatus) {
			this.updateUserProfileStatus(userProfile);
		}
		logger.logMethodExit(startTime);
		
		return userProfile;
	}
	
	/*
	 * Email blast for users who have saved application by clicking on SAVE 
	 * however didn't selected any quote (profileStatus = 1)
	 *  
	 */
	public List<UserProfile> getUserProfilesForStatus1()
			throws ServiceException {
		final long startTime = logger.logMethodEntry();
		List<UserProfile> list;
		try{
			list = profileDao.getUserProfilesForStatus1();
		} catch (DAOException e) {
			logger.error("ERROR : " + e.getMessage());
			throw new ServiceException(e.getMessage());
		}
		logger.logMethodExit(startTime);
		return list;
	}
	
	/*
	 * Email blast for users who have clicked on Apply Now by selecting Quote 
	 * however didn't submit the application to Pinney (profileStatus = 2)
	 *  
	 */
	public List<UserProfile> getUserProfilesForStatus2()
			throws ServiceException {
		final long startTime = logger.logMethodEntry();
		List<UserProfile> list;
		try{
			list = profileDao.getUserProfilesForStatus2();
		} catch (DAOException e) {
			logger.error("ERROR : " + e.getMessage());
			throw new ServiceException(e.getMessage());
		}
		logger.logMethodExit(startTime);
		return list;
	}

	/*
	 * (non-Javadoc)
	 * @see com.asg.selfservice.services.ProfileService#updateUserProfileStatusWithAdminCheck(com.asg.selfservice.domain.UserProfile, boolean)
	 */
	@Override
	public void updateUserProfileStatusWithAdminCheck(UserProfile userProfile,
			boolean adminUserFlag) throws ServiceException {
		try {
			profileDao.updateUserProfileStatusWithAdminCheck(userProfile, adminUserFlag);
		} catch (DAOException e) {
			logger.error("ERROR : " + e.getMessage());
			throw new ServiceException(e.getMessage());
		}
	}

	/*
	 * (non-Javadoc)
	 * @see com.asg.selfservice.services.ProfileService#loadProfileStatusFlag(int)
	 */
	@Override
	public int loadProfileStatusFlag(int userId) throws ServiceException {
		try {
			return profileDao.loadProfileStatusFlag(userId);
		} catch (DAOException e) {
			logger.error("ERROR : " + e.getMessage());
			throw new ServiceException(e.getMessage());
		}
	}
}
