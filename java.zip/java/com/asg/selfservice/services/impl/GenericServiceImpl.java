package com.asg.selfservice.services.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.asg.selfservice.common.logger.LogFactory;
import com.asg.selfservice.common.logger.SelfServiceLogger;
import com.asg.selfservice.dao.AnswerDAO;
import com.asg.selfservice.dao.QuestionAnswerDAO;
import com.asg.selfservice.dao.QuestionDAO;
import com.asg.selfservice.domain.Answer;
import com.asg.selfservice.domain.Question;
import com.asg.selfservice.domain.QuestionAnswer;
import com.asg.selfservice.domain.Quote;
import com.asg.selfservice.domain.UserProfile;
import com.asg.selfservice.exception.DAOException;
import com.asg.selfservice.exception.ServiceException;
import com.asg.selfservice.services.GenericService;
import com.asg.selfservice.services.QuoteService;


/**
 * This is a common class which has been used for implementing the common methods and
 * these can be accessed from any other services.
 * 
 * @author M1030133
 *
 */
@Service
public class GenericServiceImpl implements GenericService {
	private static final SelfServiceLogger logger = LogFactory.getInstance(GenericServiceImpl.class);
	
	@Autowired
	private QuestionDAO questionDao;
	
	@Autowired
	private AnswerDAO answerDao;
	
	@Autowired
	private QuestionAnswerDAO questionAnswerDao;
	
	@Autowired
	private ServletContext context;
	
	@Autowired
	private HttpSession session;
	
	@Autowired
	private QuoteService quoteService;
	
	/*
	 * This method has been used to load all the questions from DB and put into context and
	 * it will loaded from db once.
	 * 
	 * @see com.asg.selfservice.services.GenericService#loadQuestions()
	 */
	@SuppressWarnings("unchecked")
	public List<Question> loadQuestions() throws ServiceException {
		final long startTime = logger.logMethodEntry();
		List<Question> contextQuestions = null;
		try {
			if(context.getAttribute("contextQuestions") != null)  {
				contextQuestions = (List<Question>) context.getAttribute("contextQuestions");
			} else {
				contextQuestions = questionDao.loadQuestions();
				context.setAttribute("contextQuestions", contextQuestions);
			}
			
			if(session.getAttribute("selectedQuote") == null 
					&& session.getAttribute("sessionUser") != null) {
				UserProfile sessionUser = (UserProfile) session.getAttribute("sessionUser");
				Quote dbQuote = quoteService.getQuote(sessionUser.getUserId());
				session.setAttribute("selectedQuote", dbQuote);
			}
			logger.logMethodExit(startTime);
			return contextQuestions;
		} catch (DAOException e) {
			logger.error("ERROR : "+ e.getMessage());
			throw new ServiceException(e.getMessage());
		}
	}

	/*
	 * This method has been used to load all the answers from the DB which will be only once and
	 * it will be available in context.
	 * 
	 * @see com.asg.selfservice.services.genericService#loadAnswers()
	 */
	@SuppressWarnings("unchecked")
	public List<Answer> loadAnswers() throws ServiceException {
		final long startTime = logger.logMethodEntry();
		List<Answer> contextAnswers = null;
		try {
			if(context.getAttribute("contextAnswers") != null) {
				contextAnswers = (List<Answer>) context.getAttribute("contextAnswers");
			} else {
				contextAnswers = answerDao.loadAnswers();
				context.setAttribute("contextAnswers", contextAnswers);
			}
			logger.logMethodExit(startTime);
			return contextAnswers;
		} catch (DAOException e) {
			logger.error("ERROR : "+ e.getMessage());
			throw new ServiceException(e.getMessage());
		}
	}

	/*
	 * This method has been to load the question answer from the DB based on the
	 * user id and question set id.
	 * 
	 * @see
	 * com.asg.selfservice.services.GenericService#loadQuestionAnswerPerPage(int,
	 * int)
	 */
	public List<QuestionAnswer> loadQuestionAnswerPerPage(int userId, int qsetId) throws ServiceException {
		try {
			return questionAnswerDao.loadQuestionAnswerPerPage(userId, qsetId);
		} catch (DAOException e) {
			logger.error("ERROR : "+ e.getMessage());
			throw new ServiceException(e.getMessage());
		}
	}

	/*
	 * This method has been to load the question answer from the DB based on the
	 * user id and question id.
	 * 
	 * @see com.asg.selfservice.services.GenericService#loadQuestionAnswer(int,
	 * int)
	 */
	public QuestionAnswer loadQuestionAnswer(int userId, int qId) throws ServiceException {
		try {
			return questionAnswerDao.loadQuestionAnswer(userId, qId);
		} catch (DAOException e) {
			logger.error("ERROR : "+ e.getMessage());
			throw new ServiceException(e.getMessage());
		}
	}

	/*
	 * This method has been used to save/update the question answer into the db
	 * for the corresponding page.
	 * 
	 * @see
	 * com.asg.selfservice.services.GenericService#saveUpdateInfo(com.asg.selfservice
	 * .domain.UserProfile, com.asg.selfservice.domain.QuestionAnswer)
	 */
	public void saveUpdateInfo(UserProfile user, QuestionAnswer questAns) throws ServiceException {
		try {
			questionAnswerDao.saveUpdateInfo(user, questAns);
		} catch (DAOException e) {
			logger.error("ERROR : "+ e.getMessage());
			throw new ServiceException(e.getMessage());
		}
	}

	/*
	 * This method has been used to delete the question answer from the
	 * database.
	 * 
	 * @see
	 * com.asg.selfservice.services.GenericService#deleteAnswer(com.asg.selfservice
	 * .domain.UserProfile, com.asg.selfservice.domain.QuestionAnswer)
	 */
	public void deleteAnswer(UserProfile user, QuestionAnswer questAns) throws ServiceException {
		try {
			questionAnswerDao.deleteAnswer(user, questAns);
		} catch (DAOException e) {
			logger.error("ERROR : "+ e.getMessage());
			throw new ServiceException(e.getMessage());
		}
	}

	/*
	 * This method has been used to delete the question answers as a bulk from
	 * the database.
	 * 
	 * @see
	 * com.asg.selfservice.services.GenericService#deleteAnswers(com.asg.selfservice
	 * .domain.UserProfile, java.lang.Integer[])
	 */
	public void deleteAnswers(UserProfile user, Integer[] qIds) throws ServiceException {
		try {
			questionAnswerDao.deleteAnswers(user, qIds);
		} catch (DAOException e) {
			logger.error("ERROR : "+ e.getMessage());
			throw new ServiceException(e.getMessage());
		}
	}

	/*
	 * This method has been used to load the map containing the user id,
	 * question set id and sequence as a key and the corresponding question id
	 * as a value. And this can be used while updating the question answer for
	 * the corresponding question id.
	 * 
	 * @see
	 * com.asg.selfservice.services.GenericService#loadQuestAnsUIdQSetIdSeqIdMap
	 * (com.asg.selfservice.domain.UserProfile)
	 */
	@SuppressWarnings({ "unchecked" })
	public Map<String, Integer> loadQuestAnsUIdQSetIdSeqIdMap(UserProfile userProfile) throws ServiceException {
		final long startTime = logger.logMethodEntry();
		
		Map<String, Integer> questAnsUIdQSetIdSeqIdMap;
		try {
			questAnsUIdQSetIdSeqIdMap = (Map<String, Integer>) session.getAttribute("questAnsUIdQSetIdSeqIdMap");
			
			if(questAnsUIdQSetIdSeqIdMap == null || questAnsUIdQSetIdSeqIdMap.isEmpty()) {
				List<Question> questions = this.loadQuestions();
				questAnsUIdQSetIdSeqIdMap = new HashMap<String, Integer>();
				for(Question quest : questions) {
					questAnsUIdQSetIdSeqIdMap.put(userProfile.getUserId()+"-"+quest.getQsetId()+"-"+quest.getSequence(), quest.getqId());
				}
				session.setAttribute("questAnsUIdQSetIdSeqIdMap", questAnsUIdQSetIdSeqIdMap);
			}
		} catch (ServiceException e) {
			logger.error("ERROR : "+ e.getMessage());
			throw new ServiceException(e.getMessage());
		}
		logger.logMethodExit(startTime);
		return questAnsUIdQSetIdSeqIdMap;
	}
	
	/*
	 * This method has been used to load all the question answers which will be
	 * required for pinney.
	 * 
	 * @see
	 * com.asg.selfservice.services.GenericService#loadQuestionAnswersForPinney
	 * (int)
	 */
	public List<QuestionAnswer> loadQuestionAnswersForPinney(int userId) throws ServiceException {
		try {
			return questionAnswerDao.loadQuestionAnswersForPinney(userId);
		} catch (DAOException e) {
			logger.error("ERROR : " + e.getMessage());
			throw new ServiceException(e.getMessage());
		}
	}
	
	/*
	 * This method has been used to load all the question answers for EBIX from
	 * DB.
	 * 
	 * @see
	 * com.asg.selfservice.services.GenericService#loadQuestionAnswersForEBIX(int)
	 */
	public List<QuestionAnswer> loadQuestionAnswersForEBIX(int userId) throws ServiceException {
		try {
			return questionAnswerDao.loadQuestionAnswersForEBIX(userId);
		} catch (DAOException e) {
			logger.error("ERROR : " + e.getMessage());
			throw new ServiceException(e.getMessage());
		}
	}
	
	/*
	 * This method has been used to load the reflexive questions and will add
	 * into context.
	 * 
	 * @see com.asg.selfservice.services.GenericService#loadReflexiveQuestions()
	 */
	@SuppressWarnings("unchecked")
	public Map<Integer, List<Integer>> loadReflexiveQuestions() throws ServiceException {
		Map<Integer, List<Integer>> reflexiveQuestionIdsMap;
		try {
			reflexiveQuestionIdsMap = (Map<Integer, List<Integer>>) context.getAttribute("reflexiveQuestionIdsMap");
			if(reflexiveQuestionIdsMap == null || reflexiveQuestionIdsMap.isEmpty()) {
				reflexiveQuestionIdsMap = questionDao.loadReflexiveQuestions();
				context.setAttribute("reflexiveQuestionIdsMap", reflexiveQuestionIdsMap);
			}
			return reflexiveQuestionIdsMap;
		} catch (DAOException e) {
			logger.error("ERROR : " + e.getMessage());
			throw new ServiceException(e.getMessage());
		}
	}
	
	/*
	 * Used to load the question ids based on the question set Id.
	 */
	public Integer[] loadQuestionIdsBasedQSetId(int userId, int qsetId)
			throws ServiceException {
		try {
			return questionAnswerDao.loadQuestionIdsBasedQSetId(userId, qsetId);
		} catch (DAOException e) {
			logger.error("ERROR : " + e.getMessage());
			throw new ServiceException(e.getMessage());
		}
	}
	
	
	/*
	 * This load the failed pinney data
	 * 
	 */
	
	public List<UserProfile> getPinneyFailedSubmit() throws ServiceException {
		try {
			return questionAnswerDao.getPinneyFailedSubmission();
		} catch (DAOException e) {
			logger.error("ERROR : " + e.getMessage());
			throw new ServiceException(e.getMessage());
		}
	}
}
