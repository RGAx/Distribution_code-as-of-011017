/**
 * 
 */
package com.asg.selfservice.services.impl;

import org.springframework.beans.factory.annotation.Autowired;

import com.asg.selfservice.common.logger.LogFactory;
import com.asg.selfservice.common.logger.SelfServiceLogger;
import com.asg.selfservice.common.utils.ApplicationConstants;
import com.asg.selfservice.dao.LegalStatementDAO;
import com.asg.selfservice.domain.Legalstmt;
import com.asg.selfservice.exception.DAOException;
import com.asg.selfservice.exception.ServiceException;
import com.asg.selfservice.services.LegalStatementService;

/**
 * @author M1030777
 *
 */
public class LegalStatementServiceImpl implements LegalStatementService{

	private static final SelfServiceLogger logger = LogFactory.getInstance(LegalStatementServiceImpl.class);

	@Autowired
	private Legalstmt legalstmt;

	@Autowired
	private LegalStatementDAO legalstmtDao;
	
	@Override
	public Legalstmt getFIName_Type(String agency_name)  throws ServiceException {
		logger.info("Inside getFIname method.:");
		
		
		try {
			legalstmt = legalstmtDao.getFIName_Type(agency_name);
			
			if(null!=legalstmt.getFitype()){
				if(legalstmt.getFitype().equalsIgnoreCase(ApplicationConstants.BANK)){
					legalstmt.setFitypeValue(ApplicationConstants.FDIC);
				} else{
					legalstmt.setFitypeValue(ApplicationConstants.NCUA);
				}
			
			}
			
		} catch (DAOException e) {
			logger.error("ERROR : " + e.getMessage());
			throw new ServiceException(e.getMessage());
		}		
		return legalstmt;
	}

}
