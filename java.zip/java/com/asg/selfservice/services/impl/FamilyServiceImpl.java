/**
 * 
 */
package com.asg.selfservice.services.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;

import com.asg.selfservice.common.logger.LogFactory;
import com.asg.selfservice.common.logger.SelfServiceLogger;
import com.asg.selfservice.common.utils.ApplicationConstants;
import com.asg.selfservice.domain.Answer;
import com.asg.selfservice.domain.FamilyAnswer;
import com.asg.selfservice.domain.Question;
import com.asg.selfservice.domain.QuestionAnswer;
import com.asg.selfservice.domain.UserProfile;
import com.asg.selfservice.exception.ServiceException;
import com.asg.selfservice.services.FamilyService;
import com.asg.selfservice.services.GenericService;

/**
 * Service Level implementation for Family related details to save into the DB and retreiving details from the DB
 * @author M1029563
 *
 */
public class FamilyServiceImpl implements FamilyService {
	
	private static final SelfServiceLogger logger = LogFactory.getInstance(FamilyServiceImpl.class);
	
	@Autowired
	private GenericService genericService;
	
	
	public List<Question> loadfamilyhistoryQuestions() throws ServiceException {
		
		List<Question> familyhistoryQuestion = new ArrayList<Question>();
		
		try {
			List<Question> questionList = genericService.loadQuestions();
			
			for (Question question : questionList) {
				
				if(question.getQsetId() == ApplicationConstants.familyhistoryQuestionSetID) {
					familyhistoryQuestion.add(question);
				}
			}
		} catch (ServiceException e) {
			logger.error("ERROR : " + e.getMessage());
			throw new ServiceException(e.getMessage());
		}
		return familyhistoryQuestion;
	}

	/*This method is used to fetch Ages for the questionid from the ANSWERS table in the DB and returns List<String> Ages
	 * @param QId
	 * @return List<String> Ages
	 */
	public List<String> loadages(int qid) throws ServiceException {
		
		List<String> ages = new ArrayList<String>();
		try{
			List<Answer> Answers = genericService.loadAnswers();
			for(Answer answer : Answers) {
					if(answer.getqId() == qid) {
					String age = String.valueOf(answer.getAnswerValue());
					
					int temp1 = Integer.parseInt(age.split("-")[0]);
			        int temp2 = Integer.parseInt(age.split("-")[1].split("\\+")[0]);
			        int lastElement = 0;
			        
			        for(int count = temp1; count < temp2; count ++) {
			        	lastElement = count + 1;
			        	ages.add(""+count);
			        }
			        ages.add(lastElement+"");
				}
			}
		}
		catch (ServiceException e) {
			logger.error("ERROR : " + e.getMessage());
			throw new ServiceException(e.getMessage());
		}		
		return ages;
	}
	/*
	 * This method is used to save Family details in the USER_QUESTION_ANSWER Table
	 *  @param UserProfile user,FamilyAnswer familyAnswer
	 *  @Exception ServiceException
	 */
	public void saveUpdateFamilyInfo(UserProfile userProfile,FamilyAnswer familyAnswer)
			throws ServiceException {
		
		try{
			Map<String, Integer> questAnsUIdQSetIdSeqIdMap = genericService.loadQuestAnsUIdQSetIdSeqIdMap(userProfile);
			Map<Integer,List<Integer>> reflexivequestionMap = genericService.loadReflexiveQuestions();
			List<Integer> qid=null;
			List<Integer> reflexiveQid = null;
			int questionId=0;
			int qIdSize = 0;
			if(null != familyAnswer.getFamilySeq1() && !familyAnswer.getFamilySeq1().isEmpty()){
				
				questionId = questAnsUIdQSetIdSeqIdMap.get(userProfile.getUserId()+"-"+ApplicationConstants.familyhistoryQuestionSetID+"-"+ApplicationConstants.ONE);
				if(familyAnswer.getFamilySeq1().equalsIgnoreCase("no")){
					
					qid = reflexivequestionMap.get(questionId);
					genericService.saveUpdateInfo(userProfile, this.constructQuestionAnswer(userProfile, questionId, familyAnswer.getFamilySeq1().equalsIgnoreCase("yes")? "1" : "0"));
					if(null != qid && !qid.isEmpty()){
						genericService.deleteAnswers(userProfile, qid.toArray(new Integer[qid.size()]));
						qIdSize = qid.size();
					}
					
					for(int i=0;i < qIdSize;i++){
						reflexiveQid = reflexivequestionMap.get(qid.get(i));
						if(null != reflexiveQid && !reflexiveQid.isEmpty()){
							genericService.deleteAnswers(userProfile, reflexiveQid.toArray(new Integer[reflexiveQid.size()]));
						}
					}
				}
				else if(familyAnswer.getFamilySeq1().equalsIgnoreCase("yes") && familyAnswer.getFamilySeq13() == null && familyAnswer.getFamilySeq14() == null && familyAnswer.getFamilySeq15()==null && familyAnswer.getFamilySeq16()==null ){
					
					qid = reflexivequestionMap.get(questionId);
					genericService.saveUpdateInfo(userProfile, this.constructQuestionAnswer(userProfile, questionId, familyAnswer.getFamilySeq1().equalsIgnoreCase("yes")? "1" : "0"));
					if(null != qid && !qid.isEmpty()){
						genericService.deleteAnswers(userProfile, qid.toArray(new Integer[qid.size()]));
						qIdSize = qid.size();
					}
					
					for(int i=0;i < qIdSize;i++){
						reflexiveQid = reflexivequestionMap.get(qid.get(i));
						if(null != reflexiveQid && !reflexiveQid.isEmpty()){
							genericService.deleteAnswers(userProfile, reflexiveQid.toArray(new Integer[reflexiveQid.size()]));
						}
					}
				}
				else{
					genericService.saveUpdateInfo(userProfile, this.constructQuestionAnswer(userProfile, questionId, familyAnswer.getFamilySeq1().equalsIgnoreCase("yes")? "1" : "0"));
					
					if(null != familyAnswer.getFamilySeq3() && !familyAnswer.getFamilySeq3().isEmpty()){
						questionId = questAnsUIdQSetIdSeqIdMap.get(userProfile.getUserId()+"-"+ApplicationConstants.familyhistoryQuestionSetID+"-"+ApplicationConstants.THREE);
						genericService.saveUpdateInfo(userProfile, this.constructQuestionAnswer(userProfile, questionId, familyAnswer.getFamilySeq3()));
					}
					if(null != familyAnswer.getFamilySeq4() && !familyAnswer.getFamilySeq4().isEmpty()){
						questionId = questAnsUIdQSetIdSeqIdMap.get(userProfile.getUserId()+"-"+ApplicationConstants.familyhistoryQuestionSetID+"-"+ApplicationConstants.FOUR);
						genericService.saveUpdateInfo(userProfile, this.constructQuestionAnswer(userProfile, questionId, familyAnswer.getFamilySeq4()));
					}
					if(null != familyAnswer.getFamilySeq5() && !familyAnswer.getFamilySeq5().isEmpty()){
						questionId = questAnsUIdQSetIdSeqIdMap.get(userProfile.getUserId()+"-"+ApplicationConstants.familyhistoryQuestionSetID+"-"+ApplicationConstants.FIVE);
						genericService.saveUpdateInfo(userProfile, this.constructQuestionAnswer(userProfile, questionId, familyAnswer.getFamilySeq5()));
					}
					if(null != familyAnswer.getFamilySeq6() && !familyAnswer.getFamilySeq6().isEmpty()){
						questionId = questAnsUIdQSetIdSeqIdMap.get(userProfile.getUserId()+"-"+ApplicationConstants.familyhistoryQuestionSetID+"-"+ApplicationConstants.SIX);
						genericService.saveUpdateInfo(userProfile, this.constructQuestionAnswer(userProfile, questionId, familyAnswer.getFamilySeq6()));
					}
					if(null != familyAnswer.getFamilySeq7() && !familyAnswer.getFamilySeq7().isEmpty()){
						questionId = questAnsUIdQSetIdSeqIdMap.get(userProfile.getUserId()+"-"+ApplicationConstants.familyhistoryQuestionSetID+"-"+ApplicationConstants.SEVEN);
						genericService.saveUpdateInfo(userProfile, this.constructQuestionAnswer(userProfile, questionId, familyAnswer.getFamilySeq7()));
					}
					if(null != familyAnswer.getFamilySeq8() && !familyAnswer.getFamilySeq8().isEmpty()){
						questionId = questAnsUIdQSetIdSeqIdMap.get(userProfile.getUserId()+"-"+ApplicationConstants.familyhistoryQuestionSetID+"-"+ApplicationConstants.EIGHT);
						genericService.saveUpdateInfo(userProfile, this.constructQuestionAnswer(userProfile, questionId, familyAnswer.getFamilySeq8()));
					}
					if(null != familyAnswer.getFamilySeq9() && !familyAnswer.getFamilySeq9().isEmpty()){
						questionId = questAnsUIdQSetIdSeqIdMap.get(userProfile.getUserId()+"-"+ApplicationConstants.familyhistoryQuestionSetID+"-"+ApplicationConstants.NINE);
						genericService.saveUpdateInfo(userProfile, this.constructQuestionAnswer(userProfile, questionId, familyAnswer.getFamilySeq9()));
					}
					if(null != familyAnswer.getFamilySeq10() && !familyAnswer.getFamilySeq10().isEmpty()){
						questionId = questAnsUIdQSetIdSeqIdMap.get(userProfile.getUserId()+"-"+ApplicationConstants.familyhistoryQuestionSetID+"-"+ApplicationConstants.TEN);
						genericService.saveUpdateInfo(userProfile, this.constructQuestionAnswer(userProfile, questionId, familyAnswer.getFamilySeq10()));
					}
					if(null != familyAnswer.getFamilySeq11() && !familyAnswer.getFamilySeq11().isEmpty()){
						questionId = questAnsUIdQSetIdSeqIdMap.get(userProfile.getUserId()+"-"+ApplicationConstants.familyhistoryQuestionSetID+"-"+ApplicationConstants.ELEVEN);
						genericService.saveUpdateInfo(userProfile, this.constructQuestionAnswer(userProfile, questionId, familyAnswer.getFamilySeq11()));
					}
					if(null != familyAnswer.getFamilySeq12() && !familyAnswer.getFamilySeq12().isEmpty()){
						questionId = questAnsUIdQSetIdSeqIdMap.get(userProfile.getUserId()+"-"+ApplicationConstants.familyhistoryQuestionSetID+"-"+ApplicationConstants.TWELVE);
						genericService.saveUpdateInfo(userProfile, this.constructQuestionAnswer(userProfile, questionId, familyAnswer.getFamilySeq12()));
					}
					if(null != familyAnswer.getFamilySeq13() && !familyAnswer.getFamilySeq13().isEmpty() && !familyAnswer.getFamilySeq13().equalsIgnoreCase("select")){
						questionId = questAnsUIdQSetIdSeqIdMap.get(userProfile.getUserId()+"-"+ApplicationConstants.familyhistoryQuestionSetID+"-"+ApplicationConstants.THIRTEEN);
						genericService.saveUpdateInfo(userProfile, this.constructQuestionAnswer(userProfile, questionId, familyAnswer.getFamilySeq13()));
					}
					if(null != familyAnswer.getFamilySeq14() && !familyAnswer.getFamilySeq14().isEmpty()){
						questionId = questAnsUIdQSetIdSeqIdMap.get(userProfile.getUserId()+"-"+ApplicationConstants.familyhistoryQuestionSetID+"-"+ApplicationConstants.FOURTEEN);
						genericService.saveUpdateInfo(userProfile, this.constructQuestionAnswer(userProfile, questionId, familyAnswer.getFamilySeq14()));
					}
					if(null != familyAnswer.getFamilySeq15() && !familyAnswer.getFamilySeq15().isEmpty()){
						
						questionId = questAnsUIdQSetIdSeqIdMap.get(userProfile.getUserId()+"-"+ApplicationConstants.familyhistoryQuestionSetID+"-"+ApplicationConstants.FIFTEEN);
						if(familyAnswer.getFamilySeq15().equals("0")){							
							qid = reflexivequestionMap.get(questionId);
							genericService.saveUpdateInfo(userProfile, this.constructQuestionAnswer(userProfile, questionId, familyAnswer.getFamilySeq15()));
							if(null != qid && !qid.isEmpty()){
								genericService.deleteAnswers(userProfile, qid.toArray(new Integer[qid.size()]));
							}
						}
						else{
							genericService.saveUpdateInfo(userProfile, this.constructQuestionAnswer(userProfile, questionId, familyAnswer.getFamilySeq15()));
							
							if(null != familyAnswer.getFamilySeq16() && !familyAnswer.getFamilySeq16().isEmpty() ){
								questionId = questAnsUIdQSetIdSeqIdMap.get(userProfile.getUserId()+"-"+ApplicationConstants.familyhistoryQuestionSetID+"-"+ApplicationConstants.SIXTEEN);
								genericService.saveUpdateInfo(userProfile, this.constructQuestionAnswer(userProfile, questionId, familyAnswer.getFamilySeq16()));
							}
						}						
					}					
				}
			}
			
		}
		catch(ServiceException e){
			logger.error("ERROR : " + e.getMessage());
			throw new ServiceException(e.getMessage());
		}
		
	}
	
	/*This method is used to fetch Ages for the Qid from the ANSWERS table in the DB and returns List<String> relationShips
	 * @param QId
	 * @return List<String> relationShips
	 */
	public List<String> loadrelationShips(int qid) throws ServiceException {
	
		List<String> relationShips = new ArrayList<String>();
		try{
			List<Answer> Answers = genericService.loadAnswers();
			for(Answer answer : Answers) {
					if(answer.getqId() == qid) {					
					
						relationShips.add(answer.getAnswerValue());
				}
			}
		}
		catch (ServiceException e) {
			logger.error("ERROR : " + e.getMessage());
			throw new ServiceException(e.getMessage());
		}		
		return relationShips;
	}
	
	/*
	 * This is an internal method used inside this service code where question answer has been constructed
	 * based on the question id, user and answer value.
	 * 
	 */
	private QuestionAnswer constructQuestionAnswer(UserProfile user, int questionId, String ansValue) {
		final long startTime = logger.logMethodEntry();
		
		QuestionAnswer questAns = new QuestionAnswer();
		
		questAns.setqId(questionId);
		questAns.setUserId(user.getUserId());
		questAns.setAnswer(ansValue);
		questAns.setCreatedDate(new java.sql.Date((new Date()).getTime()));
		questAns.setCreatedBy(user.getFirstName() + " " + (user.getLastName() != null ? user.getLastName() : ""));
		
		logger.logMethodExit(startTime);
		return questAns;
	}
	
	/*
	 * This method is used to retrieve details from USER_QUESTION_ASNWER TABLE
	 * @param userId,qSetId;
	 * @return FamilyAnswer Map contains Family Question Sequence as Key and Family Answer as value
	 */
	public Map<Integer,String> loadfamilyPage(int userId, int qsetId)
			throws ServiceException {
		Map<Integer,String> familyAnswer = null;
		
		try{
			List<QuestionAnswer> questionAnswerList = genericService.loadQuestionAnswerPerPage(userId,qsetId);
			familyAnswer= new HashMap<Integer, String>();
			
			for(QuestionAnswer questionAnswer : questionAnswerList) {
				if(questionAnswer.getSequence() == 1) {
					familyAnswer.put(questionAnswer.getSequence(),questionAnswer.getAnswer());
				}
				if(questionAnswer.getSequence() == 2) {
					familyAnswer.put(questionAnswer.getSequence(),questionAnswer.getAnswer());
				}
				if(questionAnswer.getSequence() == 3) {
					familyAnswer.put(questionAnswer.getSequence(),questionAnswer.getAnswer());
				}
				if(questionAnswer.getSequence() == 4) {
					familyAnswer.put(questionAnswer.getSequence(),questionAnswer.getAnswer());
				}
				if(questionAnswer.getSequence() == 5) {
					familyAnswer.put(questionAnswer.getSequence(),questionAnswer.getAnswer());
				}
				if(questionAnswer.getSequence() == 6) {
					familyAnswer.put(questionAnswer.getSequence(),questionAnswer.getAnswer());
				}
				if(questionAnswer.getSequence() == 7) {
					familyAnswer.put(questionAnswer.getSequence(),questionAnswer.getAnswer());
				}
				if(questionAnswer.getSequence() == 8) {
					familyAnswer.put(questionAnswer.getSequence(),questionAnswer.getAnswer());
				}
				if(questionAnswer.getSequence() == 9) {
					familyAnswer.put(questionAnswer.getSequence(),questionAnswer.getAnswer());
				}
				if(questionAnswer.getSequence() == 10) {
					familyAnswer.put(questionAnswer.getSequence(),questionAnswer.getAnswer());
				}
				if(questionAnswer.getSequence() == 11) {
					familyAnswer.put(questionAnswer.getSequence(),questionAnswer.getAnswer());
				}
				if(questionAnswer.getSequence() == 12) {
					familyAnswer.put(questionAnswer.getSequence(),questionAnswer.getAnswer());
				}
				if(questionAnswer.getSequence() == 13) {
					familyAnswer.put(questionAnswer.getSequence(),questionAnswer.getAnswer());
				}
				if(questionAnswer.getSequence() == 14) {
					familyAnswer.put(questionAnswer.getSequence(),questionAnswer.getAnswer());
				}
				if(questionAnswer.getSequence() == 15) {
					familyAnswer.put(questionAnswer.getSequence(),questionAnswer.getAnswer());
				}
				if(questionAnswer.getSequence() == 16) {
					familyAnswer.put(questionAnswer.getSequence(),questionAnswer.getAnswer());
				}
			}			
		}
		catch (ServiceException e) {
			logger.error("ERROR : " + e.getMessage());
			throw new ServiceException(e.getMessage());
		}
		
		return familyAnswer;
	}
}
