/**
 * 
 */
package com.asg.selfservice.services.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.servlet.ModelAndView;

import com.asg.selfservice.common.logger.LogFactory;
import com.asg.selfservice.common.logger.SelfServiceLogger;
import com.asg.selfservice.common.utils.ApplicationConstants;
import com.asg.selfservice.common.utils.Utils;
import com.asg.selfservice.domain.Question;
import com.asg.selfservice.domain.QuestionAnswer;
import com.asg.selfservice.domain.TreatmentHistory;
import com.asg.selfservice.domain.UserProfile;
import com.asg.selfservice.exception.ServiceException;
import com.asg.selfservice.services.GenericService;
import com.asg.selfservice.services.TreatmentService;

/**
 * This class has been used to implement all the services such as loading the
 * Treatment History(Substance Abuse) page info, calling the dao method to save/update the Treatment History info
 * into db, updating the model with all the updated info to load the Treatment History page.
 * 
 * @author M1027376
 *
 */
public class TreatmentServiceImpl implements TreatmentService {

	private static final SelfServiceLogger logger = LogFactory.getInstance(TreatmentServiceImpl.class);
	
	@Autowired
	private GenericService genericService;
	
	@Autowired
	private ServletContext context;
	
	@Autowired
	private HttpSession session;

	@Value("#{'${selfservice.list.months}'.split(',')}") 
	private List<String> months;
	
	@Value("#{'${selfservice.list.years}'.split(',')}") 
	private List<String> years;
	
	/*
	 * This method has been used to load the model object with the corresponding
	 * details such as questions, answers, drop-down field values etc.
	 * 
	 */
	public ModelAndView loadTreatmentHistInfo(ModelAndView model, UserProfile userProfile) throws ServiceException {
		final long startTime = logger.logMethodEntry();
		
		model.addObject("treatmentQuestions", this.loadTreatmentQuestions());
		
		model.addObject("months", months);
		model.addObject("years", Utils.loadLastTenYears());
		
		model.addObject("userProfile", userProfile);
		
		model.addObject("treatment", this.constructTreatmentAnswer(userProfile.getUserId(), ApplicationConstants.treatmentHistQuestionSetID));
		
		logger.logMethodExit(startTime);
		return model;
	}
	
	
	/*
	 * This is an internal method for loading the Treatment History questions from all the questions.
	 */
	private List<Question> loadTreatmentQuestions() throws ServiceException {
		final long startTime = logger.logMethodEntry();
		
		List<Question> treatmentQuestions = new ArrayList<Question>();
		List<Question> questionList;
		try {
			questionList = genericService.loadQuestions();
		} catch (ServiceException e) {
			logger.error("ERROR : " + e.getMessage());
			throw new ServiceException(e.getMessage());
		}
		
		for (Question question : questionList) {
			if(question.getQsetId() == ApplicationConstants.treatmentHistQuestionSetID) {
				treatmentQuestions.add(question);
			}
		}
		logger.logMethodExit(startTime);
		return treatmentQuestions;
	}
	
	
	/*
	 * This method has been used to save/update the Treatment History into the DB.
	 * 
	 * @see
	 * com.asg.selfservice.services.TreatmentService#saveUpdateTreatmentInfo(com.asg
	 * .selfservice.domain.UserProfile, com.asg.selfservice.domain.Treatment)
	 */
	public void saveUpdateTreatmentInfo(UserProfile user, TreatmentHistory treatment) throws ServiceException {
		final long startTime = logger.logMethodEntry();
		
		Map<String, Integer> questAnsUIdQSetIdSeqIdMap = genericService.loadQuestAnsUIdQSetIdSeqIdMap(user);
		
		try {
			int questionId = this.loadQuestionIdFromMap(questAnsUIdQSetIdSeqIdMap, user.getUserId(), ApplicationConstants.ONE);
			if(treatment.getTreatmentHistorySeq1() != null && !treatment.getTreatmentHistorySeq1().isEmpty()) {
				genericService.saveUpdateInfo(user, this.constructQuestionAnswer(user, questionId, treatment.getTreatmentHistorySeq1()));
				
				questionId = this.loadQuestionIdFromMap(questAnsUIdQSetIdSeqIdMap, user.getUserId(), ApplicationConstants.TWO);
				if("1".equalsIgnoreCase(treatment.getTreatmentHistorySeq1())) {
					if(treatment.getTreatmentHistorySeq2() != null && !treatment.getTreatmentHistorySeq2().isEmpty()) {
						genericService.saveUpdateInfo(user, this.constructQuestionAnswer(user, questionId, treatment.getTreatmentHistorySeq2().replace(",", "-")));
					}
				} else {
					genericService.deleteAnswers(user, new Integer[]{questionId});
				}
			} else {
				genericService.deleteAnswer(user, this.constructQuestionAnswer(user, questionId, treatment.getTreatmentHistorySeq1()));
			}
			
			questionId = this.loadQuestionIdFromMap(questAnsUIdQSetIdSeqIdMap, user.getUserId(), ApplicationConstants.THREE);
			if(treatment.getTreatmentHistorySeq3() != null && !treatment.getTreatmentHistorySeq3().isEmpty()) {
				genericService.saveUpdateInfo(user, this.constructQuestionAnswer(user, questionId, treatment.getTreatmentHistorySeq3()));
				
				questionId = this.loadQuestionIdFromMap(questAnsUIdQSetIdSeqIdMap, user.getUserId(), ApplicationConstants.FOUR);
				if("1".equalsIgnoreCase(treatment.getTreatmentHistorySeq3())) {
					if(treatment.getTreatmentHistorySeq4() != null && !treatment.getTreatmentHistorySeq4().isEmpty()) {
					genericService.saveUpdateInfo(user, this.constructQuestionAnswer(user, questionId, treatment.getTreatmentHistorySeq4().replace(",", "-")));
				}
			} else {
				genericService.deleteAnswers(user, new Integer[]{questionId});
				}
			} else {
				genericService.deleteAnswer(user, this.constructQuestionAnswer(user, questionId, treatment.getTreatmentHistorySeq3()));
			}
			
		} catch (ServiceException e) {
			logger.error("ERROR : " + e.getMessage());
			throw new ServiceException(e.getMessage());
		}
		logger.logMethodExit(startTime);
	}
	
	/*
	 * This is an internal method used to construct the Treatment History answer from the answers.
	 */
	private TreatmentHistory constructTreatmentAnswer(int userId, int treatmentquestionsetId) throws ServiceException {
		final long startTime = logger.logMethodEntry();
		TreatmentHistory treatment = new TreatmentHistory();
		try {
			List<QuestionAnswer> questionAnswerList = genericService.loadQuestionAnswerPerPage(userId, treatmentquestionsetId);
			
			for(QuestionAnswer questionAnswer : questionAnswerList) {
				if(questionAnswer.getSequence() == 1) {
					treatment.setTreatmentHistorySeq1(questionAnswer.getAnswer());
				} else if(questionAnswer.getSequence() == 2) {
					treatment.setTreatmentHistorySeq2(questionAnswer.getAnswer());
				} else if(questionAnswer.getSequence() == 3) {
					treatment.setTreatmentHistorySeq3(questionAnswer.getAnswer());
				} else if(questionAnswer.getSequence() == 4) {
					treatment.setTreatmentHistorySeq4(questionAnswer.getAnswer());
				} 
			}
		} catch (ServiceException e) {
			logger.error("ERROR : " + e.getMessage());
			throw new ServiceException(e.getMessage());
		}
		logger.logMethodExit(startTime);
		return treatment;
	}
	
	/*
	 * This is an internal method used for loading the question Id from the context map.
	 */
	private int loadQuestionIdFromMap(Map<String, Integer> questAnsUIdQSetIdSeqIdMap, int userId, int sequence) {
		int questionId = 0;
		try {
			questionId = questAnsUIdQSetIdSeqIdMap.get(userId+"-"+ApplicationConstants.treatmentHistQuestionSetID+"-"+sequence);
		} catch (Exception e) {
			questionId = 0;
		}
		return questionId;
	}
	
	/*
	 * This is an internal method used inside this service where question answer has been constructed
	 * based on the question id, user and ans value.
	 */
	private QuestionAnswer constructQuestionAnswer(UserProfile user, int questionId, String ansValue) {
		final long startTime = logger.logMethodEntry();
		
		QuestionAnswer questAns = new QuestionAnswer();
		
		questAns.setqId(questionId);
		questAns.setUserId(user.getUserId());
		questAns.setAnswer(ansValue);
		questAns.setCreatedDate(new java.sql.Date((new Date()).getTime()));
		questAns.setCreatedBy(user.getFirstName() + " " + (user.getLastName() != null ? user.getLastName() : ""));
		
		logger.logMethodExit(startTime);
		return questAns;
	}

}
