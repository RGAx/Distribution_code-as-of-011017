package com.asg.selfservice.services.impl;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.servlet.ModelAndView;

import com.asg.selfservice.common.logger.LogFactory;
import com.asg.selfservice.common.logger.SelfServiceLogger;
import com.asg.selfservice.common.utils.ApplicationConstants;
import com.asg.selfservice.common.utils.Utils;
import com.asg.selfservice.domain.Answer;
import com.asg.selfservice.domain.Health;
import com.asg.selfservice.domain.Question;
import com.asg.selfservice.domain.QuestionAnswer;
import com.asg.selfservice.domain.UserProfile;
import com.asg.selfservice.exception.ServiceException;
import com.asg.selfservice.services.GenericService;
import com.asg.selfservice.services.HealthService;
import com.asg.selfservice.services.ProfileService;

/**
 * This class has been used to implement all the services such as loading the
 * tobacco page infos, calling the dao method to save/update the tobacco info
 * into db, updating the model with all the updated infos to load the tobacco
 * page.
 * 
 * @author M1030133
 *
 */
@Service
public class HealthServiceImpl implements HealthService {
	
	private static final SelfServiceLogger logger = LogFactory.getInstance(HealthServiceImpl.class);
	
	@Autowired
	private GenericService genericService;
	
	@Autowired
	private ProfileService profileService;

	@Value("#{'${selfservice.list.days}'.split(',')}") 
	private List<String> days;
	
	@Value("#{'${selfservice.list.months}'.split(',')}") 
	private List<String> months;
	
	@Value("#{'${selfservice.list.years}'.split(',')}") 
	private List<String> years;
	
	@Value("#{'${selfservice.list.states}'.split(',')}") 
	private List<String> states;
	
	/*
	 * This method has been used to load the model object with the corresponding
	 * details such as questions, answers, drop-down field values etc.
	 * 
	 * @see
	 * com.asg.selfservice.services.HealthService#loadHealthInfo(org.springframework
	 * .web.servlet.ModelAndView, com.asg.selfservice.domain.UserProfile)
	 */
	public ModelAndView loadHealthInfo(ModelAndView model, UserProfile userProfile) throws ServiceException {
		final long startTime = logger.logMethodEntry();
		
		model.addObject("healthQuestions", this.loadHealthQuestions());
		
		model.addObject("days", days);
		model.addObject("months", months);
		model.addObject("years", years);
		model.addObject("states", states);
		
		List<List<Integer>> heightFields = this.loadHeight(ApplicationConstants.healthQuestionIDForHeight);
        model.addObject("feets", heightFields.get(0));
		model.addObject("inches", heightFields.get(1));
		
		model.addObject("pounds", this.loadWeight(ApplicationConstants.healthQuestionIDForWeight));
		model.addObject("userProfile", userProfile);
		
		model.addObject("health", this.constructHealthAnswer(userProfile, ApplicationConstants.healthQuestionSetID));
		model.addObject("profileStatusFlagForAdmin", profileService.loadProfileStatusFlag(userProfile.getUserId()));
		
		logger.logMethodExit(startTime);
		return model;
	}
	
	/*
	 * This method used to construct the health answer from the answers.
	 */
	public Health constructHealthAnswer(UserProfile userProfile, int healthquestionsetId) throws ServiceException {
		final long startTime = logger.logMethodEntry();
		Health health = new Health();
		try {
			List<QuestionAnswer> questionAnswerList = genericService.loadQuestionAnswerPerPage(userProfile.getUserId(), healthquestionsetId);
			
			for(QuestionAnswer questionAnswer : questionAnswerList) {
				if(questionAnswer.getSequence() == 1) {
					health.setHealthSeq1(questionAnswer.getAnswer());
				} else if(questionAnswer.getSequence() == 2) {
					health.setHealthSeq2(questionAnswer.getAnswer());
				} else if(questionAnswer.getSequence() == 3) {
					health.setHealthSeq3(questionAnswer.getAnswer());
				} else if(questionAnswer.getSequence() == 4) {
					int feetInch = Integer.parseInt(questionAnswer.getAnswer());
					health.setHealthSeq11(""+feetInch/12);
					health.setHealthSeq12(""+feetInch%12);
					
					health.setHealthSeq4(questionAnswer.getAnswer());
				} else if(questionAnswer.getSequence() == 5) {
					health.setHealthSeq5(questionAnswer.getAnswer());
				} else if(questionAnswer.getSequence() == 6) {
					health.setHealthSeq6(questionAnswer.getAnswer());
				}
			}
		
			//Set data from UserProfile if not answered
			if(health.getHealthSeq1() == null || health.getHealthSeq1().isEmpty()) {
				health.setHealthSeq1(userProfile.getGender());
			}
			if((health.getHealthSeq2() == null || health.getHealthSeq2().isEmpty()) && userProfile.getDob() != null) {
				if(Utils.getDiffYears(userProfile.getDob(), new Date()) < 85) {
					health.setHealthSeq2(new SimpleDateFormat("MM/dd/yyyy").format(userProfile.getDob()));
				}
			}
			if((health.getHealthSeq3() == null || health.getHealthSeq3().isEmpty()) && userProfile.getAddressState() != null) {
				health.setHealthSeq3(Utils.loadStates().get(userProfile.getAddressState()));
			}
		} catch (ServiceException e) {
			logger.error("ERROR : " + e.getMessage());
			throw new ServiceException(e.getMessage());
		} catch (Exception e) {
			logger.error("ERROR : " + e.getMessage());
			throw new ServiceException(e.getMessage());
		}
		logger.logMethodExit(startTime);
		return health;
	}

	/*
	 * This is an internal method for loading the health questions from all the questions.
	 */
	private List<Question> loadHealthQuestions() throws ServiceException {
		final long startTime = logger.logMethodEntry();
		
		List<Question> healthQuestions = new ArrayList<Question>();
		List<Question> questionList;
		try {
			questionList = genericService.loadQuestions();
		} catch (ServiceException e) {
			logger.error("ERROR : " + e.getMessage());
			throw new ServiceException(e.getMessage());
		}
		
		for (Question question : questionList) {
			if(question.getQsetId() == ApplicationConstants.healthQuestionSetID) {
				healthQuestions.add(question);
			}
		}
		logger.logMethodExit(startTime);
		return healthQuestions;
	}
	
	/*
	 * This is an internal method used inside this service code where height has been loaded
	 * based on the question id.
	 */
	public List<List<Integer>> loadHeight(int questionId) throws ServiceException {
		final long startTime = logger.logMethodEntry();
		
		List<Answer> answers = null;
		List<List<Integer>> feetInches = new ArrayList<List<Integer>>();
		String height = null;
		try {
			answers = genericService.loadAnswers();
		} catch (ServiceException e) {
			logger.error("ERROR : " + e.getMessage());
			throw new ServiceException(e.getMessage());
		}
		
		for(Answer answer : answers) {
			if(answer.getqId() == questionId) {
				height = answer.getAnswerValue();
			}
		}
		List<Integer> feets = new ArrayList<Integer>();
        List<Integer> inches = new ArrayList<Integer>();
        
		int temp1 = Integer.parseInt(height.split("-")[0]);
        int temp2 = Integer.parseInt(height.split("-")[1]);
        
        for(int count = temp1; count <= temp2; count ++) {
        	if(!feets.contains(count/12))
        		feets.add(count/12);
        	
        	if(!inches.contains(count%12))
        		inches.add(count%12);
        }
        feetInches.add(feets);
        feetInches.add(inches);
        
		logger.logMethodExit(startTime);
		return feetInches;
	}
	
	/*
	 * This is an internal method used inside this service code where weight has been loaded
	 * based on the question id.
	 */
	public List<String> loadWeight(int questionId) throws ServiceException {
		final long startTime = logger.logMethodEntry();
		
		List<String> weightList = new ArrayList<String>();
		List<Answer> answers = null;
		
		try {
			answers = genericService.loadAnswers();
		} catch (ServiceException e) {
			logger.error("ERROR : " + e.getMessage());
			throw new ServiceException(e.getMessage());
		}
		
		for(Answer answer : answers) {
			if(answer.getqId() == questionId) {
				String weight = answer.getAnswerValue();
				
				int lowerValue = Integer.parseInt(weight.split("-")[0]);
		        int upperValue = Integer.parseInt(weight.split("-")[1].split("\\+")[0]);
		        
		        weightList.add("Less than "+lowerValue);
		        int count = 0;
		        for(count = lowerValue + 1; count < upperValue; count ++) {
		        	weightList.add(""+count);
		        }
		        weightList.add(count+"+");
			}
		}
		logger.logMethodExit(startTime);
		return weightList;
	}

	/*
	 * This method has been used to save/update the health into into the DB.
	 * 
	 * @see
	 * com.asg.selfservice.services.HealthService#saveUpdateHealthInfo(com.asg
	 * .selfservice.domain.UserProfile, com.asg.selfservice.domain.Health)
	 */
	public void saveUpdateHealthInfo(UserProfile user, Health health) throws ServiceException {
		final long startTime = logger.logMethodEntry();
		
		Map<String, Integer> questAnsUIdQSetIdSeqIdMap = genericService.loadQuestAnsUIdQSetIdSeqIdMap(user);
		
		try {
			int questionId = this.loadQuestionIdFromMap(questAnsUIdQSetIdSeqIdMap, user.getUserId(), ApplicationConstants.ONE);
			if(health.getHealthSeq1() != null && !health.getHealthSeq1().isEmpty()) {
				genericService.saveUpdateInfo(user, this.constructQuestionAnswer(user, questionId, health.getHealthSeq1()));
			} else {
				genericService.deleteAnswer(user, this.constructQuestionAnswer(user, questionId, health.getHealthSeq1()));
			}
			
			questionId = this.loadQuestionIdFromMap(questAnsUIdQSetIdSeqIdMap, user.getUserId(), ApplicationConstants.TWO);
			if(health.getHealthSeq2() != null && !health.getHealthSeq2().isEmpty() 
					&& !(health.getHealthSeq2().contains("m") || health.getHealthSeq2().contains("d") || health.getHealthSeq2().contains("y"))) {
				genericService.saveUpdateInfo(user, this.constructQuestionAnswer(user, questionId, health.getHealthSeq2()));
			} else {
				genericService.deleteAnswer(user, this.constructQuestionAnswer(user, questionId, health.getHealthSeq2()));
			}
			
			questionId = this.loadQuestionIdFromMap(questAnsUIdQSetIdSeqIdMap, user.getUserId(), ApplicationConstants.THREE);
			if(health.getHealthSeq3() == null && user.getAddressState() != null) {
				health.setHealthSeq3(Utils.loadStates().get(user.getAddressState()));
			}
			if(health.getHealthSeq3() != null && !health.getHealthSeq3().isEmpty()) {
				genericService.saveUpdateInfo(user, this.constructQuestionAnswer(user, questionId, health.getHealthSeq3()));
			} else {
				genericService.deleteAnswer(user, this.constructQuestionAnswer(user, questionId, health.getHealthSeq3()));
			}
			
			//Added for the validation of disabling the inch field if the user selects 7 in feet field, so the total shouldn't exceed 84
			if("7".equalsIgnoreCase(health.getHealthSeq11()) && health.getHealthSeq12() == null)
				health.setHealthSeq12("0");
			
			questionId = this.loadQuestionIdFromMap(questAnsUIdQSetIdSeqIdMap, user.getUserId(), ApplicationConstants.FOUR);
			if(health.getHealthSeq11() != null && !health.getHealthSeq11().isEmpty() && 
					health.getHealthSeq12() != null && !health.getHealthSeq12().isEmpty()) {
				String value = ""+(Integer.parseInt(health.getHealthSeq11())*12 + Integer.parseInt(health.getHealthSeq12()));
				genericService.saveUpdateInfo(user, this.constructQuestionAnswer(user, questionId, value));
			} else {
				genericService.deleteAnswer(user, this.constructQuestionAnswer(user, questionId, health.getHealthSeq4()));
			}
			
			questionId = this.loadQuestionIdFromMap(questAnsUIdQSetIdSeqIdMap, user.getUserId(), ApplicationConstants.FIVE);
			if(health.getHealthSeq5() != null && !health.getHealthSeq5().isEmpty()) {
				genericService.saveUpdateInfo(user, this.constructQuestionAnswer(user, questionId, health.getHealthSeq5()));
			} else {
				genericService.deleteAnswer(user, this.constructQuestionAnswer(user, questionId, health.getHealthSeq5()));
			}
			
			questionId = this.loadQuestionIdFromMap(questAnsUIdQSetIdSeqIdMap, user.getUserId(), ApplicationConstants.SIX);
			if(health.getHealthSeq6() != null && !health.getHealthSeq6().isEmpty()) {
				genericService.saveUpdateInfo(user, this.constructQuestionAnswer(user, questionId, health.getHealthSeq6()));
				
				if("0".equalsIgnoreCase(health.getHealthSeq6())) {
					genericService.deleteAnswers(user, genericService.loadQuestionIdsBasedQSetId(user.getUserId(), ApplicationConstants.smokingQuestionSetID));
				}
			} else {
				genericService.deleteAnswer(user, this.constructQuestionAnswer(user, questionId, health.getHealthSeq6()));
			}
			
		} catch (ServiceException e) {
			logger.error("ERROR : " + e.getMessage());
			throw new ServiceException(e.getMessage());
		} catch (Exception e) {
			logger.error("ERROR : " + e.getMessage());
			throw new ServiceException(e.getMessage());
		}
		logger.logMethodExit(startTime);
	}
	
	/*
	 * This is an internal method used for loading the question Id from the context map.
	 */
	private int loadQuestionIdFromMap(Map<String, Integer> questAnsUIdQSetIdSeqIdMap, int userId, int sequence) {
		int questionId = 0;
		try {
			questionId = questAnsUIdQSetIdSeqIdMap.get(userId+"-"+ApplicationConstants.healthQuestionSetID+"-"+sequence);
		} catch (Exception e) {
			questionId = 0;
		}
		return questionId;
	}
	
	/*
	 * This is an internal method used inside this service code where question answer has been constructed
	 * based on the question id, user and ans value.
	 */
	private QuestionAnswer constructQuestionAnswer(UserProfile user, int questionId, String ansValue) {
		final long startTime = logger.logMethodEntry();
		
		QuestionAnswer questAns = new QuestionAnswer();
		
		questAns.setqId(questionId);
		questAns.setUserId(user.getUserId());
		questAns.setAnswer(ansValue);
		questAns.setCreatedDate(new java.sql.Date((new Date()).getTime()));
		questAns.setCreatedBy(user.getFirstName() + " " + (user.getLastName() != null ? user.getLastName() : ""));
		
		logger.logMethodExit(startTime);
		return questAns;
	}
	
	/*
	 * This method has been used to load the tobacco page depending upon the
	 * tobacco answer flag.
	 */
	public String loadTobaccoPageBasedOnUserAnswer(UserProfile userProfile) throws ServiceException {
		try{
			List<QuestionAnswer> questionAnswers = genericService.loadQuestionAnswerPerPage(userProfile.getUserId(), ApplicationConstants.healthQuestionSetID);
			for(QuestionAnswer questionAnswer : questionAnswers) {
				if(questionAnswer.getSequence() == 6 && "1".equalsIgnoreCase(questionAnswer.getAnswer())) {
					return ApplicationConstants.SMOKING;
				}
			}
		}
		catch (ServiceException e) {
			logger.error("ERROR : " + e.getMessage());
			throw new ServiceException(e.getMessage());
		}
		return ApplicationConstants.HEALTH;
	}
}
