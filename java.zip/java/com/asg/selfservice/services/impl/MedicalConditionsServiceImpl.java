package com.asg.selfservice.services.impl;

/*********************
 * 
 * 
 * @author M1029563 * 
 * Service Level implementation for Medical Conditions Controller which handles service Methods loadMedicalConditionsPage,saveUpdateMedicalConditionsInfo
 */
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.servlet.ModelAndView;

import com.asg.selfservice.common.logger.LogFactory;
import com.asg.selfservice.common.logger.SelfServiceLogger;
import com.asg.selfservice.common.utils.ApplicationConstants;
import com.asg.selfservice.domain.Answer;
import com.asg.selfservice.domain.MedicalConditionsAnswer;
import com.asg.selfservice.domain.Question;
import com.asg.selfservice.domain.QuestionAnswer;
import com.asg.selfservice.domain.UserProfile;
import com.asg.selfservice.exception.ServiceException;
import com.asg.selfservice.services.GenericService;
import com.asg.selfservice.services.MedicalConditionsService;

@Service
public class MedicalConditionsServiceImpl implements MedicalConditionsService {

	private static final SelfServiceLogger logger = LogFactory.getInstance(MedicalConditionsServiceImpl.class);


	@Autowired
	private ServletContext context;

	@Autowired
	private HttpSession session;
	
	@Autowired
	private GenericService genericService;

	@Value("#{'${selfservice.list.states}'.split(',')}") 
	private List<String> states;
	
	@Autowired
	private EmailServiceImpl emailservice;

		
	/*
	 * This method is used to retrieve Medical Condition details from the DB and constructs MedicalConditions Answer Map.
	 * @Exception BaseException
	 * @see com.asg.selfservice.services.MedicalConditionsService#loadMedicalConditionsPage(org.springframework.web.servlet.ModelAndView)
	 */
	@SuppressWarnings("unchecked")
	public ModelAndView loadMedicalConditionsPage(ModelAndView model) throws ServiceException {

		List<Question> medicalQuestions = new ArrayList<Question>();
		List<Question> questionList = null;
		UserProfile	userProfile = null;
		int userId=0;
		List<String> trustee = null;
		Map<Integer,String> medicalQuestAnsMap = null;
		
		try {
			questionList = genericService.loadQuestions();
		
		for (Question question : questionList) {
			
			if(question.getQsetId() == ApplicationConstants.medicalConditionsQuestionSetID) {
				medicalQuestions.add(question);
			}
		}
		
	} catch (ServiceException e) {
		logger.error("ERROR : " + e.getMessage());
		throw new ServiceException(e.getMessage());
	}
		
		if(null  != session.getAttribute("sessionUser") && !"".equals(session.getAttribute("sessionUser"))){
			
			userProfile = (UserProfile) session.getAttribute("sessionUser");
			userId = userProfile.getUserId();
		}
		if(null != userProfile){
			try {
				trustee = this.loadTrusteerelationShips(ApplicationConstants.QuestionID_trustee_RelationShips);
				medicalQuestAnsMap = this.constructAnswer(userId, ApplicationConstants.medicalConditionsQuestionSetID);
			} catch (ServiceException e) {
				logger.error("ERROR : " + e.getMessage());
				throw new ServiceException(e.getMessage());
			}
		}
		model.addObject("medicalQuestions", medicalQuestions);
		model.addObject("medicalQuestAns", medicalQuestAnsMap);
		model.addObject("trustee", trustee);
		model.addObject("states", states);
		model.addObject("userProfile", userProfile);

		return model;
	}
	
	/*
	 * This method is used to Save/Update data in to the Table for the respective userid
	 * @param  UserProfile user,MedicalConditionsAnswer medicalConditions
	 * @Exception BaseException
	 * @see com.asg.selfservice.services.MedicalConditionsService#saveUpdateMedicalConditionsInfo(com.asg.selfservice.domain.UserProfile, com.asg.selfservice.domain.MedicalConditionsAnswer)
	 */
	public void saveUpdateMedicalConditionsInfo(UserProfile userProfile,MedicalConditionsAnswer medicalConditions) throws ServiceException {	
		
		try{
			Map<String, Integer> questAnsUIdQSetIdSeqIdMap = genericService.loadQuestAnsUIdQSetIdSeqIdMap(userProfile);
			
			int questionId=0;
			if(medicalConditions.getConditionsQuestAns1() != null && !medicalConditions.getConditionsQuestAns1().isEmpty()) {
				questionId = questAnsUIdQSetIdSeqIdMap.get(userProfile.getUserId()+"-"+ApplicationConstants.medicalConditionsQuestionSetID+"-"+ApplicationConstants.ONE);
				genericService.saveUpdateInfo(userProfile, this.constructQuestionAnswer(userProfile, questionId, medicalConditions.getConditionsQuestAns1()));
			}
			
			if(medicalConditions.getConditionsQuestAns2() != null && !medicalConditions.getConditionsQuestAns2().isEmpty()) {
				questionId = questAnsUIdQSetIdSeqIdMap.get(userProfile.getUserId()+"-"+ApplicationConstants.medicalConditionsQuestionSetID+"-"+ApplicationConstants.TWO);
				genericService.saveUpdateInfo(userProfile, this.constructQuestionAnswer(userProfile, questionId, medicalConditions.getConditionsQuestAns2()));
			}
			
			if(medicalConditions.getConditionsQuestAns3() != null && !medicalConditions.getConditionsQuestAns3().isEmpty()) {
				questionId = questAnsUIdQSetIdSeqIdMap.get(userProfile.getUserId()+"-"+ApplicationConstants.medicalConditionsQuestionSetID+"-"+ApplicationConstants.THREE);
				genericService.saveUpdateInfo(userProfile, this.constructQuestionAnswer(userProfile, questionId, medicalConditions.getConditionsQuestAns3()));
			}
			
			if(medicalConditions.getConditionsQuestAns4() != null && !medicalConditions.getConditionsQuestAns4().isEmpty()) {
				questionId = questAnsUIdQSetIdSeqIdMap.get(userProfile.getUserId()+"-"+ApplicationConstants.medicalConditionsQuestionSetID+"-"+ApplicationConstants.FOUR);
				genericService.saveUpdateInfo(userProfile, this.constructQuestionAnswer(userProfile, questionId, medicalConditions.getConditionsQuestAns4()));
			}
			
			if(medicalConditions.getConditionsQuestAns5() != null && !medicalConditions.getConditionsQuestAns5().isEmpty()) {
				questionId = questAnsUIdQSetIdSeqIdMap.get(userProfile.getUserId()+"-"+ApplicationConstants.medicalConditionsQuestionSetID+"-"+ApplicationConstants.FIVE);
				genericService.saveUpdateInfo(userProfile, this.constructQuestionAnswer(userProfile, questionId, medicalConditions.getConditionsQuestAns5()));
			}
			
			if(medicalConditions.getConditionsQuestAns6() != null && !medicalConditions.getConditionsQuestAns6().isEmpty()) {
				questionId = questAnsUIdQSetIdSeqIdMap.get(userProfile.getUserId()+"-"+ApplicationConstants.medicalConditionsQuestionSetID+"-"+ApplicationConstants.SIX);
				genericService.saveUpdateInfo(userProfile, this.constructQuestionAnswer(userProfile, questionId, medicalConditions.getConditionsQuestAns6()));
			}
			
			if(medicalConditions.getConditionsQuestAns7() != null && !medicalConditions.getConditionsQuestAns7().isEmpty()) {
				questionId = questAnsUIdQSetIdSeqIdMap.get(userProfile.getUserId()+"-"+ApplicationConstants.medicalConditionsQuestionSetID+"-"+ApplicationConstants.SEVEN);
				genericService.saveUpdateInfo(userProfile, this.constructQuestionAnswer(userProfile, questionId, medicalConditions.getConditionsQuestAns7()));
			}
			
			if(medicalConditions.getConditionsQuestAns8() != null && !medicalConditions.getConditionsQuestAns8().isEmpty()) {
				questionId = questAnsUIdQSetIdSeqIdMap.get(userProfile.getUserId()+"-"+ApplicationConstants.medicalConditionsQuestionSetID+"-"+ApplicationConstants.EIGHT);
				genericService.saveUpdateInfo(userProfile, this.constructQuestionAnswer(userProfile, questionId, medicalConditions.getConditionsQuestAns8()));
			}
			
			if(medicalConditions.getConditionsQuestAns9() != null && !medicalConditions.getConditionsQuestAns9().isEmpty()) {
				questionId = questAnsUIdQSetIdSeqIdMap.get(userProfile.getUserId()+"-"+ApplicationConstants.medicalConditionsQuestionSetID+"-"+ApplicationConstants.NINE);
				genericService.saveUpdateInfo(userProfile, this.constructQuestionAnswer(userProfile, questionId, medicalConditions.getConditionsQuestAns9()));
			}
			
			if(medicalConditions.getConditionsQuestAns10() != null && !medicalConditions.getConditionsQuestAns10().isEmpty()) {
				questionId = questAnsUIdQSetIdSeqIdMap.get(userProfile.getUserId()+"-"+ApplicationConstants.medicalConditionsQuestionSetID+"-"+ApplicationConstants.TEN);
				genericService.saveUpdateInfo(userProfile, this.constructQuestionAnswer(userProfile, questionId, medicalConditions.getConditionsQuestAns10()));
			}
			
			if(medicalConditions.getConditionsQuestAns11() != null && !medicalConditions.getConditionsQuestAns11().isEmpty()) {
				questionId = questAnsUIdQSetIdSeqIdMap.get(userProfile.getUserId()+"-"+ApplicationConstants.medicalConditionsQuestionSetID+"-"+ApplicationConstants.ELEVEN);
				genericService.saveUpdateInfo(userProfile, this.constructQuestionAnswer(userProfile, questionId, medicalConditions.getConditionsQuestAns11()));
			}
			
			if(medicalConditions.getConditionsQuestAns12() != null && !medicalConditions.getConditionsQuestAns12().isEmpty()) {
				questionId = questAnsUIdQSetIdSeqIdMap.get(userProfile.getUserId()+"-"+ApplicationConstants.medicalConditionsQuestionSetID+"-"+ApplicationConstants.TWELVE);
				genericService.saveUpdateInfo(userProfile, this.constructQuestionAnswer(userProfile, questionId, medicalConditions.getConditionsQuestAns12()));
			}
			
			if(medicalConditions.getConditionsQuestAns13() != null && !medicalConditions.getConditionsQuestAns13().isEmpty()) {
				questionId = questAnsUIdQSetIdSeqIdMap.get(userProfile.getUserId()+"-"+ApplicationConstants.medicalConditionsQuestionSetID+"-"+ApplicationConstants.THIRTEEN);
				genericService.saveUpdateInfo(userProfile, this.constructQuestionAnswer(userProfile, questionId, medicalConditions.getConditionsQuestAns13()));
			}
			
			if(medicalConditions.getConditionsQuestAns14() != null && !medicalConditions.getConditionsQuestAns14().isEmpty()) {
				questionId = questAnsUIdQSetIdSeqIdMap.get(userProfile.getUserId()+"-"+ApplicationConstants.medicalConditionsQuestionSetID+"-"+ApplicationConstants.FOURTEEN);
				genericService.saveUpdateInfo(userProfile, this.constructQuestionAnswer(userProfile, questionId, medicalConditions.getConditionsQuestAns14()));
			}
			
			if(medicalConditions.getConditionsQuestAns15() != null && !medicalConditions.getConditionsQuestAns15().isEmpty()) {
				questionId = questAnsUIdQSetIdSeqIdMap.get(userProfile.getUserId()+"-"+ApplicationConstants.medicalConditionsQuestionSetID+"-"+ApplicationConstants.FIFTEEN);
				genericService.saveUpdateInfo(userProfile, this.constructQuestionAnswer(userProfile, questionId, medicalConditions.getConditionsQuestAns15()));
			}
			
			if(medicalConditions.getConditionsQuestAns16() != null && !medicalConditions.getConditionsQuestAns16().isEmpty()) {
				questionId = questAnsUIdQSetIdSeqIdMap.get(userProfile.getUserId()+"-"+ApplicationConstants.medicalConditionsQuestionSetID+"-"+ApplicationConstants.SIXTEEN);
				genericService.saveUpdateInfo(userProfile, this.constructQuestionAnswer(userProfile, questionId, medicalConditions.getConditionsQuestAns16()));
			}
			
			if(medicalConditions.getConditionsQuestAns17() != null && !medicalConditions.getConditionsQuestAns17().isEmpty()) {
				questionId = questAnsUIdQSetIdSeqIdMap.get(userProfile.getUserId()+"-"+ApplicationConstants.medicalConditionsQuestionSetID+"-"+ApplicationConstants.SEVENTEEN);
				genericService.saveUpdateInfo(userProfile, this.constructQuestionAnswer(userProfile, questionId, medicalConditions.getConditionsQuestAns17()));
			}
			
			if(medicalConditions.getConditionsQuestAns18() != null && !medicalConditions.getConditionsQuestAns18().isEmpty()) {
				questionId = questAnsUIdQSetIdSeqIdMap.get(userProfile.getUserId()+"-"+ApplicationConstants.medicalConditionsQuestionSetID+"-"+ApplicationConstants.EIGHTEEN);
				genericService.saveUpdateInfo(userProfile, this.constructQuestionAnswer(userProfile, questionId, medicalConditions.getConditionsQuestAns18()));
			}
			
			if(medicalConditions.getConditionsQuestAns19() != null && !medicalConditions.getConditionsQuestAns19().isEmpty()) {
				questionId = questAnsUIdQSetIdSeqIdMap.get(userProfile.getUserId()+"-"+ApplicationConstants.medicalConditionsQuestionSetID+"-"+ApplicationConstants.NINETEEN);
				genericService.saveUpdateInfo(userProfile, this.constructQuestionAnswer(userProfile, questionId, medicalConditions.getConditionsQuestAns19()));
			}
			
			if(medicalConditions.getConditionsQuestAns20() != null && !medicalConditions.getConditionsQuestAns20().isEmpty()) {
				questionId = questAnsUIdQSetIdSeqIdMap.get(userProfile.getUserId()+"-"+ApplicationConstants.medicalConditionsQuestionSetID+"-"+ApplicationConstants.TWENTY);
				genericService.saveUpdateInfo(userProfile, this.constructQuestionAnswer(userProfile, questionId, medicalConditions.getConditionsQuestAns20()));
			}
			
			
			if(medicalConditions.getConditionsQuestAns28() != null && !medicalConditions.getConditionsQuestAns28().isEmpty()) {
				questionId = questAnsUIdQSetIdSeqIdMap.get(userProfile.getUserId()+"-"+ApplicationConstants.medicalConditionsQuestionSetID+"-"+ApplicationConstants.TWENTY_EIGHT);
				genericService.saveUpdateInfo(userProfile, this.constructQuestionAnswer(userProfile, questionId, medicalConditions.getConditionsQuestAns28()));
			}
			if(medicalConditions.getConditionsQuestAns29() != null && !medicalConditions.getConditionsQuestAns29().isEmpty()) {
				questionId = questAnsUIdQSetIdSeqIdMap.get(userProfile.getUserId()+"-"+ApplicationConstants.medicalConditionsQuestionSetID+"-"+ApplicationConstants.TWENTY_NINE);
				genericService.saveUpdateInfo(userProfile, this.constructQuestionAnswer(userProfile, questionId, medicalConditions.getConditionsQuestAns29()));
			}
			
			if(medicalConditions.getConditionsQuestAns30() != null && !medicalConditions.getConditionsQuestAns30().isEmpty()) {
				questionId = questAnsUIdQSetIdSeqIdMap.get(userProfile.getUserId()+"-"+ApplicationConstants.medicalConditionsQuestionSetID+"-"+ApplicationConstants.THIRTY);
				genericService.saveUpdateInfo(userProfile, this.constructQuestionAnswer(userProfile, questionId, medicalConditions.getConditionsQuestAns30()));
			}
			
			if(medicalConditions.getConditionsQuestAns31() != null && !medicalConditions.getConditionsQuestAns31().isEmpty()) {
				questionId = questAnsUIdQSetIdSeqIdMap.get(userProfile.getUserId()+"-"+ApplicationConstants.medicalConditionsQuestionSetID+"-"+ApplicationConstants.THIRTY_ONE);
				if(medicalConditions.getConditionsQuestAns31().equals("1")){
					
					genericService.saveUpdateInfo(userProfile, this.constructQuestionAnswer(userProfile, questionId, medicalConditions.getConditionsQuestAns31()));
					genericService.deleteAnswers(userProfile, new Integer[]{103,104,105,106,107,115,116});
				}
				else{
					
					if(medicalConditions.getConditionsQuestAns31() != null && !medicalConditions.getConditionsQuestAns31().isEmpty()) {
				
						genericService.saveUpdateInfo(userProfile, this.constructQuestionAnswer(userProfile, questionId, medicalConditions.getConditionsQuestAns31()));
					}
					if(medicalConditions.getConditionsQuestAns32() != null && !medicalConditions.getConditionsQuestAns32().isEmpty() && !medicalConditions.getConditionsQuestAns32().equalsIgnoreCase("select")) {
						questionId = questAnsUIdQSetIdSeqIdMap.get(userProfile.getUserId()+"-"+ApplicationConstants.medicalConditionsQuestionSetID+"-"+ApplicationConstants.THIRTY_TWO);
						genericService.saveUpdateInfo(userProfile, this.constructQuestionAnswer(userProfile, questionId, medicalConditions.getConditionsQuestAns32()));
					}
					if(medicalConditions.getConditionsQuestAns32().equalsIgnoreCase("spouse")){
						
						if(medicalConditions.getConditionsQuestAns33() != null && !medicalConditions.getConditionsQuestAns33().isEmpty()){
							questionId = questAnsUIdQSetIdSeqIdMap.get(userProfile.getUserId()+"-"+ApplicationConstants.medicalConditionsQuestionSetID+"-"+ApplicationConstants.THIRTY_THREE);
							genericService.saveUpdateInfo(userProfile, this.constructQuestionAnswer(userProfile, questionId, medicalConditions.getConditionsQuestAns33()));
						}
						if(medicalConditions.getConditionsQuestAns34() != null && !medicalConditions.getConditionsQuestAns34().isEmpty()) {
							questionId = questAnsUIdQSetIdSeqIdMap.get(userProfile.getUserId()+"-"+ApplicationConstants.medicalConditionsQuestionSetID+"-"+ApplicationConstants.THIRTY_FOUR);
							genericService.saveUpdateInfo(userProfile, this.constructQuestionAnswer(userProfile, questionId, medicalConditions.getConditionsQuestAns34()));
						}
						if(medicalConditions.getConditionsQuestAns35() != null && !medicalConditions.getConditionsQuestAns35().isEmpty()) {
							questionId = questAnsUIdQSetIdSeqIdMap.get(userProfile.getUserId()+"-"+ApplicationConstants.medicalConditionsQuestionSetID+"-"+ApplicationConstants.THIRTY_FIVE);
							genericService.saveUpdateInfo(userProfile, this.constructQuestionAnswer(userProfile, questionId, medicalConditions.getConditionsQuestAns35()));
						}
						genericService.deleteAnswers(userProfile, new Integer[]{106,107,116});
					}
					if(medicalConditions.getConditionsQuestAns32().equalsIgnoreCase("trust")){
						
						if(medicalConditions.getConditionsQuestAns36() != null && !medicalConditions.getConditionsQuestAns36().isEmpty()) {
							questionId = questAnsUIdQSetIdSeqIdMap.get(userProfile.getUserId()+"-"+ApplicationConstants.medicalConditionsQuestionSetID+"-"+ApplicationConstants.THIRTY_SIX);
							genericService.saveUpdateInfo(userProfile, this.constructQuestionAnswer(userProfile, questionId, medicalConditions.getConditionsQuestAns36()));
						}
						if(medicalConditions.getConditionsQuestAns37() != null && !medicalConditions.getConditionsQuestAns37().isEmpty()) {
							questionId = questAnsUIdQSetIdSeqIdMap.get(userProfile.getUserId()+"-"+ApplicationConstants.medicalConditionsQuestionSetID+"-"+ApplicationConstants.THIRTY_SEVEN);
							genericService.saveUpdateInfo(userProfile, this.constructQuestionAnswer(userProfile, questionId, medicalConditions.getConditionsQuestAns37()));
						}
						genericService.deleteAnswers(userProfile, new Integer[]{103,104,105,115});
					}
					if(medicalConditions.getConditionsQuestAns32().equalsIgnoreCase("other")){
						questionId = questAnsUIdQSetIdSeqIdMap.get(userProfile.getUserId()+"-"+ApplicationConstants.medicalConditionsQuestionSetID+"-"+ApplicationConstants.FOURTY_FIVE);
						if(medicalConditions.getConditionsQuestAns45() != null && !medicalConditions.getConditionsQuestAns45().isEmpty()) {
							
							genericService.saveUpdateInfo(userProfile, this.constructQuestionAnswer(userProfile, questionId, medicalConditions.getConditionsQuestAns45()));
							genericService.deleteAnswers(userProfile, new Integer[]{103,104,105,106,107});
						}
					}
				}
				
			}
			if(medicalConditions.getConditionsQuestAns38() != null && !medicalConditions.getConditionsQuestAns38().isEmpty()) {
				questionId = questAnsUIdQSetIdSeqIdMap.get(userProfile.getUserId()+"-"+ApplicationConstants.medicalConditionsQuestionSetID+"-"+ApplicationConstants.THIRTY_EIGHT);
				if(medicalConditions.getConditionsQuestAns38().equals("0")){
					genericService.saveUpdateInfo(userProfile, this.constructQuestionAnswer(userProfile, questionId, medicalConditions.getConditionsQuestAns38()));
					genericService.deleteAnswers(userProfile, new Integer[]{109,110});
				}
				else if(medicalConditions.getConditionsQuestAns38().equals("1") && medicalConditions.getConditionsQuestAns39()==null && medicalConditions.getConditionsQuestAns40()==null){
					questionId = questAnsUIdQSetIdSeqIdMap.get(userProfile.getUserId()+"-"+ApplicationConstants.medicalConditionsQuestionSetID+"-"+ApplicationConstants.THIRTY_EIGHT);
					genericService.saveUpdateInfo(userProfile, this.constructQuestionAnswer(userProfile, questionId, medicalConditions.getConditionsQuestAns38()));
					genericService.deleteAnswers(userProfile, new Integer[]{109,110});
				}
				else{
					if(medicalConditions.getConditionsQuestAns38() != null && !medicalConditions.getConditionsQuestAns38().isEmpty()) {
						questionId = questAnsUIdQSetIdSeqIdMap.get(userProfile.getUserId()+"-"+ApplicationConstants.medicalConditionsQuestionSetID+"-"+ApplicationConstants.THIRTY_EIGHT);
						genericService.saveUpdateInfo(userProfile, this.constructQuestionAnswer(userProfile, questionId, medicalConditions.getConditionsQuestAns38()));
					}
					if(medicalConditions.getConditionsQuestAns39() != null && !medicalConditions.getConditionsQuestAns39().isEmpty()) {
						questionId = questAnsUIdQSetIdSeqIdMap.get(userProfile.getUserId()+"-"+ApplicationConstants.medicalConditionsQuestionSetID+"-"+ApplicationConstants.THIRTY_NINE);
						genericService.saveUpdateInfo(userProfile, this.constructQuestionAnswer(userProfile, questionId, medicalConditions.getConditionsQuestAns39()));
					}
					if(medicalConditions.getConditionsQuestAns40() != null && !medicalConditions.getConditionsQuestAns40().isEmpty()) {
						questionId = questAnsUIdQSetIdSeqIdMap.get(userProfile.getUserId()+"-"+ApplicationConstants.medicalConditionsQuestionSetID+"-"+ApplicationConstants.FOURTY);
						genericService.saveUpdateInfo(userProfile, this.constructQuestionAnswer(userProfile, questionId, medicalConditions.getConditionsQuestAns40()));
					}
				}
			}
			
			if(medicalConditions.getConditionsQuestAns42() != null && !medicalConditions.getConditionsQuestAns42().isEmpty()) {
				questionId = questAnsUIdQSetIdSeqIdMap.get(userProfile.getUserId()+"-"+ApplicationConstants.medicalConditionsQuestionSetID+"-"+ApplicationConstants.FOURTY_TWO);
				genericService.saveUpdateInfo(userProfile, this.constructQuestionAnswer(userProfile, questionId, medicalConditions.getConditionsQuestAns42()));
			}
			if(medicalConditions.getConditionsQuestAns43() != null && !medicalConditions.getConditionsQuestAns43().isEmpty()) {
				questionId = questAnsUIdQSetIdSeqIdMap.get(userProfile.getUserId()+"-"+ApplicationConstants.medicalConditionsQuestionSetID+"-"+ApplicationConstants.FOURTY_THREE);
				genericService.saveUpdateInfo(userProfile, this.constructQuestionAnswer(userProfile, questionId, medicalConditions.getConditionsQuestAns43()));
			}
			if(medicalConditions.getConditionsQuestAns44() != null && !medicalConditions.getConditionsQuestAns44().isEmpty() && !medicalConditions.getConditionsQuestAns44().equalsIgnoreCase("select")) {
				questionId = questAnsUIdQSetIdSeqIdMap.get(userProfile.getUserId()+"-"+ApplicationConstants.medicalConditionsQuestionSetID+"-"+ApplicationConstants.FOURTY_FOUR);
				genericService.saveUpdateInfo(userProfile, this.constructQuestionAnswer(userProfile, questionId, medicalConditions.getConditionsQuestAns44()));
			}
			
		}
		catch (ServiceException e) {
			logger.error("ERROR : " + e.getMessage());
			throw new ServiceException(e.getMessage());
		}
	}
	/*
	 * This method is used to Construct MedicalConditionsANswer Map from USER_QUESTION_ANSWER TABLLE
	 * @param  int userId, int qsetId
	 * @Exception ServiceException
	 * @see com.asg.selfservice.services.MedicalConditionsService#constructAnswer(int userId, int qsetId)
	 */
	public Map<Integer,String> constructAnswer(int userId, int qsetId) throws ServiceException {
		Map<Integer,String> medicalQuestAnsMap = new HashMap<Integer, String>();
		

		List<QuestionAnswer> questAnswers = genericService.loadQuestionAnswerPerPage(userId, qsetId);

		for(QuestionAnswer quesAnswer : questAnswers) {
		
			if(quesAnswer.getSequence() == ApplicationConstants.ONE){
				medicalQuestAnsMap.put(quesAnswer.getqId(),quesAnswer.getAnswer());
			}
			
			if(quesAnswer.getSequence() == ApplicationConstants.TWO){
				medicalQuestAnsMap.put(quesAnswer.getqId(),quesAnswer.getAnswer());
			}	
			if(quesAnswer.getSequence() == ApplicationConstants.THREE){
				medicalQuestAnsMap.put(quesAnswer.getqId(),quesAnswer.getAnswer());
			}	
			if(quesAnswer.getSequence() == ApplicationConstants.FOUR){
				medicalQuestAnsMap.put(quesAnswer.getqId(),quesAnswer.getAnswer());
			}
			if(quesAnswer.getSequence() == ApplicationConstants.FIVE){
				medicalQuestAnsMap.put(quesAnswer.getqId(),quesAnswer.getAnswer());
			}
			if(quesAnswer.getSequence() == ApplicationConstants.SIX){
				medicalQuestAnsMap.put(quesAnswer.getqId(),quesAnswer.getAnswer());
			}
			if(quesAnswer.getSequence() == ApplicationConstants.SEVEN){
				medicalQuestAnsMap.put(quesAnswer.getqId(),quesAnswer.getAnswer());
			}
			if(quesAnswer.getSequence() == ApplicationConstants.EIGHT){
				medicalQuestAnsMap.put(quesAnswer.getqId(),quesAnswer.getAnswer());
			}
			if(quesAnswer.getSequence() == ApplicationConstants.NINE){
				medicalQuestAnsMap.put(quesAnswer.getqId(),quesAnswer.getAnswer());
			}
			if(quesAnswer.getSequence() == ApplicationConstants.TEN){
				medicalQuestAnsMap.put(quesAnswer.getqId(),quesAnswer.getAnswer());
			}
			if(quesAnswer.getSequence() == ApplicationConstants.ELEVEN){
				medicalQuestAnsMap.put(quesAnswer.getqId(),quesAnswer.getAnswer());
			}
			if(quesAnswer.getSequence() == ApplicationConstants.TWELVE){
				medicalQuestAnsMap.put(quesAnswer.getqId(),quesAnswer.getAnswer());
			}
			if(quesAnswer.getSequence() == ApplicationConstants.THIRTEEN){
				medicalQuestAnsMap.put(quesAnswer.getqId(),quesAnswer.getAnswer());
			}
			if(quesAnswer.getSequence() == ApplicationConstants.FOURTEEN){
				medicalQuestAnsMap.put(quesAnswer.getqId(),quesAnswer.getAnswer());
			}
			if(quesAnswer.getSequence() == ApplicationConstants.FIFTEEN){
				medicalQuestAnsMap.put(quesAnswer.getqId(),quesAnswer.getAnswer());
			}
			if(quesAnswer.getSequence() == ApplicationConstants.SIXTEEN){
				medicalQuestAnsMap.put(quesAnswer.getqId(),quesAnswer.getAnswer());
			}
			if(quesAnswer.getSequence() == ApplicationConstants.SEVENTEEN){
				medicalQuestAnsMap.put(quesAnswer.getqId(),quesAnswer.getAnswer());
			}
			if(quesAnswer.getSequence() == ApplicationConstants.EIGHTEEN){
				medicalQuestAnsMap.put(quesAnswer.getqId(),quesAnswer.getAnswer());
			}
			if(quesAnswer.getSequence() == ApplicationConstants.NINETEEN){
				medicalQuestAnsMap.put(quesAnswer.getqId(),quesAnswer.getAnswer());
			}
			if(quesAnswer.getSequence() == ApplicationConstants.TWENTY){
				medicalQuestAnsMap.put(quesAnswer.getqId(),quesAnswer.getAnswer());
			}			
			if(quesAnswer.getSequence() == ApplicationConstants.TWENTY_EIGHT){
				medicalQuestAnsMap.put(quesAnswer.getqId(),quesAnswer.getAnswer());
			}
			if(quesAnswer.getSequence() == ApplicationConstants.TWENTY_NINE){
				medicalQuestAnsMap.put(quesAnswer.getqId(),quesAnswer.getAnswer());
			}
			if(quesAnswer.getSequence() == ApplicationConstants.THIRTY){
				medicalQuestAnsMap.put(quesAnswer.getqId(),quesAnswer.getAnswer());
			}
			if(quesAnswer.getSequence() == ApplicationConstants.THIRTY_ONE){
				medicalQuestAnsMap.put(quesAnswer.getqId(),quesAnswer.getAnswer());
			}
			if(quesAnswer.getSequence() == ApplicationConstants.THIRTY_TWO){
				medicalQuestAnsMap.put(quesAnswer.getqId(),quesAnswer.getAnswer());	
			}
			if(quesAnswer.getSequence() == ApplicationConstants.THIRTY_THREE){
				medicalQuestAnsMap.put(quesAnswer.getqId(),quesAnswer.getAnswer());
			}
			if(quesAnswer.getSequence() == ApplicationConstants.THIRTY_FOUR){
				medicalQuestAnsMap.put(quesAnswer.getqId(),quesAnswer.getAnswer());
			}
			if(quesAnswer.getSequence() == ApplicationConstants.THIRTY_FIVE){
				medicalQuestAnsMap.put(quesAnswer.getqId(),quesAnswer.getAnswer());
			}
			if(quesAnswer.getSequence() == ApplicationConstants.THIRTY_SIX){
				medicalQuestAnsMap.put(quesAnswer.getqId(),quesAnswer.getAnswer());
			}
			if(quesAnswer.getSequence() == ApplicationConstants.THIRTY_SEVEN){
				medicalQuestAnsMap.put(quesAnswer.getqId(),quesAnswer.getAnswer());
			}
			if(quesAnswer.getSequence() == ApplicationConstants.THIRTY_EIGHT){
				medicalQuestAnsMap.put(quesAnswer.getqId(),quesAnswer.getAnswer());
			}
			if(quesAnswer.getSequence() == ApplicationConstants.THIRTY_NINE){
				medicalQuestAnsMap.put(quesAnswer.getqId(),quesAnswer.getAnswer());
			}
			if(quesAnswer.getSequence() == ApplicationConstants.FOURTY){
				medicalQuestAnsMap.put(quesAnswer.getqId(),quesAnswer.getAnswer());
			}
			if(quesAnswer.getSequence() == ApplicationConstants.FOURTY_ONE){
				medicalQuestAnsMap.put(quesAnswer.getqId(),quesAnswer.getAnswer());
			}
			if(quesAnswer.getSequence() == ApplicationConstants.FOURTY_TWO){
				medicalQuestAnsMap.put(quesAnswer.getqId(),quesAnswer.getAnswer());
			}
			if(quesAnswer.getSequence() == ApplicationConstants.FOURTY_THREE){
				medicalQuestAnsMap.put(quesAnswer.getqId(),quesAnswer.getAnswer());
			}
			if(quesAnswer.getSequence() == ApplicationConstants.FOURTY_FOUR){
				medicalQuestAnsMap.put(quesAnswer.getqId(),quesAnswer.getAnswer());
			}
			if(quesAnswer.getSequence() == ApplicationConstants.FOURTY_FIVE){
				medicalQuestAnsMap.put(quesAnswer.getqId(),quesAnswer.getAnswer());
			}

		}
		return medicalQuestAnsMap;
	}	
	/*
	 * This is an internal method used inside this service code where question answer has been constructed
	 * based on the question id, user and ans value.
	 */
	private QuestionAnswer constructQuestionAnswer(UserProfile user, int questionId, String ansValue) {
		QuestionAnswer quesAnswer = new QuestionAnswer();
		
		quesAnswer.setqId(questionId);
		quesAnswer.setUserId(user.getUserId());
		quesAnswer.setAnswer(ansValue);
		quesAnswer.setCreatedDate(new java.sql.Date((new Date()).getTime()));
		quesAnswer.setCreatedBy(user.getFirstName() + " " + (user.getLastName() != null ? user.getLastName() : ""));
		
		return quesAnswer;
	}
	/*
	 * This method is used to fetch Trust RelationShips for the respective question id from the ANSWERS table in the DB and returns List<String> Trustees
	 * @param QID
	 * @return List<String> Trustees
	 */
	public List<String> loadTrusteerelationShips(int qId)
			throws ServiceException {
		List<String> trustees = new ArrayList<String>();
		
		try {
			List<Answer> answers = genericService.loadAnswers();
			for(Answer answer : answers) {
				if(answer.getqId() == qId) {
					
					trustees.add(answer.getAnswerValue());
				}
			}
		} catch (ServiceException e) {
			logger.error("ERROR : " + e.getMessage());
			throw new ServiceException(e.getMessage());
		}
		
		return trustees;
	}
	/*
	 * This method is used to trigger an email to user when the user has submitted the APPLICATION BEGIN 1 AND BEGIN 2
	 * @param UserProfile userProfile
	 * @return 
	 */
	public void sendsubmittedapplicationNotificationMail(UserProfile userProfile)
			throws ServiceException {
		
		try{
			emailservice.sendSubmitMail(userProfile);
		}
		catch(ServiceException e){
			logger.error("ERROR : " + e.getMessage());
			throw new ServiceException(e.getMessage());
		}
		
	}	 

}
