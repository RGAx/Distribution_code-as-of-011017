package com.asg.selfservice.services;

import com.asg.selfservice.domain.Quote;
import com.asg.selfservice.domain.UserProfile;
import com.asg.selfservice.exception.ServiceException;

/**
 * This class has been used for defining the operations such as loading the user
 * question answer, getting the best quote etc which have been implemented in
 * EBIXServiceImpl class.
 * 
 * @author M1030133
 *
 */
public interface EBIXService extends BaseService {

	public Quote getBestQuote(UserProfile userProfile) throws ServiceException;

}
