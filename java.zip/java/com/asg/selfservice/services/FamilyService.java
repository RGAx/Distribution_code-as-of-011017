/**
 * 
 */
package com.asg.selfservice.services;

import java.util.List;
import java.util.Map;

import com.asg.selfservice.domain.FamilyAnswer;
import com.asg.selfservice.domain.Question;
import com.asg.selfservice.domain.UserProfile;
import com.asg.selfservice.exception.ServiceException;

/**
 * This interface has been used for defining the Family operations such as loading the Family page,
 * loading the questions and saving/updating the family info into the DB.
 * 	Implemented in FamilyServiceImpl class.
 * 
 * @author M1029563
 *
 */
public interface FamilyService extends BaseService{
	
	public List<Question> loadfamilyhistoryQuestions() throws ServiceException;
		
	public void saveUpdateFamilyInfo(UserProfile user,FamilyAnswer familyAnswer) throws ServiceException;
	
	public Map<Integer,String> loadfamilyPage(int userId,int qsetId) throws ServiceException;
	
	public List<String> loadages(int qid) throws ServiceException;
	
	public List<String> loadrelationShips(int qid) throws ServiceException;

}
