package com.asg.selfservice.services;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import com.asg.selfservice.common.logger.LogFactory;
import com.asg.selfservice.common.logger.SelfServiceLogger;
import com.asg.selfservice.exception.DAOException;
import com.asg.selfservice.exception.ServiceException;

/**
 * @author M1030777
 * This class is actually responsible for triggering the scheduler at 11 and 12  midnight.
 *
 */
@Service
public class SchedulerServiceImpl {

	private static final SelfServiceLogger logger = LogFactory.getInstance(SchedulerServiceImpl.class);
	
	 @Autowired
	 @Qualifier("syncEmailScheduleJobs")
	 private ScheduleJob scheduleJob;
	 
	 
	 @Autowired
	 @Qualifier("syncSchedulePinneyJobs")
	 private RunPinneyScheduler pinneyScheduler;
	 

	 /**
	  *  This class is actually responsible for triggering the scheduler at  12  midnight.
	 * @throws ServiceException
	 */
	
	 	 @Scheduled(cron="0 55 23 * * ?")
	 //@Scheduled(fixedDelay = 900000)
	 	 public synchronized void doSchedule() throws ServiceException {
		 logger.info("Start schedule");			
		   
		 try {
			scheduleJob.scheduledEmailJob();
		} catch (DAOException e) {
			logger.error("ERROR: " + e.getMessage());
			throw new ServiceException(e.getMessage());
		}       
		 logger.info("End schedule");	
	 }
	 	
	 	
	 	 /**
	 	  *  This class is actually responsible for triggering the scheduler at 11 midnight.
		 * @throws Exception 
		 */
		
		 	@Scheduled(cron="0 0 23 * * ?")
		 	public synchronized void doPinneySchedule() throws Exception {
			logger.info("Start Pinney schedule - " + new Date());			
			   
			 try {
				 pinneyScheduler.schedulePinneyJob();
			} catch (DAOException e) {
				logger.error("ERROR: " + e.getMessage());
				throw new ServiceException(e.getMessage());
			}       
			 logger.info("End Pinney schedule - " + new Date());	
		 }	
		 	
			 
		 	/**
		 	 * This method is trigerrs email to the users who has clicked apply now and exited the site
		 	 * @throws ServiceException
		 	 */
		 	@Scheduled(cron="0 55 23 * * ?")
		 	//@Scheduled(fixedDelay = 900000)
		 	 public synchronized void doScheduleRemainderEmailForApplyNow() throws ServiceException {
			 logger.info("Start schedule for doScheduleRemainderEmailForApplyNow");			
			   
			 try {
				scheduleJob.scheduledEmailJobForApplyNow();
				
			} catch (DAOException e) {
				logger.error("ERROR: " + e.getMessage());
				throw new ServiceException(e.getMessage());
			}       
			 logger.info("End schedule");	
		 }
		  
			/**
		 	 * This method is trigerrs email to the users who has saved form data and exited the site
		 	 * @throws ServiceException
		 	 */
		 
		  @Scheduled(cron="0 55 23 * * ?")
		 	//@Scheduled(fixedDelay = 900000)
		 	 public synchronized void doScheduleRemainderEmailForHitSave() throws ServiceException {
			 logger.info("Start schedule for doScheduleRemainderEmailForHitSave");			
			   
			 try {
				scheduleJob.scheduledEmailJobForHitSave();
				
			} catch (DAOException e) {
				logger.error("ERROR: " + e.getMessage());
				throw new ServiceException(e.getMessage());
			}       
			 logger.info("End schedule");	
		 }
	 
}
