package com.asg.selfservice.services;

import java.util.List;
import java.util.Map;

import com.asg.selfservice.domain.Answer;
import com.asg.selfservice.domain.Question;
import com.asg.selfservice.domain.QuestionAnswer;
import com.asg.selfservice.domain.UserProfile;
import com.asg.selfservice.exception.ServiceException;

/**
 * This is a common interface which has been used for defining the common
 * methods and these can be accessed from any other services.
 * 
 * @author M1030133
 *
 */
public interface GenericService extends BaseService {
	public List<Question> loadQuestions() throws ServiceException;

	public List<Answer> loadAnswers() throws ServiceException;

	public Map<String, Integer> loadQuestAnsUIdQSetIdSeqIdMap(
			UserProfile userProfile) throws ServiceException;

	public List<QuestionAnswer> loadQuestionAnswerPerPage(int userId, int qsetId)
			throws ServiceException;

	public QuestionAnswer loadQuestionAnswer(int userId, int qId)
			throws ServiceException;

	public void saveUpdateInfo(UserProfile user, QuestionAnswer questAns)
			throws ServiceException;

	public void deleteAnswer(UserProfile user, QuestionAnswer questAns)
			throws ServiceException;

	public void deleteAnswers(UserProfile user, Integer[] qIds)
			throws ServiceException;

	public List<QuestionAnswer> loadQuestionAnswersForPinney(int userId)
			throws ServiceException;

	public List<QuestionAnswer> loadQuestionAnswersForEBIX(int userId)
			throws ServiceException;

	public Map<Integer, List<Integer>> loadReflexiveQuestions()
			throws ServiceException;
	
	public Integer[] loadQuestionIdsBasedQSetId(int userId, int qsetId)
			throws ServiceException;

	public List<UserProfile> getPinneyFailedSubmit() throws ServiceException;
}
