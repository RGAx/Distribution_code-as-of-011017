package com.asg.selfservice.services;

import org.springframework.web.servlet.ModelAndView;

import com.asg.selfservice.domain.Quote;
import com.asg.selfservice.domain.UserProfile;
import com.asg.selfservice.exception.ServiceException;

/**
 * This interface has been used for defining the QUote operations such as
 * loading the quotes, updating the policy info, updating the quote into the DB.
 * This has been implemented in QuoteServiceImpl class.
 * 
 * @author M1030133
 *
 */
public interface QuoteService extends BaseService {
	public Quote getQuote(int userId) throws ServiceException;
	
	public ModelAndView loadQuotes(ModelAndView model, UserProfile userProfile)
			throws ServiceException;

	public UserProfile updatePolicy(UserProfile userProfile,
			UserProfile sessionUser) throws ServiceException;

	public void updateQuote(int quoteIndex, UserProfile sessionUser)
			throws ServiceException;
	
	public void deleteprevSavedQuoteOnSubmitwithEmptyQuote(int userId) 
			throws ServiceException;
}
