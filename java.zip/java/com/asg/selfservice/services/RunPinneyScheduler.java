/**
 * 
 */
package com.asg.selfservice.services;


/**
 * @author M1030777
 *
 */
public interface RunPinneyScheduler {
	//Pinney Scheduler
	public void schedulePinneyJob() throws Exception;
}
