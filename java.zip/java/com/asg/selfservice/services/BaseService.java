package com.asg.selfservice.services;

/**
 * Defines base service.
 * @author M1030133
 *
 */
public interface BaseService {

}
