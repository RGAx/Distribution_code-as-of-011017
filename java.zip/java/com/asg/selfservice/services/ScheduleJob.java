/**
 * 
 */
package com.asg.selfservice.services;

import com.asg.selfservice.exception.DAOException;
import com.asg.selfservice.exception.ServiceException;

/**
 * @author M1030777
 * This Interface is used to send scheduled Email to respective prospects
 *
 */
public interface ScheduleJob {
	public void  scheduledEmailJob() throws ServiceException, DAOException;
	
	public void scheduledEmailJobForApplyNow() throws ServiceException, DAOException;
	
	public void scheduledEmailJobForHitSave() throws ServiceException, DAOException;


}
