/**
 * 
 */
package com.asg.selfservice.services;

import java.util.List;

import com.asg.selfservice.domain.DrivingHistory;
import com.asg.selfservice.domain.Question;
import com.asg.selfservice.domain.UserProfile;
import com.asg.selfservice.exception.ServiceException;


/**
 * This interface has been used for defining the Driving operations such as loading the driving page,
 * loading the questions and saving/updating the driving info into the DB.
 * 	Implemented in DrivingHistoryServiceImpl class.
 *  @author M1029563
 *
 */
public interface DrivingService extends BaseService {

	public DrivingHistory loadDrivingPage(int userId,int qsetId) throws ServiceException;
	
	public void saveUpdateDrivingInfo(UserProfile userProfile,DrivingHistory drivingHistory) throws ServiceException;
	
	public List<Question> loadQuestions() throws ServiceException;
}
