package com.asg.selfservice.services;

import com.asg.selfservice.domain.Legalstmt;
import com.asg.selfservice.exception.ServiceException;

/**
 * @author M1030777
 *
 */
public interface LegalStatementService {

	Legalstmt getFIName_Type(String agency_name) throws ServiceException;

}
