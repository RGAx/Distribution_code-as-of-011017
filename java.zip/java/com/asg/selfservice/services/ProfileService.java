package com.asg.selfservice.services;

import java.util.List;

import com.asg.selfservice.domain.Health;
import com.asg.selfservice.domain.UserProfile;
import com.asg.selfservice.exception.ServiceException;

/**
 * This interface has been used for defining the profile operations such as
 * loading/saving/updating the user profile infos from/into DB.
 * 
 * @author M1030133
 *
 */
public interface ProfileService extends BaseService {
	public UserProfile loadUserProfileByEmail(String emailAddress)
			throws ServiceException;

	public UserProfile loadUserProfileById(int userId) throws ServiceException;

	public void updateUserProfileInitialMonthlyEstimate(UserProfile userProfile)
			throws ServiceException;

	public void updateUserProfileWithPassword(UserProfile userProfile)
			throws ServiceException;

	public void updateUserProfilePassword(UserProfile userProfile)
			throws ServiceException;

	public void updateUserProfileStatus(UserProfile userProfile)
			throws ServiceException;

	public List<UserProfile> fetchSavedData() throws ServiceException;
	
	public UserProfile saveUserProfile(UserProfile userProfile) throws ServiceException;
	
	public UserProfile saveUserProfileOnApplyNow(UserProfile userProfile) throws ServiceException;
	
	public UserProfile saveUserProfileOnSubmitApplication(UserProfile userProfile) throws ServiceException;
	
	public boolean validatePassword(UserProfile userProfile) throws ServiceException;
	
	public void updateUserProfileInfo(UserProfile userProfile) throws ServiceException;

	public UserProfile updateUserProfileWithHealthDetails(UserProfile userProfile,
			Health health) throws ServiceException;

	public boolean validateEmail(String emailAddress, UserProfile sessionUser) throws ServiceException;
	
	public List<UserProfile> getUserProfilesForStatus1()throws ServiceException;

	public List<UserProfile> getUserProfilesForStatus2()throws ServiceException;

	public void updateUserProfileStatusWithAdminCheck(UserProfile userProfile,
			boolean adminUserFlag) throws ServiceException;
	
	public int loadProfileStatusFlag(int userId) throws ServiceException;

}
