package com.asg.selfservice.services;

import java.util.List;

import com.asg.selfservice.domain.MedicalHistoryAnswer;
import com.asg.selfservice.domain.Question;
import com.asg.selfservice.domain.UserProfile;
import com.asg.selfservice.exception.ServiceException;


/**
 * This interface has been used for defining the Medical History operations such as loading the medical history page,
 * loading the questions and saving/updating the medical history info into the DB.
 * 	Implemented in MedicalHistoryServiceImpl class.
 *  @author M1029563
 *
 */
public interface MedicalHistoryService extends BaseService {
	
	public List<Question> loadQuestions() throws ServiceException;

	public String saveUpdateMedicalInfo(UserProfile user,MedicalHistoryAnswer cholAnswer) throws ServiceException;
	
	public MedicalHistoryAnswer loadMedicalInfo(int userId,int questiosetId) throws ServiceException;
	
	public List<String> loadcholestrolLevels(int qId) throws ServiceException;
	
	public List<String> loadhdlRatios(int qId) throws ServiceException;	
	
	public List<String> loadsystolicpressureLevels(int qId) throws ServiceException;
	
	public List<String> loaddiastolicpressureLevels(int qId) throws ServiceException;
	 
}
