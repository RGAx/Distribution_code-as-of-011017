package com.asg.selfservice.services;

import org.springframework.web.servlet.ModelAndView;

import com.asg.selfservice.domain.Health;
import com.asg.selfservice.domain.UserProfile;
import com.asg.selfservice.exception.ServiceException;

/**
 * This interface has been used for defining the health operations such as loading the health page,
 * loading the questions and saving/updating the health info into the DB.
 * This has been implemented in HealthServiceImpl class.
 * 
 * @author M1030133
 *
 */
public interface HealthService extends BaseService {

	public ModelAndView loadHealthInfo(ModelAndView model, UserProfile userProfile) throws ServiceException;

	public void saveUpdateHealthInfo(UserProfile userProfile, Health health) throws ServiceException;

	public String loadTobaccoPageBasedOnUserAnswer(UserProfile userProfile) throws ServiceException;
	
	public Health constructHealthAnswer(UserProfile userProfile, int healthquestionsetId) throws ServiceException;
}
