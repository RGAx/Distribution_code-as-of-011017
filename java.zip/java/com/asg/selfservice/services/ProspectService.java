package com.asg.selfservice.services;

import java.util.List;

import com.asg.selfservice.domain.CampaignReport;
import com.asg.selfservice.domain.Prospect;
import com.asg.selfservice.exception.ServiceException;



public interface ProspectService extends BaseService {

	public Prospect getProspectData(String encryptedUId) throws ServiceException;

	public void updateCheckboxHits(Prospect prospect) throws ServiceException;

	public List<String> getListOfAgencies() throws ServiceException;

	public List<Prospect> getUserHistory(String agencyName) throws ServiceException;

	public Prospect loadProspectData(String encryptedUId) throws ServiceException;

	public List<CampaignReport> getCampaignReport() throws ServiceException;
}
