package com.asg.selfservice.services;

import org.springframework.ui.Model;
import org.springframework.web.servlet.ModelAndView;

import com.asg.selfservice.domain.CustomerCallback;
import com.asg.selfservice.exception.ServiceException;


public interface CustomerCallBackService extends BaseService {
	
	public ModelAndView loadThankYouPage(ModelAndView modelAndView) throws ServiceException;
	public ModelAndView saveCustomerCallBackDetailsInfo(CustomerCallback callBack, ModelAndView model) throws ServiceException;
	public ModelAndView loadThankYouPage2(ModelAndView modelAndView) throws ServiceException;
	public ModelAndView saveCustomerCallBackInfoSecond(CustomerCallback callBack, ModelAndView model) throws ServiceException;
	
	public String saveQuotePageCustomercallBackdetails(CustomerCallback callBack, Model model,String pageFrom) throws ServiceException;
}
