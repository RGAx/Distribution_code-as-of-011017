package com.asg.selfservice.domain;

/**
 * Defines Answer domain.
 * 
 * @author M1030133
 *
 */
public class Answer extends BaseEntity {

	private int answerId;
	private int qId;
	private String answerValue;
	private String ebixAnswer;
	private int sequence;
	private int statusFlag;

	public int getAnswerId() {
		return answerId;
	}

	public void setAnswerId(int answerId) {
		this.answerId = answerId;
	}

	public int getqId() {
		return qId;
	}

	public void setqId(int qId) {
		this.qId = qId;
	}

	public String getAnswerValue() {
		return answerValue;
	}

	public void setAnswerValue(String answerValue) {
		this.answerValue = answerValue;
	}

	public String getEbixAnswer() {
		return ebixAnswer;
	}

	public void setEbixAnswer(String ebixAnswer) {
		this.ebixAnswer = ebixAnswer;
	}

	public int getSequence() {
		return sequence;
	}

	public void setSequence(int sequence) {
		this.sequence = sequence;
	}

	public int getStatusFlag() {
		return statusFlag;
	}

	public void setStatusFlag(int statusFlag) {
		this.statusFlag = statusFlag;
	}
}
