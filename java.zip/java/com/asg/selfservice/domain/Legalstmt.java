package com.asg.selfservice.domain;

/**
 * 
 * 
 * This is Domain/Model Class. This class contains the Legal Info
 *         Info This class is POJO class
 * 
 */
public class Legalstmt {

	private String finame;
	private String fitype;
	private String ins_AgencyCode;
	private String ins_agencyname;
	private String fitypeValue;
	
	public String getFiname() {
		return finame;
	}
	public void setFiname(String finame) {
		this.finame = finame;
	}
	public String getFitype() {
		return fitype;
	}
	public void setFitype(String fitype) {
		this.fitype = fitype;
	}
	public String getIns_AgencyCode() {
		return ins_AgencyCode;
	}
	public void setIns_AgencyCode(String ins_AgencyCode) {
		this.ins_AgencyCode = ins_AgencyCode;
	}
	public String getIns_agencyname() {
		return ins_agencyname;
	}
	public void setIns_agencyname(String ins_agencyname) {
		this.ins_agencyname = ins_agencyname;
	}
	public String getFitypeValue() {
		return fitypeValue;
	}
	public void setFitypeValue(String fitypeValue) {
		this.fitypeValue = fitypeValue;
	}
	
	
}
