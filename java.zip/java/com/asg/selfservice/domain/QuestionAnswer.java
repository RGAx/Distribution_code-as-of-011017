package com.asg.selfservice.domain;

/**
 * Defines QuestionAnswer model.
 * 
 * @author M1030133
 *
 */
public class QuestionAnswer extends BaseEntity {
	private int questionAnswerId;
	private int userId;
	private int qId;
	private int qsetId;
	private int sequence;
	private String answer;
	private int ebixQuesId;
	private String ebixQuesType;
	private int ebixControlId;
	private String ebixControlValueType;
	private String defaultAnswer;

	public int getQuestionAnswerId() {
		return questionAnswerId;
	}

	public void setQuestionAnswerId(int questionAnswerId) {
		this.questionAnswerId = questionAnswerId;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public int getqId() {
		return qId;
	}

	public void setqId(int qId) {
		this.qId = qId;
	}

	public int getQsetId() {
		return qsetId;
	}

	public void setQsetId(int qsetId) {
		this.qsetId = qsetId;
	}

	public int getSequence() {
		return sequence;
	}

	public void setSequence(int sequence) {
		this.sequence = sequence;
	}

	public String getAnswer() {
		return answer;
	}

	public void setAnswer(String answer) {
		this.answer = answer;
	}

	public int getEbixQuesId() {
		return ebixQuesId;
	}

	public void setEbixQuesId(int ebixQuesId) {
		this.ebixQuesId = ebixQuesId;
	}

	public String getEbixQuesType() {
		return ebixQuesType;
	}

	public void setEbixQuesType(String ebixQuesType) {
		this.ebixQuesType = ebixQuesType;
	}

	public int getEbixControlId() {
		return ebixControlId;
	}

	public void setEbixControlId(int ebixControlId) {
		this.ebixControlId = ebixControlId;
	}

	public String getEbixControlValueType() {
		return ebixControlValueType;
	}

	public void setEbixControlValueType(String ebixControlValueType) {
		this.ebixControlValueType = ebixControlValueType;
	}

	public String getDefaultAnswer() {
		return defaultAnswer;
	}

	public void setDefaultAnswer(String defaultAnswer) {
		this.defaultAnswer = defaultAnswer;
	}
}
