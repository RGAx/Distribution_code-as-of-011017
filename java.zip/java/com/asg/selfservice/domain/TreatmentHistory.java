/**
 * 
 */
package com.asg.selfservice.domain;

/**
 * @author M1027376
 *
 */
public class TreatmentHistory {

	private String treatmentHistorySeq1;
	private String treatmentHistorySeq2;
	private String treatmentHistorySeq3;
	private String treatmentHistorySeq4;
	
	public String getTreatmentHistorySeq1() {
		return treatmentHistorySeq1;
	}
	public void setTreatmentHistorySeq1(String treatmentHistorySeq1) {
		this.treatmentHistorySeq1 = treatmentHistorySeq1;
	}
	public String getTreatmentHistorySeq2() {
		return treatmentHistorySeq2;
	}
	public void setTreatmentHistorySeq2(String treatmentHistorySeq2) {
		this.treatmentHistorySeq2 = treatmentHistorySeq2;
	}
	public String getTreatmentHistorySeq3() {
		return treatmentHistorySeq3;
	}
	public void setTreatmentHistorySeq3(String treatmentHistorySeq3) {
		this.treatmentHistorySeq3 = treatmentHistorySeq3;
	}
	public String getTreatmentHistorySeq4() {
		return treatmentHistorySeq4;
	}
	public void setTreatmentHistorySeq4(String treatmentHistorySeq4) {
		this.treatmentHistorySeq4 = treatmentHistorySeq4;
	}
	
	@Override
	public String toString() {
		return "TratmentHistory [treatmentHistorySeq1=" + treatmentHistorySeq1
				+ ", treatmentHistorySeq2=" + treatmentHistorySeq2
				+ ", treatmentHistorySeq3=" + treatmentHistorySeq3
				+ ", treatmentHistorySeq4=" + treatmentHistorySeq4 + "]";
	}
	
	
}
