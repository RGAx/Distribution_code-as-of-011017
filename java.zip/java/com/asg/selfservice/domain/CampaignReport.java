/**
 * 
 */
package com.asg.selfservice.domain;

/**
 * @author M1027376
 *
 */
public class CampaignReport {

	private int slNo;
	private String campaigndate;
	private String campaignId;
	private String agencyName;
	private String campaignSize;
	private String applynowCount;
	private String diffcoverageCount;
	private String midwayCount;
	private String createdprofCount;
	private String submittedCount;
	
	/**
	 * @return the slNo
	 */
	public int getSlNo() {
		return slNo;
	}
	/**
	 * @param slNo the slNo to set
	 */
	public void setSlNo(int slNo) {
		this.slNo = slNo;
	}
	/**
	 * @return the campaigndate
	 */
	public String getCampaigndate() {
		return campaigndate;
	}
	/**
	 * @param campaigndate the campaigndate to set
	 */
	public void setCampaigndate(String campaigndate) {
		this.campaigndate = campaigndate;
	}
	/**
	 * @return the campaignId
	 */
	public String getCampaignId() {
		return campaignId;
	}
	/**
	 * @param campaignId the campaignId to set
	 */
	public void setCampaignId(String campaignId) {
		this.campaignId = campaignId;
	}
	/**
	 * @return the agencyName
	 */
	public String getAgencyName() {
		return agencyName;
	}
	/**
	 * @param agencyName the agencyName to set
	 */
	public void setAgencyName(String agencyName) {
		this.agencyName = agencyName;
	}
	/**
	 * @return the campaignSize
	 */
	public String getCampaignSize() {
		return campaignSize;
	}
	/**
	 * @param campaignSize the campaignSize to set
	 */
	public void setCampaignSize(String campaignSize) {
		this.campaignSize = campaignSize;
	}
	/**
	 * @return the applynowCount
	 */
	public String getApplynowCount() {
		return applynowCount;
	}
	/**
	 * @param applynowCount the applynowCount to set
	 */
	public void setApplynowCount(String applynowCount) {
		this.applynowCount = applynowCount;
	}
	/**
	 * @return the diffcoverageCount
	 */
	public String getDiffcoverageCount() {
		return diffcoverageCount;
	}
	/**
	 * @param diffcoverageCount the diffcoverageCount to set
	 */
	public void setDiffcoverageCount(String diffcoverageCount) {
		this.diffcoverageCount = diffcoverageCount;
	}
	/**
	 * @return the midwayCount
	 */
	public String getMidwayCount() {
		return midwayCount;
	}
	/**
	 * @param midwayCount the midwayCount to set
	 */
	public void setMidwayCount(String midwayCount) {
		this.midwayCount = midwayCount;
	}
	/**
	 * @return the createdprofCount
	 */
	public String getCreatedprofCount() {
		return createdprofCount;
	}
	/**
	 * @param createdprofCount the createdprofCount to set
	 */
	public void setCreatedprofCount(String createdprofCount) {
		this.createdprofCount = createdprofCount;
	}
	/**
	 * @return the submittedCount
	 */
	public String getSubmittedCount() {
		return submittedCount;
	}
	/**
	 * @param submittedCount the submittedCount to set
	 */
	public void setSubmittedCount(String submittedCount) {
		this.submittedCount = submittedCount;
	}
	
}
