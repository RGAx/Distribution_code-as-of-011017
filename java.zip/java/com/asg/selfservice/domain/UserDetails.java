package com.asg.selfservice.domain;

public class UserDetails {

	private int id;
	private String userId;
	private String emailAddress;
	private String campaignDate;
	private String agencyName;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getEmailAddress() {
		return emailAddress;
	}

	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	public String getAgencyName() {
		return agencyName;
	}

	public void setAgencyName(String agencyName) {
		this.agencyName = agencyName;
	}

	public String getCampaignDate() {
		return campaignDate;
	}

	public void setCampaignDate(String campaignDate) {
		this.campaignDate = campaignDate;
	}

}
