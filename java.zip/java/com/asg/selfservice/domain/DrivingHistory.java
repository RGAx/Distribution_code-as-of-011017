/**
 * 
 */
package com.asg.selfservice.domain;

import org.springframework.stereotype.Component;

/**
 * Defines DrivingHistory Model class Attribute containing Cholestrol,BloodPressure Details
 * @author M1029563
 *
 */
@Component
public class DrivingHistory {
	
	private String drivingSeq1;
	private String drivingSeq2;
	private String drivingSeq3;
	private String drivingSeq4;
	private String drivingSeq5;
	private String drivingSeq6;
	private String drivingSeq7;
	private String drivingSeq8;
	private String drivingSeq9;
	private String drivingSeq10;
	private String drivingSeq11;
	private String drivingSeq12;
	private String drivingSeq13;
	private String drivingSeq14;
	private String drivingSeq15;
	
	public String getDrivingSeq1() {
		return drivingSeq1;
	}
	public void setDrivingSeq1(String drivingSeq1) {
		this.drivingSeq1 = drivingSeq1;
	}
	public String getDrivingSeq2() {
		return drivingSeq2;
	}
	public void setDrivingSeq2(String drivingSeq2) {
		this.drivingSeq2 = drivingSeq2;
	}
	public String getDrivingSeq3() {
		return drivingSeq3;
	}
	public void setDrivingSeq3(String drivingSeq3) {
		this.drivingSeq3 = drivingSeq3;
	}
	public String getDrivingSeq4() {
		return drivingSeq4;
	}
	public void setDrivingSeq4(String drivingSeq4) {
		this.drivingSeq4 = drivingSeq4;
	}
	public String getDrivingSeq5() {
		return drivingSeq5;
	}
	public void setDrivingSeq5(String drivingSeq5) {
		this.drivingSeq5 = drivingSeq5;
	}
	public String getDrivingSeq6() {
		return drivingSeq6;
	}
	public void setDrivingSeq6(String drivingSeq6) {
		this.drivingSeq6 = drivingSeq6;
	}
	public String getDrivingSeq7() {
		return drivingSeq7;
	}
	public void setDrivingSeq7(String drivingSeq7) {
		this.drivingSeq7 = drivingSeq7;
	}
	public String getDrivingSeq8() {
		return drivingSeq8;
	}
	public void setDrivingSeq8(String drivingSeq8) {
		this.drivingSeq8 = drivingSeq8;
	}
	public String getDrivingSeq9() {
		return drivingSeq9;
	}
	public void setDrivingSeq9(String drivingSeq9) {
		this.drivingSeq9 = drivingSeq9;
	}
	public String getDrivingSeq10() {
		return drivingSeq10;
	}
	public void setDrivingSeq10(String drivingSeq10) {
		this.drivingSeq10 = drivingSeq10;
	}
	public String getDrivingSeq11() {
		return drivingSeq11;
	}
	public void setDrivingSeq11(String drivingSeq11) {
		this.drivingSeq11 = drivingSeq11;
	}
	public String getDrivingSeq12() {
		return drivingSeq12;
	}
	public void setDrivingSeq12(String drivingSeq12) {
		this.drivingSeq12 = drivingSeq12;
	}
	public String getDrivingSeq13() {
		return drivingSeq13;
	}
	public void setDrivingSeq13(String drivingSeq13) {
		this.drivingSeq13 = drivingSeq13;
	}
	public String getDrivingSeq14() {
		return drivingSeq14;
	}
	public void setDrivingSeq14(String drivingSeq14) {
		this.drivingSeq14 = drivingSeq14;
	}
	public String getDrivingSeq15() {
		return drivingSeq15;
	}
	public void setDrivingSeq15(String drivingSeq15) {
		this.drivingSeq15 = drivingSeq15;
	}
	
	@Override
	public String toString() {
		return "DrivingHistory [drivingSeq1=" + drivingSeq1 + ", drivingSeq2="
				+ drivingSeq2 + ", drivingSeq3=" + drivingSeq3
				+ ", drivingSeq4=" + drivingSeq4 + ", drivingSeq5="
				+ drivingSeq5 + ", drivingSeq6=" + drivingSeq6
				+ ", drivingSeq7=" + drivingSeq7 + ", drivingSeq8="
				+ drivingSeq8 + ", drivingSeq9=" + drivingSeq9
				+ ", drivingSeq10=" + drivingSeq10 + ", drivingSeq11="
				+ drivingSeq11 + ", drivingSeq12=" + drivingSeq12
				+ ", drivingSeq13=" + drivingSeq13 + ", drivingSeq14="
				+ drivingSeq14 + ", drivingSeq15=" + drivingSeq15 + "]";
	}

}
