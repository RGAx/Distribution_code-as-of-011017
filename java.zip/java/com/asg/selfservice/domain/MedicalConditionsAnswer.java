package com.asg.selfservice.domain;

import java.util.Map;

/**
 * Defines MedicalConditionsAnswer Model Class Attribute that Handles Application Begin2 Page details
 * @author M1029563
 *
 */
public class MedicalConditionsAnswer {
	
	private String conditionsQuestAns1;
	private String conditionsQuestAns2;
	private String conditionsQuestAns3;
	private String conditionsQuestAns4;
	private String conditionsQuestAns5;
	private String conditionsQuestAns6;
	private String conditionsQuestAns7;
	private String conditionsQuestAns8;
	private String conditionsQuestAns9;
	private String conditionsQuestAns10;
	private String conditionsQuestAns11;
	private String conditionsQuestAns12;
	private String conditionsQuestAns13;
	private String conditionsQuestAns14;
	private String conditionsQuestAns15;
	private String conditionsQuestAns16;
	private String conditionsQuestAns17;
	private String conditionsQuestAns18;
	private String conditionsQuestAns19;
	private String conditionsQuestAns20;
	private String conditionsQuestAns28;
	private String conditionsQuestAns29;
	private String conditionsQuestAns30;
	private String conditionsQuestAns31;
	private String conditionsQuestAns32;
	private String conditionsQuestAns33;
	private String conditionsQuestAns34;
	private String conditionsQuestAns35;
   private String conditionsQuestAns36;
	private String conditionsQuestAns37;
	private String conditionsQuestAns38;
	private String conditionsQuestAns39;
	private String conditionsQuestAns40;
	private String conditionsQuestAns41;
	private String conditionsQuestAns42;
	private String conditionsQuestAns43;
	private String conditionsQuestAns44;
	private String conditionsQuestAns45;
		
	private Map<String,String> medicalSubList;
	
	
	public String getConditionsQuestAns1() {
		return conditionsQuestAns1;
	}
	public void setConditionsQuestAns1(String conditionsQuestAns1) {
		this.conditionsQuestAns1 = conditionsQuestAns1;
	}
	public String getConditionsQuestAns2() {
		return conditionsQuestAns2;
	}
	public void setConditionsQuestAns2(String conditionsQuestAns2) {
		this.conditionsQuestAns2 = conditionsQuestAns2;
	}
	public String getConditionsQuestAns3() {
		return conditionsQuestAns3;
	}
	public void setConditionsQuestAns3(String conditionsQuestAns3) {
		this.conditionsQuestAns3 = conditionsQuestAns3;
	}
	public String getConditionsQuestAns4() {
		return conditionsQuestAns4;
	}
	public void setConditionsQuestAns4(String conditionsQuestAns4) {
		this.conditionsQuestAns4 = conditionsQuestAns4;
	}
	public String getConditionsQuestAns5() {
		return conditionsQuestAns5;
	}
	public void setConditionsQuestAns5(String conditionsQuestAns5) {
		this.conditionsQuestAns5 = conditionsQuestAns5;
	}
	public String getConditionsQuestAns6() {
		return conditionsQuestAns6;
	}
	public void setConditionsQuestAns6(String conditionsQuestAns6) {
		this.conditionsQuestAns6 = conditionsQuestAns6;
	}
	public String getConditionsQuestAns7() {
		return conditionsQuestAns7;
	}
	public void setConditionsQuestAns7(String conditionsQuestAns7) {
		this.conditionsQuestAns7 = conditionsQuestAns7;
	}
	public String getConditionsQuestAns8() {
		return conditionsQuestAns8;
	}
	public void setConditionsQuestAns8(String conditionsQuestAns8) {
		this.conditionsQuestAns8 = conditionsQuestAns8;
	}
	public String getConditionsQuestAns9() {
		return conditionsQuestAns9;
	}
	public void setConditionsQuestAns9(String conditionsQuestAns9) {
		this.conditionsQuestAns9 = conditionsQuestAns9;
	}
	public String getConditionsQuestAns10() {
		return conditionsQuestAns10;
	}
	public void setConditionsQuestAns10(String conditionsQuestAns10) {
		this.conditionsQuestAns10 = conditionsQuestAns10;
	}
	public String getConditionsQuestAns11() {
		return conditionsQuestAns11;
	}
	public void setConditionsQuestAns11(String conditionsQuestAns11) {
		this.conditionsQuestAns11 = conditionsQuestAns11;
	}
	public String getConditionsQuestAns12() {
		return conditionsQuestAns12;
	}
	public void setConditionsQuestAns12(String conditionsQuestAns12) {
		this.conditionsQuestAns12 = conditionsQuestAns12;
	}
	public String getConditionsQuestAns13() {
		return conditionsQuestAns13;
	}
	public void setConditionsQuestAns13(String conditionsQuestAns13) {
		this.conditionsQuestAns13 = conditionsQuestAns13;
	}
	public String getConditionsQuestAns14() {
		return conditionsQuestAns14;
	}
	public void setConditionsQuestAns14(String conditionsQuestAns14) {
		this.conditionsQuestAns14 = conditionsQuestAns14;
	}
	public String getConditionsQuestAns15() {
		return conditionsQuestAns15;
	}
	public void setConditionsQuestAns15(String conditionsQuestAns15) {
		this.conditionsQuestAns15 = conditionsQuestAns15;
	}
	public String getConditionsQuestAns16() {
		return conditionsQuestAns16;
	}
	public void setConditionsQuestAns16(String conditionsQuestAns16) {
		this.conditionsQuestAns16 = conditionsQuestAns16;
	}
	public String getConditionsQuestAns17() {
		return conditionsQuestAns17;
	}
	public void setConditionsQuestAns17(String conditionsQuestAns17) {
		this.conditionsQuestAns17 = conditionsQuestAns17;
	}
	public String getConditionsQuestAns18() {
		return conditionsQuestAns18;
	}
	public void setConditionsQuestAns18(String conditionsQuestAns18) {
		this.conditionsQuestAns18 = conditionsQuestAns18;
	}
	public String getConditionsQuestAns19() {
		return conditionsQuestAns19;
	}
	public void setConditionsQuestAns19(String conditionsQuestAns19) {
		this.conditionsQuestAns19 = conditionsQuestAns19;
	}
	public String getConditionsQuestAns20() {
		return conditionsQuestAns20;
	}
	public void setConditionsQuestAns20(String conditionsQuestAns20) {
		this.conditionsQuestAns20 = conditionsQuestAns20;
	}
	public String getConditionsQuestAns28() {
		return conditionsQuestAns28;
	}
	public void setConditionsQuestAns28(String conditionsQuestAns28) {
		this.conditionsQuestAns28 = conditionsQuestAns28;
	}
	public String getConditionsQuestAns29() {
		return conditionsQuestAns29;
	}
	public void setConditionsQuestAns29(String conditionsQuestAns29) {
		this.conditionsQuestAns29 = conditionsQuestAns29;
	}
	public String getConditionsQuestAns30() {
		return conditionsQuestAns30;
	}
	public void setConditionsQuestAns30(String conditionsQuestAns30) {
		this.conditionsQuestAns30 = conditionsQuestAns30;
	}
	public String getConditionsQuestAns31() {
		return conditionsQuestAns31;
	}
	public void setConditionsQuestAns31(String conditionsQuestAns31) {
		this.conditionsQuestAns31 = conditionsQuestAns31;
	}
	public String getConditionsQuestAns32() {
		return conditionsQuestAns32;
	}
	public void setConditionsQuestAns32(String conditionsQuestAns32) {
		this.conditionsQuestAns32 = conditionsQuestAns32;
	}
	public String getConditionsQuestAns33() {
		return conditionsQuestAns33;
	}
	public void setConditionsQuestAns33(String conditionsQuestAns33) {
		this.conditionsQuestAns33 = conditionsQuestAns33;
	}
	public String getConditionsQuestAns34() {
		return conditionsQuestAns34;
	}
	public void setConditionsQuestAns34(String conditionsQuestAns34) {
		this.conditionsQuestAns34 = conditionsQuestAns34;
	}
	public String getConditionsQuestAns35() {
		return conditionsQuestAns35;
	}
	public void setConditionsQuestAns35(String conditionsQuestAns35) {
		this.conditionsQuestAns35 = conditionsQuestAns35;
	}
	public String getConditionsQuestAns36() {
		return conditionsQuestAns36;
	}
	public void setConditionsQuestAns36(String conditionsQuestAns36) {
		this.conditionsQuestAns36 = conditionsQuestAns36;
	}
	public String getConditionsQuestAns37() {
		return conditionsQuestAns37;
	}
	public void setConditionsQuestAns37(String conditionsQuestAns37) {
		this.conditionsQuestAns37 = conditionsQuestAns37;
	}
	public String getConditionsQuestAns38() {
		return conditionsQuestAns38;
	}
	public void setConditionsQuestAns38(String conditionsQuestAns38) {
		this.conditionsQuestAns38 = conditionsQuestAns38;
	}
	public String getConditionsQuestAns39() {
		return conditionsQuestAns39;
	}
	public void setConditionsQuestAns39(String conditionsQuestAns39) {
		this.conditionsQuestAns39 = conditionsQuestAns39;
	}
	public String getConditionsQuestAns40() {
		return conditionsQuestAns40;
	}
	public void setConditionsQuestAns40(String conditionsQuestAns40) {
		this.conditionsQuestAns40 = conditionsQuestAns40;
	}
	public String getConditionsQuestAns41() {
		return conditionsQuestAns41;
	}
	public void setConditionsQuestAns41(String conditionsQuestAns41) {
		this.conditionsQuestAns41 = conditionsQuestAns41;
	}
	public String getConditionsQuestAns42() {
		return conditionsQuestAns42;
	}
	public void setConditionsQuestAns42(String conditionsQuestAns42) {
		this.conditionsQuestAns42 = conditionsQuestAns42;
	}
	public String getConditionsQuestAns43() {
		return conditionsQuestAns43;
	}
	public void setConditionsQuestAns43(String conditionsQuestAns43) {
		this.conditionsQuestAns43 = conditionsQuestAns43;
	}
	public String getConditionsQuestAns44() {
		return conditionsQuestAns44;
	}
	public void setConditionsQuestAns44(String conditionsQuestAns44) {
		this.conditionsQuestAns44 = conditionsQuestAns44;
	}
	public String getConditionsQuestAns45() {
		return conditionsQuestAns45;
	}
	public void setConditionsQuestAns45(String conditionsQuestAns45) {
		this.conditionsQuestAns45 = conditionsQuestAns45;
	}
	public Map<String, String> getMedicalSubList() {
		return medicalSubList;
	}
	public void setMedicalSubList(Map<String, String> medicalSubList) {
		this.medicalSubList = medicalSubList;
	}
	@Override
	public String toString() {
		return "MedicalConditionsAnswer [conditionsQuestAns1="
				+ conditionsQuestAns1 + ", conditionsQuestAns2="
				+ conditionsQuestAns2 + ", conditionsQuestAns3="
				+ conditionsQuestAns3 + ", conditionsQuestAns4="
				+ conditionsQuestAns4 + ", conditionsQuestAns5="
				+ conditionsQuestAns5 + ", conditionsQuestAns6="
				+ conditionsQuestAns6 + ", conditionsQuestAns7="
				+ conditionsQuestAns7 + ", conditionsQuestAns8="
				+ conditionsQuestAns8 + ", conditionsQuestAns9="
				+ conditionsQuestAns9 + ", conditionsQuestAns10="
				+ conditionsQuestAns10 + ", conditionsQuestAns11="
				+ conditionsQuestAns11 + ", conditionsQuestAns12="
				+ conditionsQuestAns12 + ", conditionsQuestAns13="
				+ conditionsQuestAns13 + ", conditionsQuestAns14="
				+ conditionsQuestAns14 + ", conditionsQuestAns15="
				+ conditionsQuestAns15 + ", conditionsQuestAns16="
				+ conditionsQuestAns16 + ", conditionsQuestAns17="
				+ conditionsQuestAns17 + ", conditionsQuestAns18="
				+ conditionsQuestAns18 + ", conditionsQuestAns19="
				+ conditionsQuestAns19 + ", conditionsQuestAns20="
				+ conditionsQuestAns20 + ", conditionsQuestAns28="
				+ conditionsQuestAns28 + ", conditionsQuestAns29="
				+ conditionsQuestAns29 + ", conditionsQuestAns30="
				+ conditionsQuestAns30 + ", conditionsQuestAns31="
				+ conditionsQuestAns31 + ", conditionsQuestAns32="
				+ conditionsQuestAns32 + ", conditionsQuestAns33="
				+ conditionsQuestAns33 + ", conditionsQuestAns34="
				+ conditionsQuestAns34 + ", conditionsQuestAns35="
				+ conditionsQuestAns35 + ", conditionsQuestAns36="
				+ conditionsQuestAns36 + ", conditionsQuestAns37="
				+ conditionsQuestAns37 + ", conditionsQuestAns38="
				+ conditionsQuestAns38 + ", conditionsQuestAns39="
				+ conditionsQuestAns39 + ", conditionsQuestAns40="
				+ conditionsQuestAns40 + ", conditionsQuestAns41="
				+ conditionsQuestAns41 + ", conditionsQuestAns42="
				+ conditionsQuestAns42 + ", conditionsQuestAns43="
				+ conditionsQuestAns43 + ", conditionsQuestAns44="
				+ conditionsQuestAns44 + ", conditionsQuestAns45="
				+ conditionsQuestAns45 + ", medicalSubList=" + medicalSubList
				+ "]";
	}
	
}
