package com.asg.selfservice.domain;

/**
 * Defines the tobacco part-2 model.
 * 
 * @author M1030133
 *
 */
public class Smoking {
	private String smokingSeq1;
	private String smokingSeq2;
	private String smokingSeq3;
	private String smokingSeq4;
	private String smokingSeq5;
	private String smokingSeq6;
	private String smokingSeq7;
	//private String smokingSeq8;
	private String smokingSeq9;
	private String smokingSeq10;
	private String smokingSeq11;
	private String smokingSeq12;
	private String smokingSeq13;
	private String smokingSeq14;
	private String smokingSeq15;
	private String smokingSeq16;
	private String smokingSeq17;
	private String smokingSeq18;
	private String smokingSeq19;
	private String smokingSeq20;

	public String getSmokingSeq1() {
		return smokingSeq1;
	}

	public void setSmokingSeq1(String smokingSeq1) {
		this.smokingSeq1 = smokingSeq1;
	}

	public String getSmokingSeq2() {
		return smokingSeq2;
	}

	public void setSmokingSeq2(String smokingSeq2) {
		this.smokingSeq2 = smokingSeq2;
	}

	public String getSmokingSeq3() {
		return smokingSeq3;
	}

	public void setSmokingSeq3(String smokingSeq3) {
		this.smokingSeq3 = smokingSeq3;
	}

	public String getSmokingSeq4() {
		return smokingSeq4;
	}

	public void setSmokingSeq4(String smokingSeq4) {
		this.smokingSeq4 = smokingSeq4;
	}

	public String getSmokingSeq5() {
		return smokingSeq5;
	}

	public void setSmokingSeq5(String smokingSeq5) {
		this.smokingSeq5 = smokingSeq5;
	}

	public String getSmokingSeq6() {
		return smokingSeq6;
	}

	public void setSmokingSeq6(String smokingSeq6) {
		this.smokingSeq6 = smokingSeq6;
	}

	public String getSmokingSeq7() {
		return smokingSeq7;
	}

	public void setSmokingSeq7(String smokingSeq7) {
		this.smokingSeq7 = smokingSeq7;
	}

	/*public String getSmokingSeq8() {
		return smokingSeq8;
	}

	public void setSmokingSeq8(String smokingSeq8) {
		this.smokingSeq8 = smokingSeq8;
	}*/

	public String getSmokingSeq9() {
		return smokingSeq9;
	}

	public void setSmokingSeq9(String smokingSeq9) {
		this.smokingSeq9 = smokingSeq9;
	}

	public String getSmokingSeq10() {
		return smokingSeq10;
	}

	public void setSmokingSeq10(String smokingSeq10) {
		this.smokingSeq10 = smokingSeq10;
	}

	public String getSmokingSeq11() {
		return smokingSeq11;
	}

	public void setSmokingSeq11(String smokingSeq11) {
		this.smokingSeq11 = smokingSeq11;
	}

	public String getSmokingSeq12() {
		return smokingSeq12;
	}

	public void setSmokingSeq12(String smokingSeq12) {
		this.smokingSeq12 = smokingSeq12;
	}

	public String getSmokingSeq13() {
		return smokingSeq13;
	}

	public void setSmokingSeq13(String smokingSeq13) {
		this.smokingSeq13 = smokingSeq13;
	}

	public String getSmokingSeq14() {
		return smokingSeq14;
	}

	public void setSmokingSeq14(String smokingSeq14) {
		this.smokingSeq14 = smokingSeq14;
	}

	public String getSmokingSeq15() {
		return smokingSeq15;
	}

	public void setSmokingSeq15(String smokingSeq15) {
		this.smokingSeq15 = smokingSeq15;
	}

	public String getSmokingSeq16() {
		return smokingSeq16;
	}

	public void setSmokingSeq16(String smokingSeq16) {
		this.smokingSeq16 = smokingSeq16;
	}

	public String getSmokingSeq17() {
		return smokingSeq17;
	}

	public void setSmokingSeq17(String smokingSeq17) {
		this.smokingSeq17 = smokingSeq17;
	}

	public String getSmokingSeq18() {
		return smokingSeq18;
	}

	public void setSmokingSeq18(String smokingSeq18) {
		this.smokingSeq18 = smokingSeq18;
	}

	public String getSmokingSeq19() {
		return smokingSeq19;
	}

	public void setSmokingSeq19(String smokingSeq19) {
		this.smokingSeq19 = smokingSeq19;
	}

	public String getSmokingSeq20() {
		return smokingSeq20;
	}

	public void setSmokingSeq20(String smokingSeq20) {
		this.smokingSeq20 = smokingSeq20;
	}

}
