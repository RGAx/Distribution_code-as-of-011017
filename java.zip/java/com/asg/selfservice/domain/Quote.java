package com.asg.selfservice.domain;

import java.util.Date;

/**
 * Defines the Quote model.
 * 
 * @author M1030133
 *
 */
public class Quote {
	private int quoteId;
	private int userId;
	private String productName;
	private String policyName;
	private String healthCategory;
	private String annualPremium;
	private String monthlyPremium;
	private String ambestRating;
	private String companyName;
	private String companyLogo;
	private Date createdDate;
	private String createdBy;
	private Date updatedDate;
	private String updatedBy;
	
	private boolean validQuote;

	public int getQuoteId() {
		return quoteId;
	}

	public void setQuoteId(int quoteId) {
		this.quoteId = quoteId;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getPolicyName() {
		return policyName;
	}

	public void setPolicyName(String policyName) {
		this.policyName = policyName;
	}

	public String getHealthCategory() {
		return healthCategory;
	}

	public void setHealthCategory(String healthCategory) {
		this.healthCategory = healthCategory;
	}

	public String getAnnualPremium() {
		return annualPremium;
	}

	public void setAnnualPremium(String annualPremium) {
		this.annualPremium = annualPremium;
	}

	public String getMonthlyPremium() {
		return monthlyPremium;
	}

	public void setMonthlyPremium(String monthlyPremium) {
		this.monthlyPremium = monthlyPremium;
	}

	public String getAmbestRating() {
		return ambestRating;
	}

	public void setAmbestRating(String ambestRating) {
		this.ambestRating = ambestRating;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public String getCompanyLogo() {
		return companyLogo;
	}

	public void setCompanyLogo(String companyLogo) {
		this.companyLogo = companyLogo;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getUpdatedDate() {
		return updatedDate;
	}

	public void setUpdatedDate(Date updatedDate) {
		this.updatedDate = updatedDate;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public boolean isValidQuote() {
		return validQuote;
	}

	public void setValidQuote(boolean validQuote) {
		this.validQuote = validQuote;
	}

	@Override
	public String toString() {
		return "Quote [quoteId=" + quoteId + ", userId=" + userId
				+ ", productName=" + productName + ", policyName=" + policyName
				+ ", healthCategory=" + healthCategory + ", annualPremium="
				+ annualPremium + ", monthlyPremium=" + monthlyPremium
				+ ", ambestRating=" + ambestRating + ", companyName="
				+ companyName + ", companyLogo=" + companyLogo
				+ ", createdDate=" + createdDate + ", createdBy=" + createdBy
				+ ", updatedDate=" + updatedDate + ", updatedBy=" + updatedBy
				+ "]";
	}
}
