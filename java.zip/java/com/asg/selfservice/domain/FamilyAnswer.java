/**
 * 
 */
package com.asg.selfservice.domain;

import org.springframework.stereotype.Component;

/**
 * Defines FamilyAnswer Model Class that Handles Family related Details in Family Page
 * @author M1029563
 *
 */
@Component
public class FamilyAnswer {

	private String familySeq1;
	private String familySeq2;
	private String familySeq3;
	private String familySeq4;
	private String familySeq5;
	private String familySeq6;
	private String familySeq7;
	private String familySeq8;
	private String familySeq9;
	private String familySeq10;
	private String familySeq11;
	private String familySeq12;
	private String familySeq13;
	private String familySeq14;
	private String familySeq15;
	private String familySeq16;
	
	public String getFamilySeq1() {
		return familySeq1;
	}
	public void setFamilySeq1(String familySeq1) {
		this.familySeq1 = familySeq1;
	}
	public String getFamilySeq2() {
		return familySeq2;
	}
	public void setFamilySeq2(String familySeq2) {
		this.familySeq2 = familySeq2;
	}
	public String getFamilySeq3() {
		return familySeq3;
	}
	public void setFamilySeq3(String familySeq3) {
		this.familySeq3 = familySeq3;
	}
	public String getFamilySeq4() {
		return familySeq4;
	}
	public void setFamilySeq4(String familySeq4) {
		this.familySeq4 = familySeq4;
	}
	public String getFamilySeq5() {
		return familySeq5;
	}
	public void setFamilySeq5(String familySeq5) {
		this.familySeq5 = familySeq5;
	}
	public String getFamilySeq6() {
		return familySeq6;
	}
	public void setFamilySeq6(String familySeq6) {
		this.familySeq6 = familySeq6;
	}
	public String getFamilySeq7() {
		return familySeq7;
	}
	public void setFamilySeq7(String familySeq7) {
		this.familySeq7 = familySeq7;
	}
	public String getFamilySeq8() {
		return familySeq8;
	}
	public void setFamilySeq8(String familySeq8) {
		this.familySeq8 = familySeq8;
	}
	public String getFamilySeq9() {
		return familySeq9;
	}
	public void setFamilySeq9(String familySeq9) {
		this.familySeq9 = familySeq9;
	}
	public String getFamilySeq10() {
		return familySeq10;
	}
	public void setFamilySeq10(String familySeq10) {
		this.familySeq10 = familySeq10;
	}
	public String getFamilySeq11() {
		return familySeq11;
	}
	public void setFamilySeq11(String familySeq11) {
		this.familySeq11 = familySeq11;
	}
	public String getFamilySeq12() {
		return familySeq12;
	}
	public void setFamilySeq12(String familySeq12) {
		this.familySeq12 = familySeq12;
	}
	public String getFamilySeq13() {
		return familySeq13;
	}
	public void setFamilySeq13(String familySeq13) {
		this.familySeq13 = familySeq13;
	}
	public String getFamilySeq14() {
		return familySeq14;
	}
	public void setFamilySeq14(String familySeq14) {
		this.familySeq14 = familySeq14;
	}
	public String getFamilySeq15() {
		return familySeq15;
	}
	public void setFamilySeq15(String familySeq15) {
		this.familySeq15 = familySeq15;
	}
	public String getFamilySeq16() {
		return familySeq16;
	}
	public void setFamilySeq16(String familySeq16) {
		this.familySeq16 = familySeq16;
	}
	
	@Override
	public String toString() {
		return "FamilyAnswer [familySeq1=" + familySeq1 + ", familySeq2="
				+ familySeq2 + ", familySeq3=" + familySeq3 + ", familySeq4="
				+ familySeq4 + ", familySeq5=" + familySeq5 + ", familySeq6="
				+ familySeq6 + ", familySeq7=" + familySeq7 + ", familySeq8="
				+ familySeq8 + ", familySeq9=" + familySeq9 + ", familySeq10="
				+ familySeq10 + ", familySeq11=" + familySeq11
				+ ", familySeq12=" + familySeq12 + ", familySeq13="
				+ familySeq13 + ", familySeq14=" + familySeq14
				+ ", familySeq15=" + familySeq15 + ", familySeq16="
				+ familySeq16 + "]";
	}
}
