package com.asg.selfservice.domain;

import org.springframework.stereotype.Component;

/**
 * Defines MedicalHistoryProfile Model class Attribute containing Cholestrol,BloodPressure Details
 * @author M1029563
 *
 */
@Component
public class MedicalHistoryAnswer {

		private String cholestrolSeq1;
		private String cholestrolSeq2;
		private String cholestrolSeq3;
		private String cholestrolSeq4;
		private String cholestrolSeq5;
		private String bloodpressureSeq6;
		private String bloodpressureSeq7;
		private String bloodpressureSeq8;
		private String bloodpressureSeq9;
		private String bloodpressureSeq10;
		
		public String getCholestrolSeq1() {
			return cholestrolSeq1;
		}
		public void setCholestrolSeq1(String cholestrolSeq1) {
			this.cholestrolSeq1 = cholestrolSeq1;
		}
		public String getCholestrolSeq2() {
			return cholestrolSeq2;
		}
		public void setCholestrolSeq2(String cholestrolSeq2) {
			this.cholestrolSeq2 = cholestrolSeq2;
		}
		public String getCholestrolSeq3() {
			return cholestrolSeq3;
		}
		public void setCholestrolSeq3(String cholestrolSeq3) {
			this.cholestrolSeq3 = cholestrolSeq3;
		}
		public String getCholestrolSeq4() {
			return cholestrolSeq4;
		}
		public void setCholestrolSeq4(String cholestrolSeq4) {
			this.cholestrolSeq4 = cholestrolSeq4;
		}
		public String getCholestrolSeq5() {
			return cholestrolSeq5;
		}
		public void setCholestrolSeq5(String cholestrolSeq5) {
			this.cholestrolSeq5 = cholestrolSeq5;
		}
		public String getBloodpressureSeq6() {
			return bloodpressureSeq6;
		}
		public void setBloodpressureSeq6(String bloodpressureSeq6) {
			this.bloodpressureSeq6 = bloodpressureSeq6;
		}
		public String getBloodpressureSeq7() {
			return bloodpressureSeq7;
		}
		public void setBloodpressureSeq7(String bloodpressureSeq7) {
			this.bloodpressureSeq7 = bloodpressureSeq7;
		}
		public String getBloodpressureSeq8() {
			return bloodpressureSeq8;
		}
		public void setBloodpressureSeq8(String bloodpressureSeq8) {
			this.bloodpressureSeq8 = bloodpressureSeq8;
		}
		public String getBloodpressureSeq9() {
			return bloodpressureSeq9;
		}
		public void setBloodpressureSeq9(String bloodpressureSeq9) {
			this.bloodpressureSeq9 = bloodpressureSeq9;
		}
		public String getBloodpressureSeq10() {
			return bloodpressureSeq10;
		}
		public void setBloodpressureSeq10(String bloodpressureSeq10) {
			this.bloodpressureSeq10 = bloodpressureSeq10;
		}
		@Override
		public String toString() {
			return "MedicalHistoryAnswer [cholestrolSeq1=" + cholestrolSeq1
					+ ", cholestrolSeq2=" + cholestrolSeq2
					+ ", cholestrolSeq3=" + cholestrolSeq3
					+ ", cholestrolSeq4=" + cholestrolSeq4
					+ ", cholestrolSeq5=" + cholestrolSeq5
					+ ", bloodpressureSeq6=" + bloodpressureSeq6
					+ ", bloodpressureSeq7=" + bloodpressureSeq7
					+ ", bloodpressureSeq8=" + bloodpressureSeq8
					+ ", bloodpressureSeq9=" + bloodpressureSeq9
					+ ", bloodpressureSeq10=" + bloodpressureSeq10 + "]";
		}
				
		
}
