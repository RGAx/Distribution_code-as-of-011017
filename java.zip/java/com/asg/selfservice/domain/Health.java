package com.asg.selfservice.domain;

/**
 * Defines the tobacco part-1 model.
 * 
 * @author M1030133
 *
 */
public class Health {
	private String healthSeq1;
	private String healthSeq2;
	private String healthSeq3;
	private String healthSeq4;
	private String healthSeq5;
	private String healthSeq6;

	private String healthSeq11;
	private String healthSeq12;

	public String getHealthSeq1() {
		return healthSeq1;
	}

	public void setHealthSeq1(String healthSeq1) {
		this.healthSeq1 = healthSeq1;
	}

	public String getHealthSeq2() {
		return healthSeq2;
	}

	public void setHealthSeq2(String healthSeq2) {
		this.healthSeq2 = healthSeq2;
	}

	public String getHealthSeq3() {
		return healthSeq3;
	}

	public void setHealthSeq3(String healthSeq3) {
		this.healthSeq3 = healthSeq3;
	}

	public String getHealthSeq4() {
		return healthSeq4;
	}

	public void setHealthSeq4(String healthSeq4) {
		this.healthSeq4 = healthSeq4;
	}

	public String getHealthSeq5() {
		return healthSeq5;
	}

	public void setHealthSeq5(String healthSeq5) {
		this.healthSeq5 = healthSeq5;
	}

	public String getHealthSeq6() {
		return healthSeq6;
	}

	public void setHealthSeq6(String healthSeq6) {
		this.healthSeq6 = healthSeq6;
	}

	public String getHealthSeq11() {
		return healthSeq11;
	}

	public void setHealthSeq11(String healthSeq11) {
		this.healthSeq11 = healthSeq11;
	}

	public String getHealthSeq12() {
		return healthSeq12;
	}

	public void setHealthSeq12(String healthSeq12) {
		this.healthSeq12 = healthSeq12;
	}
}
