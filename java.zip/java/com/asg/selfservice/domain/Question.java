package com.asg.selfservice.domain;

/**
 * Defines the Question model.
 * 
 * @author M1030133
 *
 */
public class Question {
	private int qId;
	private int qsetId;
	private String qsetName;
	private String question;
	private int refQID1;
	private int refQID2;
	private int refQID3;
	private int refQID4;
	private int refQID5;
	private int refQID6;
	private int refQID7;
	private int refQID8;
	private int refQID9;
	private int refQID10;
	private int sequence;
	private int ansTypeId;
	private int statusFlag;

	public int getqId() {
		return qId;
	}

	public void setqId(int qId) {
		this.qId = qId;
	}

	public int getQsetId() {
		return qsetId;
	}

	public void setQsetId(int qsetId) {
		this.qsetId = qsetId;
	}

	public String getQsetName() {
		return qsetName;
	}

	public void setQsetName(String qsetName) {
		this.qsetName = qsetName;
	}

	public String getQuestion() {
		return question;
	}

	public void setQuestion(String question) {
		this.question = question;
	}

	public int getRefQID1() {
		return refQID1;
	}

	public void setRefQID1(int refQID1) {
		this.refQID1 = refQID1;
	}

	public int getRefQID2() {
		return refQID2;
	}

	public void setRefQID2(int refQID2) {
		this.refQID2 = refQID2;
	}

	public int getRefQID3() {
		return refQID3;
	}

	public void setRefQID3(int refQID3) {
		this.refQID3 = refQID3;
	}

	public int getRefQID4() {
		return refQID4;
	}

	public void setRefQID4(int refQID4) {
		this.refQID4 = refQID4;
	}

	public int getRefQID5() {
		return refQID5;
	}

	public void setRefQID5(int refQID5) {
		this.refQID5 = refQID5;
	}

	public int getRefQID6() {
		return refQID6;
	}

	public void setRefQID6(int refQID6) {
		this.refQID6 = refQID6;
	}

	public int getRefQID7() {
		return refQID7;
	}

	public void setRefQID7(int refQID7) {
		this.refQID7 = refQID7;
	}

	public int getRefQID8() {
		return refQID8;
	}

	public void setRefQID8(int refQID8) {
		this.refQID8 = refQID8;
	}

	public int getRefQID9() {
		return refQID9;
	}

	public void setRefQID9(int refQID9) {
		this.refQID9 = refQID9;
	}

	public int getRefQID10() {
		return refQID10;
	}

	public void setRefQID10(int refQID10) {
		this.refQID10 = refQID10;
	}

	public int getSequence() {
		return sequence;
	}

	public void setSequence(int sequence) {
		this.sequence = sequence;
	}

	public int getAnsTypeId() {
		return ansTypeId;
	}

	public void setAnsTypeId(int ansTypeId) {
		this.ansTypeId = ansTypeId;
	}

	public int getStatusFlag() {
		return statusFlag;
	}

	public void setStatusFlag(int statusFlag) {
		this.statusFlag = statusFlag;
	}
}
