package com.asg.selfservice.domain.pinney;

import java.util.List;

public class Contact_info {

	private List<Address> addresses_attributes;
	private List<Email> emails_attributes;
	private double home_phone_value;
	private int zip;
	private int state_id;
	private String city;

	public List<Address> getAddresses_attributes() {
		return addresses_attributes;
	}

	public void setAddresses_attributes(List<Address> addresses_attributes) {
		this.addresses_attributes = addresses_attributes;
	}

	public List<Email> getEmails_attributes() {
		return emails_attributes;
	}

	public void setEmails_attributes(List<Email> emails_attributes) {
		this.emails_attributes = emails_attributes;
	}

	public double getHome_phone_value() {
		return home_phone_value;
	}

	public void setHome_phone_value(double d) {
		this.home_phone_value = d;
	}

	public int getZip() {
		return zip;
	}

	public void setZip(int zip) {
		this.zip = zip;
	}

	public int getState_id() {
		return state_id;
	}

	public void setState_id(int state_id) {
		this.state_id = state_id;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

}
