package com.asg.selfservice.domain.pinney;

public class Moving_violation_history {
	private int last_6_mo;// integer
	private int last_1_yr;// integer
	private int last_2_yr;// integer
	private int last_3_yr;// integer
	private int last_5_yr;// integer
	
	public int getLast_6_mo() {
		return last_6_mo;
	}
	public void setLast_6_mo(int last_6_mo) {
		this.last_6_mo = last_6_mo;
	}
	public int getLast_1_yr() {
		return last_1_yr;
	}
	public void setLast_1_yr(int last_1_yr) {
		this.last_1_yr = last_1_yr;
	}
	public int getLast_2_yr() {
		return last_2_yr;
	}
	public void setLast_2_yr(int last_2_yr) {
		this.last_2_yr = last_2_yr;
	}
	public int getLast_3_yr() {
		return last_3_yr;
	}
	public void setLast_3_yr(int last_3_yr) {
		this.last_3_yr = last_3_yr;
	}
	public int getLast_5_yr() {
		return last_5_yr;
	}
	public void setLast_5_yr(int last_5_yr) {
		this.last_5_yr = last_5_yr;
	}
	
	
}
