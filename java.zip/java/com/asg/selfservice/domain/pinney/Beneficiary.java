package com.asg.selfservice.domain.pinney;


public class Beneficiary {
	private int relationship_id;
	private int percentage;
	private String full_name;

	public int getRelationship_id() {
		return relationship_id;
	}

	public void setRelationship_id(int relationship_id) {
		this.relationship_id = relationship_id;
	}

	public int getPercentage() {
		return percentage;
	}

	public void setPercentage(int percentage) {
		this.percentage = percentage;
	}

	public String getFull_name() {
		return full_name;
	}

	public void setFull_name(String full_name) {
		this.full_name = full_name;
	}
}
