package com.asg.selfservice.domain.pinney;

public class Financial_info {
	private int annual_income;

	public int getAnnual_income() {
		return annual_income;
	}

	public void setAnnual_income(int annual_income) {
		this.annual_income = annual_income;
	}

}
