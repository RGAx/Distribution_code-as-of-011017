package com.asg.selfservice.domain.pinney;

public class Policy_details {
	private double annual_premium;
	private int carrier_id;
	private String carrier_health_class;
	private int category_id;
	private String category_name;
	private int face_amount;
	private String health;
	private int health_class_id;
	private double monthly_premium;
	private double planned_modal_premium;
	private String plan_name;
	private String product_type_name;
	private String premium_mode_name;
	private int policy_type_id;

	public double getAnnual_premium() {
		return annual_premium;
	}

	public void setAnnual_premium(double annual_premium) {
		this.annual_premium = annual_premium;
	}

	public int getCarrier_id() {
		return carrier_id;
	}

	public void setCarrier_id(int carrier_id) {
		this.carrier_id = carrier_id;
	}

	public String getCarrier_health_class() {
		return carrier_health_class;
	}

	public void setCarrier_health_class(String carrier_health_class) {
		this.carrier_health_class = carrier_health_class;
	}

	public int getCategory_id() {
		return category_id;
	}

	public void setCategory_id(int category_id) {
		this.category_id = category_id;
	}

	public String getCategory_name() {
		return category_name;
	}

	public void setCategory_name(String category_name) {
		this.category_name = category_name;
	}

	public int getFace_amount() {
		return face_amount;
	}

	public void setFace_amount(int face_amount) {
		this.face_amount = face_amount;
	}

	public String getHealth() {
		return health;
	}

	public void setHealth(String health) {
		this.health = health;
	}

	public int getHealth_class_id() {
		return health_class_id;
	}

	public void setHealth_class_id(int health_class_id) {
		this.health_class_id = health_class_id;
	}

	public double getMonthly_premium() {
		return monthly_premium;
	}

	public void setMonthly_premium(double monthly_premium) {
		this.monthly_premium = monthly_premium;
	}

	public double getPlanned_modal_premium() {
		return planned_modal_premium;
	}

	public void setPlanned_modal_premium(double planned_modal_premium) {
		this.planned_modal_premium = planned_modal_premium;
	}

	public String getPlan_name() {
		return plan_name;
	}

	public void setPlan_name(String plan_name) {
		this.plan_name = plan_name;
	}

	public String getProduct_type_name() {
		return product_type_name;
	}

	public void setProduct_type_name(String product_type_name) {
		this.product_type_name = product_type_name;
	}

	public String getPremium_mode_name() {
		return premium_mode_name;
	}

	public void setPremium_mode_name(String premium_mode_name) {
		this.premium_mode_name = premium_mode_name;
	}

	public int getPolicy_type_id() {
		return policy_type_id;
	}

	public void setPolicy_type_id(int policy_type_id) {
		this.policy_type_id = policy_type_id;
	}

}
