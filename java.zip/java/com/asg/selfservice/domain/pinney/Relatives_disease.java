package com.asg.selfservice.domain.pinney;

public class Relatives_disease {

	private boolean breast_cancer;// boolean
	private boolean cardiovascular_disease;// boolean
	private boolean cardiovascular_impairments;// boolean
	private boolean cerebrovascular_disease;// boolean
	private boolean colon_cancer;// boolean
	private boolean coronary_artery_disease;// boolean
	private boolean diabetes;// boolean
	private boolean kidney_disease;// boolean
	private boolean malignant_melanoma;// boolean
	private boolean ovarian_cancer;// boolean
	private int age_of_contraction;// integer
	private int age_of_death;// integer
	private boolean parent;// boolean

	public boolean isBreast_cancer() {
		return breast_cancer;
	}

	public void setBreast_cancer(boolean breast_cancer) {
		this.breast_cancer = breast_cancer;
	}

	public boolean isCardiovascular_disease() {
		return cardiovascular_disease;
	}

	public void setCardiovascular_disease(boolean cardiovascular_disease) {
		this.cardiovascular_disease = cardiovascular_disease;
	}

	public boolean isCardiovascular_impairments() {
		return cardiovascular_impairments;
	}

	public void setCardiovascular_impairments(boolean cardiovascular_impairments) {
		this.cardiovascular_impairments = cardiovascular_impairments;
	}

	public boolean isCerebrovascular_disease() {
		return cerebrovascular_disease;
	}

	public void setCerebrovascular_disease(boolean cerebrovascular_disease) {
		this.cerebrovascular_disease = cerebrovascular_disease;
	}

	public boolean isColon_cancer() {
		return colon_cancer;
	}

	public void setColon_cancer(boolean colon_cancer) {
		this.colon_cancer = colon_cancer;
	}

	public boolean isCoronary_artery_disease() {
		return coronary_artery_disease;
	}

	public void setCoronary_artery_disease(boolean coronary_artery_disease) {
		this.coronary_artery_disease = coronary_artery_disease;
	}

	public boolean isDiabetes() {
		return diabetes;
	}

	public void setDiabetes(boolean diabetes) {
		this.diabetes = diabetes;
	}

	public boolean isKidney_disease() {
		return kidney_disease;
	}

	public void setKidney_disease(boolean kidney_disease) {
		this.kidney_disease = kidney_disease;
	}

	public boolean isMalignant_melanoma() {
		return malignant_melanoma;
	}

	public void setMalignant_melanoma(boolean malignant_melanoma) {
		this.malignant_melanoma = malignant_melanoma;
	}

	public boolean isOvarian_cancer() {
		return ovarian_cancer;
	}

	public void setOvarian_cancer(boolean ovarian_cancer) {
		this.ovarian_cancer = ovarian_cancer;
	}

	public int getAge_of_contraction() {
		return age_of_contraction;
	}

	public void setAge_of_contraction(int age_of_contraction) {
		this.age_of_contraction = age_of_contraction;
	}

	public int getAge_of_death() {
		return age_of_death;
	}

	public void setAge_of_death(int age_of_death) {
		this.age_of_death = age_of_death;
	}

	public boolean isParent() {
		return parent;
	}

	public void setParent(boolean parent) {
		this.parent = parent;
	}

}
