package com.asg.selfservice.domain.pinney;

import java.util.Date;
import java.util.List;

public class ProspectClient {
	private int id;
	private String name;
	private String zip;
	private String phone;
	private Date createdDate;
	private List<Beneficiary> beneficiary;
	
	
	public List<Beneficiary> getBeneficiary() {
		return beneficiary;
	}
	public void setBeneficiary(List<Beneficiary> beneficiary) {
		this.beneficiary = beneficiary;
	}
	public Date getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getZip() {
		return zip;
	}
	public void setZip(String zip) {
		this.zip = zip;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}

	
	@Override
	public String toString() {
		
		return Integer.toString(id)+" "+name+" "+phone+" "+zip;
	}


}
