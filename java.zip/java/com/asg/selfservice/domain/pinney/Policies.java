package com.asg.selfservice.domain.pinney;

import java.util.List;

public class Policies {
	private boolean bind;
	private Policy_details approved_details_attributes;
	private List<Beneficiary> beneficiaries_attributes;
	private Policy_details submitted_details_attributes;
	private String category_name;
	private String created_at;
	private int face_amount;
	private boolean insured_is_owner;
	private int owner_id;
	private boolean owner_is_beneficiary;
	private String policy_type_name;
	private String premium_payer_id;
	private int product_type_id;
	private String product_type_name; // Policy type
	private String quoted_at;
	private String reason;
	private boolean underwriter_assist;

	public boolean isBind() {
		return bind;
	}

	public void setBind(boolean bind) {
		this.bind = bind;
	}

	public Policy_details getApproved_details_attributes() {
		return approved_details_attributes;
	}

	public void setApproved_details_attributes(
			Policy_details approved_details_attributes) {
		this.approved_details_attributes = approved_details_attributes;
	}

	public List<Beneficiary> getBeneficiaries_attributes() {
		return beneficiaries_attributes;
	}

	public void setBeneficiaries_attributes(
			List<Beneficiary> beneficiaries_attributes) {
		this.beneficiaries_attributes = beneficiaries_attributes;
	}

	public Policy_details getSubmitted_details_attributes() {
		return submitted_details_attributes;
	}

	public void setSubmitted_details_attributes(
			Policy_details submitted_details_attributes) {
		this.submitted_details_attributes = submitted_details_attributes;
	}

	public String getCategory_name() {
		return category_name;
	}

	public void setCategory_name(String category_name) {
		this.category_name = category_name;
	}

	public String getCreated_at() {
		return created_at;
	}

	public void setCreated_at(String created_at) {
		this.created_at = created_at;
	}

	public int getFace_amount() {
		return face_amount;
	}

	public void setFace_amount(int face_amount) {
		this.face_amount = face_amount;
	}

	public boolean isInsured_is_owner() {
		return insured_is_owner;
	}

	public void setInsured_is_owner(boolean insured_is_owner) {
		this.insured_is_owner = insured_is_owner;
	}

	public int getOwner_id() {
		return owner_id;
	}

	public void setOwner_id(int owner_id) {
		this.owner_id = owner_id;
	}

	public boolean isOwner_is_beneficiary() {
		return owner_is_beneficiary;
	}

	public void setOwner_is_beneficiary(boolean owner_is_beneficiary) {
		this.owner_is_beneficiary = owner_is_beneficiary;
	}

	public String getPolicy_type_name() {
		return policy_type_name;
	}

	public void setPolicy_type_name(String policy_type_name) {
		this.policy_type_name = policy_type_name;
	}

	public String getPremium_payer_id() {
		return premium_payer_id;
	}

	public void setPremium_payer_id(String premium_payer_id) {
		this.premium_payer_id = premium_payer_id;
	}

	public int getProduct_type_id() {
		return product_type_id;
	}

	public void setProduct_type_id(int product_type_id) {
		this.product_type_id = product_type_id;
	}

	public String getProduct_type_name() {
		return product_type_name;
	}

	public void setProduct_type_name(String product_type_name) {
		this.product_type_name = product_type_name;
	}

	public String getQuoted_at() {
		return quoted_at;
	}

	public void setQuoted_at(String quoted_at) {
		this.quoted_at = quoted_at;
	}

	public String getReason() {
		return reason;
	}

	public void setReason(String reason) {
		this.reason = reason;
	}

	public boolean isUnderwriter_assist() {
		return underwriter_assist;
	}

	public void setUnderwriter_assist(boolean underwriter_assist) {
		this.underwriter_assist = underwriter_assist;
	}

}
