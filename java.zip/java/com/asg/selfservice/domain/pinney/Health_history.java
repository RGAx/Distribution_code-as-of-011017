package com.asg.selfservice.domain.pinney;

public class Health_history {

	private boolean alcohol_abuse;// boolean
	private boolean anxiety;// boolean
	private boolean asthma;// boolean
	private boolean atrial_fibrillations;// boolean
	private boolean copd;// boolean
	private boolean crohns;// boolean
	private boolean depression;// boolean
	private boolean diabetes_1;// boolean
	private boolean diabetes_2;// boolean
	private boolean diabetes_neuropathy;// boolean
	private boolean elft;// boolean
	private boolean emphysema;// boolean
	private boolean epilepsy;// boolean
	private boolean heart_attack;// boolean
	private boolean heart_murmur_valve_disorder;// boolean
	private boolean hepatitis_c;// boolean
	private boolean internal_cancer;// boolean
	private boolean irregular_heart_beat;// boolean
	private boolean mental_illness;// boolean
	private boolean parkinsons;// boolean
	private boolean prostate_cancer;// boolean
	private boolean rheumatoid_arthritis;// boolean
	private boolean sleep_apnea;// boolean
	private boolean skin_cancer;// boolean
	private boolean stroke;// boolean
	private boolean ulcerative_colitis_iletis;// boolean
	private boolean vascular_disease;// boolean
	private boolean weight_loss_surgery;// boolean

	public boolean isAlcohol_abuse() {
		return alcohol_abuse;
	}

	public void setAlcohol_abuse(boolean alcohol_abuse) {
		this.alcohol_abuse = alcohol_abuse;
	}

	public boolean isAsthma() {
		return asthma;
	}

	public void setAsthma(boolean asthma) {
		this.asthma = asthma;
	}

	public boolean isAnxiety() {
		return anxiety;
	}

	public void setAnxiety(boolean anxiety) {
		this.anxiety = anxiety;
	}

	public boolean isAtrial_fibrillations() {
		return atrial_fibrillations;
	}

	public void setAtrial_fibrillations(boolean atrial_fibrillations) {
		this.atrial_fibrillations = atrial_fibrillations;
	}

	public boolean isCopd() {
		return copd;
	}

	public void setCopd(boolean copd) {
		this.copd = copd;
	}

	public boolean isCrohns() {
		return crohns;
	}

	public void setCrohns(boolean crohns) {
		this.crohns = crohns;
	}

	public boolean isDepression() {
		return depression;
	}

	public void setDepression(boolean depression) {
		this.depression = depression;
	}

	public boolean isDiabetes_1() {
		return diabetes_1;
	}

	public void setDiabetes_1(boolean diabetes_1) {
		this.diabetes_1 = diabetes_1;
	}

	public boolean isDiabetes_2() {
		return diabetes_2;
	}

	public void setDiabetes_2(boolean diabetes_2) {
		this.diabetes_2 = diabetes_2;
	}

	public boolean isDiabetes_neuropathy() {
		return diabetes_neuropathy;
	}

	public void setDiabetes_neuropathy(boolean diabetes_neuropathy) {
		this.diabetes_neuropathy = diabetes_neuropathy;
	}

	public boolean isElft() {
		return elft;
	}

	public void setElft(boolean elft) {
		this.elft = elft;
	}

	public boolean isEmphysema() {
		return emphysema;
	}

	public void setEmphysema(boolean emphysema) {
		this.emphysema = emphysema;
	}

	public boolean isEpilepsy() {
		return epilepsy;
	}

	public void setEpilepsy(boolean epilepsy) {
		this.epilepsy = epilepsy;
	}

	public boolean isHeart_attack() {
		return heart_attack;
	}

	public void setHeart_attack(boolean heart_attack) {
		this.heart_attack = heart_attack;
	}

	public boolean isHeart_murmur_valve_disorder() {
		return heart_murmur_valve_disorder;
	}

	public void setHeart_murmur_valve_disorder(
			boolean heart_murmur_valve_disorder) {
		this.heart_murmur_valve_disorder = heart_murmur_valve_disorder;
	}

	public boolean isHepatitis_c() {
		return hepatitis_c;
	}

	public void setHepatitis_c(boolean hepatitis_c) {
		this.hepatitis_c = hepatitis_c;
	}

	public boolean isInternal_cancer() {
		return internal_cancer;
	}

	public void setInternal_cancer(boolean internal_cancer) {
		this.internal_cancer = internal_cancer;
	}

	public boolean isIrregular_heart_beat() {
		return irregular_heart_beat;
	}

	public void setIrregular_heart_beat(boolean irregular_heart_beat) {
		this.irregular_heart_beat = irregular_heart_beat;
	}

	public boolean isMental_illness() {
		return mental_illness;
	}

	public void setMental_illness(boolean mental_illness) {
		this.mental_illness = mental_illness;
	}

	public boolean isParkinsons() {
		return parkinsons;
	}

	public void setParkinsons(boolean parkinsons) {
		this.parkinsons = parkinsons;
	}

	public boolean isProstate_cancer() {
		return prostate_cancer;
	}

	public void setProstate_cancer(boolean prostate_cancer) {
		this.prostate_cancer = prostate_cancer;
	}

	public boolean isRheumatoid_arthritis() {
		return rheumatoid_arthritis;
	}

	public void setRheumatoid_arthritis(boolean rheumatoid_arthritis) {
		this.rheumatoid_arthritis = rheumatoid_arthritis;
	}

	public boolean isSleep_apnea() {
		return sleep_apnea;
	}

	public void setSleep_apnea(boolean sleep_apnea) {
		this.sleep_apnea = sleep_apnea;
	}

	public boolean isSkin_cancer() {
		return skin_cancer;
	}

	public void setSkin_cancer(boolean skin_cancer) {
		this.skin_cancer = skin_cancer;
	}

	public boolean isStroke() {
		return stroke;
	}

	public void setStroke(boolean stroke) {
		this.stroke = stroke;
	}

	public boolean isUlcerative_colitis_iletis() {
		return ulcerative_colitis_iletis;
	}

	public void setUlcerative_colitis_iletis(boolean ulcerative_colitis_iletis) {
		this.ulcerative_colitis_iletis = ulcerative_colitis_iletis;
	}

	public boolean isVascular_disease() {
		return vascular_disease;
	}

	public void setVascular_disease(boolean vascular_disease) {
		this.vascular_disease = vascular_disease;
	}

	public boolean isWeight_loss_surgery() {
		return weight_loss_surgery;
	}

	public void setWeight_loss_surgery(boolean weight_loss_surgery) {
		this.weight_loss_surgery = weight_loss_surgery;
	}
}
