package com.asg.selfservice.domain.pinney;

import java.util.List;

import com.ebix.lifelink.client.NotesAttribute;

public class Client {

	private boolean active;
	private String birth;
	private String birth_country;
	private String birth_state_name;
	private List<Policies> cases_attributes;
	private Contact_info contact_info_attributes;
	private String dln;// driving licence number
	private String dl_state_name; // enum
	private Financial_info financial_info_attributes;
	private String first_name;
	private String gender;// Male! Female
	private Health_info health_info_attributes;
	private String last_name;
	private String lead_type; // not sure this is present or required
	private int profile_id;
	private String ssn;
	private List<NotesAttribute> notes_attributes;

	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	public String getBirth() {
		return birth;
	}

	public void setBirth(String birth) {
		this.birth = birth;
	}

	public String getBirth_country() {
		return birth_country;
	}

	public void setBirth_country(String birth_country) {
		this.birth_country = birth_country;
	}

	public String getBirth_state_name() {
		return birth_state_name;
	}

	public void setBirth_state_name(String birth_state_name) {
		this.birth_state_name = birth_state_name;
	}

	public List<Policies> getCases_attributes() {
		return cases_attributes;
	}

	public void setCases_attributes(List<Policies> cases_attributes) {
		this.cases_attributes = cases_attributes;
	}

	public Contact_info getContact_info_attributes() {
		return contact_info_attributes;
	}

	public void setContact_info_attributes(Contact_info contact_info_attributes) {
		this.contact_info_attributes = contact_info_attributes;
	}

	public String getDln() {
		return dln;
	}

	public void setDln(String dln) {
		this.dln = dln;
	}

	public String getDl_state_name() {
		return dl_state_name;
	}

	public void setDl_state_name(String dl_state_name) {
		this.dl_state_name = dl_state_name;
	}

	public String getFirst_name() {
		return first_name;
	}

	public void setFirst_name(String first_name) {
		this.first_name = first_name;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public Health_info getHealth_info_attributes() {
		return health_info_attributes;
	}

	public void setHealth_info_attributes(Health_info health_info_attributes) {
		this.health_info_attributes = health_info_attributes;
	}

	public String getLast_name() {
		return last_name;
	}

	public void setLast_name(String last_name) {
		this.last_name = last_name;
	}

	public String getLead_type() {
		return lead_type;
	}

	public void setLead_type(String lead_type) {
		this.lead_type = lead_type;
	}

	public int getProfile_id() {
		return profile_id;
	}

	public void setProfile_id(int profile_id) {
		this.profile_id = profile_id;
	}

	public String getSsn() {
		return ssn;
	}

	public void setSsn(String ssn) {
		this.ssn = ssn;
	}

	public List<NotesAttribute> getNotes_attributes() {
		return notes_attributes;
	}

	public void setNotes_attributes(List<NotesAttribute> notes_attributes) {
		this.notes_attributes = notes_attributes;
	}

	public Financial_info getFinancial_info_attributes() {
		return financial_info_attributes;
	}

	public void setFinancial_info_attributes(
			Financial_info financial_info_attributes) {
		this.financial_info_attributes = financial_info_attributes;
	}
}
