package com.asg.selfservice.domain.pinney;

public class FamilyAttribute {
	private String breast_cancer;
	private String cardiovascular_disease;
	private String cardiovascular_impairments;
	private String cerebrovascular_disease;
	private String colon_cancer;
	private String coronary_artery_disease;
	private String diabetes;
	private String kidney_disease;
	private String malignant_melanoma;
	private String ovarian_cancer;
	private String age_of_contraction;
	private String age_of_death;
	private String parent;

	public String getBreast_cancer() {
		return breast_cancer;
	}

	public void setBreast_cancer(String breast_cancer) {
		this.breast_cancer = breast_cancer;
	}

	public String getCardiovascular_disease() {
		return cardiovascular_disease;
	}

	public void setCardiovascular_disease(String cardiovascular_disease) {
		this.cardiovascular_disease = cardiovascular_disease;
	}

	public String getCardiovascular_impairments() {
		return cardiovascular_impairments;
	}

	public void setCardiovascular_impairments(String cardiovascular_impairments) {
		this.cardiovascular_impairments = cardiovascular_impairments;
	}

	public String getCerebrovascular_disease() {
		return cerebrovascular_disease;
	}

	public void setCerebrovascular_disease(String cerebrovascular_disease) {
		this.cerebrovascular_disease = cerebrovascular_disease;
	}

	public String getColon_cancer() {
		return colon_cancer;
	}

	public void setColon_cancer(String colon_cancer) {
		this.colon_cancer = colon_cancer;
	}

	public String getCoronary_artery_disease() {
		return coronary_artery_disease;
	}

	public void setCoronary_artery_disease(String coronary_artery_disease) {
		this.coronary_artery_disease = coronary_artery_disease;
	}

	public String getDiabetes() {
		return diabetes;
	}

	public void setDiabetes(String diabetes) {
		this.diabetes = diabetes;
	}

	public String getKidney_disease() {
		return kidney_disease;
	}

	public void setKidney_disease(String kidney_disease) {
		this.kidney_disease = kidney_disease;
	}

	public String getMalignant_melanoma() {
		return malignant_melanoma;
	}

	public void setMalignant_melanoma(String malignant_melanoma) {
		this.malignant_melanoma = malignant_melanoma;
	}

	public String getOvarian_cancer() {
		return ovarian_cancer;
	}

	public void setOvarian_cancer(String ovarian_cancer) {
		this.ovarian_cancer = ovarian_cancer;
	}

	public String getAge_of_contraction() {
		return age_of_contraction;
	}

	public void setAge_of_contraction(String age_of_contraction) {
		this.age_of_contraction = age_of_contraction;
	}

	public String getAge_of_death() {
		return age_of_death;
	}

	public void setAge_of_death(String age_of_death) {
		this.age_of_death = age_of_death;
	}

	public String getParent() {
		return parent;
	}

	public void setParent(String parent) {
		this.parent = parent;
	}
}
