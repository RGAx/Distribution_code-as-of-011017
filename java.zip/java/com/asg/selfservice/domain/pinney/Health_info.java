package com.asg.selfservice.domain.pinney;

import java.util.List;

public class Health_info {
	
	private String birth;// String
	private String bp_control_start;// String
	private int bp_diastolic;// integer
	private int bp_systolic;// integer
	private int cholesterol;// integer
	private String cholesterol_control_start;// String
	private float cholesterol_hdl;// float
	private boolean cigarettes_current;// boolean
	private int cigarettes_per_day;// integer
	private boolean cigars_current;// boolean
	private int cigars_per_month;// integer
	private boolean criminal;// boolean
	private List<Relatives_disease> family_diseases_attributes;// List<Relatives disease>
	private int feet;// integer 
	private boolean foreign_travel;// boolean
	private boolean gender;// boolean 
	private boolean hazardous_avocation;// boolean
	private String hazardous_avocation_detail;// string
	private Health_history health_history_attributes;// Health history
	private int inches;// integer
	private String last_bp_treatment;// String
	private String last_cholesterol_treatment;// String
	private String last_cigar;// String
	private String last_cigarette;// String
	private String last_dl_suspension;// String
	private String last_dui_dwi;// String 
	private String last_nicotine_patch_or_gum;// String 
	private String last_pipe;// String
	private String last_reckless_driving;// String
	private String last_tobacco_chewed;// String
	private Moving_violation_history moving_violation_history_attributes;// Moving_violation_history
	private boolean nicotine_patch_or_gum_current;// boolean
	private String penultimate_car_accident;// String
	private boolean pipe_current;// boolean
	private int pipes_per_year;// integer
	private boolean tobacco_chewed_current;// boolean
	private int weight;// integer
	private boolean smoker;
	
	public String getBirth() {
		return birth;
	}
	public void setBirth(String birth) {
		this.birth = birth;
	}
	
	public String getBp_control_start() {
		return bp_control_start;
	}
	public void setBp_control_start(String bp_control_start) {
		this.bp_control_start = bp_control_start;
	}
	
	public int getBp_diastolic() {
		return bp_diastolic;
	}
	public void setBp_diastolic(int bp_diastolic) {
		this.bp_diastolic = bp_diastolic;
	}
	
	public int getBp_systolic() {
		return bp_systolic;
	}
	public void setBp_systolic(int bp_systolic) {
		this.bp_systolic = bp_systolic;
	}
	
	public int getCholesterol() {
		return cholesterol;
	}
	public void setCholesterol(int cholesterol) {
		this.cholesterol = cholesterol;
	}
	
	public String getCholesterol_control_start() {
		return cholesterol_control_start;
	}
	public void setCholesterol_control_start(String cholesterol_control_start) {
		this.cholesterol_control_start = cholesterol_control_start;
	}
	
	public float getCholesterol_hdl() {
		return cholesterol_hdl;
	}
	public void setCholesterol_hdl(float cholesterol_hdl) {
		this.cholesterol_hdl = cholesterol_hdl;
	}
	
	public boolean isCigarettes_current() {
		return cigarettes_current;
	}
	public void setCigarettes_current(boolean cigarettes_current) {
		this.cigarettes_current = cigarettes_current;
	}
	
	public int getCigarettes_per_day() {
		return cigarettes_per_day;
	}
	public void setCigarettes_per_day(int cigarettes_per_day) {
		this.cigarettes_per_day = cigarettes_per_day;
	}
	
	public boolean isCigars_current() {
		return cigars_current;
	}
	public void setCigars_current(boolean cigars_current) {
		this.cigars_current = cigars_current;
	}
	
	public int getCigars_per_month() {
		return cigars_per_month;
	}
	public void setCigars_per_month(int cigars_per_month) {
		this.cigars_per_month = cigars_per_month;
	}
	
	public boolean isCriminal() {
		return criminal;
	}
	public void setCriminal(boolean criminal) {
		this.criminal = criminal;
	}
	
	public List<Relatives_disease> getFamily_diseases_attributes() {
		return family_diseases_attributes;
	}
	public void setFamily_diseases_attributes(
			List<Relatives_disease> family_diseases_attributes) {
		this.family_diseases_attributes = family_diseases_attributes;
	}
	
	public int getFeet() {
		return feet;
	}
	public void setFeet(int feet) {
		this.feet = feet;
	}
	
	public boolean isForeign_travel() {
		return foreign_travel;
	}
	public void setForeign_travel(boolean foreign_travel) {
		this.foreign_travel = foreign_travel;
	}
	
	public boolean getGender() {
		return gender;
	}
	public void setGender(boolean gender) {
		this.gender = gender;
	}
	
	public boolean isHazardous_avocation() {
		return hazardous_avocation;
	}
	public void setHazardous_avocation(boolean hazardous_avocation) {
		this.hazardous_avocation = hazardous_avocation;
	}
	
	public String getHazardous_avocation_detail() {
		return hazardous_avocation_detail;
	}
	public void setHazardous_avocation_detail(String hazardous_avocation_detail) {
		this.hazardous_avocation_detail = hazardous_avocation_detail;
	}
	
	public Health_history getHealth_history_attributes() {
		return health_history_attributes;
	}
	public void setHealth_history_attributes(
			Health_history health_history_attributes) {
		this.health_history_attributes = health_history_attributes;
	}
	
	public int getInches() {
		return inches;
	}
	public void setInches(int inches) {
		this.inches = inches;
	}
	
	public String getLast_bp_treatment() {
		return last_bp_treatment;
	}
	public void setLast_bp_treatment(String last_bp_treatment) {
		this.last_bp_treatment = last_bp_treatment;
	}
	
	public String getLast_cholesterol_treatment() {
		return last_cholesterol_treatment;
	}
	public void setLast_cholesterol_treatment(String last_cholesterol_treatment) {
		this.last_cholesterol_treatment = last_cholesterol_treatment;
	}
	
	public String getLast_cigar() {
		return last_cigar;
	}
	public void setLast_cigar(String last_cigar) {
		this.last_cigar = last_cigar;
	}
	
	public String getLast_cigarette() {
		return last_cigarette;
	}
	public void setLast_cigarette(String last_cigarette) {
		this.last_cigarette = last_cigarette;
	}
	
	public String getLast_dl_suspension() {
		return last_dl_suspension;
	}
	public void setLast_dl_suspension(String last_dl_suspension) {
		this.last_dl_suspension = last_dl_suspension;
	}
	
	public String getLast_dui_dwi() {
		return last_dui_dwi;
	}
	public void setLast_dui_dwi(String last_dui_dwi) {
		this.last_dui_dwi = last_dui_dwi;
	}
	
	public String getLast_nicotine_patch_or_gum() {
		return last_nicotine_patch_or_gum;
	}
	public void setLast_nicotine_patch_or_gum(String last_nicotine_patch_or_gum) {
		this.last_nicotine_patch_or_gum = last_nicotine_patch_or_gum;
	}
	
	public String getLast_pipe() {
		return last_pipe;
	}
	public void setLast_pipe(String last_pipe) {
		this.last_pipe = last_pipe;
	}
	
	public String getLast_reckless_driving() {
		return last_reckless_driving;
	}
	public void setLast_reckless_driving(String last_reckless_driving) {
		this.last_reckless_driving = last_reckless_driving;
	}
	
	public String getLast_tobacco_chewed() {
		return last_tobacco_chewed;
	}
	public void setLast_tobacco_chewed(String last_tobacco_chewed) {
		this.last_tobacco_chewed = last_tobacco_chewed;
	}
	
	public Moving_violation_history getMoving_violation_history_attributes() {
		return moving_violation_history_attributes;
	}
	public void setMoving_violation_history_attributes(
			Moving_violation_history moving_violation_history_attributes) {
		this.moving_violation_history_attributes = moving_violation_history_attributes;
	}
	
	public boolean isNicotine_patch_or_gum_current() {
		return nicotine_patch_or_gum_current;
	}
	public void setNicotine_patch_or_gum_current(
			boolean nicotine_patch_or_gum_current) {
		this.nicotine_patch_or_gum_current = nicotine_patch_or_gum_current;
	}
	
	public String getPenultimate_car_accident() {
		return penultimate_car_accident;
	}
	public void setPenultimate_car_accident(String penultimate_car_accident) {
		this.penultimate_car_accident = penultimate_car_accident;
	}
	
	public boolean isPipe_current() {
		return pipe_current;
	}
	public void setPipe_current(boolean pipe_current) {
		this.pipe_current = pipe_current;
	}
	
	public int getPipes_per_year() {
		return pipes_per_year;
	}
	public void setPipes_per_year(int pipes_per_year) {
		this.pipes_per_year = pipes_per_year;
	}
	
	public boolean isTobacco_chewed_current() {
		return tobacco_chewed_current;
	}
	public void setTobacco_chewed_current(boolean tobacco_chewed_current) {
		this.tobacco_chewed_current = tobacco_chewed_current;
	}
	
	public int getWeight() {
		return weight;
	}
	public void setWeight(int weight) {
		this.weight = weight;
	}
	public boolean isSmoker() {
		return smoker;
	}
	public void setSmoker(boolean smoker) {
		this.smoker = smoker;
	}
}
