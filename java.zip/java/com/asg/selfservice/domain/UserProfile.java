package com.asg.selfservice.domain;

import java.io.Serializable;
import java.util.Date;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotEmpty;

/**
 * Defines the User profile model.
 * @author M1030133
 *
 */
public class UserProfile implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private int userId;
	private String encryptedUid;
	private String campaignId;
	private String salutation;
	private String firstName;
	private String lastName;
	private Date dob;
	private String address1;
	private String addressCity;
	private String addressState;
	private String zipCode;
	private String phoneNumber;
	
	@NotEmpty @Email
	private String emailAddress;
	
	@NotEmpty
	private String password;
	
	private Date pwdChangeDate;
	private int profileStatusFlag;
	private int UnsuccessfulAttemptCtr;
	private Date lastUnsuccessfulDate;
	private String initialMonthlyEstimate;
	private String insuranceCoverage;
	private int insuranceTerm;
	private String pinneyQuoteStatus;
	private Date lastPinneyUpdatedDate;
	private String agencyLogo;
	private Date createdDate;
	private String createdBy;
	private Date updatedDate;
	private String updatedBy;
	private String Gender;
	
	private String dateTemp;
	private String newPassword;
	private String confPassword;
	//email
	private String savedDate;
	private String agency_name;
	private int validCount;
	private String lastUpdateDate;
	
	private String userType;
	
	public String getLastUpdateDate() {
		return lastUpdateDate;
	}

	public void setLastUpdateDate(String lastUpdateDate) {
		this.lastUpdateDate = lastUpdateDate;
	}

	public String getAgency_name() {
		return agency_name;
	}

	public void setAgency_name(String agency_name) {
		this.agency_name = agency_name;
	}

	public String getSavedDate() {
		return savedDate;
	}

	public void setSavedDate(String savedDate) {
		this.savedDate = savedDate;
	}

	public int getValidCount() {
		return validCount;
	}

	public void setValidCount(int validCount) {
		this.validCount = validCount;
	}

	public UserProfile() {
	}
	
	public UserProfile(int userId, String encryptedUid, String campaignId,
			String salutation, String firstName, String lastName, Date dob,
			String address1, String addressCity, String addressState,
			String zipCode, String phoneNumber, String emailAddress,
			String password, Date pwdChangeDate, char profileStatusFlag,
			int unsuccessfulAttemptCtr, Date lastUnsuccessfulDate,
			String initialMonthlyEstimate, String insuranceCoverage,
			String tempCoverage, int insuranceTerm, String pinneyQuoteStatus,
			Date lastPinneyUpdatedDate, String agencyLogo, Date createdDate,
			String createdBy, Date updatedDate, String updatedBy,
			String dateTemp, String newPassword, String confPassword) {
		super();
		this.userId = userId;
		this.encryptedUid = encryptedUid;
		this.campaignId = campaignId;
		this.salutation = salutation;
		this.firstName = firstName;
		this.lastName = lastName;
		this.dob = dob;
		this.address1 = address1;
		this.addressCity = addressCity;
		this.addressState = addressState;
		this.zipCode = zipCode;
		this.phoneNumber = phoneNumber;
		this.emailAddress = emailAddress;
		this.password = password;
		this.pwdChangeDate = pwdChangeDate;
		this.profileStatusFlag = profileStatusFlag;
		UnsuccessfulAttemptCtr = unsuccessfulAttemptCtr;
		this.lastUnsuccessfulDate = lastUnsuccessfulDate;
		this.initialMonthlyEstimate = initialMonthlyEstimate;
		this.insuranceCoverage = insuranceCoverage;
		this.insuranceTerm = insuranceTerm;
		this.pinneyQuoteStatus = pinneyQuoteStatus;
		this.lastPinneyUpdatedDate = lastPinneyUpdatedDate;
		this.agencyLogo = agencyLogo;
		this.createdDate = createdDate;
		this.createdBy = createdBy;
		this.updatedDate = updatedDate;
		this.updatedBy = updatedBy;
		this.dateTemp = dateTemp;
		this.newPassword = newPassword;
		this.confPassword = confPassword;
	}
	
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	
	public String getEncryptedUid() {
		return encryptedUid;
	}
	public void setEncryptedUid(String encryptedUid) {
		this.encryptedUid = encryptedUid;
	}
	
	public String getCampaignId() {
		return campaignId;
	}
	public void setCampaignId(String campaignId) {
		this.campaignId = campaignId;
	}
	
	public String getSalutation() {
		return salutation;
	}
	public void setSalutation(String salutation) {
		this.salutation = salutation;
	}
	
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	
	public Date getDob() {
		return dob;
	}
	public void setDob(Date dob) {
		this.dob = dob;
	}
	
	public String getAddress1() {
		return address1;
	}
	public void setAddress1(String address1) {
		this.address1 = address1;
	}
	
	public String getAddressCity() {
		return addressCity;
	}
	public void setAddressCity(String addressCity) {
		this.addressCity = addressCity;
	}
	
	public String getAddressState() {
		return addressState;
	}
	public void setAddressState(String addressState) {
		this.addressState = addressState;
	}
	
	public String getZipCode() {
		return zipCode;
	}
	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}
	
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	
	public String getEmailAddress() {
		return emailAddress;
	}
	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}
	
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	public Date getPwdChangeDate() {
		return pwdChangeDate;
	}
	public void setPwdChangeDate(Date pwdChangeDate) {
		this.pwdChangeDate = pwdChangeDate;
	}
	
	
	public int getProfileStatusFlag() {
		return profileStatusFlag;
	}
	public void setProfileStatusFlag(int profileStatusFlag) {
		this.profileStatusFlag = profileStatusFlag;
	}
	
	public int getUnsuccessfulAttemptCtr() {
		return UnsuccessfulAttemptCtr;
	}
	public void setUnsuccessfulAttemptCtr(int unsuccessfulAttemptCtr) {
		UnsuccessfulAttemptCtr = unsuccessfulAttemptCtr;
	}
	
	public Date getLastUnsuccessfulDate() {
		return lastUnsuccessfulDate;
	}
	public void setLastUnsuccessfulDate(Date lastUnsuccessfulDate) {
		this.lastUnsuccessfulDate = lastUnsuccessfulDate;
	}
	
	
	public String getInitialMonthlyEstimate() {
		return initialMonthlyEstimate;
	}
	public void setInitialMonthlyEstimate(String initialMonthlyEstimate) {
		this.initialMonthlyEstimate = initialMonthlyEstimate;
	}
	
	public String getInsuranceCoverage() {
		return insuranceCoverage;
	}
	public void setInsuranceCoverage(String insuranceCoverage) {
		this.insuranceCoverage = insuranceCoverage;
	}
	
	public int getInsuranceTerm() {
		return insuranceTerm;
	}
	public void setInsuranceTerm(int insuranceTerm) {
		this.insuranceTerm = insuranceTerm;
	}
	
	public String getPinneyQuoteStatus() {
		return pinneyQuoteStatus;
	}
	public void setPinneyQuoteStatus(String pinneyQuoteStatus) {
		this.pinneyQuoteStatus = pinneyQuoteStatus;
	}
	
	public Date getLastPinneyUpdatedDate() {
		return lastPinneyUpdatedDate;
	}
	public void setLastPinneyUpdatedDate(Date lastPinneyUpdatedDate) {
		this.lastPinneyUpdatedDate = lastPinneyUpdatedDate;
	}
	
	public String getAgencyLogo() {
		return agencyLogo;
	}

	public void setAgencyLogo(String agencyLogo) {
		this.agencyLogo = agencyLogo;
	}

	public Date getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	
	public Date getUpdatedDate() {
		return updatedDate;
	}
	public void setUpdatedDate(Date updatedDate) {
		this.updatedDate = updatedDate;
	}
	
	public String getUpdatedBy() {
		return updatedBy;
	}
	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}
	
	public String getDateTemp() {
		return dateTemp;
	}
	public void setDateTemp(String dateTemp) {
		this.dateTemp = dateTemp;
	}
	
	public String getNewPassword() {
		return newPassword;
	}
	public void setNewPassword(String newPassword) {
		this.newPassword = newPassword;
	}
	
	public String getConfPassword() {
		return confPassword;
	}
	public void setConfPassword(String confPassword) {
		this.confPassword = confPassword;
	}
	
	public String getGender() {
		return Gender;
	}

	public void setGender(String gender) {
		Gender = gender;
	}

	@Override
	public String toString() {
		return "UserProfile [userId=" + userId + ", encryptedUid="
				+ encryptedUid + ", campaignId=" + campaignId + ", salutation="
				+ salutation + ", firstName=" + firstName + ", lastName="
				+ lastName + ", dob=" + dob + ", address1=" + address1
				+ ", addressCity=" + addressCity + ", addressState="
				+ addressState + ", zipCode=" + zipCode + ", phoneNumber="
				+ phoneNumber + ", emailAddress=" + emailAddress
				+ ", password=" + password + ", pwdChangeDate=" + pwdChangeDate
				+ ", profileStatusFlag=" + profileStatusFlag
				+ ", UnsuccessfulAttemptCtr=" + UnsuccessfulAttemptCtr
				+ ", lastUnsuccessfulDate=" + lastUnsuccessfulDate
				+ ", intitalMonthlyEstimate=" + initialMonthlyEstimate
				+ ", insuranceCoverage=" + insuranceCoverage
				+ ", insuranceTerm=" + insuranceTerm + ", pinneyQuoteStatus="
				+ pinneyQuoteStatus + ", lastPinneyUpdatedDate="
				+ lastPinneyUpdatedDate + ", agencyLogo=" + agencyLogo
				+ ", createdDate=" + createdDate + ", createdBy=" + createdBy
				+ ", updatedDate=" + updatedDate + ", updatedBy=" + updatedBy + ",savedDate="+ savedDate
				+ "]";
	}
	
	//Validation error message fields
	private String loginFailErrorMsg;
	private String forgotPwdErrorMsg;
	private String oldPwdErrMsg;

	public String getLoginFailErrorMsg() {
		return loginFailErrorMsg;
	}

	public void setLoginFailErrorMsg(String loginFailErrorMsg) {
		this.loginFailErrorMsg = loginFailErrorMsg;
	}

	public String getForgotPwdErrorMsg() {
		return forgotPwdErrorMsg;
	}

	public void setForgotPwdErrorMsg(String forgotPwdErrorMsg) {
		this.forgotPwdErrorMsg = forgotPwdErrorMsg;
	}

	public String getOldPwdErrMsg() {
		return oldPwdErrMsg;
	}

	public void setOldPwdErrMsg(String oldPwdErrMsg) {
		this.oldPwdErrMsg = oldPwdErrMsg;
	}

	public String getUserType() {
		return userType;
	}

	public void setUserType(String userType) {
		this.userType = userType;
	}
	
}
