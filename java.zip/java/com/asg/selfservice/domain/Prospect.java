package com.asg.selfservice.domain;


/**
 * Sagar
 * 
 * @author M1027376 This is Domain/Model Class. This class contains the User
 *         Info This class is POJO class
 * 
 */

public class Prospect {

	public Prospect() {
		super();
	}

	private int id;
	private String encryptedUId;
	private String firstName;
	private String lastName;
	private String agencyName;
	private String insuranceCompany;
	private String address;
	private String city;
	private String state;
	private String zip;
	private String phoneNumber;
	private String email;
	private String videoUrl;
	private String dob;
	private String salutation;
	private String sentDate;
	private int checkboxHits;
	private int landingpageHits;
	private String campaignId;
	private String pathLocation;
	private int upCreated;
	private String navigationPage;
	private String gender;
	private int age;
	private String logoName;
	private String processedDate;
	private int minEstimate;
	private int secondMinEstimate;
	
	private String password;



	/**
	 * @param id
	 * @param encryptedUId
	 * @param firstName
	 * @param lastName
	 * @param agencyName
	 * @param insuranceCompany
	 * @param address
	 * @param city
	 * @param state
	 * @param zip
	 * @param phoneNumber
	 * @param email
	 * @param videoUrl
	 * @param dob
	 * @param salutation
	 * @param sentDate
	 * @param checkboxHits
	 * @param landingpageHits
	 * @param campaignId
	 * @param pathLocation
	 * @param upCreated
	 * @param navigationPage
	 * @param gender
	 * @param age
	 * @param logoName
	 * @param processedDate
	 * @param minEstimate
	 * @param secondMinEstimate
	 * @param password
	 */
	public Prospect(int id, String encryptedUId, String firstName,
			String lastName, String agencyName, String insuranceCompany,
			String address, String city, String state, String zip,
			String phoneNumber, String email, String videoUrl, String dob,
			String salutation, String sentDate, int checkboxHits,
			int landingpageHits, String campaignId, String pathLocation,
			int upCreated, String navigationPage, String gender, int age,
			String logoName, String processedDate, int minEstimate,
			int secondMinEstimate, String password) {
		super();
		this.id = id;
		this.encryptedUId = encryptedUId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.agencyName = agencyName;
		this.insuranceCompany = insuranceCompany;
		this.address = address;
		this.city = city;
		this.state = state;
		this.zip = zip;
		this.phoneNumber = phoneNumber;
		this.email = email;
		this.videoUrl = videoUrl;
		this.dob = dob;
		this.salutation = salutation;
		this.sentDate = sentDate;
		this.checkboxHits = checkboxHits;
		this.landingpageHits = landingpageHits;
		this.campaignId = campaignId;
		this.pathLocation = pathLocation;
		this.upCreated = upCreated;
		this.navigationPage = navigationPage;
		this.gender = gender;
		this.age = age;
		this.logoName = logoName;
		this.processedDate = processedDate;
		this.minEstimate = minEstimate;
		this.secondMinEstimate = secondMinEstimate;
		this.password = password;
	}

	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}

	/**
	 * @param id
	 *            the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}

	/**
	 * @return the firstName
	 */
	public String getFirstName() {
		return firstName;
	}

	/**
	 * @param firstName
	 *            the firstName to set
	 */
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	/**
	 * @return the lastName
	 */
	public String getLastName() {
		return lastName;
	}

	/**
	 * @param lastName
	 *            the lastName to set
	 */
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	/**
	 * @return the agencyName
	 */
	public String getAgencyName() {
		return agencyName;
	}

	/**
	 * @param agencyName
	 *            the agencyName to set
	 */
	public void setAgencyName(String agencyName) {
		this.agencyName = agencyName;
	}

	/**
	 * @return the insuranceCompany
	 */
	public String getInsuranceCompany() {
		return insuranceCompany;
	}

	/**
	 * @param insuranceCompany
	 *            the insuranceCompany to set
	 */
	public void setInsuranceCompany(String insuranceCompany) {
		this.insuranceCompany = insuranceCompany;
	}

	/**
	 * @return the address
	 */
	public String getAddress() {
		return address;
	}

	/**
	 * @param address
	 *            the address to set
	 */
	public void setAddress(String address) {
		this.address = address;
	}

	/**
	 * @return the zip
	 */
	public String getZip() {
		return zip;
	}

	/**
	 * @param zip
	 *            the zip to set
	 */
	public void setZip(String zip) {
		this.zip = zip;
	}

	/**
	 * @return the phoneNumber
	 */
	public String getPhoneNumber() {
		return phoneNumber;
	}

	/**
	 * @param phoneNumber
	 *            the phoneNumber to set
	 */
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	/**
	 * @return the email
	 */
	public String getEmail() {
		return email;
	}

	/**
	 * @param email
	 *            the email to set
	 */
	public void setEmail(String email) {
		this.email = email;
	}

	/**
	 * @return the videoUrl
	 */
	public String getVideoUrl() {
		return videoUrl;
	}

	/**
	 * @param videoUrl
	 *            the videoUrl to set
	 */
	public void setVideoUrl(String videoUrl) {
		this.videoUrl = videoUrl;
	}

	/**
	 * @return the dob
	 */
	public String getDob() {
		return dob;
	}

	/**
	 * @param dob
	 *            the dob to set
	 */
	public void setDob(String dob) {
		this.dob = dob;
	}

	/**
	 * @return the salutation
	 */
	public String getSalutation() {
		return salutation;
	}

	/**
	 * @param salutation
	 *            the salutation to set
	 */
	public void setSalutation(String salutation) {
		this.salutation = salutation;
	}

	/**
	 * @return the sentDate
	 */
	public String getSentDate() {
		return sentDate;
	}

	/**
	 * @param sentDate
	 *            the sentDate to set
	 */
	public void setSentDate(String sentDate) {
		this.sentDate = sentDate;
	}

	/**
	 * @return the checkboxHits
	 */
	public int getCheckboxHits() {
		return checkboxHits;
	}

	/**
	 * @param checkboxHits
	 *            the checkboxHits to set
	 */
	public void setCheckboxHits(int checkboxHits) {
		this.checkboxHits = checkboxHits;
	}

	/**
	 * @return the landingpageHits
	 */
	public int getLandingpageHits() {
		return landingpageHits;
	}

	/**
	 * @param landingpageHits
	 *            the landingpageHits to set
	 */
	public void setLandingpageHits(int landingpageHits) {
		this.landingpageHits = landingpageHits;
	}

	/**
	 * @return the minEstimate
	 */
	public int getMinEstimate() {
		return minEstimate;
	}

	/**
	 * @param minEstimate the minEstimate to set
	 */
	public void setMinEstimate(int minEstimate) {
		this.minEstimate = minEstimate;
	}

	/**
	 * @return the secondMinEstimate
	 */
	public int getSecondMinEstimate() {
		return secondMinEstimate;
	}

	/**
	 * @param secondMinEstimate the secondMinEstimate to set
	 */
	public void setSecondMinEstimate(int secondMinEstimate) {
		this.secondMinEstimate = secondMinEstimate;
	}

	/**
	 * @return the navigationPage
	 */
	public String getNavigationPage() {
		return navigationPage;
	}

	/**
	 * @return the upCreated
	 */
	public int getUpCreated() {
		return upCreated;
	}

	/**
	 * @param upCreated the upCreated to set
	 */
	public void setUpCreated(int upCreated) {
		this.upCreated = upCreated;
	}

	/**
	 * @param navigationPage
	 *            the navigationPage to set
	 */
	public void setNavigationPage(String navigationPage) {
		this.navigationPage = navigationPage;
	}

	/**
	 * @return the gender
	 */
	public String getGender() {
		return gender;
	}

	/**
	 * @param gender
	 *            the gender to set
	 */
	public void setGender(String gender) {
		this.gender = gender;
	}

	/**
	 * @return the age
	 */
	public int getAge() {
		return age;
	}

	/**
	 * @param age
	 *            the age to set
	 */
	public void setAge(int age) {
		this.age = age;
	}

	/**
	 * @return the logoName
	 */
	public String getLogoName() {
		return logoName;
	}

	/**
	 * @param logoName the logoName to set
	 */
	public void setLogoName(String logoName) {
		this.logoName = logoName;
	}

	/**
	 * @return the city
	 */
	public String getCity() {
		return city;
	}

	/**
	 * @param city the city to set
	 */
	public void setCity(String city) {
		this.city = city;
	}

	/**
	 * @return the state
	 */
	public String getState() {
		return state;
	}

	/**
	 * @param state the state to set
	 */
	public void setState(String state) {
		this.state = state;
	}

	/**
	 * @return the campaignId
	 */
	public String getCampaignId() {
		return campaignId;
	}

	/**
	 * @param campaignId the campaignId to set
	 */
	public void setCampaignId(String campaignId) {
		this.campaignId = campaignId;
	}

	/**
	 * @return the pathLocation
	 */
	public String getPathLocation() {
		return pathLocation;
	}

	/**
	 * @param pathLocation the pathLocation to set
	 */
	public void setPathLocation(String pathLocation) {
		this.pathLocation = pathLocation;
	}

	/**
	 * @return the processedDate
	 */
	public String getProcessedDate() {
		return processedDate;
	}

	/**
	 * @param processedDate the processedDate to set
	 */
	public void setProcessedDate(String processedDate) {
		this.processedDate = processedDate;
	}

	/**
	 * @return the encryptedUId
	 */
	public String getEncryptedUId() {
		return encryptedUId;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	/**
	 * @param encryptedUId the encryptedUId to set
	 */
	public void setEncryptedUId(String encryptedUId) {
		this.encryptedUId = encryptedUId;
	}


	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Prospect [id=" + id + ", encryptedUId=" + encryptedUId
				+ ", firstName=" + firstName + ", lastName=" + lastName
				+ ", agencyName=" + agencyName + ", insuranceCompany="
				+ insuranceCompany + ", address=" + address + ", city=" + city
				+ ", state=" + state + ", zip=" + zip + ", phoneNumber="
				+ phoneNumber + ", email=" + email + ", videoUrl=" + videoUrl
				+ ", dob=" + dob + ", salutation=" + salutation + ", sentDate="
				+ sentDate + ", checkboxHits=" + checkboxHits
				+ ", landingpageHits=" + landingpageHits + ", campaignId="
				+ campaignId + ", pathLocation=" + pathLocation + ", upCreated="
				+ upCreated + ", navigationPage=" + navigationPage
				+ ", gender=" + gender + ", age=" + age + ", logoName="
				+ logoName + ", processedDate=" + processedDate
				+ ", minEstimate=" + minEstimate + ", secondMinEstimate="
				+ secondMinEstimate + ", password=" + password + "]";
	}


}
