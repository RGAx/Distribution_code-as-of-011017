package com.asg.selfservice.domain;

import org.springframework.stereotype.Component;

@Component
public class CustomerCallback {
	
	//TABLE: CUSTOMER_CALLBACK	
	
		 
		
		private String callbackphoneNumber;
		private String callBackDate;	
		private String getBackTime;	
	
		public String getCallbackphoneNumber() {
			return callbackphoneNumber;
		}
		public void setCallbackphoneNumber(String callbackphoneNumber) {
			this.callbackphoneNumber = callbackphoneNumber;
		}
		public String getCallBackDate() {
			return callBackDate;
		}
		public void setCallBackDate(String callBackDate) {
			this.callBackDate = callBackDate;
		}
		public String getGetBackTime() {
			return getBackTime;
		}
		public void setGetBackTime(String getBackTime) {
			this.getBackTime = getBackTime;
		}
		@Override
		public String toString() {
			
			return "CustomerCallback [ callbackphoneNumber=" + callbackphoneNumber + ", callBackDate="
					+ callBackDate + ", getBackTime=" + getBackTime
					+ "]";
		}
		
}