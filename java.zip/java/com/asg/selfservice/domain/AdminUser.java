package com.asg.selfservice.domain;

import java.util.Date;

public class AdminUser {
	private int userId;
	private String emailAddress;
	private String password;
	private int unsuccessfulAttemtCtr;
	private Date lastUnsuccessfulDate;
	private String createdBy;
	private Date createdDate;

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public String getEmailAddress() {
		return emailAddress;
	}

	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public int getUnsuccessfulAttemtCtr() {
		return unsuccessfulAttemtCtr;
	}

	public void setUnsuccessfulAttemtCtr(int unsuccessfulAttemtCtr) {
		this.unsuccessfulAttemtCtr = unsuccessfulAttemtCtr;
	}

	public Date getLastUnsuccessfulDate() {
		return lastUnsuccessfulDate;
	}

	public void setLastUnsuccessfulDate(Date lastUnsuccessfulDate) {
		this.lastUnsuccessfulDate = lastUnsuccessfulDate;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

}
