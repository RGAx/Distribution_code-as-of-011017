/**
 * 
 */
package com.asg.selfservice.domain;

import org.springframework.stereotype.Component;

/**
 * Defines UserApplicationDetail Model Class Attribute that Handles Application Begin Page details
 * @author M1029563
 *
 */
@Component
public class UserApplicationDetail {
	
		//Fields to Insert User data for Application begin in USER_QUESTION_ANSWER Table
		private String country;
		private String state;
		private String residencyStatus;
		private String grossIncome;
		private String reaInsurance;
		private String prefpaymentPeriod; 
		private String beneficiaryfullName;
		private String beneficiaryrelShip;
		private String beneficiaryPercentage;
		
		//Getter and setter Methods
		public String getCountry() {
			return country;
		}
		public void setCountry(String country) {
			this.country = country;
		}
		public String getState() {
			return state;
		}
		public void setState(String state) {
			this.state = state;
		}
		public String getResidencyStatus() {
			return residencyStatus;
		}
		public void setResidencyStatus(String residencyStatus) {
			this.residencyStatus = residencyStatus;
		}
		public String getGrossIncome() {
			return grossIncome;
		}
		public void setGrossIncome(String grossIncome) {
			this.grossIncome = grossIncome;
		}
		public String getReaInsurance() {
			return reaInsurance;
		}
		public void setReaInsurance(String reaInsurance) {
			this.reaInsurance = reaInsurance;
		}
		public String getPrefpaymentPeriod() {
			return prefpaymentPeriod;
		}
		public void setPrefpaymentPeriod(String prefpaymentPeriod) {
			this.prefpaymentPeriod = prefpaymentPeriod;
		}
		public String getBeneficiaryfullName() {
			return beneficiaryfullName;
		}
		public void setBeneficiaryfullName(String beneficiaryfullName) {
			this.beneficiaryfullName = beneficiaryfullName;
		}
		public String getBeneficiaryrelShip() {
			return beneficiaryrelShip;
		}
		public void setBeneficiaryrelShip(String beneficiaryrelShip) {
			this.beneficiaryrelShip = beneficiaryrelShip;
		}
		public String getBeneficiaryPercentage() {
			return beneficiaryPercentage;
		}
		public void setBeneficiaryPercentage(String beneficiaryPercentage) {
			this.beneficiaryPercentage = beneficiaryPercentage;
		}
		
		@Override
		public String toString() {
			return "UserApplicationDetail [country=" + country + ", state=" + state
					+ ", residencyStatus=" + residencyStatus + ", grossIncome="
					+ grossIncome + ", reaInsurance=" + reaInsurance
					+ ", prefpaymentPeriod=" + prefpaymentPeriod
					+ ", beneficiaryfullName=" + beneficiaryfullName
					+ ", beneficiaryrelShip=" + beneficiaryrelShip
					+ ", beneficiaryPercentage=" + beneficiaryPercentage + "]";
		}
}
