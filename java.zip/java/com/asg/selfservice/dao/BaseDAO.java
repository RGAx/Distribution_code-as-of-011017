package com.asg.selfservice.dao;

import org.springframework.jdbc.core.JdbcTemplate;

/**
 * This class has been used as superclass dao layer which can be extended from
 * other dao interfaces.
 * 
 * @author M1030133
 *
 */
public interface BaseDAO {
	public void setJdbcTemplate(JdbcTemplate jdbcTemplate);
}
