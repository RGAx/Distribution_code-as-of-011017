package com.asg.selfservice.dao;

import java.util.List;

import com.asg.selfservice.domain.CampaignReport;
import com.asg.selfservice.domain.Prospect;
import com.asg.selfservice.domain.UserProfile;
import com.asg.selfservice.exception.DAOException;

public interface ProspectDAO {

	public Prospect getProspectData(String encryptedUId) throws DAOException;
	
	public List<Integer> getPriceData(String gender, int age) throws DAOException;
	
	public void updateLandingPageHits(int landingPageHits, int id) throws DAOException;
	
	public void updateCheckboxHits(int checkboxHits, int userID) throws DAOException;
	
	public void insertIntoUserProfile(Prospect prospect) throws DAOException;
	
	public List<String> getListOfAgencies() throws DAOException;
	
	public List<Prospect> getListOfCheckboxHitRecords() throws DAOException;

	public int getUserProfileData(String encryptedUId) throws DAOException;

	public UserProfile loadUserProfileBasedEncryptedUID(String encryptedUId) throws DAOException;

	public List<Prospect> getUserHistory(String agencyName, String processedDate) throws DAOException;

	public List<CampaignReport> getCampaignreport() throws DAOException;
	
}
