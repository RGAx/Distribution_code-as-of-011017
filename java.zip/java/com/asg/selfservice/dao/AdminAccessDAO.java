package com.asg.selfservice.dao;

import java.util.List;

import com.asg.selfservice.domain.UserDetails;
import com.asg.selfservice.domain.UserProfile;
import com.asg.selfservice.exception.DAOException;

/**
 * Used for defining the load users method which is implemented in impl class.
 * 
 * @author M1030133
 *
 */
public interface AdminAccessDAO extends BaseDAO {

	public List<UserDetails> loadUsers(String emailAddress) throws DAOException;

	public UserProfile loadAdminUser(String emailAddress) throws DAOException;

}
