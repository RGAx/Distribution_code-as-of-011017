/**
 * 
 */
package com.asg.selfservice.dao;

import com.asg.selfservice.exception.DAOException;

/**
 * This interface has been used for defining the methods for user operations
 * such as laoding the user profile, updating the counter for unsuccessful login
 * attempts, verifying the presence of the user in the database which have been
 * implemented in LoginDAOImpl class.
 * 
 * @author M1030133
 *
 */
public interface LoginDAO extends BaseDAO {
	public void updateCounter(int count, String email) throws DAOException;

	public boolean isUserExists(String userName) throws DAOException;

	public void updateAdminCounter(int count, String email) throws DAOException;
}
