package com.asg.selfservice.dao;

import java.util.List;

import com.asg.selfservice.domain.QuestionAnswer;
import com.asg.selfservice.domain.UserProfile;
import com.asg.selfservice.exception.DAOException;

/**
 * This class has been used to define the question answer related operations
 * such as loading the questions from the db, saving/updating the answers into
 * the db and deleting the answers from the db if not required etc.
 * 
 * @author M1030133
 *
 */
public interface QuestionAnswerDAO extends BaseDAO {
	public List<QuestionAnswer> loadQuestionAnswerPerPage(int userId, int qsetId)
			throws DAOException;

	public QuestionAnswer loadQuestionAnswer(int userId, int qId)
			throws DAOException;

	public void saveUpdateInfo(UserProfile user, QuestionAnswer questAns)
			throws DAOException;

	public void deleteAnswer(UserProfile user, QuestionAnswer questAns)
			throws DAOException;

	public void deleteAnswers(UserProfile user, Integer[] qIds)
			throws DAOException;

	public List<QuestionAnswer> loadQuestionAnswersForPinney(int userId)
			throws DAOException;

	public List<QuestionAnswer> loadQuestionAnswersForEBIX(int userId)
			throws DAOException;

	public Integer[] loadQuestionIdsBasedQSetId(int userId, int qsetId)
			throws DAOException;

	public List<UserProfile> getPinneyFailedSubmission() throws DAOException;
}
