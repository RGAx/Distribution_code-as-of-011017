package com.asg.selfservice.dao;

import com.asg.selfservice.domain.Quote;
import com.asg.selfservice.domain.UserProfile;
import com.asg.selfservice.exception.DAOException;

/**
 * This interface has been used for defining the operations for quote page which
 * have been implemented in the QuoteDAOImpl class.
 * 
 * @author M1030133
 *
 */
public interface QuoteDAO extends BaseDAO {
	public void updatePolicy(UserProfile userProfile) throws DAOException;

	public Quote getQuote(int userId) throws DAOException;

	public void insertQuote(Quote quote) throws DAOException;

	public void updateQuote(Quote quote) throws DAOException;
	
	public void deleteSavedQuoteafterpinneySubmitWithEmptyQuote(int userId) throws DAOException;
}
