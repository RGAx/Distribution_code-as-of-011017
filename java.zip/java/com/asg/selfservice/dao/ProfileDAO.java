package com.asg.selfservice.dao;

import java.util.List;

import com.asg.selfservice.domain.UserProfile;
import com.asg.selfservice.exception.DAOException;

/**
 * This interface has been used to define all the profile related operations
 * such as loading the user profile based on the email address, loading the user
 * profile based on the user id etc.
 * 
 * @author M1030133
 *
 */
public interface ProfileDAO extends BaseDAO {
	public UserProfile loadUserProfileByEmail(String emailAddress)
			throws DAOException;

	public UserProfile loadUserProfileById(int userId) throws DAOException;

	public void updateUserProfileInitialMonthlyEstimate(UserProfile userProfile)
			throws DAOException;

	public void updateUserProfileWithPassword(UserProfile userProfile)
			throws DAOException;

	public void updateUserProfilePassword(UserProfile userProfile)
			throws DAOException;

	public void updateUserProfileStatus(UserProfile userProfile)
			throws DAOException;

	public List<UserProfile> getuserDetails() throws DAOException;

	public void updateUserProfileInfo(UserProfile userProfile)
			throws DAOException;

	public void updateUserProfileWithHealthDetails(UserProfile userProfile)
			throws DAOException;
	
	public List<UserProfile> getUserProfilesForStatus1()throws DAOException;

	public List<UserProfile> getUserProfilesForStatus2() throws DAOException;

	public void updateUserProfileStatusWithAdminCheck(UserProfile userProfile,
			boolean adminUserFlag) throws DAOException;

	public int loadProfileStatusFlag(int userId) throws DAOException;
	
}
