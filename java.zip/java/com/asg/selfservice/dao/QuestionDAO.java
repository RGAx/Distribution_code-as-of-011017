package com.asg.selfservice.dao;

import java.util.List;
import java.util.Map;

import com.asg.selfservice.domain.Question;
import com.asg.selfservice.exception.DAOException;

/**
 * This interface has been used to define the operations such as loading the
 * questions from the DB.
 * 
 * @author M1030133
 *
 */
public interface QuestionDAO extends BaseDAO {
	public List<Question> loadQuestions() throws DAOException;

	public Map<Integer, List<Integer>> loadReflexiveQuestions()
			throws DAOException;
}
