package com.asg.selfservice.dao;

import com.asg.selfservice.domain.CustomerCallback;
import com.asg.selfservice.domain.UserProfile;
import com.asg.selfservice.exception.DAOException;

public interface CustomerCallBackDAO extends BaseDAO {
	
	public boolean saveCustomerCallBackDetailsInfo(CustomerCallback callBack, UserProfile userProfile) throws DAOException;
	public CustomerCallback getUserDetails(int user) throws DAOException;

}
