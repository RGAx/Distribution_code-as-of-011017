package com.asg.selfservice.dao;

import java.util.List;

import com.asg.selfservice.domain.Answer;
import com.asg.selfservice.exception.DAOException;

/**
 * This class has been used for defining the default answer related operations
 * such as loading the answers etc from the DB.
 * 
 * @author M1030133
 *
 */
public interface AnswerDAO extends BaseDAO {
	public List<Answer> loadAnswers() throws DAOException;
}
