package com.asg.selfservice.dao.impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.springframework.dao.DataAccessException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.asg.selfservice.common.logger.LogFactory;
import com.asg.selfservice.common.logger.SelfServiceLogger;
import com.asg.selfservice.common.utils.ApplicationConstants;
import com.asg.selfservice.common.utils.QueryConstants;
import com.asg.selfservice.common.utils.Utils;
import com.asg.selfservice.dao.ProspectDAO;
import com.asg.selfservice.domain.CampaignReport;
import com.asg.selfservice.domain.Prospect;
import com.asg.selfservice.domain.UserProfile;
import com.asg.selfservice.exception.DAOException;

/**
 * This class has been used to implement all the db operations such as loading the 
 * prospect details based on encryptedUId, loading the user profile based on encryptedUId,
 * inserting the user profile details into the db, 
 * To get price data, Update Landing Page Hits, To update CheckboxHits, and
 * To get the List of CheckboxHitRecords.
 */
@Repository
public class ProspectDAOImpl implements ProspectDAO {
	
	private static final SelfServiceLogger logger = LogFactory.getInstance(ProspectDAOImpl.class);
	
	private JdbcTemplate jdbcTemplate;
	
	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {  
	    this.jdbcTemplate = jdbcTemplate;  
	}
	
	/*
	 * This method has been used to fetch prospect details based on encryptedUId.
	 */
	public Prospect getProspectData(String encryptedUId) throws DAOException {
		// using RowMapper anonymous class, we can create a separate RowMapper
		// for reuse
		Prospect prospect = null;
		logger.info("Loading prospect details for..: encryptedUId" +encryptedUId);
		try {
			prospect = jdbcTemplate.queryForObject(
					QueryConstants.GET_PROSPECT_DETAILS,
					new Object[] { encryptedUId }, new RowMapper<Prospect>() {

						public Prospect mapRow(ResultSet rs, int rowNum)
								throws SQLException {
							Prospect prospect = new Prospect();
							prospect.setId(rs.getInt("UNIQUE_ID"));
							prospect.setEncryptedUId(rs.getString("ENCRYPTED_UID"));
							prospect.setFirstName(rs.getString("FIRST_NAME"));
							prospect.setLastName(rs.getString("LAST_NAME"));
							prospect.setInsuranceCompany(rs.getString("INSURANCE_COMPANY"));
							prospect.setAddress(rs.getString("ADDRESS_1"));
							prospect.setCity(rs.getString("ADDRESS_CITY"));
							prospect.setState(rs.getString("ADDRESS_STATE"));
							prospect.setZip(rs.getString("Zip_Code"));
							prospect.setPhoneNumber(rs.getString("PHONE_NUMBER"));
							prospect.setAgencyName(rs.getString("AGENCY_NAME"));
							prospect.setEmail(rs.getString("EMAIL_ADDRESS"));
							prospect.setVideoUrl(rs.getString("VIDEO_URL"));
							prospect.setDob(rs.getString("DOB"));
							prospect.setSalutation(rs.getString("SALUTATION"));
							prospect.setCheckboxHits(rs.getInt("CHECKBOX_CTR"));
							prospect.setLandingpageHits(rs.getInt("LANDING_PAGE_CTR"));
							prospect.setSentDate(rs.getString("INITIAL_SENT_DATE"));
							prospect.setCampaignId(rs.getString("CAMPAIGN_ID"));
							prospect.setPathLocation(rs.getString("PATH_LOC"));

							return prospect;
						}
					});
		} catch (EmptyResultDataAccessException e) {
			logger.error("ERROR : " + e.getMessage());
			return null;
		} catch (DataAccessException e) {
			logger.error("ERROR : " + e.getMessage());
			throw new DAOException(e.getMessage());
		}
		return prospect;
	}
        
	/*
	 * This method has been used to fetch price data based on gender and age.
	 */
	public List<Integer> getPriceData(String gender, int age) throws DAOException {
		logger.info("Fetching price data for gender : "+gender +"and age : " +age);
		List<Integer> minValues = new ArrayList<Integer>();
		Object[] args = new Object[] {gender, age};
		try {
			List<Map<String, Object>> listOfObjs = jdbcTemplate.queryForList(QueryConstants.PRICE_QUOTE_FOR_PROSPECT, args);
			for(Map<String, Object> obj : listOfObjs) {
				minValues.add(Integer.parseInt(String.valueOf(obj.get("ESTIMATE_MIN"))));
			}
		} catch (EmptyResultDataAccessException e) {
			logger.error("ERROR : " + e.getMessage());
			return null;
		} catch (DataAccessException e) {
			logger.error("ERROR : " + e.getMessage());
			throw new DAOException(e.getMessage());
			
		} catch (NumberFormatException e) {
			logger.error("ERROR : " + e.getMessage());
			throw new DAOException(e.getMessage());
		}
		return minValues;
	}

	/*
	 * This method has been used to update landingPageHits count for the userId of the prospect.
	 */
	public void updateLandingPageHits(int landingPageHits, int userId) throws DAOException {
		logger.info("Updating landing page count for userID : " +userId);
		Object[] args = new Object[] {landingPageHits, ""+userId};
		
		int out = 0;
		try {
			 out = jdbcTemplate.update(QueryConstants.UPDATE_LANDING_PAGE_CTR, args);
		} catch (DataAccessException e) {
			logger.error("ERROR : " + e.getMessage());
			throw new DAOException(e.getMessage());
		}
		if(out !=0){
            logger.info("Prospect details updated with userId="+userId);
        } else {
        	logger.info("No prospect found with userId="+userId);
        }
        
	}

	/*
	 * This method has been used to update checkboxHits count for the userId of the prospect.
	 */
	public void updateCheckboxHits(int checkboxHits, int userID) throws DAOException {
		logger.info("Updating checkbox hits count for userID : " +userID);
		Object[] args = new Object[] {checkboxHits, ""+userID};
		
		int out = 0;
		try {
			 out = jdbcTemplate.update(QueryConstants.UPDATE_CHECKBOX_CTR, args);
		} catch (DataAccessException e) {
			logger.error("ERROR : " + e.getMessage());
			throw new DAOException(e.getMessage());
		}
		
		if(out !=0){
            logger.info("Prospect details updated with userId="+userID);
        } else {
        	logger.info("No prospect found with userId="+userID);
        }
	}

	/*
	 * This method returns User Profile Status Flag based on encryptedUId.
	 */
	public int getUserProfileData(String encryptedUId) throws DAOException {
		logger.info("Getting user profile status for encryptedUId : " +encryptedUId);
		// using RowMapper anonymous class, we can create a separate RowMapper for reuse
			int userProfileFlag;
			try {
				userProfileFlag = jdbcTemplate.queryForObject(
					QueryConstants.GET_USERPROFILE_CREATED, new Object[] { encryptedUId }, new RowMapper<Integer>() {

						public Integer mapRow(ResultSet rs, int rowNum) throws SQLException {
							int upCreated = (rs.getInt("PROFILE_STATUS_FLAG"));
					 		return upCreated;
					 	}
					});
			} catch(EmptyResultDataAccessException e) {
				logger.error("ERROR : " + e.getMessage());
				return ApplicationConstants.USER_PROFILE_NOT_CREATED;
			} catch (DataAccessException e) {
				logger.error("ERROR : " + e.getMessage());
				throw new DAOException(e.getMessage());
			}
			return userProfileFlag;
	}

	/*
	 * This method inserts Prospect details into USER_PROFILE table.
	 */
	public void insertIntoUserProfile(Prospect prospect) throws DAOException {
		logger.info("Inserting prospect details into user profile");
		String monthlyEstimate = "$"+prospect.getMinEstimate()+"-$"+ prospect.getSecondMinEstimate();
		Object[] args = null;
		DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
		int out = 0;
		
		try {
			if(prospect.getCampaignId() != null && prospect.getCampaignId() != "") {
			
				int campaignID = Integer.parseInt(prospect.getCampaignId());
				args = new Object[] {prospect.getEncryptedUId(), campaignID, prospect.getSalutation(), prospect.getFirstName(), prospect.getLastName(), new java.sql.Date(dateFormat.parse(prospect.getDob()).getTime()),
					prospect.getAddress(), prospect.getCity(), prospect.getState(), prospect.getZip(), prospect.getPhoneNumber(), prospect.getEmail(),"xyz",
					0, new java.sql.Timestamp(new Date().getTime()), monthlyEstimate, ApplicationConstants.COVERAGE, ApplicationConstants.TERM, new java.sql.Timestamp(new Date().getTime()), 
					new java.sql.Timestamp(new Date().getTime()), prospect.getFirstName(), new java.sql.Timestamp(new Date().getTime()), prospect.getFirstName(), prospect.getGender(), prospect.getLogoName(), prospect.getAgencyName()};
			} else {
				args = new Object[] {prospect.getEncryptedUId(), 0, prospect.getSalutation(), prospect.getFirstName(), prospect.getLastName(), new java.sql.Date(dateFormat.parse(prospect.getDob()).getTime()),
						prospect.getAddress(), prospect.getCity(), prospect.getState(), prospect.getZip(), prospect.getPhoneNumber(), prospect.getEmail(),"xyz",
						0, new java.sql.Timestamp(new Date().getTime()), monthlyEstimate, ApplicationConstants.COVERAGE, ApplicationConstants.TERM, new java.sql.Timestamp(new Date().getTime()), 
						new java.sql.Timestamp(new Date().getTime()), prospect.getFirstName(), new java.sql.Timestamp(new Date().getTime()), prospect.getFirstName(), prospect.getGender(), prospect.getLogoName(), prospect.getAgencyName()};
			}
			 out = jdbcTemplate.update(QueryConstants.INSERT_INTO_USER_PROFILE, args);
		} catch (ParseException e) {
			logger.error("ERROR : " + e.getMessage());
			throw new DAOException(e.getMessage());
		} catch (DataAccessException e) {
			logger.error("ERROR : " + e.getMessage());
			throw new DAOException(e.getMessage());
		}
		
		if(out !=0){
            logger.info("User Profile details inserted with encryptedUserID="+prospect.getEncryptedUId());
        } else {
        	logger.info("No prospect found with encryptedUserID="+prospect.getEncryptedUId());
        }
	}

	/*
	 * This method returns list of all the agency names concatenated with Processed Date.
	 */
	public List<String> getListOfAgencies() throws DAOException {
		logger.info("Getting list of agency names and processed dates");
		List<String> listOfAgencies = new ArrayList<String>();
		try {
			List<Map<String, Object>> listOfObjs = jdbcTemplate.queryForList(QueryConstants.GET_AGENCY_NAMES);
			String processedDate = null;
			String agencyName = null;
			
			for(Map<String, Object> obj : listOfObjs) {
				
				agencyName = String.valueOf(obj.get("AGENCY_NAME"));
				processedDate = String.valueOf(obj.get("PROCESSEDDATE"));
				
				if(processedDate.contains(".")){
					processedDate = processedDate.substring(0, processedDate.indexOf(".")); 
				}
				//Date date = ApplicationConstants.TIMEFORMATTER.parse(processedDate);
				//String formattedProcessedDate = ApplicationConstants.TIMEFORMATTER.format(date);
				
				listOfAgencies.add(agencyName+"_"+processedDate);
			}
		} catch (EmptyResultDataAccessException e) {
			logger.error("ERROR : " + e.getMessage());
			return null;
		}  /*catch (ParseException e) {
			logger.error("ERROR : " + e.getMessage());
			throw new DAOException(e.getMessage());
		}*/ catch (DataAccessException e) {
			logger.error("ERROR : " + e.getMessage());
			throw new DAOException(e.getMessage());
		}
		return listOfAgencies;
	}

	/*
	 * This method will hit the DB to fetch the list of Records based on agencyName.
	 * 
	 * */
	public List<Prospect> getUserHistory(String agencyName, String processedDate) throws DAOException {
		logger.info("Getting checkbox hit report based on the selected agency name");
		List<Prospect> usersOfAgency = new ArrayList<Prospect>();
		
		Object[] args = new Object[] {agencyName, processedDate};
		
		try {
			List<Map<String, Object>> listOfUsers = jdbcTemplate.queryForList(QueryConstants.GET_USER_HISTORY, args);
			for (Map<String, Object> obj : listOfUsers) {
				Prospect pros = new Prospect();
				pros.setEncryptedUId(String.valueOf(obj.get("ENCRYPTED_UID")));
				pros.setFirstName(String.valueOf(obj.get("FIRST_NAME")));
				pros.setLastName(String.valueOf(obj.get("LAST_NAME")));
				pros.setAgencyName(String.valueOf(obj.get("AGENCY_NAME")));
				pros.setCheckboxHits(Integer.parseInt(String.valueOf(obj.get("CHECKBOX_CTR"))));
				pros.setEmail(String.valueOf(obj.get("EMAIL_ADDRESS")));
				usersOfAgency.add(pros);
			}
		} catch (EmptyResultDataAccessException e) {
			logger.error("ERROR : " + e.getMessage());
			return null;
		} catch (DataAccessException e) {
			logger.error("ERROR : " + e.getMessage());
			throw new DAOException(e.getMessage());
		} catch (NumberFormatException e) {
			logger.error("ERROR : " + e.getMessage());
			throw new DAOException(e.getMessage());
		}
		return usersOfAgency;
	}

	/*
	 * This method will hit the DB to fetch the list of Records with CheckBoxHits > 0.
	 * 
	 * */
	public List<Prospect> getListOfCheckboxHitRecords() throws DAOException {
		logger.info("Getting checkbox hit report of all the records with CheckBoxHits > 0");
		List<Prospect> listOfAgencies = new ArrayList<Prospect>();
		try {
			List<Map<String, Object>> listOfObjs = jdbcTemplate.queryForList(QueryConstants.GET_CHECKBOX_HITS_REPORT);
			for(Map<String, Object> obj : listOfObjs) {
				Prospect pros = new Prospect();
				pros.setEncryptedUId(String.valueOf(obj.get("ENCRYPTED_UID")));
				pros.setFirstName(String.valueOf(obj.get("FIRST_NAME")));
				pros.setLastName(String.valueOf(obj.get("LAST_NAME")));
				pros.setAgencyName(String.valueOf(obj.get("AGENCY_NAME")));
				pros.setCheckboxHits(Integer.parseInt(String.valueOf(obj.get("CHECKBOX_CTR"))));
				pros.setEmail(String.valueOf(obj.get("EMAIL_ADDRESS")));
				
				listOfAgencies.add(pros);
			}
		} catch (EmptyResultDataAccessException e) {
			logger.error("ERROR : " + e.getMessage());
			return null;
		} catch (DataAccessException e) {
			logger.error("ERROR : " + e.getMessage());
			throw new DAOException(e.getMessage());
		} catch (NumberFormatException e) {
			logger.error("ERROR : " + e.getMessage());
			throw new DAOException(e.getMessage());
		}
		return listOfAgencies;
	}

	public UserProfile loadUserProfileBasedEncryptedUID(String encryptedUId) throws DAOException {
		// using RowMapper anonymous class, we can create a separate RowMapper
		// for reuse
		final SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");
		UserProfile userProfile;
		try {
			userProfile = jdbcTemplate.queryForObject(
					QueryConstants.USER_PROFILE_DETAILS_BASED_ENCRYPTED_ID,
					new Object[] { encryptedUId }, new RowMapper<UserProfile>() {

						public UserProfile mapRow(ResultSet rs, int rowNum) throws SQLException {
							UserProfile userProfile = new UserProfile();
							userProfile.setUserId(rs.getInt("USER_ID"));
							userProfile.setInsuranceCoverage(rs.getString("INSURANCE_COVERAGE"));
							userProfile.setInsuranceTerm(rs.getInt("INSURANCE_TERM"));

							if (rs.getDate("DOB") != null) {
								userProfile.setDob(rs.getDate("DOB"));
							}
							if (userProfile.getDob() != null) {
								userProfile.setDateTemp(formatter.format(userProfile.getDob()));
							}

							userProfile.setAddressState(rs.getString("ADDRESS_STATE"));
							userProfile.setFirstName(rs.getString("FIRST_NAME"));
							userProfile.setLastName(rs.getString("LAST_NAME"));
							userProfile.setEmailAddress(rs.getString("EMAIL_ADDRESS"));
							String phoneNumber = rs.getString("PHONE_NUMBER");
							if(phoneNumber != null) {
								phoneNumber = Utils.phoneNumberFormat(phoneNumber);
							}
							userProfile.setPhoneNumber(phoneNumber);
							userProfile.setPinneyQuoteStatus(rs.getString("PINNEY_QUOTE_STATUS"));
							userProfile.setInitialMonthlyEstimate(rs.getString("INITIAL_MONTHLY_ESTIMATE"));
							userProfile.setPassword(rs.getString("PASSWORD"));
							userProfile.setGender(rs.getString("GENDER"));
							userProfile.setAgencyLogo(rs.getString("AGENCY_LOGO"));
							userProfile.setProfileStatusFlag(rs.getInt("PROFILE_STATUS_FLAG"));
							userProfile.setAgency_name(rs.getString("AGENCY_NAME"));
							userProfile.setCampaignId(rs.getString("CAMPAIGN_ID"));

							return userProfile;
						}
					});
		} catch (EmptyResultDataAccessException e) {
			logger.error("ERROR : " + e.getMessage());
			return null;
		} catch (DataAccessException e) {
			logger.error("ERROR : " + e.getMessage());
			throw new DAOException(e.getMessage());
		}
		return userProfile;
	}

	/*
	 * This method is used for fetching the Campaign & Pinney Report.
	 */
	@Override
	public List<CampaignReport> getCampaignreport() throws DAOException {
		logger.info("Fetching campaign and pinney report");
		List<CampaignReport> report = new ArrayList<CampaignReport>();
		
		try {
			
			List<Map<String, Object>> listOfReports = jdbcTemplate.queryForList(QueryConstants.GET_CAMPAIGN_REPORT);
			String processedDate = null;
			
			for (Map<String, Object> obj : listOfReports) {
				CampaignReport reportObj = new CampaignReport();
				
				processedDate = String.valueOf(obj.get("PROCESSEDDATE"));
				
				if(processedDate.contains(".")) {
					processedDate = processedDate.substring(0, processedDate.indexOf(".")); 
				}
				reportObj.setCampaigndate(processedDate);
				reportObj.setCampaignId(String.valueOf(obj.get("CAMPAIGN_ID")));
				reportObj.setAgencyName(String.valueOf(obj.get("AGENCY_NAME")));
				reportObj.setApplynowCount(String.valueOf(obj.get("USERS_CLICKED_ON_APPLY_NOW")));
				reportObj.setMidwayCount(String.valueOf(obj.get("USERS_LEFT_APPLICATION")));
				reportObj.setDiffcoverageCount(String.valueOf(obj.get("USERS_DIFF_COVERAGE_TERM")));
				reportObj.setCreatedprofCount(String.valueOf(obj.get("PROFILE_CREATED")));
				reportObj.setSubmittedCount(String.valueOf(obj.get("USERS_SUBMITTED_APPLICATION")));
				reportObj.setCampaignSize(String.valueOf(obj.get("CAMPAIGN_SIZE")));
				
				report.add(reportObj);
			}
		} catch (EmptyResultDataAccessException e) {
			logger.error("ERROR : " + e.getMessage());
			return null;
		} catch (DataAccessException e) {
			logger.error("ERROR : " + e.getMessage());
			throw new DAOException(e.getMessage());
		} catch (NumberFormatException e) {
			logger.error("ERROR : " + e.getMessage());
			throw new DAOException(e.getMessage());
		}
		
		return report;
	}
}


	
