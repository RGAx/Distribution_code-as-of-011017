package com.asg.selfservice.dao.impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;

import org.springframework.dao.DataAccessException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.asg.selfservice.common.logger.LogFactory;
import com.asg.selfservice.common.logger.SelfServiceLogger;
import com.asg.selfservice.common.utils.QueryConstants;
import com.asg.selfservice.dao.QuoteDAO;
import com.asg.selfservice.domain.Quote;
import com.asg.selfservice.domain.UserProfile;
import com.asg.selfservice.exception.DAOException;

/**
 * This class has been used for implementing the Quote operations such as updating the 
 * policy info, getting the quote based on the user id and saving/updating the quote
 * into the DB etc..
 * 
 * @author M1030133
 *
 */
public class QuoteDAOImpl implements QuoteDAO {
	private static final SelfServiceLogger logger = LogFactory.getInstance(QuoteDAOImpl.class);
	
	private JdbcTemplate jdbcTemplate;  
	  
	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {  
	    this.jdbcTemplate = jdbcTemplate;  
	} 
	
	/*
	 * This method has been used for updating the user policy info into the database.
	 * 
	 * @see com.asg.selfservice.dao.QuoteDAO#updatePolicy(com.asg.selfservice.domain.UserProfile)
	 */
	public void updatePolicy(UserProfile userProfile) throws DAOException {
		final long startTime = logger.logMethodEntry();
		
		Object[] args = new Object[] { userProfile.getInsuranceCoverage(),
				userProfile.getInsuranceTerm(),new java.sql.Date((new Date()).getTime()),userProfile.getUserId() };
         
        int out;
		try {
			out = jdbcTemplate.update(QueryConstants.UPDATE_POLICY, args);
		} catch(DataAccessException e) {
			logger.error("ERROR : "+e.getMessage());
			throw new DAOException(e.getMessage());
		}
        if(out !=0){
            logger.info("User policy updated with id="+userProfile.getUserId());
            logger.logMethodExit(startTime);
        } else {
        	logger.info("No user found with id="+userProfile.getUserId());
        	logger.logMethodExit(startTime);
        }
	}
	
	/*
	 * This method has been used for getting the quote based on the user id from the DB.
	 * 
	 * @see com.asg.selfservice.dao.QuoteDAO#getQuote(int)
	 */
	public Quote getQuote(int userId) throws DAOException {
		final long startTime = logger.logMethodEntry();
		try {
			Quote quote = jdbcTemplate.queryForObject(QueryConstants.GET_QUOTE, new Object[] { userId },
					new RowMapper<Quote>() {
						public Quote mapRow(ResultSet rs, int rowNum)
								throws SQLException {
							Quote quote = new Quote();
							quote.setQuoteId(rs.getInt("PRODUCT_QUOTE_ID"));
							quote.setUserId(rs.getInt("USER_ID"));
							quote.setProductName(rs.getString("PRODUCT_NAME"));
							quote.setPolicyName(rs.getString("POLICY_NAME"));
							quote.setHealthCategory(rs.getString("HEALTH_CATEGORY"));
							quote.setAnnualPremium(rs.getString("ANNUAL_PREMIUM"));
							quote.setMonthlyPremium(rs.getString("MONTHLY_PREMIUM"));
							quote.setAmbestRating(rs.getString("AMBEST_RATING"));
							quote.setCompanyName(rs.getString("COMPANY_NAME"));
							quote.setCompanyLogo(rs.getString("COMPANY_LOGO"));
							return quote;
						}
					});
			logger.info("--QUOTE DETAILS FOR userId--" + userId + "::" + quote);
			logger.logMethodExit(startTime);
			return quote;
		} catch(EmptyResultDataAccessException e) {
			logger.error("ERROR : "+e.getMessage());
			return null;
		} catch(DataAccessException e) {
			logger.error("ERROR : "+e.getMessage());
			throw new DAOException(e.getMessage());
		}
	}

	/*
	 * Inserting the quote info into the DB.
	 * 
	 * @see com.asg.selfservice.dao.QuoteDAO#insertQuote(com.asg.selfservice.domain.Quote)
	 */
	public void insertQuote(Quote quote) throws DAOException {
		final long startTime = logger.logMethodEntry();
		
		Object[] args = new Object[] {quote.getUserId(), quote.getProductName(), quote.getPolicyName(), quote.getHealthCategory(), 
				quote.getAnnualPremium(), quote.getMonthlyPremium(), quote.getAmbestRating(), quote.getCompanyName(), quote.getCompanyLogo(), 
				new java.sql.Date((new Date()).getTime()), quote.getCreatedBy()};
         
        int out;
		try {
			out = jdbcTemplate.update(QueryConstants.INSERT_QUOTE, args);
		} catch(DataAccessException e) {
			logger.error("ERROR : "+e.getMessage());
			throw new DAOException(e.getMessage());
		}
        if(out !=0){
            logger.info("Quote inserted for user id="+quote.getUserId());
            logger.logMethodExit(startTime);
        } else {
        	logger.info("Insertion un-successful");
        	logger.logMethodExit(startTime);
        }
	}
	
	/*
	 * Updating the Quote info into the DB.
	 * @see com.asg.selfservice.dao.QuoteDAO#updateQuote(com.asg.selfservice.domain.Quote)
	 */
	public void updateQuote(Quote quote) throws DAOException {
		final long startTime = logger.logMethodEntry();
		
		Object[] args = new Object[] {quote.getProductName(), quote.getPolicyName(), quote.getHealthCategory(), 
				quote.getAnnualPremium(), quote.getMonthlyPremium(), quote.getAmbestRating(), quote.getCompanyName(), quote.getCompanyLogo(), 
				new java.sql.Date((new Date()).getTime()), quote.getUpdatedBy(), quote.getQuoteId()};
         
        int out;
		try {
			out = jdbcTemplate.update(QueryConstants.UPDATE_QUOTE, args);
		} catch(DataAccessException e) {
			logger.error("ERROR : "+e.getMessage());
			throw new DAOException(e.getMessage());
		}
        if(out !=0){
            logger.info("Quote updated with id="+quote.getQuoteId());
            logger.logMethodExit(startTime);
        } else {
        	logger.info("No quote found with id="+quote.getQuoteId());
        	logger.logMethodExit(startTime);
        }
	}

	/* (non-Javadoc)
	 * Used to delete the Previous Saved quote from the PRODUCT_QUOTE TABLE if user submits the APPLICATION or PINNEY with no Quotes displayed in the Quote Page.
	 * @see com.asg.selfservice.dao.QuoteDAO#deleteSavedQuoteafterpinneySubmitWithEmptyQuote(int)
	 */
	@Override
	public void deleteSavedQuoteafterpinneySubmitWithEmptyQuote(int userId) throws DAOException {
		
		Object[] args = new Object[] {userId};
		final long startTime = logger.logMethodEntry();
		int out;
		try {
			out = jdbcTemplate.update(QueryConstants.DELETE_PREVSAVED_QUOTE, args);
		} catch(DataAccessException e) {
			logger.error("ERROR : "+e.getMessage());
			throw new DAOException(e.getMessage());
		}
        if(out !=0){
            logger.info("Quote Deleted with id="+userId);
            logger.logMethodExit(startTime);
        } else {
        	logger.info("No quote found with the id="+userId);
        	logger.logMethodExit(startTime);
        }
		
	}
}
