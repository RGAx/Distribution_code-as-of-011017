package com.asg.selfservice.dao.impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.springframework.dao.DataAccessException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.asg.selfservice.common.logger.LogFactory;
import com.asg.selfservice.common.logger.SelfServiceLogger;
import com.asg.selfservice.common.utils.ApplicationConstants;
import com.asg.selfservice.common.utils.QueryConstants;
import com.asg.selfservice.common.utils.Utils;
import com.asg.selfservice.dao.ProfileDAO;
import com.asg.selfservice.domain.UserProfile;
import com.asg.selfservice.exception.DAOException;

/**
 * This class has been used to implement all the profile related operations
 * such as loading the user profile based on the email address, loading the user
 * profile based on the user id etc.
 * 
 * @author M1030133
 *
 */
public class ProfileDAOImpl implements ProfileDAO {
	private static final SelfServiceLogger logger = LogFactory.getInstance(ProfileDAOImpl.class);
	
	private JdbcTemplate jdbcTemplate;

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}  
	
	/*
	 * This method has been used to load the user profile complete details based
	 * on the email address.
	 * 
	 * @see com.asg.selfservice.dao.ProfileDAO#loadUserProfileByEmail(java.lang.String
	 * )
	 */
	public UserProfile loadUserProfileByEmail(String emailAddress) throws DAOException {
		final long startTime = logger.logMethodEntry();
		UserProfile userProfile;
		try {
			userProfile = jdbcTemplate.queryForObject(QueryConstants.LOAD_USER_PROFILE_BY_EMAIL,
					new Object[] { emailAddress }, new RowMapper<UserProfile>() {

						public UserProfile mapRow(ResultSet rs, int rowNum) throws SQLException {
							UserProfile userProfile = new UserProfile();
							userProfile.setUserId(rs.getInt("USER_ID"));
							userProfile.setEncryptedUid(rs.getString("ENCRYPTED_UID"));
							userProfile.setCampaignId(rs.getString("CAMPAIGN_ID"));
							userProfile.setSalutation(rs.getString("SALUTATION"));
							
							userProfile.setFirstName(rs.getString("FIRST_NAME"));
							userProfile.setLastName(rs.getString("LAST_NAME"));
							
							userProfile.setDob(rs.getDate("DOB"));
							userProfile.setAddress1(rs.getString("ADDRESS_1"));
							userProfile.setAddressCity(rs.getString("ADDRESS_CITY"));
							userProfile.setAddressState(rs.getString("ADDRESS_STATE"));
							userProfile.setZipCode(rs.getString("ZIP_CODE"));
							
							String phoneNumber = rs.getString("PHONE_NUMBER");
							if(phoneNumber != null) {
								phoneNumber = Utils.phoneNumberFormat(phoneNumber);
							}
							userProfile.setPhoneNumber(phoneNumber);
							userProfile.setEmailAddress(rs.getString("EMAIL_ADDRESS"));
							
							userProfile.setPassword(rs.getString("PASSWORD"));
							userProfile.setPwdChangeDate(rs.getDate("PWD_CHANGE_DATE"));
							userProfile.setProfileStatusFlag(rs.getInt("PROFILE_STATUS_FLAG"));
							
							userProfile.setUnsuccessfulAttemptCtr(rs.getInt("UNSUCCESSFUL_ATTEMPT_CTR"));
							userProfile.setLastUnsuccessfulDate(rs.getTimestamp("LAST_UNSUCCESFUL_DATE"));
							
							userProfile.setInitialMonthlyEstimate(rs.getString("INITIAL_MONTHLY_ESTIMATE"));
							userProfile.setInsuranceCoverage(rs.getString("INSURANCE_COVERAGE"));
							userProfile.setInsuranceTerm(rs.getInt("INSURANCE_TERM"));
							
							userProfile.setPinneyQuoteStatus(rs.getString("PINNEY_QUOTE_STATUS"));
							userProfile.setLastPinneyUpdatedDate(rs.getDate("LAST_PIENNY_UPDATED_DATE"));
							
							userProfile.setAgencyLogo(rs.getString("AGENCY_LOGO"));
							userProfile.setGender(rs.getString("GENDER"));
							userProfile.setAgency_name(rs.getString("AGENCY_NAME"));
							
							userProfile.setCreatedBy(rs.getString("CREATED_BY"));
							userProfile.setCreatedDate(rs.getDate("CREATED_DATE"));
							userProfile.setUpdatedBy(rs.getString("UPDATED_BY"));
							userProfile.setUpdatedDate(rs.getDate("UPDATED_DATE"));
							

							return userProfile;
						}
					});
		} catch (EmptyResultDataAccessException e) {
			logger.error("ERROR : " + e.getMessage());
			return null;
		} catch (DataAccessException e) {
			logger.error("ERROR : " + e.getMessage());
			throw new DAOException(e.getMessage());
		}
		logger.logMethodExit(startTime);
		return userProfile;
	}
	
	/*
	 * This method has been used to load the user profile complete details based
	 * on the user id.
	 * 
	 * @see com.asg.selfservice.dao.ProfileDAO#loadUserProfileById(int)
	 */
	public UserProfile loadUserProfileById(int userId) throws DAOException {
		final long startTime = logger.logMethodEntry();
		UserProfile userProfile;
		try {
			userProfile = jdbcTemplate.queryForObject(QueryConstants.LOAD_USER_PROFILE_BY_ID,
					new Object[] { userId }, new RowMapper<UserProfile>() {

						public UserProfile mapRow(ResultSet rs, int rowNum) throws SQLException {
							UserProfile userProfile = new UserProfile();
							userProfile.setUserId(rs.getInt("USER_ID"));
							userProfile.setEncryptedUid(rs.getString("ENCRYPTED_UID"));
							userProfile.setCampaignId(rs.getString("CAMPAIGN_ID"));
							userProfile.setSalutation(rs.getString("SALUTATION"));
							
							userProfile.setFirstName(rs.getString("FIRST_NAME"));
							userProfile.setLastName(rs.getString("LAST_NAME"));
							
							userProfile.setDob(rs.getDate("DOB"));
							userProfile.setAddress1(rs.getString("ADDRESS_1"));
							userProfile.setAddressCity(rs.getString("ADDRESS_CITY"));
							userProfile.setAddressState(rs.getString("ADDRESS_STATE"));
							userProfile.setZipCode(rs.getString("ZIP_CODE"));
							
							String phoneNumber = rs.getString("PHONE_NUMBER");
							if(phoneNumber != null) {
								phoneNumber = Utils.phoneNumberFormat(phoneNumber);
							}
							userProfile.setPhoneNumber(phoneNumber);
							userProfile.setEmailAddress(rs.getString("EMAIL_ADDRESS"));
							
							userProfile.setPassword(rs.getString("PASSWORD"));
							userProfile.setPwdChangeDate(rs.getDate("PWD_CHANGE_DATE"));
							userProfile.setProfileStatusFlag(rs.getInt("PROFILE_STATUS_FLAG"));
							
							userProfile.setUnsuccessfulAttemptCtr(rs.getInt("UNSUCCESSFUL_ATTEMPT_CTR"));
							userProfile.setLastUnsuccessfulDate(rs.getTimestamp("LAST_UNSUCCESFUL_DATE"));
							
							userProfile.setInitialMonthlyEstimate(rs.getString("INITIAL_MONTHLY_ESTIMATE"));
							userProfile.setInsuranceCoverage(rs.getString("INSURANCE_COVERAGE"));
							userProfile.setInsuranceTerm(rs.getInt("INSURANCE_TERM"));
							
							userProfile.setPinneyQuoteStatus(rs.getString("PINNEY_QUOTE_STATUS"));
							userProfile.setLastPinneyUpdatedDate(rs.getDate("LAST_PIENNY_UPDATED_DATE"));
							
							userProfile.setAgencyLogo(rs.getString("AGENCY_LOGO"));
							userProfile.setGender(rs.getString("GENDER"));
							userProfile.setAgency_name(rs.getString("AGENCY_NAME"));
							
							userProfile.setCreatedBy(rs.getString("CREATED_BY"));
							userProfile.setCreatedDate(rs.getDate("CREATED_DATE"));
							userProfile.setUpdatedBy(rs.getString("UPDATED_BY"));
							userProfile.setUpdatedDate(rs.getDate("UPDATED_DATE"));

							return userProfile;
						}
					});
		} catch (EmptyResultDataAccessException e) {
			logger.error("ERROR : " + e.getMessage());
			return null;
		} catch (DataAccessException e) {
			logger.error("ERROR : " + e.getMessage());
			throw new DAOException(e.getMessage());
		}
		logger.logMethodExit(startTime);
		return userProfile;
	}
	
	/*
	 * This method has been used for updating the user profile initial monthly estimate.
	 * @see com.asg.selfservice.dao.ProfileDAO#updateUserProfileInitialMonthlyEstimate(com.asg.selfservice.domain.UserProfile)
	 */
	public void updateUserProfileInitialMonthlyEstimate(UserProfile userProfile) throws DAOException {
		final long startTime = logger.logMethodEntry();
		
		if(userProfile.getInitialMonthlyEstimate() != null && !userProfile.getInitialMonthlyEstimate().contains("$")) {
			userProfile.setInitialMonthlyEstimate("$"+userProfile.getInitialMonthlyEstimate());
		}
        int out = 0;
		try {
			Object[] args = new Object[] {userProfile.getInitialMonthlyEstimate(), userProfile.getFirstName(), new java.sql.Date(new Date().getTime()), userProfile.getUserId()};
			out = jdbcTemplate.update(QueryConstants.UPDATE_USER_PROFILE_INITIAL_MONTHLY_ESTIMATE, args);
		} catch (DataAccessException e) {
			logger.error("ERROR : " + e.getMessage());
			throw new DAOException(e.getMessage());
		}
		
        if(out !=0){
            logger.info("User profile initial monthly updated with id="+userProfile.getUserId());
        } else {
        	logger.info("No user found with id="+userProfile.getUserId());
        }
        logger.logMethodExit(startTime);
	}
	
	/*
	 * This method has been used for updating the user profile along with the
	 * user password.
	 * 
	 * @see
	 * com.asg.selfservice.dao.ProfileDAO#updateUserProfileWithPassword(
	 * com.asg.selfservice.domain.UserProfile)
	 */
	public void updateUserProfileWithPassword(UserProfile userProfile) throws DAOException {
		final long startTime = logger.logMethodEntry();
		
        int out = 0;
		try {
			Object[] args = new Object[] {userProfile.getEmailAddress(), userProfile.getPhoneNumber(), userProfile.getFirstName(),
					userProfile.getLastName(), userProfile.getPassword(), userProfile.getFirstName(), new java.sql.Date(new Date().getTime()), userProfile.getUserId()};
			out = jdbcTemplate.update(QueryConstants.UPDATE_USER_PROFILE_WITH_PASSWORD, args);
		} catch (DataAccessException e) {
			logger.error("ERROR : " + e.getMessage());
			throw new DAOException(e.getMessage());
		}
		
        if(out !=0){
            logger.info("User profile with password updated with id="+userProfile.getUserId());
        } else {
        	logger.info("No user found with id="+userProfile.getUserId());
        }
        logger.logMethodExit(startTime);
	}
	
	/*
	 * This method has been used for updating only the user password.
	 * 
	 * @see
	 * com.asg.selfservice.dao.ProfileDAO#updateUserProfilePassword(com.
	 * asg.selfservice.domain.UserProfile)
	 */
	public void updateUserProfilePassword(UserProfile userProfile) throws DAOException {
		final long startTime = logger.logMethodEntry();
		
        int out = 0;
        String firstname = userProfile.getFirstName();
        if(userProfile.getUpdatedBy() != null && ApplicationConstants.ADMIN.equalsIgnoreCase(userProfile.getUpdatedBy())) {
        	firstname = userProfile.getUpdatedBy();
        }
		try {
			Object[] args = new Object[] {userProfile.getPassword(), firstname, new java.sql.Date(new Date().getTime()), userProfile.getUserId()};
			out = jdbcTemplate.update(QueryConstants.UPDATE_USER_PROFILE_PASSWORD, args);
			
		} catch (DataAccessException e) {
			logger.error("ERROR : " + e.getMessage());
			throw new DAOException(e.getMessage());
		}
		
        if(out !=0){
            logger.info("User profile password updated with id="+userProfile.getUserId());
        } else {
        	logger.info("No user found with id="+userProfile.getUserId());
        }
        logger.logMethodExit(startTime);
	}
	
	/*
	 * This method has been used for updating the user profile status.
	 * 
	 * @see
	 * com.asg.selfservice.dao.ProfileDAO#updateUserProfileStatus(com.asg
	 * .selfservice.domain.UserProfile)
	 */
	public void updateUserProfileStatus(UserProfile userProfile) throws DAOException {
		final long startTime = logger.logMethodEntry();
		
        int out = 0;
		try {
			Object[] args = new Object[] {userProfile.getProfileStatusFlag(), userProfile.getFirstName(), new java.sql.Date(new Date().getTime()), userProfile.getUserId()};
			out = jdbcTemplate.update(QueryConstants.UPDATE_USER_PROFILE_STATUS, args);
		} catch (DataAccessException e) {
			logger.error("ERROR : " + e.getMessage());
			throw new DAOException(e.getMessage());
		}
		
        if(out !=0){
            logger.info("User profile status updated with id="+userProfile.getUserId());
        } else {
        	logger.info("No user found with id="+userProfile.getUserId());
        }
        logger.logMethodExit(startTime);
	}

	/* (non-Javadoc)
	 * @see com.asg.selfservice.dao.ProfileDAO#getuserDetails()
	 */
	@Override
	/*
	 * Email blast for users who have come to application clicking on checkbox 
	 * however left the application midway(profileStatus = 0)
	 * 
	 * 
	 */
	public List<UserProfile> getuserDetails() throws DAOException {
		final long startTime = logger.logMethodEntry();
        List<UserProfile> questionList = new ArrayList<UserProfile>();
 
        List<Map<String,Object>> userDataRows = jdbcTemplate.queryForList(QueryConstants.GET_USER_DATA);
         
        for(Map<String,Object> userRow : userDataRows){
        	UserProfile userdata = new UserProfile();
        	userdata.setUserId(Integer.parseInt(String.valueOf(userRow.get("USER_ID"))));
        	userdata.setFirstName(String.valueOf(userRow.get("FIRST_NAME")));
        	userdata.setEmailAddress(String.valueOf(userRow.get("EMAIL_ADDRESS")));
        	userdata.setSavedDate(String.valueOf(userRow.get("CREATED_DATE")));
        	userdata.setLastUpdateDate(String.valueOf(userRow.get("UPDATED_DATE")));
        	userdata.setAgency_name(String.valueOf(userRow.get("AGENCY_NAME")));
        	userdata.setEncryptedUid(String.valueOf(userRow.get("ENCRYPTED_UID")));
			questionList.add(userdata);
        }
        logger.logMethodExit(startTime);
        return questionList;
	}
	
	/*
	 * This method has been used for updating the user profile details and
	 * redirecting to the same page.
	 * 
	 * @see
	 * com.asg.selfservice.dao.ProfileDAO#updateUserProfile(com.asg.selfservice
	 * .domain.UserProfile)
	 */
	public void updateUserProfileInfo(UserProfile userProfile) throws DAOException {
		final long startTime = logger.logMethodEntry();
		
        int out = 0;
		try {
			Object[] args = new Object[] {userProfile.getEmailAddress(), userProfile.getPhoneNumber(), userProfile.getFirstName(),
					userProfile.getLastName(), userProfile.getFirstName(), new java.sql.Date(new Date().getTime()), userProfile.getUserId()};
			out = jdbcTemplate.update(QueryConstants.UPDATE_USER_PROFILE_DETAILS, args);
			
		} catch (DataAccessException e) {
			logger.error("ERROR : " + e.getMessage());
			throw new DAOException(e.getMessage());
		}
		
        if(out !=0){
            logger.info("User profile updated with id="+userProfile.getUserId());
        } else {
        	logger.info("No user found with id="+userProfile.getUserId());
        }
        logger.logMethodExit(startTime);
	}

	/*
	 * This method has been used for updating the user profile details with the updated health page infos and
	 * redirecting to the same page.
	 * 
	 * @see
	 * com.asg.selfservice.dao.ProfileDAO#updateUserProfileWithHealthDetails(com.asg.selfservice
	 * .domain.UserProfile)
	 */
	public void updateUserProfileWithHealthDetails(
			UserProfile userProfile) throws DAOException {
		final long startTime = logger.logMethodEntry();
		
        int out = 0;
		try {
			Object[] args = new Object[] {userProfile.getGender(), userProfile.getDob() != null ? new java.sql.Date(userProfile.getDob().getTime()) : null, userProfile.getAddressState(), 
					userProfile.getFirstName(), new java.sql.Date(new Date().getTime()), userProfile.getUserId()};
			out = jdbcTemplate.update(QueryConstants.UPDATE_USER_PROFILE_WITH_HEALTH_INFO_DETAILS, args);
			
		} catch (DataAccessException e) {
			logger.error("ERROR : " + e.getMessage());
			throw new DAOException(e.getMessage());
		}
		
        if(out !=0){
            logger.info("User profile updated with id="+userProfile.getUserId());
        } else {
        	logger.info("No user found with id="+userProfile.getUserId());
        }
        logger.logMethodExit(startTime);
	}
	
	
	/*
	 * Email blast for users who have saved application by clicking on SAVE 
	 * however didn't selected any quote (profileStatus = 1)
	 *  
	 */
	public List<UserProfile> getUserProfilesForStatus1() throws DAOException {
		final long startTime = logger.logMethodEntry();
        List<UserProfile> questionList = new ArrayList<UserProfile>();
 
        List<Map<String,Object>> userDataRows = jdbcTemplate.queryForList(QueryConstants.GET_USER_DATA_FOR_STATUS_1);
         
        for(Map<String,Object> userRow : userDataRows){
        	UserProfile userdata = new UserProfile();
        	userdata.setUserId(Integer.parseInt(String.valueOf(userRow.get("USER_ID"))));
        	userdata.setFirstName(String.valueOf(userRow.get("FIRST_NAME")));
        	userdata.setEmailAddress(String.valueOf(userRow.get("EMAIL_ADDRESS")));
        	userdata.setSavedDate(String.valueOf(userRow.get("CREATED_DATE")));
        	userdata.setLastUpdateDate(String.valueOf(userRow.get("UPDATED_DATE")));
        	userdata.setAgency_name(String.valueOf(userRow.get("AGENCY_NAME")));
			questionList.add(userdata);
        }
        logger.logMethodExit(startTime);
        return questionList;
	}
	
	/*
	 * Email blast for users who have clicked on Apply Now by selecting Quote 
	 * however didn't submit the application to Pinney (profileStatus = 2)
	 *  
	 */
	public List<UserProfile> getUserProfilesForStatus2() throws DAOException {
		final long startTime = logger.logMethodEntry();
        List<UserProfile> questionList = new ArrayList<UserProfile>();
 
        List<Map<String,Object>> userDataRows = jdbcTemplate.queryForList(QueryConstants.GET_USER_DATA_FOR_STATUS_2);
         
        for(Map<String,Object> userRow : userDataRows){
        	UserProfile userdata = new UserProfile();
        	userdata.setUserId(Integer.parseInt(String.valueOf(userRow.get("USER_ID"))));
        	userdata.setFirstName(String.valueOf(userRow.get("FIRST_NAME")));
        	userdata.setEmailAddress(String.valueOf(userRow.get("EMAIL_ADDRESS")));
        	userdata.setSavedDate(String.valueOf(userRow.get("CREATED_DATE")));
        	userdata.setLastUpdateDate(String.valueOf(userRow.get("UPDATED_DATE")));
        	userdata.setAgency_name(String.valueOf(userRow.get("AGENCY_NAME")));
			questionList.add(userdata);
        }
        logger.logMethodExit(startTime);
        return questionList;
	}

	/*
	 * (non-Javadoc)
	 * @see com.asg.selfservice.dao.ProfileDAO#updateUserProfileStatusWithAdminCheck(com.asg.selfservice.domain.UserProfile, boolean)
	 */
	@Override
	public void updateUserProfileStatusWithAdminCheck(UserProfile userProfile,
			boolean adminUserFlag) throws DAOException {
		final long startTime = logger.logMethodEntry();
		
        int out = 0;
		try {
			Object[] args = new Object[] {userProfile.getProfileStatusFlag(), adminUserFlag ? ApplicationConstants.ADMIN : userProfile.getFirstName(), 
					new java.sql.Date(new Date().getTime()), userProfile.getUserId()};
			out = jdbcTemplate.update(QueryConstants.UPDATE_USER_PROFILE_STATUS, args);
		} catch (DataAccessException e) {
			logger.error("ERROR : " + e.getMessage());
			throw new DAOException(e.getMessage());
		}
		
        if(out !=0){
            logger.info("User profile status updated with id="+userProfile.getUserId());
        } else {
        	logger.info("No user found with id="+userProfile.getUserId());
        }
        logger.logMethodExit(startTime);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.asg.selfservice.dao.ProfileDAO#loadProfileStatusFlag(int)
	 */
	@Override
	public int loadProfileStatusFlag(int userId) throws DAOException {
		int userProfileFlag;
		try {
			userProfileFlag = jdbcTemplate.queryForObject(QueryConstants.LOAD_PROFILE_STATUS_FLAG,
					new Object[] { userId }, new RowMapper<Integer>() {

						public Integer mapRow(ResultSet rs, int rowNum) throws SQLException {
							return rs.getInt("PROFILE_STATUS_FLAG");
						}
					});
		} catch (EmptyResultDataAccessException e) {
			logger.error("ERROR : " + e.getMessage());
			return ApplicationConstants.USER_PROFILE_NOT_CREATED;
		
		} catch (DataAccessException e) {
			logger.error("ERROR : " + e.getMessage());
			throw new DAOException(e.getMessage());
		}
		return userProfileFlag;
	}
}
