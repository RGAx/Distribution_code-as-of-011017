package com.asg.selfservice.dao.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.asg.selfservice.common.logger.LogFactory;
import com.asg.selfservice.common.logger.SelfServiceLogger;
import com.asg.selfservice.common.utils.QueryConstants;
import com.asg.selfservice.dao.AnswerDAO;
import com.asg.selfservice.domain.Answer;
import com.asg.selfservice.exception.DAOException;

/**
 * This has been used to load all the answers from the db which can be used for
 * all the pages and can be loaded per session.
 * 
 * @author M1030133
 *
 */
@Repository
public class AnswerDAOImpl implements AnswerDAO {
	private static final SelfServiceLogger logger = LogFactory.getInstance(AnswerDAOImpl.class);
	private JdbcTemplate jdbcTemplate;

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	/*
	 * This has been used to load all the answers from the db.
	 * 
	 * @see com.asg.selfservice.dao.AnswerDAO#loadAnswers()
	 */
	public List<Answer> loadAnswers() throws DAOException {
		List<Answer> answers = new ArrayList<Answer>();
		try {
			List<Map<String, Object>> recordRows = jdbcTemplate.queryForList(QueryConstants.GET_ANSWERS);
			for (Map<String, Object> recordRow : recordRows) {
				Answer answer = new Answer();
				answer.setqId(Integer.parseInt(String.valueOf(recordRow.get("Q_ID"))));
				answer.setAnswerValue(String.valueOf(recordRow.get("ANSWER_VALUE")));
				answer.setEbixAnswer(String.valueOf(recordRow.get("EBIX_ANSWER")));

				answers.add(answer);
			}
		} catch (DataAccessException e) {
			logger.error("ERROR : " + e.getMessage());
			throw new DAOException(e.getMessage());
		}
		return answers;
	}
}
