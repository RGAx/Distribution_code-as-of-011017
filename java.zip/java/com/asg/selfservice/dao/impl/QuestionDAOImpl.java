package com.asg.selfservice.dao.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.dao.DataAccessException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.asg.selfservice.common.logger.LogFactory;
import com.asg.selfservice.common.logger.SelfServiceLogger;
import com.asg.selfservice.common.utils.QueryConstants;
import com.asg.selfservice.dao.QuestionDAO;
import com.asg.selfservice.domain.Question;
import com.asg.selfservice.exception.DAOException;

/**
 * This class has been used for implementing the operations such as loading the
 * Questions for all the pages at one shot, so that these can be used in further
 * pages.
 * 
 * @author M1030133
 *
 */
@Repository
public class QuestionDAOImpl implements QuestionDAO {
	private static final SelfServiceLogger logger = LogFactory.getInstance(QuestionDAOImpl.class);

	private JdbcTemplate jdbcTemplate;

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	/*
	 * This method has been used for loading the questions from the db which can
	 * be used in all pages and can be loaded only for once per session.
	 * 
	 * @see com.asg.selfservice.dao.QuestionDAO#loadQuestions()
	 */
	public List<Question> loadQuestions() throws DAOException {
		final long startTime = logger.logMethodEntry();
		
        List<Question> questionList = new ArrayList<Question>();
 
        List<Map<String, Object>> questionRows;
		try {
			questionRows = jdbcTemplate.queryForList(QueryConstants.QUESTIONS);
		} catch (DataAccessException e) {
			logger.error("ERROR : " + e.getMessage());
			throw new DAOException(e.getMessage());
		}
         
        for(Map<String,Object> questionRow : questionRows){
        	Question quest = new Question();
			
        	quest.setQsetId(Integer.parseInt(String.valueOf(questionRow.get("QSET_ID"))));
			quest.setqId(Integer.parseInt(String.valueOf(questionRow.get("Q_ID"))));
			quest.setQsetName(String.valueOf(questionRow.get("QSET_NAME")));
			quest.setQuestion(String.valueOf(questionRow.get("QUESTIONS")));
			
			if(questionRow.get("REFL_QID_1") != null) {
				quest.setRefQID1(Integer.parseInt(String.valueOf(questionRow.get("REFL_QID_1"))));
			}
			if(questionRow.get("REFL_QID_2") != null) {
				quest.setRefQID2(Integer.parseInt(String.valueOf(questionRow.get("REFL_QID_2"))));
			}
			if(questionRow.get("REFL_QID_3") != null) {
				quest.setRefQID3(Integer.parseInt(String.valueOf(questionRow.get("REFL_QID_3"))));
			}
			if(questionRow.get("REFL_QID_4") != null) {
				quest.setRefQID4(Integer.parseInt(String.valueOf(questionRow.get("REFL_QID_4"))));
			}
			if(questionRow.get("REFL_QID_5") != null) {
				quest.setRefQID5(Integer.parseInt(String.valueOf(questionRow.get("REFL_QID_5"))));
			}
			if(questionRow.get("REFL_QID_6") != null) {
				quest.setRefQID6(Integer.parseInt(String.valueOf(questionRow.get("REFL_QID_6"))));
			}
			if(questionRow.get("REFL_QID_7") != null) {
				quest.setRefQID7(Integer.parseInt(String.valueOf(questionRow.get("REFL_QID_7"))));
			}
			if(questionRow.get("REFL_QID_8") != null) {
				quest.setRefQID8(Integer.parseInt(String.valueOf(questionRow.get("REFL_QID_8"))));
			}
			if(questionRow.get("REFL_QID_9") != null) {
				quest.setRefQID9(Integer.parseInt(String.valueOf(questionRow.get("REFL_QID_9"))));
			}
			if(questionRow.get("REFL_QID_10") != null) {
				quest.setRefQID10(Integer.parseInt(String.valueOf(questionRow.get("REFL_QID_10"))));
			}
			
			if(questionRow.get("SEQUENCE") != null) {
				quest.setSequence(Integer.parseInt(String.valueOf(questionRow.get("SEQUENCE"))));
			}
			if(questionRow.get("ANSWER_TYPE_ID") != null) {
				quest.setAnsTypeId(Integer.parseInt(String.valueOf(questionRow.get("ANSWER_TYPE_ID"))));
			}
			
			questionList.add(quest);
        }
        logger.logMethodExit(startTime);
        return questionList;
	}
	
	/*
	 * This method has been used for loading the reflexive questions from the
	 * DB.
	 * 
	 * @see com.asg.selfservice.dao.QuestionDAO#loadReflexiveQuestions()
	 */
	public Map<Integer, List<Integer>> loadReflexiveQuestions() throws DAOException {
		final long startTime = logger.logMethodEntry();
		
		Map<Integer, List<Integer>> reflexiveQuestionMap = new HashMap<Integer, List<Integer>>();
		
		try {
			List<Map<String,Object>> reflexiveQuestRows = jdbcTemplate.queryForList(QueryConstants.LOAD_REFLEXIVE_QUESTIONS);
			for(Map<String,Object> reflexiveQuestRow : reflexiveQuestRows){
				
				int questId = Integer.parseInt(String.valueOf(reflexiveQuestRow.get("Q_ID")));
				List<Integer> questIdList = new ArrayList<Integer>();
				
				if(reflexiveQuestRow.get("REFL_QID_1") != null) {
					questIdList.add(Integer.parseInt(String.valueOf(reflexiveQuestRow.get("REFL_QID_1"))));
				}
				if(reflexiveQuestRow.get("REFL_QID_2") != null) {
					questIdList.add(Integer.parseInt(String.valueOf(reflexiveQuestRow.get("REFL_QID_2"))));
				}
				if(reflexiveQuestRow.get("REFL_QID_3") != null) {
					questIdList.add(Integer.parseInt(String.valueOf(reflexiveQuestRow.get("REFL_QID_3"))));
				}
				if(reflexiveQuestRow.get("REFL_QID_4") != null) {
					questIdList.add(Integer.parseInt(String.valueOf(reflexiveQuestRow.get("REFL_QID_4"))));
				}
				if(reflexiveQuestRow.get("REFL_QID_5") != null) {
					questIdList.add(Integer.parseInt(String.valueOf(reflexiveQuestRow.get("REFL_QID_5"))));
				}
				if(reflexiveQuestRow.get("REFL_QID_6") != null) {
					questIdList.add(Integer.parseInt(String.valueOf(reflexiveQuestRow.get("REFL_QID_6"))));
				}
				if(reflexiveQuestRow.get("REFL_QID_7") != null) {
					questIdList.add(Integer.parseInt(String.valueOf(reflexiveQuestRow.get("REFL_QID_7"))));
				}
				if(reflexiveQuestRow.get("REFL_QID_8") != null) {
					questIdList.add(Integer.parseInt(String.valueOf(reflexiveQuestRow.get("REFL_QID_8"))));
				}
				if(reflexiveQuestRow.get("REFL_QID_9") != null) {
					questIdList.add(Integer.parseInt(String.valueOf(reflexiveQuestRow.get("REFL_QID_9"))));
				}
				if(reflexiveQuestRow.get("REFL_QID_10") != null) {
					questIdList.add(Integer.parseInt(String.valueOf(reflexiveQuestRow.get("REFL_QID_10"))));
				}
				
				reflexiveQuestionMap.put(questId, questIdList);
			}
		} catch (EmptyResultDataAccessException e) {
			logger.error("ERROR : " + e.getMessage());
			throw new DAOException(e.getMessage());
		} catch (DataAccessException e) {
			logger.error("ERROR : " + e.getMessage());
			throw new DAOException(e.getMessage());
		}
		logger.logMethodExit(startTime);
		return reflexiveQuestionMap;
	}
}
