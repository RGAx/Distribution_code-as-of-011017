package com.asg.selfservice.dao.impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.dao.DataAccessException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.asg.selfservice.common.logger.LogFactory;
import com.asg.selfservice.common.logger.SelfServiceLogger;
import com.asg.selfservice.common.utils.QueryConstants;
import com.asg.selfservice.dao.AdminAccessDAO;
import com.asg.selfservice.domain.UserDetails;
import com.asg.selfservice.domain.UserProfile;
import com.asg.selfservice.exception.DAOException;

/**
 * Used for implementing the admin operation such as loading the users based on
 * the email address.
 * 
 * @author M1030133
 *
 */
@Repository
public class AdminAccessDAOImpl implements AdminAccessDAO {

	private static final SelfServiceLogger LOGGER = LogFactory
			.getInstance(AdminAccessDAOImpl.class);

	private JdbcTemplate jdbcTemplate;

	@Override
	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	/*
	 * Used for loading the users based on email address;
	 * 
	 * @see com.asg.selfservice.dao.AdminAccessDAO#loadUsers(java.lang.String)
	 */
	@Override
	public List<UserDetails> loadUsers(String emailAddress) throws DAOException {
		final long startTime = LOGGER.logMethodEntry();
		List<UserDetails> users = new ArrayList<UserDetails>();
		try {
			Object[] args = new Object[] { emailAddress };
			List<Map<String, Object>> adminUserDataRows = jdbcTemplate
					.queryForList(QueryConstants.LOAD_ADMIN_USERS, args);

			int count = 1;
			for (Map<String, Object> userMap : adminUserDataRows) {
				UserDetails user = new UserDetails();
				user.setId(count++);
				user.setUserId(String.valueOf(userMap.get("USER_ID")));
				user.setEmailAddress(emailAddress);
				user.setCampaignDate(String.valueOf(userMap.get("INITIAL_SENT_DATE")));
				user.setAgencyName(String.valueOf(userMap.get("AGENCY_NAME")));
				

				users.add(user);
			}
		} catch (DataAccessException e) {
			LOGGER.error("ERROR:" + e.getMessage());
			throw new DAOException(e.getMessage());
		}
		LOGGER.logMethodExit(startTime);
		return users;
	}

	/*
	 * (non-Javadoc)
	 * @see com.asg.selfservice.dao.AdminAccessDAO#loadAdminUser(java.lang.String)
	 */
	@Override
	public UserProfile loadAdminUser(String emailAddress) throws DAOException {
		final long startTime = LOGGER.logMethodEntry();
		try {
			Object[] args = new Object[] { emailAddress };
			UserProfile adminUser = jdbcTemplate.queryForObject(
					QueryConstants.LOAD_ADMIN_USER, args,
					new RowMapper<UserProfile>() {
						@Override
						public UserProfile mapRow(ResultSet rs, int rowNum)
								throws SQLException {
							UserProfile adminUser = new UserProfile();
							adminUser.setUserId(rs.getInt("USER_ID"));
							adminUser.setEmailAddress(rs
									.getString("EMAIL_ADDRESS"));
							adminUser.setPassword(rs.getString("PASSWORD"));
							adminUser.setLastUnsuccessfulDate(rs
									.getTimestamp("LAST_UNSUCCESSFUL_DATE"));
							adminUser.setUnsuccessfulAttemptCtr(rs
									.getInt("UNSUCCESSFUL_ATTEMPT_CTR"));
							adminUser.setCreatedBy(rs.getString("CREATED_BY"));
							adminUser.setCreatedDate(rs
									.getTimestamp("CREATED_DATE"));
							return adminUser;
						}
					});
			LOGGER.logMethodExit(startTime);
			return adminUser;

		} catch (EmptyResultDataAccessException e) {
			LOGGER.error("ERROR : " + e.getMessage());
			return null;
		} catch (DataAccessException e) {
			LOGGER.error("ERROR : " + e.getMessage());
			throw new DAOException(e.getMessage());
		}
	}
}
