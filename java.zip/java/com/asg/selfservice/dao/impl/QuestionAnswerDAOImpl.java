package com.asg.selfservice.dao.impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.springframework.dao.DataAccessException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;

import com.asg.selfservice.common.logger.LogFactory;
import com.asg.selfservice.common.logger.SelfServiceLogger;
import com.asg.selfservice.common.utils.QueryConstants;
import com.asg.selfservice.common.utils.Utils;
import com.asg.selfservice.dao.QuestionAnswerDAO;
import com.asg.selfservice.domain.QuestionAnswer;
import com.asg.selfservice.domain.UserProfile;
import com.asg.selfservice.exception.DAOException;

/**
 * This class has been used to implement the question answer related operations
 * such as loading the questions from the db, saving/updating the answers into
 * the db and deleting the answers from the db if not required etc.
 * 
 * @author M1030133
 *
 */
public class QuestionAnswerDAOImpl implements QuestionAnswerDAO {

	private static final SelfServiceLogger logger = LogFactory.getInstance(QuestionAnswerDAOImpl.class);
	private JdbcTemplate jdbcTemplate;
	
	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}
	
	/*
	 * This has been used for loading the answer based on the userid and
	 * question set id.
	 * 
	 * @see
	 * com.asg.selfservice.dao.QuestionAnswerDAO#loadQuestionAnswerPerPage(int,
	 * int)
	 */
	public List<QuestionAnswer> loadQuestionAnswerPerPage(int userId, int qsetId) throws DAOException {
		final long startTime = logger.logMethodEntry();
		
		List<QuestionAnswer> quesAnsList = new ArrayList<QuestionAnswer>();
		try {
			List<Map<String,Object>> userQuesAnsRows = jdbcTemplate.queryForList(
					QueryConstants.LOAD_USER_QUESTION_ANSWER_THROUGH_QSETID, new Object[] { userId, qsetId });
			for(Map<String,Object> userQuesAnsRow : userQuesAnsRows){
							QuestionAnswer quesAns = new QuestionAnswer();
							quesAns.setQuestionAnswerId(Integer.parseInt(String.valueOf(userQuesAnsRow.get("USER_QUESTION_ANSWER_ID"))));
							quesAns.setqId(Integer.parseInt(String.valueOf(userQuesAnsRow.get("Q_ID"))));
							quesAns.setAnswer(String.valueOf(userQuesAnsRow.get("ANSWER")));
							quesAns.setSequence(Integer.parseInt(String.valueOf(userQuesAnsRow.get("SEQUENCE"))));

							quesAnsList.add(quesAns);
						}
		} catch (EmptyResultDataAccessException e) {
			logger.info("Returning no result");
			return null;
		} catch (DataAccessException e) {
			logger.error("ERROR : " + e.getMessage());
			throw new DAOException(e.getMessage());
		}
		logger.logMethodExit(startTime);
		return quesAnsList;
	}
	
	/*
	 * This has been used for loading the answer based on the userid and
	 * question id.
	 * 
	 * @see com.asg.selfservice.dao.QuestionAnswerDAO#loadQuestionAnswer(int,
	 * int)
	 */
	public QuestionAnswer loadQuestionAnswer(int userId, int qId) throws DAOException {
		final long startTime = logger.logMethodEntry();
		
		QuestionAnswer quesAns = null;
		try {
			quesAns = jdbcTemplate.queryForObject(
					QueryConstants.LOAD_USER_QUESTION_ANSWER_THROUGH_QID, new Object[] { userId, qId },
					new RowMapper<QuestionAnswer>() {

						public QuestionAnswer mapRow(ResultSet rs, int rowNum) throws SQLException {
							QuestionAnswer quesAns = new QuestionAnswer();
							quesAns.setQuestionAnswerId(rs.getInt(1));
							quesAns.setAnswer(rs.getString(2));

							return quesAns;
						}
					});
		} catch (EmptyResultDataAccessException e) {
			logger.info("Returning no result");
			return null;
		} catch (DataAccessException e) {
			logger.error("ERROR : " + e.getMessage());
			throw new DAOException(e.getMessage());
		}
		logger.logMethodExit(startTime);
		return quesAns;
	}
	
	/*
	 * This has been used for saving/updating the answers for the questions that
	 * has been entered in the UI by the user.
	 * 
	 * @see
	 * com.asg.selfservice.dao.QuestionAnswerDAO#saveUpdateInfo(com.asg.selfservice
	 * .domain.UserProfile, com.asg.selfservice.domain.QuestionAnswer)
	 */
	public void saveUpdateInfo(UserProfile user, QuestionAnswer questAns) throws DAOException {
		final long startTime = logger.logMethodEntry();
        int out = 0;
        
        QuestionAnswer dbQuestAns = null;
		try {
			dbQuestAns = this.loadQuestionAnswer(questAns.getUserId(), questAns.getqId());
		}  catch (DataAccessException e) {
			logger.error("ERROR : " + e.getMessage());
			throw new DAOException(e.getMessage());
			
		} catch (Exception e) {
			logger.error("ERROR : " + e.getMessage());
			throw new DAOException(e.getMessage());
		}
        try {
			if(dbQuestAns != null) {
				Object[] args = new Object[] { questAns.getAnswer(),
						user.getFirstName() + " " + (user.getLastName() != null ? user.getLastName() : ""), new java.sql.Date((new Date()).getTime()), dbQuestAns.getQuestionAnswerId()};
			     
			    out = jdbcTemplate.update(QueryConstants.UPDATE_USER_QUESTION_ANSWER, args);
			} else {
				Object[] args = new Object[] { questAns.getUserId(),
						questAns.getqId(), questAns.getAnswer(),
						questAns.getCreatedBy(), questAns.getCreatedDate() };
			     
			    out = jdbcTemplate.update(QueryConstants.SAVE_USER_QUESTION_ANSWER, args);
			}
		} catch (DataAccessException e) {
			logger.error("ERROR : " + e.getMessage());
			throw new DAOException(e.getMessage());
		}
		
        if(out !=0){
            logger.info("UserQuestionAnswer saved with id="+questAns.getQuestionAnswerId());
        } else logger.info("UserQuestionAnswer save failed with id="+questAns.getQuestionAnswerId());
        
        logger.logMethodExit(startTime);
	}
	
	/*
	 * This has been used for deleting the answer from db.
	 * 
	 * @see
	 * com.asg.selfservice.dao.QuestionAnswerDAO#deleteAnswer(com.asg.selfservice
	 * .domain.UserProfile, com.asg.selfservice.domain.UserQuestionAnswer)
	 */
	public void deleteAnswer(UserProfile user, QuestionAnswer questAns) throws DAOException {
		final long startTime = logger.logMethodEntry();
		
        QuestionAnswer dbQuesAns = null;
		try {
			dbQuesAns = this.loadQuestionAnswer(questAns.getUserId(), questAns.getqId());
		} catch (DataAccessException e) {
			logger.error("ERROR : " + e.getMessage());
			throw new DAOException(e.getMessage());
		}
		
        if(dbQuesAns != null && dbQuesAns.getQuestionAnswerId() != 0) {
        	int out = 0;
			try {
				out = jdbcTemplate.update(QueryConstants.DELETE_USER_QUESTION_ANSWER, dbQuesAns.getQuestionAnswerId());
			}  catch (DataAccessException e) {
				logger.error("ERROR : " + e.getMessage());
				throw new DAOException(e.getMessage());
			}
            if(out !=0){
                logger.debug("Record deleted with id="+dbQuesAns.getQuestionAnswerId());
            } else logger.debug("No record found with id="+dbQuesAns.getQuestionAnswerId());
        }
        logger.logMethodExit(startTime);
	}
	
	/*
	 * This has been used for deleting the set of answers from db based on the
	 * question ids.
	 * 
	 * @see
	 * com.asg.selfservice.dao.QuestionAnswerDAO#deleteAnswers(com.asg.selfservice
	 * .domain.UserProfile, java.lang.Integer[])
	 */
	public void deleteAnswers(UserProfile user, Integer[] qIds) throws DAOException {
		final long startTime = logger.logMethodEntry();
		
		NamedParameterJdbcTemplate namedJdbcTemplate = new NamedParameterJdbcTemplate(jdbcTemplate);
		MapSqlParameterSource args = new MapSqlParameterSource();
		args.addValue("user_id", user.getUserId());
		args.addValue("q_ids", Arrays.asList(new Object[] {qIds}));
        
    	int out = 0;
		try {
			out = namedJdbcTemplate.update(QueryConstants.DELETE_USER_QUESTION_ANSWERS, args);
		} catch (DataAccessException e) {
			logger.error("ERROR : " + e.getMessage());
			throw new DAOException(e.getMessage());
		}
    	
        if(out !=0){
            logger.debug("Successfully deleted the records");
        } else logger.debug("Deletion un-successful");
        
        logger.logMethodExit(startTime);
	}
	
	/*
	 * This has been used for loading the answer details for pinney based on the userid.
	 * 
	 * @see com.asg.selfservice.dao.QuestionAnswerDAO#loadQuestionAnswerForPinney(int)
	 */
	public List<QuestionAnswer> loadQuestionAnswersForPinney(int userId) throws DAOException {
		final long startTime = logger.logMethodEntry();
		
		// using RowMapper anonymous class, we can create a separate RowMapper for reuse
		List<QuestionAnswer> quesAnsList = new ArrayList<QuestionAnswer>();
		try {
			List<Map<String,Object>> quesAnsRows = jdbcTemplate.queryForList(
					QueryConstants.LOAD_USER_QUESTION_ANSWER_FOR_PINNEY, new Object[] { userId });
			for(Map<String,Object> quesAnsRow : quesAnsRows){
				QuestionAnswer quesAns = new QuestionAnswer();
				quesAns.setQuestionAnswerId(Integer.parseInt(String.valueOf(quesAnsRow.get("USER_QUESTION_ANSWER_ID"))));
				quesAns.setqId(Integer.parseInt(String.valueOf(quesAnsRow.get("Q_ID"))));
				quesAns.setAnswer(String.valueOf(quesAnsRow.get("ANSWER")));
				quesAns.setQsetId(Integer.parseInt(String.valueOf(quesAnsRow.get("QSET_ID"))));
				quesAns.setSequence(Integer.parseInt(String.valueOf(quesAnsRow.get("SEQUENCE"))));

				quesAnsList.add(quesAns);
			}
		} catch (EmptyResultDataAccessException e) {
			logger.info("Returning no result");
			return null;
		} catch (DataAccessException e) {
			logger.error("ERROR : " + e.getMessage());
			throw new DAOException(e.getMessage());
		}
		logger.logMethodExit(startTime);
		return quesAnsList;
	}
	
	/*
	 * Used for loading the user question answer based on the user id.
	 * @see com.asg.selfservice.dao.QuestionAnswerDAO#loadUserQuestionAnswersForEBIX(int)
	 */
	public List<QuestionAnswer> loadQuestionAnswersForEBIX(int userId) throws DAOException {
		final long startTime = logger.logMethodEntry();
		
		List<QuestionAnswer> quesAnsList = new ArrayList<QuestionAnswer>();
		try {
			List<Map<String,Object>> userQuesAnsRows = jdbcTemplate.queryForList(
					QueryConstants.LOAD_USER_QUESTION_ANSWER_EBIX, new Object[] { userId });
			for(Map<String,Object> userQuesAnsRow : userQuesAnsRows){
				QuestionAnswer quesAns = new QuestionAnswer();
				quesAns.setQuestionAnswerId(Integer.parseInt(String.valueOf(userQuesAnsRow.get("USER_QUESTION_ANSWER_ID"))));
				quesAns.setUserId(Integer.parseInt(String.valueOf(userQuesAnsRow.get("USER_ID"))));
				quesAns.setqId(Integer.parseInt(String.valueOf(userQuesAnsRow.get("Q_ID"))));
				quesAns.setAnswer(String.valueOf(userQuesAnsRow.get("ANSWER")));
				quesAns.setEbixQuesId(Integer.parseInt(String.valueOf(userQuesAnsRow.get("EBIX_QUESID"))));
				quesAns.setEbixQuesType(String.valueOf(userQuesAnsRow.get("EBIX_QUESTYPE")));
				quesAns.setEbixControlId(Integer.parseInt(String.valueOf(userQuesAnsRow.get("EBIX_CONTROL_ID"))));
				quesAns.setEbixControlValueType(String.valueOf(userQuesAnsRow.get("EBIX_CONTROLVALUETYPE")));
				quesAns.setDefaultAnswer(String.valueOf(userQuesAnsRow.get("DEFAULT_ANSWER")));

				quesAnsList.add(quesAns);
						}
		} catch (EmptyResultDataAccessException e) {
			logger.error("ERROR : " + e.getMessage());
			throw new DAOException(e.getMessage());
		} catch (DataAccessException e) {
			logger.error("ERROR : " + e.getMessage());
			throw new DAOException(e.getMessage());
		}
		logger.logMethodExit(startTime);
		return quesAnsList;
	}
	
	/*
	 * This has been used for loading the question ids based on the userid and
	 * question set id.
	 * 
	 * @see
	 * com.asg.selfservice.dao.QuestionAnswerDAO#loadQuestionAnswerPerPage(int,
	 * int)
	 */
	public Integer[] loadQuestionIdsBasedQSetId(int userId, int qsetId)
			throws DAOException {
		final long startTime = logger.logMethodEntry();

		Integer[] qIds = new Integer[20];
		try {
			List<Map<String, Object>> userQuesAnsRows = jdbcTemplate.queryForList(QueryConstants.LOAD_QIDS_THROUGH_QSETID, new Object[] { userId, qsetId });
			int count = 0;
			
			for (Map<String, Object> userQuesAnsRow : userQuesAnsRows) {
				qIds[count++] = Integer.parseInt(String.valueOf(userQuesAnsRow.get("Q_ID")));
			}
		} catch (EmptyResultDataAccessException e) {
			logger.info("Returning no result");
			return null;
		} catch (DataAccessException e) {
			logger.error("ERROR : " + e.getMessage());
			throw new DAOException(e.getMessage());
		}
		logger.logMethodExit(startTime);
		return qIds;
	}
	
	/*
	 * The method will query user_profile table to fetch Encripted userid, userid  etc. wher profile id =4 (Failed)
	 */
	
	
	public List<UserProfile> getPinneyFailedSubmission() throws DAOException {
		final long startTime = logger.logMethodEntry();
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        List<UserProfile> questionList = new ArrayList<UserProfile>();
 
        try {
			List<Map<String,Object>> userDataRows = jdbcTemplate.queryForList(QueryConstants.GET_PINNEY_SUBMISSION_DATA);
			 
			for(Map<String,Object> rs : userDataRows){
				
				UserProfile userProfile = new UserProfile();
				userProfile.setUserId(Integer.parseInt(String.valueOf(rs.get("USER_ID"))));
				userProfile.setEncryptedUid(String.valueOf(rs.get("ENCRYPTED_UID")));
				userProfile.setCampaignId(String.valueOf(rs.get("CAMPAIGN_ID")));
				userProfile.setSalutation(String.valueOf(rs.get("SALUTATION")));
				
				userProfile.setFirstName(String.valueOf(rs.get("FIRST_NAME")));
				userProfile.setLastName(String.valueOf(rs.get("LAST_NAME")));
				
				userProfile.setDob(dateFormat.parse(String.valueOf(rs.get("DOB"))));
				
				if(rs.get("ADDRESS_1") != null) {
					userProfile.setAddress1(String.valueOf(rs.get("ADDRESS_1")));
				}
				if(rs.get("ADDRESS_CITY") != null) {
					userProfile.setAddressCity(String.valueOf(rs.get("ADDRESS_CITY")));
				}
				if(rs.get("ADDRESS_STATE") != null) {
					userProfile.setAddressState(String.valueOf(rs.get("ADDRESS_STATE")));
				}
				userProfile.setZipCode(String.valueOf(rs.get("ZIP_CODE")));
				
				String phoneNumber = String.valueOf(rs.get("PHONE_NUMBER"));
				if(phoneNumber != null) {
					phoneNumber = Utils.phoneNumberFormat(phoneNumber);
				}
				userProfile.setPhoneNumber(phoneNumber);
				userProfile.setEmailAddress(String.valueOf(rs.get("EMAIL_ADDRESS")));
				
				userProfile.setProfileStatusFlag(Integer.parseInt(String.valueOf(rs.get("PROFILE_STATUS_FLAG"))));
				
				if(rs.get("INITIAL_MONTHLY_ESTIMATE") != null) {
					userProfile.setInitialMonthlyEstimate(String.valueOf(rs.get("INITIAL_MONTHLY_ESTIMATE")));
				}
				if(rs.get("INSURANCE_COVERAGE") != null) {
					userProfile.setInsuranceCoverage(String.valueOf(rs.get("INSURANCE_COVERAGE")));
				}
				if(rs.get("INSURANCE_TERM") != null) {
					userProfile.setInsuranceTerm(Integer.parseInt(String.valueOf(rs.get("INSURANCE_TERM"))));
				}
				userProfile.setGender(String.valueOf(rs.get("GENDER")));
				userProfile.setCreatedBy(String.valueOf(rs.get("CREATED_BY")));
				userProfile.setCreatedDate(dateFormat.parse(String.valueOf(rs.get("CREATED_DATE"))));
				
				questionList.add(userProfile);
			}
		} catch (DataAccessException e) {
			logger.error("ERROR : " + e.getMessage());
			throw new DAOException(e.getMessage());
		} catch (NumberFormatException e) {
			logger.error("ERROR : " + e.getMessage());
			throw new DAOException(e.getMessage());
		} catch (ParseException e) {
			logger.error("ERROR : " + e.getMessage());
			throw new DAOException(e.getMessage());
		}
        logger.logMethodExit(startTime);
        return questionList;
	}
}
