package com.asg.selfservice.dao.impl;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.dao.DataAccessException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.asg.selfservice.common.logger.LogFactory;
import com.asg.selfservice.common.logger.SelfServiceLogger;
import com.asg.selfservice.common.utils.QueryConstants;
import com.asg.selfservice.dao.LegalStatementDAO;
import com.asg.selfservice.domain.Legalstmt;
import com.asg.selfservice.exception.DAOException;

/**
 * @author M1030777
 *
 */
public class LegalStatementDAOImpl implements LegalStatementDAO{

	private static final SelfServiceLogger logger = LogFactory.getInstance(LegalStatementDAOImpl.class);
	
	private JdbcTemplate jdbcTemplate;
	
	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {  
	    this.jdbcTemplate = jdbcTemplate;  
	}
	
/*
 * 
 * 	(non-Javadoc)
 * @see com.asg.selfservice.dao.LegalStatementDAO#getFIName_Type(java.lang.String)
 */
	@Override
	public Legalstmt getFIName_Type(String agency_name) throws DAOException {
		
		final long startTime = logger.logMethodEntry();
		Legalstmt legalstmt;
		try {
			legalstmt = jdbcTemplate.queryForObject(
					QueryConstants.GET_LEGALNAME_TYPE_DETAILS,
					new Object[] {"%"+ agency_name + "%" }, new RowMapper<Legalstmt>() {

						public Legalstmt mapRow(ResultSet rs, int rowNum)
								throws SQLException {
							Legalstmt legalstmtsetter = new Legalstmt();
							legalstmtsetter.setFiname(rs.getString("FINAME"));
							legalstmtsetter.setFitype(rs.getString("FITYPE"));
							return legalstmtsetter;
						}
					});
		} catch (EmptyResultDataAccessException e) {
			logger.error("ERROR : " + e.getMessage());
			return null;
		} catch (DataAccessException e) {
			logger.error("ERROR : " + e.getMessage());
			throw new DAOException(e.getMessage());
		}
		logger.logMethodExit(startTime);
		return legalstmt;
	}
	
	/*
	 * 
	 * 	Like (%) query may return more than one row to handle that ...this query is used. on HOLD
	 */
/*	
	public List<Legalstmt> getFIName_Type_List(String agency_name) throws DAOException {
		//logger.info("Start of UserQuestionAnswerDAOImpl :: loadUserQuestionAnswer : userId - " + userId);
		final long startTime = logger.logMethodEntry();
		
		// using RowMapper anonymous class, we can create a separate RowMapper for reuse
		List<Legalstmt> legalstmtList = new ArrayList<Legalstmt>();
		try {
			List<Map<String,Object>> legalstmtRows = jdbcTemplate.queryForList(
					QueryConstants.LOAD_USER_QUESTION_ANSWER, new Object[] { agency_name + "%" });
			for(Map<String,Object> legalstmtRow : legalstmtRows){
							Legalstmt setlegalstmt = new Legalstmt();
								setlegalstmt.setFiname(String.valueOf(legalstmtRow.get("FINAME")));
								setlegalstmt.setFitype(String.valueOf(legalstmtRow.get("FITYPE")));
							legalstmtList.add(setlegalstmt);
						}
		} catch (EmptyResultDataAccessException e) {
			logger.info("Returning no result");
			return null;
		} catch (DataAccessException e) {
			logger.error("ERROR : " + e.getMessage());
			throw new DAOException(e.getMessage());
			
		} catch (Exception e) {
			logger.error("ERROR : " + e.getMessage());
			throw new DAOException(e.getMessage());
		}
		
		
		logger.logMethodExit(startTime);
		return legalstmtList;
	}*/

}
