package com.asg.selfservice.dao.impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.asg.selfservice.common.logger.LogFactory;
import com.asg.selfservice.common.logger.SelfServiceLogger;
import com.asg.selfservice.common.utils.QueryConstants;
import com.asg.selfservice.common.utils.Utils;
import com.asg.selfservice.dao.CustomerCallBackDAO;
import com.asg.selfservice.domain.CustomerCallback;
import com.asg.selfservice.domain.UserProfile;
import com.asg.selfservice.exception.DAOException;

/**
 * This class has been used to implement all the DB operations such as
 * fetching the customer callback details and 
 * saving the customer callback details.
 */
public class CustomerCallbackDAOImpl implements CustomerCallBackDAO {
	
	private static final SelfServiceLogger logger = LogFactory.getInstance(CustomerCallbackDAOImpl.class);
	
	@Autowired
	private CustomerCallback callBack;
	
	private JdbcTemplate jdbcTemplate;  

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {  
	    this.jdbcTemplate = jdbcTemplate; 
	}

	public CustomerCallback getUserDetails(int userId) throws DAOException {
		logger.info("DAO method to Fetch customer callback details based on userId:"+userId);
		CustomerCallback customerCallback = null;
		try {
			customerCallback = jdbcTemplate.queryForObject(
					QueryConstants.GET_USER_CALLBACK_DETAILS,
					new Object[] { userId }, new RowMapper<CustomerCallback>() {

						public CustomerCallback mapRow(ResultSet rs, int rowNum)
								throws SQLException {
							CustomerCallback customerCallback = new CustomerCallback();
							String phoneNumber = rs.getString("PHONE_NUMBER").trim();
							String formattedNumber = Utils.phoneNumberFormat(phoneNumber);
							customerCallback.setCallbackphoneNumber(formattedNumber);
							return customerCallback;
						}
					});

		} catch (EmptyResultDataAccessException e) {
			return null;
		} catch(IndexOutOfBoundsException e) {
			logger.error("ERROR : " + e.getMessage());
			throw new DAOException(e.getMessage());
			
		} catch (DataAccessException e) {
			logger.error("ERROR : " + e.getMessage());
			throw new DAOException(e.getMessage());
		}
		return customerCallback;
	}
	
	public boolean saveCustomerCallBackDetailsInfo(CustomerCallback callBack, UserProfile userProfile) throws DAOException {
		logger.info("DAO method to Save customer callback details for :"+callBack);
		Object[] args = null;
		Object[] args1 = null;
		int userID = 0;
		DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
		
		try {
			userID = jdbcTemplate.queryForObject(QueryConstants.GET_CUSTOMER_CALLBACK, new Object[] {userProfile.getUserId()}, Integer.class);
		} catch (EmptyResultDataAccessException e) {
			userID = 0;
		}  catch (DataAccessException e) {
			logger.error("ERROR : " + e.getMessage());
			throw new DAOException(e.getMessage());
		}
		
			try {
				if(userID==0) {
					if (callBack.getCallBackDate() != null && !callBack.getCallBackDate().isEmpty() && callBack.getCallBackDate().split("/").length == 3) {
						args = new Object[] {userProfile.getUserId(), callBack.getCallbackphoneNumber(),
								new java.sql.Date(dateFormat.parse(callBack.getCallBackDate()).getTime()),
								callBack.getGetBackTime(), userProfile.getFirstName() };
					} else {
						args = new Object[] { userProfile.getUserId(), callBack.getCallbackphoneNumber(),
							null, callBack.getGetBackTime(), userProfile.getFirstName() };
					}
			
					int out = jdbcTemplate.update(QueryConstants.SAVE_USER_CALLBACK_DETAILS, args);
					if (out != 0) {
						return true;
					}
				}
				else {
					if (callBack.getCallBackDate() != null && !callBack.getCallBackDate().isEmpty() && callBack.getCallBackDate().split("/").length == 3) {
						args1 = new Object[] {callBack.getCallbackphoneNumber(),
								new java.sql.Date(dateFormat.parse(callBack.getCallBackDate()).getTime()),
								callBack.getGetBackTime(), userProfile.getUserId() };
					} else {
						args1 = new Object[] {callBack.getCallbackphoneNumber(),
							null, callBack.getGetBackTime(), userProfile.getUserId() };
					}
					
					int out1 = jdbcTemplate.update(QueryConstants.UPDATE_USER_CALLBACK_DETAILS, args1);
					if (out1 != 0) {
						return true;
					}
				}
			} catch (EmptyResultDataAccessException e) {
				return false;
			} catch (DataAccessException e) {
				logger.error("ERROR : " + e.getMessage());
				throw new DAOException(e.getMessage());
			} catch (ParseException e) {
				logger.error("ERROR : " + e.getMessage());
				throw new DAOException(e.getMessage());
			}
			return false;
	}

		
	
}

