/**
 * 
 */
package com.asg.selfservice.dao.impl;

import java.util.Date;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.asg.selfservice.common.logger.LogFactory;
import com.asg.selfservice.common.logger.SelfServiceLogger;
import com.asg.selfservice.common.utils.QueryConstants;
import com.asg.selfservice.dao.LoginDAO;
import com.asg.selfservice.exception.DAOException;

/**
 * This class has been used for implementing the user operations such as loading
 * the user profile, updating the unsuccessful attempts into db and verifying if
 * the user exists in the db or not.
 * 
 * @author M1030133
 *
 */
@Repository
public class LoginDAOImpl implements LoginDAO {
	private static final SelfServiceLogger logger = LogFactory.getInstance(LoginDAOImpl.class);

	private JdbcTemplate jdbcTemplate;  
	  
	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {  
	    this.jdbcTemplate = jdbcTemplate;  
	}  

	/*
	 * This method has been used for updating the counter value for the unsuccessful login attempts
	 * done by the user.
	 * @see com.asg.selfservice.dao.LoginDAO#updateCounter(int, java.lang.String)
	 */
	public void updateCounter(int count, String email) throws DAOException {
		final long startTime = logger.logMethodEntry();
		
		Object[] args = new Object[] {count, new java.sql.Timestamp((new Date()).getTime()), email};
		
		int out = 0;
		try {
			out = jdbcTemplate.update(QueryConstants.UPDATE_UNSUCCESFUL_CTR, args);
			logger.logMethodExit(startTime);
		} catch (DataAccessException e) {
			logger.error("ERROR : " + e.getMessage());
			throw new DAOException(e.getMessage());
		}
		if(out !=0){
            logger.info("User profile updated with email address="+email);
        } else {
        	logger.info("No user found with email address="+email);
        }
		
	}

	/*
	 * Ths method has been used for validating the database if the user is present in the db or not
	 * based on the email address.
	 * @see com.asg.selfservice.dao.LoginDAO#isUserExists(java.lang.String)
	 */
	public boolean isUserExists(String username) throws DAOException {
		final long startTime = logger.logMethodEntry();
		
		int count;
		try {
			count = jdbcTemplate.queryForObject(QueryConstants.USER_EXISTS, new Object[] { username }, Integer.class);
		} catch (DataAccessException e) {
			logger.error("ERROR : " + e.getMessage());
			throw new DAOException(e.getMessage());
		}
		logger.logMethodExit(startTime);
		return count > 0;
	}

	@Override
	public void updateAdminCounter(int count, String email) throws DAOException {
		final long startTime = logger.logMethodEntry();
		
		Object[] args = new Object[] {count, new java.sql.Timestamp((new Date()).getTime()), email};
		
		int out = 0;
		try {
			out = jdbcTemplate.update(QueryConstants.UPDATE_ADMIN_UNSUCCESFUL_CTR, args);
			logger.logMethodExit(startTime);
		} catch (DataAccessException e) {
			logger.error("ERROR : " + e.getMessage());
			throw new DAOException(e.getMessage());
		}
		if(out !=0){
            logger.info("User profile updated with email address="+email);
        } else {
        	logger.info("No user found with email address="+email);
        }
	}
}
