package com.asg.selfservice.dao.impl;

import org.springframework.jdbc.core.JdbcTemplate;

import com.asg.selfservice.dao.BaseDAO;

/**
 * This has been used as a superclass which can be used in all other classes.
 * 
 * @author M1030133
 *
 */
public class BaseDAOImpl implements BaseDAO {
	private JdbcTemplate jdbcTemplate;

	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}
}
