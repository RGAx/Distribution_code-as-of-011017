/**
 * 
 */
package com.asg.selfservice.dao;

import com.asg.selfservice.domain.Legalstmt;
import com.asg.selfservice.exception.DAOException;

/**
 * @author M1030777
 *
 */
public interface LegalStatementDAO {

	Legalstmt getFIName_Type(String agency_name) throws DAOException;

}
