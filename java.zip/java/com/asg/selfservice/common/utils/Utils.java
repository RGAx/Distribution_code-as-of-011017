package com.asg.selfservice.common.utils;

import java.io.IOException;
import java.io.InputStream;
import java.security.SecureRandom;
import java.text.DateFormat;
import java.text.NumberFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.asg.selfservice.domain.UserProfile;

public class Utils {
	
	/*
	 * Currency Formatter  
	 * Formatting the Price to display in US currency
	 */
	public static String showPriceInUSD(int priceInUSD) {
		NumberFormat currencyFormat = NumberFormat
				.getCurrencyInstance(Locale.US);
		return currencyFormat.format(priceInUSD).split("\\.")[0];
	}

	/*
	 * Generate a random String suitable for use as a password. The password is
	 * sent to user using the Email id entered. link Forgot password
	 */

	public static String generateRandomPassword() {

		final Random random = new SecureRandom();
		// final int PASSWORD_LENGTH = 8;
		String letters = "abcdefghijklmnopqrstuvwxyz";
		String numeric = "23456789";
		String alpha = "$@#";

		StringBuilder sb = new StringBuilder();
		for (int i = 0; i < 3; i++) {
			int index = (int) (random.nextDouble() * letters.length());
			sb.append(letters.substring(index, index + 1));
		}
		for (int i = 0; i < 1; i++) {
			int index = (int) (random.nextDouble() * alpha.length());
			sb.append(alpha.substring(index, index + 1));
		}
		for (int i = 0; i < 1; i++) {
			int index = (int) (random.nextDouble() * numeric.length());
			sb.append(numeric.substring(index, index + 1));
		}
		for (int i = 0; i < 3; i++) {
			int index = (int) (random.nextDouble() * letters.length());
			sb.append(letters.substring(index, index + 1));
		}

		return sb.toString();
	}

	public static int getDiffYears(Date first, Date last) {
		Calendar a = getCalendar(first);
		Calendar b = getCalendar(last);
		int diff = b.get(Calendar.YEAR) - a.get(Calendar.YEAR);
		if (a.get(Calendar.MONTH) > b.get(Calendar.MONTH)
				|| (a.get(Calendar.MONTH) == b.get(Calendar.MONTH) && a
						.get(Calendar.DATE) > b.get(Calendar.DATE))) {
			diff--;
		}
		return diff;
	}

	public static Calendar getCalendar(Date date) {
		Calendar cal = Calendar.getInstance(Locale.US);
		cal.setTime(date);
		return cal;
	}

	/*
	 * This method accept String Date return type Long (Days)
	 */
	public static Long getNoofDays(String savedDate) {
		long days = 0;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		Date date = new Date();
		String currentDate = dateFormat.format(date);

		String sentDate = savedDate;

		Date d1 = null;
		Date d2 = null;

		try {
			d1 = dateFormat.parse(currentDate);
			d2 = dateFormat.parse(sentDate);

			long diff = d1.getTime() - d2.getTime();
			days = diff / (24 * 60 * 60 * 1000);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return (long) days;

	}

	public static Map<String, String> loadStates() throws Exception {
		Map<String, String> statesMap = new HashMap<String, String>();
		try {
			DocumentBuilder dBuilder = DocumentBuilderFactory.newInstance()
					.newDocumentBuilder();
			
			InputStream is = Utils.class.getResourceAsStream("/states.xml");
			Document doc = dBuilder.parse(is);
			NodeList nList = doc.getElementsByTagName("state");
			
			for (int temp = 0; temp < nList.getLength(); temp++) {
				Node nNode = nList.item(temp);
				if (nNode.getNodeType() == Node.ELEMENT_NODE) {
					Element eElement = (Element) nNode;
					statesMap.put(eElement.getAttribute("code"), eElement.getAttribute("name"));
				}
			}
		} catch (SAXException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return statesMap;
	}
	
	public static String encryptPassword(String password) {
		return new BCryptPasswordEncoder().encode(password);
	}
	
	public static boolean passwordMatches(String rawPassword, String encodedPassword) {
		return new BCryptPasswordEncoder().matches(rawPassword, encodedPassword);
	}
	
	/*
	 * Email Messages
	 */
	public static String setMeassage(String agencyName, String firstName, String encryptedUID) {
		String msg = null;
		
		if(null != agencyName && null != firstName) {
		 msg = "Hi " +firstName+ ",<br><br>" 
				+ "It looks as though you left the site before finishing. We \'ve made it easier for you to <a href=\"https://etlwasqa-srv.cloudapp.net:9443/ArchInsurance/home?userID="+encryptedUID+"\">Click!</a> here to continue. <br><br>"
				+ "Regards,<br>"
				+ agencyName;
		}
		//String formattedMessage = MessageFormat.format(msg1, "http://google.com", "agencyName");
		//System.out.println(formattedMessage); // Richard has to go to School in 31/05/2012 / 1days

		return msg;
	}
	
	
	/*
	 * Email Messages for User profile with username and  password  
	 */
	public static String setProfileCreateMsg(UserProfile userProfile, String password) {
		String msg = null;
		String firstName = userProfile.getFirstName();
		String agencyName = userProfile.getAgency_name();
		String useremailadd = userProfile.getEmailAddress();
		
		
		
		if(null != agencyName && null != firstName) {
		 msg = "Hi " +firstName+ ",<br><br>" 
				+ "We\'ve created a profile for you. Please log in whenever you would like to change your contact information. You can easily change the password after you log in. <br><br>"
				+"User Name: " +useremailadd +",<br>"
				+"Password: " +password + ", <br>"
				+ "Regards,<br>"
				+ agencyName;
		}
		return msg;
	}
	
	/*
	 * Email Messages for Thank you  Profile 
	 */
	public static String setSubmitMsg(UserProfile userProfile) {
		String msg = null;
		String firstName = userProfile.getFirstName();
		String agencyName = userProfile.getAgency_name();
				
		
		if(null != agencyName && null != firstName) {
		 msg = "Hi " +firstName+ ",<br><br>" 
				+ "We appreciate you taking the time to answer a few questions to receive your life insurance policy.  <br><br>"
				+ "Regards,<br>"
				+ agencyName;
		}
		return msg;
	}
	
	
	/*
	 * Used to load last ten years
	 */
	public static List<Integer> loadLastTenYears() {
		List<Integer> years = new ArrayList<Integer>();
		int currentYear = Calendar.getInstance().get(Calendar.YEAR);
		
		for(int i = 0; i <= 10; i++) {
			years.add(currentYear--);
		}
		return years;
	}
	
	/*
	 * Appending phone number with '-' to display in xxx-xxx-xxxx format
	 */
	
	public static String phoneNumberFormat(String phoneNumber) {
		String formattedNumber = null;
		phoneNumber = phoneNumber.replace("-", "");
		formattedNumber = phoneNumber.substring(0, 3)+"-"+phoneNumber.substring(3, 6)+"-"+phoneNumber.substring(6, 10);
		return formattedNumber;
	}
	
	/*
	 * Get the index of month from a list of months. 
	 */
	public static int loadMonthIndex(String monthName) {
		
		String [] months = {"Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"};
		
		for(int i = 0; i < months.length; i++) {
			if(monthName.equalsIgnoreCase(months[i])){
				return i + 1;
			}
		}
		return 0;
	}
	
	/*
	 * Get the Date difference by passing Year and Month
	 *  with respect to Todays date
	 */
	public static long getDateDifference(int year, int month) {

		long noOfYears;

		/** The date at the end of the last century */
		Date d1 = new GregorianCalendar(year, month, 31, 23, 59).getTime();

		/** Today's date */
		Date today = new Date();

		// Get msec from each, and subtract.
		long diff = today.getTime() - d1.getTime();

		noOfYears = Math.round((double)((double)diff / (double)(1000 * 24 * 60 * 60)) / (double)365);

		return noOfYears;
	}
	
	/*
	 * Getting the time difference in minutes.
	 */
	public static long getTimeDifferenceInMinutes(Date d1, Date d2) {
		//in milliseconds
		long diff = d2.getTime() - d1.getTime();
		long diffMinutes = diff / (60 * 1000) % 60;
		
		return diffMinutes;
	}
	
	/*
	 * Used to load the state Id based on State code.
	 */
	public static Map<String, Integer> loadStateIds() throws Exception {
		Map<String, Integer> statesIdMap = new HashMap<String, Integer>();
		try {
			DocumentBuilder dBuilder = DocumentBuilderFactory.newInstance()
					.newDocumentBuilder();
			
			InputStream is = Utils.class.getResourceAsStream("/PinneyStates.xml");
			Document doc = dBuilder.parse(is);
			NodeList nList = doc.getElementsByTagName("state");
			
			for (int temp = 0; temp < nList.getLength(); temp++) {
				Node nNode = nList.item(temp);
				if (nNode.getNodeType() == Node.ELEMENT_NODE) {
					Element eElement = (Element) nNode;
					statesIdMap.put(eElement.getAttribute("code"), Integer.parseInt(eElement.getAttribute("id")));
				}
			}
		} catch (SAXException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return statesIdMap;
	}
	
	/*
	 * Used to load the carrier Id based on carrier name.
	 */
	public static Map<String, Integer> loadCarriers() throws Exception {
		Map<String, Integer> carrierMap = new HashMap<String, Integer>();
		try {
			DocumentBuilder dBuilder = DocumentBuilderFactory.newInstance()
					.newDocumentBuilder();
			
			InputStream is = Utils.class.getResourceAsStream("/carriers.xml");
			Document doc = dBuilder.parse(is);
			NodeList nList = doc.getElementsByTagName("carrier");
			
			for (int temp = 0; temp < nList.getLength(); temp++) {
				Node nNode = nList.item(temp);
				if (nNode.getNodeType() == Node.ELEMENT_NODE) {
					Element eElement = (Element) nNode;
					carrierMap.put(eElement.getAttribute("name"), Integer.parseInt(eElement.getAttribute("id")));
				}
			}
		} catch (SAXException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return carrierMap;
	}
	
	/*
	 * Used to load the category id based on name.
	 */
	public static Map<String, Integer> loadHealthCategoryOptions() throws Exception {
		Map<String, Integer> carrierMap = new HashMap<String, Integer>();
		try {
			DocumentBuilder dBuilder = DocumentBuilderFactory.newInstance()
					.newDocumentBuilder();
			
			InputStream is = Utils.class.getResourceAsStream("/health_category_option.xml");
			Document doc = dBuilder.parse(is);
			NodeList nList = doc.getElementsByTagName("health_category_option");
			
			for (int temp = 0; temp < nList.getLength(); temp++) {
				Node nNode = nList.item(temp);
				if (nNode.getNodeType() == Node.ELEMENT_NODE) {
					Element eElement = (Element) nNode;
					carrierMap.put(eElement.getAttribute("name"), Integer.parseInt(eElement.getAttribute("id")));
				}
			}
		} catch (SAXException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return carrierMap;
	}
	
	/*
	 * Used to load the category id based on name.
	 */
	public static Map<String, String> loadCategoryOptions() throws Exception {
		Map<String, String> categoryOptions = new HashMap<String, String>();
		try {
			DocumentBuilder dBuilder = DocumentBuilderFactory.newInstance()
					.newDocumentBuilder();
			
			InputStream is = Utils.class.getResourceAsStream("/category_options.xml");
			Document doc = dBuilder.parse(is);
			NodeList nList = doc.getElementsByTagName("category_option");
			
			for (int temp = 0; temp < nList.getLength(); temp++) {
				Node nNode = nList.item(temp);
				if (nNode.getNodeType() == Node.ELEMENT_NODE) {
					Element eElement = (Element) nNode;
					categoryOptions.put(eElement.getAttribute("name"), eElement.getAttribute("value"));
				}
			}
		} catch (SAXException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return categoryOptions;
	}
	
	/*
	 * Used to load the relationships
	 */
	public static Map<String, Integer> loadRelationships() throws Exception {
		Map<String, Integer> categoryOptions = new HashMap<String, Integer>();
		try {
			DocumentBuilder dBuilder = DocumentBuilderFactory.newInstance()
					.newDocumentBuilder();
			
			InputStream is = Utils.class.getResourceAsStream("/relationships.xml");
			Document doc = dBuilder.parse(is);
			NodeList nList = doc.getElementsByTagName("relationship");
			
			for (int temp = 0; temp < nList.getLength(); temp++) {
				Node nNode = nList.item(temp);
				if (nNode.getNodeType() == Node.ELEMENT_NODE) {
					Element eElement = (Element) nNode;
					categoryOptions.put(eElement.getAttribute("name"), Integer.parseInt(eElement.getAttribute("id")));
				}
			}
		} catch (SAXException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return categoryOptions;
	}
}
