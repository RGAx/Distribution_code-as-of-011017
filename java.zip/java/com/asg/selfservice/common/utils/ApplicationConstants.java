package com.asg.selfservice.common.utils;


/**
 * This class has been used to define the general constants.
 * 
 * @author M1030133
 *
 */
public class ApplicationConstants {
	
	public static final int ZERO = 0;
	public static final int ONE = 1;
	public static final int TWO = 2;
	public static final int THREE = 3;
	public static final int FOUR = 4;
	public static final int FIVE = 5;
	public static final int SIX = 6;
	public static final int SEVEN = 7;
	public static final int EIGHT = 8;
	public static final int NINE = 9;
	public static final int TEN = 10;
	public static final int ELEVEN = 11;
	public static final int TWELVE = 12;
	public static final int THIRTEEN = 13;
	public static final int FOURTEEN = 14;
	public static final int FIFTEEN = 15;
	public static final int SIXTEEN = 16;
	public static final int SEVENTEEN = 17;
	public static final int EIGHTEEN = 18;
	public static final int NINETEEN = 19;
	public static final int TWENTY = 20;
	public static final int TWENTY_ONE = 21;
	public static final int TWENTY_TWO = 22;
	public static final int TWENTY_THREE = 23;
	public static final int TWENTY_FOUR = 24;
	public static final int TWENTY_FIVE = 25;
	public static final int TWENTY_SIX = 26;
	public static final int TWENTY_SEVEN = 27;
	public static final int TWENTY_EIGHT = 28;
	public static final int TWENTY_NINE = 29;
	public static final int THIRTY = 30;
	public static final int THIRTY_ONE = 31;
	public static final int THIRTY_TWO = 32;
	public static final int THIRTY_THREE = 33;
	public static final int THIRTY_FOUR = 34;
	public static final int THIRTY_FIVE = 35;
	public static final int THIRTY_SIX = 36;
	public static final int THIRTY_SEVEN = 37;
	public static final int THIRTY_EIGHT = 38;
	public static final int THIRTY_NINE = 39;
	public static final int FOURTY = 40;
	public static final int FOURTY_ONE = 41;
	public static final int FOURTY_TWO = 42;
	public static final int FOURTY_THREE = 43;
	public static final int FOURTY_FOUR = 44;
	public static final int FOURTY_FIVE = 45;
	

	public static final int healthQuestionSetID = 1;
	public static final int smokingQuestionSetID = 2;

	public static final int medicalhistoryQuestionSetID = 3;
	public static final int familyhistoryQuestionSetID = 4;
	public static final int drivinghistoryQuestionSetID = 5;
	
	public static final int healthQuestionIDForHeight = 4;
	public static final int healthQuestionIDForWeight = 5;
	
	public static final int treatmentHistQuestionSetID = 6;
	public static final int applicationQuestionSetID = 7;
	public static final int medicalConditionsQuestionSetID = 8;
	
	
	public static final int QuestionIDForcholestrolLevel = 28;
	public static final int QuestionIDForhdlLevel=29;	
	public static final int QuestionID_bp_syspressureLevel = 33;
	public static final int QuestionID_bp_diaspressureLevel = 34;
	public static final int QuestionID_Family_Relations = 39;
	public static final int QuestionID_Family_Ages = 40;
	public static final int QuestionID_Reason_Insurance = 66;
	public static final int QuestionID_Pref_Payment_Period = 67;
	public static final int QuestionID_Beneficiary_RelationShips = 69;
	public static final int QuestionID_Beneficiary_Percentages = 70;
	public static final int QuestionID_trustee_RelationShips = 115;
	
	
	// Prospect Service
	public static final int USER_PROFILE_CREATED = 1;
	public static final int USER_PROFILE_NOT_CREATED = 0;
	
	public static final String COVERAGE = "$250,000";
	public static final int TERM = 10;
	
	public static final String LOGOUT = "logout";
	public static final String ERROR = "error";
	
	public static final String LANDINGPAGE = "landingPage";
	public static final String URL_CLICK = "URL_CLICK";
	public static final String LOGIN = "login";
	
	public static final String PROFILE = "profile";
	public static final String HEALTH = "health";
	public static final String SMOKING = "smoking";
	public static final String QUOTE = "quote";
	public static final String SEARCH = "search";
	public static final String MEDICAL_PROFILE = "medicalprofile";
	public static final String DRIVING = "driving";
	public static final String TREATMENT = "treatment";
	public static final String FAMILY = "family";
	public static final String NEW_LANDING_PAGE = "new_landing_page";
	public static final String ADMIN_PAGE = "adminPage";
	public static final String ADMIN_HEALTH = "adminHealth";
	public static final String ADMIN_USER = "adminUser";
	public static final String ADMIN = "ADMIN";
	public static final String CUSTOM_USER = "customUser";
	
	public static final String PAGE_FROM = "pageFrom";
	public static final String AJAX_PAGE_FROM = "ajaxPageFrom";
	public static final String AJAX_PAGE_CALL = "ajaxPageCall";
	public static final String EMAIL = "email";
	public static final String CUSTOMERCALLBACK = "customercallback";
	
	//MedicalConditions Page	
	public static final String MEDICALCONDITIONS = "medicalconditions"; 
	
	//Applications Page
	public static final String APPLICATION = "application";
	
	//EBIX service 
	public static final boolean BreakDownPremiums=false;
	public static final boolean CalcToPenny=true;
	public static final boolean DisplayProductClasses=false;
	public static final boolean GetCompanyInfo=true;
	public static final boolean ShowCurrentRates=false;
	public static final boolean ShowRemovedProducts=true;
	public static final boolean ShowProdInfoOnRemoval=true;
	public static final boolean ShowProdInfoOnly=false;
	public static final boolean ShowPremiumsOnly=false;
	public static final boolean Calc1StYearModal=true;
	
	//Login section
	public static final int LOGIN_UNSUCCESSFUL_ATTEMPTS_COUNT = 3;
	public static final int ACCOUNT_UNLOCK_TIME = 15;
	
	//for legal statement
	public static final String BANK = "Bank"; 
	public static final String FDIC = "Federal Deposit Insurance Corporation (FDIC)";
	public static final String NCUA = "National Credit Union Administration (NCUA)";
	public static final String LEGAL_STMT = "legal";
	
	//privacy, Terms and condtion
	public static final String TERMS_CONDN = "terms_conditions";
	public static final String PRIVACY_INFO = "privacy";
	
	//QUOTE_SUBMISSION_STATUS and APPLICATION_SUBMISSION_STATUS
	public static final int QUOTE_SUBMITTED_STATUS = 2;
	public static final int APPLICATION_SUBMITTED_SUCCESS = 3;
	public static final int APPLICATION_SUBMITTED_FAILED = 4;
	
	//For Disclaimer TextPage Navigation
	public static final String DISCLAIMER = "disclaimer";

}
