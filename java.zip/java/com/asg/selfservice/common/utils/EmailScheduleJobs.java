package com.asg.selfservice.common.utils;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.asg.selfservice.common.logger.LogFactory;
import com.asg.selfservice.common.logger.SelfServiceLogger;
import com.asg.selfservice.domain.Quote;
import com.asg.selfservice.domain.UserProfile;
import com.asg.selfservice.exception.DAOException;
import com.asg.selfservice.exception.ServiceException;
import com.asg.selfservice.services.ProfileService;
import com.asg.selfservice.services.QuoteService;
import com.asg.selfservice.services.ScheduleJob;
import com.asg.selfservice.services.impl.EmailServiceImpl;


/*
 * This Class Schedule the Email Triggering to User who have saved the form data. 
 * This Job will run @ 12 A.M or 1 A.M EST every day.
 * The Email is sent to user 2 time only i.e on 7th day and 15th day from the date of saved.
 * 
 * 
 */
@Component("syncEmailScheduleJobs")
public class EmailScheduleJobs implements ScheduleJob {

	private static final SelfServiceLogger logger = LogFactory.getInstance(EmailScheduleJobs.class);
	
	@Autowired
	private ProfileService profileService;
	
	@Autowired
	private EmailServiceImpl sendEmail;
	
	@Autowired
	private QuoteService quoteService;
	
	@Value("${email.emailreminder.subject}") 
	private String subject;
	
	@Value("${email.forgotpassword.from}")
	private String mailaddress;
	
	@Value("#{'${application.context.url}'}") 
	private String contextURL; 
	
	
	
	/*
	 * This Method Schedule the Email Triggering to User who have saved questions and left the application. 
	 * This Job will run @ 12 A.M or 1 A.M EST every day.
	 * The Email is sent to user 3 time only i.e on 3rd day, 5th day and  7th day from the date of saved.
	 * 
	 * 
	 */
	
	@Override
	public  void scheduledEmailJob() throws ServiceException, DAOException {
	String threadName = Thread.currentThread().getName();
	
	logger.info("   " + threadName + " has began working.");			
				           				   
			     		try {
			     				
			     			String formatedmsg;
			     			String from; 
			     			 synchronized(this) {
			     							     				
			     				
			     				 List<UserProfile> list = profileService.fetchSavedData();
			     				 for (UserProfile up : list){
			     					 
			     					 //Long days = Utils.getNoofDays(up.getSavedDate());
			     					Long days = Utils.getNoofDays(up.getLastUpdateDate());
			     					logger.info("days : " + days);	
			     					//Modified 
			     					if(days == 3 || days == 5 || days == 7 ) {
			     						logger.info("Send email process started");
			     						// String name = up.getFirstName();
			     						String emailAddress = up.getEmailAddress();	
			     									     					 	
			     						String agency_name = up.getAgency_name();
			     						agency_name = agency_name.replace(" ","");
			     						from = agency_name.concat(mailaddress);
			     					 	
			     						formatedmsg = setMeassage(up.getAgency_name(),up.getFirstName(),up.getEncryptedUid());
			     						
			     						if(null != formatedmsg){
			     							sendEmail.sendMail(from, emailAddress, subject, formatedmsg);
			     						} else{
			     							sendEmail.sendMail(from, emailAddress, subject, null);
			     						}
			     					
			     						logger.info("Send email process ends here");
			     				 }
			     					     				
			     				 }
			     				
			     			 }
			     			 
			     		} catch (ServiceException e) {
							logger.error("ERROR : " + e.getMessage());
							throw new ServiceException(e.getMessage());
						}
			     		
			     		logger.info("   " + threadName + " has completed work.");		        
			       
			 }
	
	/*
	 * This Method Schedule the Email Triggering to User who have saved the form data. 
	 * This Job will run @ 12 A.M or 1 A.M EST every day.
	 * The Email is sent to user 3 time only i.e on 3rd day, 5th day and  7th day from the date of saved.
	 * 
	 * 
	 */
	@Override
	public  void scheduledEmailJobForHitSave() throws ServiceException, DAOException {
	String threadName = Thread.currentThread().getName();
	
	logger.info("   " + threadName + " has began working.");			
				           				   
			     		try {
			     				
			     			String formatedmsg;
			     			String from; 
			     			 synchronized(this) {
			     							     				
			     				
			     				 List<UserProfile> list = profileService.getUserProfilesForStatus1();
			     				 for (UserProfile up : list){
			     					Long days = Utils.getNoofDays(up.getLastUpdateDate());
			     					logger.info("days : " + days);	
			     					
			     					if(days == 3 || days == 5 || days==7 ) {
			     						logger.info("Send email process started for scheduledEmailJobForHitSave");
			     						String emailAddress = up.getEmailAddress();	
			     									     					 	
			     						String agency_name = up.getAgency_name();
			     						agency_name = agency_name.replace(" ","");
			     						from = agency_name.concat(mailaddress);
			     					 	
			     						formatedmsg = setMeassageForHitSave(up);
			     						
			     						if(null != formatedmsg){
			     							sendEmail.sendMail(from, emailAddress, subject, formatedmsg);
			     						} else{
			     							sendEmail.sendMail(from, emailAddress, subject, null);
			     						}
			     					
			     						logger.info("Send email process ends here");
			     				 }
			     					     				
			     				 }
			     			
			     				
			     			 }
			     			 
			     		} catch (ServiceException e) {
							logger.error("ERROR : " + e.getMessage());
							throw new ServiceException(e.getMessage());
						}
			     		
			     		logger.info("   " + threadName + " has completed work.");		        
			       
			 }

	/*
	 * This Method Schedule the Email Triggering to User who has clicked on apply now and exited the site. 
	 * This Job will run @ 12 A.M or 1 A.M EST every day.
	 * The Email is sent to user 3 time only i.e on 3rd day, 5th day and  7th day from the date of saved.
	 * 
	 * 
	 */
	
	@Override
	public  void scheduledEmailJobForApplyNow() throws ServiceException, DAOException {
	String threadName = Thread.currentThread().getName();
	
	logger.info("   " + threadName + " has began working.");			
				           				   
			     		try {
			     				
			     			String formatedmsg;
			     			String from; 
			     			 synchronized(this) {
			     							     				
			     				
			     				 List<UserProfile> list = profileService.getUserProfilesForStatus2();
			     				 for (UserProfile up : list){
			     					 Quote quote = quoteService.getQuote(up.getUserId());
			     					Long days = Utils.getNoofDays(up.getLastUpdateDate());
			     					logger.info("days : " + days);	
			     					
			     					if(days == 3 || days == 5 || days==7 ) {
			     						logger.info("Send email process started for scheduledEmailJobForApplyNow");
			     						String emailAddress = up.getEmailAddress();	
			     									     					 	
			     						String agency_name = up.getAgency_name();
			     						agency_name = agency_name.replace(" ","");
			     						from = agency_name.concat(mailaddress);
			     					 	
			     						formatedmsg = setMeassageForApplyNow(up,quote);
			     						
			     						if(null != formatedmsg){
			     							sendEmail.sendMail(from, emailAddress, subject, formatedmsg);
			     						} else{
			     							sendEmail.sendMail(from, emailAddress, subject, null);
			     						}
			     					
			     						logger.info("Send email process ends here");
			     				 }
			     					     				
			     				 }
			     			
			     				
			     			 }
			     			 
			     		} catch (ServiceException e) {
							logger.error("ERROR : " + e.getMessage());
							throw new ServiceException(e.getMessage());
						}
			     		
			     		logger.info("   " + threadName + " has completed work.");		        
			       
			 }
	
	private String setMeassageForHitSave(UserProfile up) {
			String msg = null;
		
		if(null != up) {
		 msg = "Hi " +up.getFirstName()+ ",<br><br>" 
				+ "It looks as though you left the site before finishing. We \'ve made it easier for you to <a href=\""+contextURL+"login.html\">Click Here</a> to continue.<br><br>"
				+ "Regards,<br>"
				+ up.getAgency_name();
		}
		
		return msg;
	}

	private String setMeassageForApplyNow(UserProfile up, Quote quote) {
		String msg = null;
		
		if(null != up && null != quote) {
			//Image loading
			if((quote.getCompanyName() != null && quote.getCompanyName().contains("AG"))
					|| (quote.getPolicyName() != null && quote.getPolicyName().contains("AG"))) {
				quote.setCompanyLogo("AIG_logo");
			} else if((quote.getCompanyName() != null && quote.getCompanyName().contains("Banner"))
					|| (quote.getPolicyName() != null && quote.getPolicyName().contains("Banner"))) {
				quote.setCompanyLogo("Banner_logo");
			} else if((quote.getCompanyName() != null && quote.getCompanyName().contains("Principal"))
					|| (quote.getPolicyName() != null && quote.getPolicyName().contains("Principal"))) {
				quote.setCompanyLogo("Principal_logo");
			} else if((quote.getCompanyName() != null && quote.getCompanyName().contains("Protective"))
					|| (quote.getPolicyName() != null && quote.getPolicyName().contains("Protective"))) {
				quote.setCompanyLogo("Protectivelife_logo");
			} else if((quote.getCompanyName() != null && quote.getCompanyName().contains("Sagicor"))
					|| (quote.getPolicyName() != null && quote.getPolicyName().contains("Sagicor"))) {
				quote.setCompanyLogo("Sagicor_logo");
			}else{
				//optional code- if the image loading fails.
				quote.setCompanyLogo("Company Logo cannot be loaded.");
			}
			
		 msg = "Hi " +up.getFirstName()+ ",<br><br>" 
				+ "It looks as though you left the site before finishing. We \'ve made it easier for you to <a href=\""+contextURL+"login.html\">Click Here</a> to continue.<br>"
				+ "The carrier chosen is "+ quote.getCompanyName()+" with monthly premium "+ quote.getMonthlyPremium()+".<br>"
				+"<table>"
				+"<tr style=\"background: #527589; height: 100px\"  align=\"center\">"
				+"<td style=\"width: 300px;\" valign=\"middle\">"
				//+"<img alt=\""+quote.getCompanyLogo()+"\" src=\"http://localhost:8080/ArchInsurance/resources/carrierlogos/"+quote.getCompanyLogo()+".png\"></td>"
				+"<img alt=\""+quote.getCompanyLogo()+"\" src=\""+contextURL+"resources/carrierlogos/"+quote.getCompanyLogo()+".png\"></td>"
				+"</tr>"
				+"<tr style=\"background: #a2bdce; color: #7b7c7e\"  align=\"center\"><td>Monthly Premium</td></tr>"
				+"<tr align=\"center\" style=\"background: #edeef0; color: #527589\"><td>"+quote.getMonthlyPremium()+"</td></tr>"
				+"</table><br><br>"
				+ "Regards,<br>"
				+ up.getAgency_name();
		}
		
		
		return msg;
	}
	
	/*
	 * Email Messages
	 */
	public String setMeassage(String agencyName, String firstName, String encryptedUID) {
		String msg = null;
		
		if(null != agencyName && null != firstName &&null!=encryptedUID) {
		 msg = "Hi " +firstName+ ",<br><br>" 
				+ "It looks as though you left the site before finishing. We \'ve made it easier for you to <a href=\""+contextURL+"home?userID="+encryptedUID+"\">Click Here</a> here to continue. <br><br>"
				+ "Regards,<br>"
				+ agencyName;
		}
		//String formattedMessage = MessageFormat.format(msg1, "http://google.com", "agencyName");
		//System.out.println(formattedMessage); // Richard has to go to School in 31/05/2012 / 1days

		return msg;
	}
	
	
}
