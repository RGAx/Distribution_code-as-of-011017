/**
 * 
 */
package com.asg.selfservice.common.utils;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.springframework.web.servlet.view.document.AbstractExcelView;

import com.asg.selfservice.domain.CampaignReport;

/**
 * @author M1027376
 *
 */
public class ReportBuilder extends AbstractExcelView {

	@Override
	protected void buildExcelDocument(Map<String, Object> model, HSSFWorkbook workbook, HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		
		@SuppressWarnings("unchecked")
		List<CampaignReport> campaignReport = (List<CampaignReport>) model.get("campaignReport");
		
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		Date date = new Date();
		String currentDate = dateFormat.format(date);
		
		String excelName = "HighLevel_Summary_Report"+"_"+currentDate;
		response.setContentType("application/vnd.ms-excel");
		response.setHeader("Content-Disposition", "attachment; filename="+excelName+".xls");
		
		// create a new Excel sheet
		HSSFSheet sheet = workbook.createSheet(excelName);
		sheet.setDefaultColumnWidth(30);
		
		// create style for header cells
		CellStyle style = workbook.createCellStyle();
		Font font = workbook.createFont();
		font.setFontName("Calibri");
		
		//style.setFillForegroundColor(HSSFColor.BLUE.index);
		//style.setFillPattern(CellStyle.SOLID_FOREGROUND);
		//font.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
		//font.setColor(HSSFColor.WHITE.index);
		style.setFont(font);
		
		// create header row
		HSSFRow header = sheet.createRow(0);
		
		header.createCell(0).setCellValue("Sl No");
		header.getCell(0).setCellStyle(style);
		
		header.createCell(1).setCellValue("Campaign Date");
		header.getCell(1).setCellStyle(style);
		
		header.createCell(2).setCellValue("Campaign ID");
		header.getCell(2).setCellStyle(style);
		
		header.createCell(3).setCellValue("Agency Name");
		header.getCell(3).setCellStyle(style);
		
		header.createCell(4).setCellValue("Campaign Size");
		header.getCell(4).setCellStyle(style);
		
		header.createCell(5).setCellValue("Users clicked on Apply Now");
		header.getCell(5).setCellStyle(style);
		
		header.createCell(6).setCellValue("Users with different coverage & term");
		header.getCell(6).setCellStyle(style);
		
		header.createCell(7).setCellValue("Users left application");
		header.getCell(7).setCellStyle(style);
		
		header.createCell(8).setCellValue("Users profile created");
		header.getCell(8).setCellStyle(style);
		
		header.createCell(9).setCellValue("Users submitted application");
		header.getCell(9).setCellStyle(style);
		
		// create data rows
		int rowCount = 1;
				
		for (int i=0; i<campaignReport.size(); i++) {
			HSSFRow aRow = sheet.createRow(rowCount++);
			aRow.createCell(0).setCellValue(i+1);
			aRow.createCell(1).setCellValue(campaignReport.get(i).getCampaigndate());
			aRow.createCell(2).setCellValue(campaignReport.get(i).getCampaignId());
			aRow.createCell(3).setCellValue(campaignReport.get(i).getAgencyName());
			aRow.createCell(4).setCellValue(campaignReport.get(i).getCampaignSize());
			aRow.createCell(5).setCellValue(campaignReport.get(i).getApplynowCount());
			aRow.createCell(6).setCellValue(campaignReport.get(i).getDiffcoverageCount());
			aRow.createCell(7).setCellValue(campaignReport.get(i).getMidwayCount());
			aRow.createCell(8).setCellValue(campaignReport.get(i).getCreatedprofCount());
			aRow.createCell(9).setCellValue(campaignReport.get(i).getSubmittedCount());
		}
	}

}
