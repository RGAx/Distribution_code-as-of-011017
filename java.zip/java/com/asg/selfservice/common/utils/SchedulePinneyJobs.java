package com.asg.selfservice.common.utils;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.asg.selfservice.common.logger.LogFactory;
import com.asg.selfservice.common.logger.SelfServiceLogger;
import com.asg.selfservice.pinney.services.impl.PinneyServiceHelperImpl;
import com.asg.selfservice.services.ProfileService;
import com.asg.selfservice.services.RunPinneyScheduler;


/*
 * This Class Schedule the Pinney Triggering to User who have submitted the application to pinney  but Live submission failed for some reason. 
 * This Job will run @ 12 A.M or 1 A.M EST every day to fetch the failed records and submit it to pinney.
 * 
 * 
 * 
 */
@Component("syncSchedulePinneyJobs")
public class SchedulePinneyJobs implements RunPinneyScheduler {

	private static final SelfServiceLogger logger = LogFactory.getInstance(SchedulePinneyJobs.class);
	
	@Autowired
	private ProfileService profileService;
	
	@Autowired
	private PinneyServiceHelperImpl pinneyserviceHelper;

	@Override
	public void schedulePinneyJob() throws Exception {
		try {
			pinneyserviceHelper.runPinneyScheduler();
		} catch (Exception e) {
			logger.error("ERROR : " + e.getMessage());
			throw new Exception(e.getMessage());
		}
		
	}

	
	
}
