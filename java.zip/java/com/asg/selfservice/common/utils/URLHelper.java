package com.asg.selfservice.common.utils;

import java.util.Properties;

public class URLHelper {
	
	protected static String ebixEndPointURL = null;
	protected static String pinneyEndPointURL = null;
	protected static final String SERVICE_EBIX_ENDPOINT_URL = "service.ebix.endpoint.url";
	protected static final String SERVICE_PINNEY_ENDPOINT_URL = "service.pinney.endpoint.url";
	protected static String INIT_PROP  = "application.properties";

	public static Properties props = new Properties();
	
	static {
		try{
			 props.load(Thread.currentThread().getContextClassLoader().getResourceAsStream(INIT_PROP));
		}catch(Exception ex){
			ex.getMessage();
			//System.out.println("Error while loading properties file"+ex.getMessage());			
		}
	}
	
	public static String getEbixServiceAddress() 
	{
		 
		ebixEndPointURL = (String)props.get(SERVICE_EBIX_ENDPOINT_URL);
        return ebixEndPointURL;
	}
	
	public static String getPennyServiceAddress() 
	{
		 
		pinneyEndPointURL = (String)props.get(SERVICE_PINNEY_ENDPOINT_URL);
        return pinneyEndPointURL;
	}
	
	public static String getKeyProperty(String key){
		return (String)props.get(key);
	}
	
}