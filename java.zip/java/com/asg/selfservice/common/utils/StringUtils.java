package com.asg.selfservice.common.utils;

import java.security.SecureRandom;
import java.util.Random;

public class StringUtils
{

  private static final Random RANDOM = new SecureRandom();
  /** Length of password. @see #generateRandomPassword() */
  public static final int PASSWORD_LENGTH = 8;
  /**
   * Generate a random String suitable for use as a temporary password.
   *
   * @return String suitable for use as a temporary password
   * @since 2.4
   */
  public static String generateRandomPassword()
  {
      // Pick from some letters that won't be easily mistaken for each
      // other. So, for example, omit o O and 0, 1 l and L.
      String letters = "abcdefghjkmnpqrstuvwxyzABCDEFGHJKMNPQRSTUVWXYZ";
      String alphaNumeric = "23456789][?/<~#!@$%^&*()+=}|:;',>{";     

      StringBuilder sb = new StringBuilder();
      for (int i=0; i<6; i++)
      {
          int index = (int)(RANDOM.nextDouble()*letters.length());
          sb.append(letters.substring(index, index+1));
      }
      for (int i=0; i<2; i++)
      {
          int index = (int)(RANDOM.nextDouble()*alphaNumeric.length());
          sb.append(alphaNumeric.substring(index, index+1));
      }     
      return sb.toString();
  }
}

