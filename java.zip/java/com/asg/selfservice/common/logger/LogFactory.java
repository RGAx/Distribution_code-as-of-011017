package com.asg.selfservice.common.logger;

@SuppressWarnings("rawtypes")
public class LogFactory {
	public static SelfServiceLogger getInstance() {
		return new SelfServiceLoggerImpl();
	}

	public static SelfServiceLogger getInstance(String className) {
		return new SelfServiceLoggerImpl(className);
	}

	public static SelfServiceLogger getInstance(Class clazz) {
		return new SelfServiceLoggerImpl(clazz.getCanonicalName());
	}
}