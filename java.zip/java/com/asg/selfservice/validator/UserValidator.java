package com.asg.selfservice.validator;

import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.asg.selfservice.domain.UserProfile;

/**
 * Validates the user fields.
 * @author M1030133
 *
 */
@Component
public class UserValidator implements Validator {
 
	@Override
    public boolean supports(Class clazz) {
        return UserProfile.class.isAssignableFrom(clazz);
    }
 
	@Override
    public void validate(Object target, Errors errors) {
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "emailAddress", "emailAddress.required");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "password", "password.required");
    }
}