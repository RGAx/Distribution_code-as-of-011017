package com.asg.selfservice.pinney.services.impl;

import java.util.Arrays;
import java.util.List;

import org.apache.commons.codec.binary.Base64;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import com.asg.selfservice.common.logger.LogFactory;
import com.asg.selfservice.common.logger.SelfServiceLogger;
import com.asg.selfservice.common.utils.ApplicationConstants;
import com.asg.selfservice.domain.QuestionAnswer;
import com.asg.selfservice.domain.UserProfile;
import com.asg.selfservice.exception.ServiceException;
import com.asg.selfservice.services.ProfileService;

/**
 * This class has been used for the operations such as constructing the pinney
 * request and execute the pinney request to get the json response object.
 * 
 * @author M1030133
 *
 */
public class PinneyServiceHelperImpl {
	private static final SelfServiceLogger logger = LogFactory.getInstance(PinneyServiceHelperImpl.class);
	
	@Autowired
	private PinneyRequestProcessor pinneyRequestProcessor;
	
	@Autowired
	private ProfileService profileService;
	
	private RestTemplate restTemplate = new RestTemplate(); 
	
	@Value("${pinney.connection.url}")
	private String pinneyConnectionURL;
	
	@Value("${pinney.profile.username}")
	private String pinneyProfileUsername;
	
	@Value("${pinney.profile.password}")
	private String pinneyProfilePassword;
	
	/*
	 * This method has been used for constructing the pinney request by using the user profile details.
	 */
	public boolean pinneyRequest(UserProfile userProfile) throws Exception {
		final long startTime = logger.logMethodEntry();
		try {
			List<QuestionAnswer> questAnsList = pinneyRequestProcessor.loadUserQuestionAnswers(userProfile);
			
			String json = pinneyRequestProcessor.constructJsonRequest(questAnsList, userProfile);
			logger.info("Request in Json : "+ json);
			
			JSONObject response  = executePinneyRequest(json);
			logger.info("Response : "+ response);
			logger.logMethodExit(startTime);
		
			return true;
		} catch (ServiceException e) {
			logger.error("ERROR : " + e.getMessage());
			return false;
		
		} catch (Exception e) {
			logger.error("ERROR : " + e.getMessage());
			return false;
		}
	}
	
	/*
	 * This method has been for executing the pinney request after taking the 
	 * constructed json string.
	 */
	public JSONObject executePinneyRequest(String json) throws Exception {
		final long startTime = logger.logMethodEntry();
		
		HttpHeaders requestHeaders = new HttpHeaders();
		
		String plainCreds = pinneyProfileUsername+":"+pinneyProfilePassword;
		byte[] plainCredsBytes = plainCreds.getBytes();
		byte[] base64CredsBytes = Base64.encodeBase64(plainCredsBytes);
		String base64Creds = new String(base64CredsBytes);
		requestHeaders.add("Authorization", "Basic " + base64Creds);
		 
		requestHeaders.setContentType(new MediaType("application","json"));
		requestHeaders.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		
		HttpEntity<String> requestEntity = new HttpEntity<String>(json, requestHeaders);
		
		JSONObject response;
		try {
			logger.info("Executing pinney Request:" + json);
			response = restTemplate.postForObject(pinneyConnectionURL, requestEntity, JSONObject.class);
			
			logger.info("Executed successfully : response - "+ response);
		} catch (RestClientException e) {
			logger.error("ERROR : " + e.getMessage());
			throw new Exception(e.getMessage());
		} catch(Exception e) {
			logger.error("ERROR : " + e.getMessage());
			throw new Exception(e.getMessage());
		}
		logger.logMethodExit(startTime);
		return response;
	}
	
	
	/*
	 * Pinney scheduler method to check for failed records from DB The column
	 * profile_status_flag = 4 ( failed) if = 3 (Passed)
	 */
	public void runPinneyScheduler() throws Exception {
		final long startTime = logger.logMethodEntry();
		int counter = 0;
		try {
			logger.info("Pinney scheduler started");
			List<UserProfile> pinneyFailedList = pinneyRequestProcessor.loadFailedPinneySubmision();
			for (UserProfile pinneylist : pinneyFailedList) {
				try {
					logger.info("User - " + pinneylist.getFirstName() + ", Userid - "+ pinneylist.getUserId());
					boolean pinneyStatus = pinneyRequest(pinneylist);
					logger.info("pinneyStatus : " + pinneyStatus);
					
					pinneylist.setProfileStatusFlag(pinneyStatus ? ApplicationConstants.APPLICATION_SUBMITTED_SUCCESS : ApplicationConstants.APPLICATION_SUBMITTED_FAILED);
					
					logger.info("Status updating to " + pinneylist.getProfileStatusFlag());
					profileService.updateUserProfileStatus(pinneylist);
				} catch (ServiceException e) {
					logger.error("ERROR : " + e.getMessage());
					throw new Exception(e.getMessage());
					
				} catch (Exception e) {
					logger.error("ERROR : " + e.getMessage());
					throw new Exception(e.getMessage());
				}
				counter = counter + 1;
				logger.info("Pinney scheduler ends here : counter - " + counter);
			}
			logger.logMethodExit(startTime);
		} catch (RestClientException e) {
			logger.error("ERROR : " + e.getMessage());
			throw new Exception(e.getMessage());
			
		} catch (Exception e) {
			logger.error("ERROR : " + e.getMessage());
			throw new Exception(e.getMessage());
		}
	}
}
