package com.asg.selfservice.pinney.services.impl;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import com.asg.selfservice.common.logger.LogFactory;
import com.asg.selfservice.common.logger.SelfServiceLogger;
import com.asg.selfservice.common.utils.ApplicationConstants;
import com.asg.selfservice.common.utils.Utils;
import com.asg.selfservice.controller.pinney.PinneyClient;
import com.asg.selfservice.domain.QuestionAnswer;
import com.asg.selfservice.domain.Quote;
import com.asg.selfservice.domain.UserProfile;
import com.asg.selfservice.domain.pinney.Address;
import com.asg.selfservice.domain.pinney.Beneficiary;
import com.asg.selfservice.domain.pinney.Client;
import com.asg.selfservice.domain.pinney.Contact_info;
import com.asg.selfservice.domain.pinney.Email;
import com.asg.selfservice.domain.pinney.FamilyAttribute;
import com.asg.selfservice.domain.pinney.Financial_info;
import com.asg.selfservice.domain.pinney.Health_history;
import com.asg.selfservice.domain.pinney.Health_info;
import com.asg.selfservice.domain.pinney.Moving_violation_history;
import com.asg.selfservice.domain.pinney.Policies;
import com.asg.selfservice.domain.pinney.Policy_details;
import com.asg.selfservice.domain.pinney.Relatives_disease;
import com.asg.selfservice.exception.ServiceException;
import com.asg.selfservice.services.GenericService;
import com.asg.selfservice.services.QuoteService;
import com.ebix.lifelink.client.NotesAttribute;
import com.google.gson.Gson;

/**
 * This class has been used for loading the question answers from the database
 * corresponding to the user and constructing the json request using those
 * question answers.
 * 
 * @author M1030133
 *
 */
public class PinneyRequestProcessor {
	private static final SelfServiceLogger logger = LogFactory.getInstance(PinneyRequestProcessor.class);
	
	@Autowired
	private GenericService genericService;
	
	@Autowired
	private QuoteService quoteService;
	
	@Value("#{'${insuritas.pinney.agencies}'.split(',')}") 
	private List<String> insuritasPinneyAgencies;
	
	@Value("${insuritas.pinney.profile.id}")
	private int insuritasPinneyProfileID;
	
	@Value("${liazon.pinney.profile.id}")
	private int liazonPinneyProfileID;
	
	@Value("${william.pinney.profile.id}")
	private int williamPinneyProfileID;
	
	@Value("${pinney.user.id}")
	private int pinneyUserID;
	
	@Value("${pinney.term.id}")
	private int termID;
	
	@Value("${pinney.response.type}")
	private String responseType;
	
	private SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
	
	/*
	 * This method has been used for loading the question answer from the DB based on the current user.
	 */
	public List<QuestionAnswer> loadUserQuestionAnswers(UserProfile userProfile) throws ServiceException {
		final long startTime = logger.logMethodEntry();
		
		List<QuestionAnswer> questionAnsList;
		try {
			questionAnsList = genericService.loadQuestionAnswersForPinney(userProfile.getUserId());
		} catch (ServiceException e) {
			logger.error("ERROR : " + e.getMessage());
			throw new ServiceException(e.getMessage());
		}
		logger.logMethodExit(startTime);
		return questionAnsList;
	}
	
	/*
	 * This method has been used for constructing the json request by using the question answers and 
	 * the user details which can be used for getting the json response after passing to Pinney.
	 */
	public String constructJsonRequest(List<QuestionAnswer> questionAnsList, UserProfile userProfile) throws Exception {
		final long startTime = logger.logMethodEntry();
		
		String json = null;
		try {
			PinneyClient crm_connection_Client = new PinneyClient();
			crm_connection_Client.setUserId(pinneyUserID);
			
			Client crm_connection = new Client();
			crm_connection.setActive(true);
			crm_connection.setBirth(dateFormat.format(userProfile.getDob()));
			if(Utils.loadStates().get(userProfile.getAddressState()) != null) {
				crm_connection.setBirth_state_name(Utils.loadStates().get(userProfile.getAddressState()));
			}
			
			crm_connection.setContact_info_attributes(this.constructContactInfo(userProfile));
			crm_connection.setFirst_name(userProfile.getFirstName());
			crm_connection.setGender(userProfile.getGender() != null && "M".equalsIgnoreCase(userProfile.getGender()) ? "Male" : "Female");
			crm_connection.setLast_name(userProfile.getLastName());
			
			if (userProfile.getAgency_name() != null && !userProfile.getAgency_name().isEmpty()) {
				if (userProfile.getAgency_name().equalsIgnoreCase("William Raveis")) {
					crm_connection.setProfile_id(williamPinneyProfileID);
				
				} else if (insuritasPinneyAgencies != null
						&& insuritasPinneyAgencies.contains(userProfile.getAgency_name())) {
					crm_connection.setProfile_id(insuritasPinneyProfileID);
				
				} else {
					crm_connection.setProfile_id(insuritasPinneyProfileID);
				}
			}
			
			Quote quote = quoteService.getQuote(userProfile.getUserId());
			
			crm_connection = this.constructCrmConnection(crm_connection, questionAnsList, userProfile, quote);
			crm_connection.setCases_attributes(this.constructCaseAttributes(crm_connection.getCases_attributes(), userProfile, quote));
			
			crm_connection_Client.setCrm_connection(crm_connection);
			crm_connection_Client.setResponse(responseType);
			
			json = new Gson().toJson(crm_connection_Client);
		} catch (Exception e) {
			logger.error("ERROR : " + e.getMessage());
			throw new ServiceException(e.getMessage());
		}
		logger.logMethodExit(startTime);
		return json;
	}
	
	/*
	 * Used to construct the case attribute
	 */
	private List<Policies> constructCaseAttributes(List<Policies> cases_attributes, UserProfile userProfile, Quote quote) throws Exception {
		Policies cases_attribute = cases_attributes.get(0);
		
		String insuranceCoverage = userProfile.getInsuranceCoverage();
		if(insuranceCoverage != null) {
			insuranceCoverage = insuranceCoverage.replace("$", "");
			insuranceCoverage = insuranceCoverage.replace(",", "");
			cases_attribute.setFace_amount(Integer.parseInt(insuranceCoverage));
		}
		if(quote != null) {
			cases_attribute.setApproved_details_attributes(this.constructApprovedDetailsAtrributes(userProfile, quote));
			cases_attribute.setSubmitted_details_attributes(this.constructSubmittedDetailsAttributes(userProfile, quote));
		}
		cases_attributes.set(0, cases_attribute);
		return cases_attributes;
	}

	/*
	 * Used to load the contact infos which can be used to construct the health info attributes.
	 */
	private Contact_info constructContactInfo(UserProfile userProfile) throws Exception {
		//contact_info_attributes starts here
		Contact_info contact_info_attributes = new Contact_info();
		
		List<Address> addresses_attributes = new ArrayList<Address>();
		Address address = new Address();
		address.setValue(userProfile.getAddress1() + "," + userProfile.getAddressState() + "," + userProfile.getZipCode());
		addresses_attributes.add(address);
		
		if(addresses_attributes != null && !addresses_attributes.isEmpty()) {
			contact_info_attributes.setAddresses_attributes(addresses_attributes);
		}
		
		List<Email> emails_attributes = new ArrayList<Email>();
		Email email = new Email();
		email.setValue(userProfile.getEmailAddress());
		emails_attributes.add(email);
		
		if(emails_attributes != null && !emails_attributes.isEmpty()) {
			contact_info_attributes.setEmails_attributes(emails_attributes);
		}
		
		String home_phone_value = userProfile.getPhoneNumber();
		if(home_phone_value != null && home_phone_value != "") {
			home_phone_value = home_phone_value.replace("-", "");
			contact_info_attributes.setHome_phone_value(Double.parseDouble(home_phone_value));
		}

		contact_info_attributes.setCity(userProfile.getAddressCity());
		if(userProfile.getZipCode() != null) {
			contact_info_attributes.setZip(Integer.parseInt(userProfile.getZipCode()));
		}
		if(Utils.loadStateIds().get(userProfile.getAddressState()) != null) {
			contact_info_attributes.setState_id(Utils.loadStateIds().get(userProfile.getAddressState()));
		}
		return contact_info_attributes;
	}
	
	/*
	 * This has been used as an internal method for constructing the health infos from userquestion answer list
	 * which can be used in the above method.
	 */
	private Client constructCrmConnection(Client crm_connection,
			List<QuestionAnswer> questionAnsList, UserProfile userProfile, Quote quote) throws Exception {
		final long startTime = logger.logMethodEntry();
		
		List<NotesAttribute> notes_attributes = new ArrayList<NotesAttribute>();
		NotesAttribute notes_attribute = new NotesAttribute();
		String text = "";
		
		Health_info health_info_attributes = new Health_info();
		Health_history health_history_attributes = new Health_history();
		
		Moving_violation_history moving_violation_history_attributes = new Moving_violation_history();
		String fullNames = null, percentages = null, relationships = null;
		
		Financial_info financial_info_attributes = new Financial_info();
		FamilyAttribute familyAttribute = new FamilyAttribute();
		
		for(QuestionAnswer questionAnswer : questionAnsList) {
			if(questionAnswer.getAnswer() != null && !"0".equalsIgnoreCase(questionAnswer.getAnswer())) {
				
				if(questionAnswer.getQsetId() == ApplicationConstants.healthQuestionSetID) {
					if(questionAnswer.getSequence() == 1) {
						health_info_attributes.setGender(questionAnswer.getAnswer() != null && "M".equalsIgnoreCase(questionAnswer.getAnswer()) ? true : false);
					
					} else if(questionAnswer.getSequence() == 2) {
						health_info_attributes.setBirth(dateFormat.format(new SimpleDateFormat("MM/dd/yyyy").parse(questionAnswer.getAnswer())));
					
					} else if(questionAnswer.getSequence() == 4) {
						int height = Integer.parseInt(questionAnswer.getAnswer());
						health_info_attributes.setFeet(height/12);
						health_info_attributes.setInches(height%12);
					
					} else if(questionAnswer.getSequence() == 5) {
						String answer = questionAnswer.getAnswer();
						if(answer.contains("+")) {
							answer = answer.replace("+", "");
						} else if("Less than 80".equalsIgnoreCase(answer)) {
							answer = "80";
						}
						health_info_attributes.setWeight(Integer.parseInt(answer));
					
					} else if(questionAnswer.getSequence() == 6) {
						health_info_attributes.setSmoker(Integer.parseInt(questionAnswer.getAnswer()) == 1);
					}
				} else if(questionAnswer.getQsetId() == ApplicationConstants.smokingQuestionSetID) {
					if(questionAnswer.getSequence() == 2) {
						health_info_attributes.setCigarettes_current(Integer.parseInt(questionAnswer.getAnswer()) == 1);
					
					} else if(questionAnswer.getSequence() == 3) {
						health_info_attributes.setCigars_current(Integer.parseInt(questionAnswer.getAnswer()) == 1);
					
					} else if(questionAnswer.getSequence() == 4) {
						health_info_attributes.setPipe_current(Integer.parseInt(questionAnswer.getAnswer()) == 1);
					
					} else if(questionAnswer.getSequence() == 5) {
						health_info_attributes.setTobacco_chewed_current(Integer.parseInt(questionAnswer.getAnswer()) == 1);
					
					} else if(questionAnswer.getSequence() == 6) {
						//notes_attribute.setSnuff(Integer.parseInt(questionAnswer.getAnswer()) == 1);
						boolean ansVal = Integer.parseInt(questionAnswer.getAnswer()) == 1;
						text += "snuff?"+ansVal;
					
					} else if(questionAnswer.getSequence() == 7) {
						health_info_attributes.setNicotine_patch_or_gum_current(Integer.parseInt(questionAnswer.getAnswer()) == 1);
					
					} else if(questionAnswer.getSequence() == 8) {
						//notes_attribute.setTest_negative(Integer.parseInt(questionAnswer.getAnswer()) == 1);
						boolean ansVal = Integer.parseInt(questionAnswer.getAnswer()) == 1;
						text += ", test_negative?"+ansVal;
					
					} else if(questionAnswer.getSequence() == 9) {
						health_info_attributes.setLast_cigarette(dateFormat.format(new SimpleDateFormat("dd-MMM-yyyy").parse("01-"+questionAnswer.getAnswer())));
					
					} else if(questionAnswer.getSequence() == 10) {
						String answer = questionAnswer.getAnswer();
						if(answer.contains("+"))
							answer = answer.replace("+", "");
						health_info_attributes.setCigarettes_per_day(Integer.parseInt(answer));
					
					} else if(questionAnswer.getSequence() == 11) {
						health_info_attributes.setLast_cigar(dateFormat.format(new SimpleDateFormat("dd-MMM-yyyy").parse("01-"+questionAnswer.getAnswer())));
					
					} else if(questionAnswer.getSequence() == 12) {
						String answer = questionAnswer.getAnswer();
						if(answer.contains("+"))
							answer = answer.replace("+", "");
						health_info_attributes.setCigars_per_month(Integer.parseInt(answer)*30);
					
					} else if(questionAnswer.getSequence() == 13) {
						health_info_attributes.setLast_pipe(dateFormat.format(new SimpleDateFormat("dd-MMM-yyyy").parse("01-"+questionAnswer.getAnswer())));
					
					} else if(questionAnswer.getSequence() == 14) {
						String answer = questionAnswer.getAnswer();
						if(answer.contains("+"))
							answer = answer.replace("+", "");
						health_info_attributes.setPipes_per_year(Integer.parseInt(answer)*365);
					
					} else if(questionAnswer.getSequence() == 15) {
						health_info_attributes.setLast_tobacco_chewed(dateFormat.format(new SimpleDateFormat("dd-MMM-yyyy").parse("01-"+questionAnswer.getAnswer())));
					
					} else if(questionAnswer.getSequence() == 16) {
						String answer = questionAnswer.getAnswer();
						if(answer.contains("+"))
							answer = answer.replace("+", "");
						//notes_attribute.setTobacco_chew_per_day(Integer.parseInt(answer));
						text += ", tobacco_chew_per_day?"+Integer.parseInt(answer);
					
					} else if(questionAnswer.getSequence() == 18) {
						String answer = questionAnswer.getAnswer();
						if(answer.contains("+"))
							answer = answer.replace("+", "");
						//notes_attribute.setTobacco_snuff_per_day(Integer.parseInt(answer));
						text += ", tobacco_snuff_per_day?"+Integer.parseInt(answer);
					
					} else if(questionAnswer.getSequence() == 19) {
						health_info_attributes.setLast_nicotine_patch_or_gum(dateFormat.format(new SimpleDateFormat("dd-MMM-yyyy").parse("01-"+questionAnswer.getAnswer())));
					}
				} else if(questionAnswer.getQsetId() == ApplicationConstants.medicalhistoryQuestionSetID) {
					if(questionAnswer.getSequence() == 2) {
						health_info_attributes.setCholesterol(Integer.parseInt(questionAnswer.getAnswer()));
					
					} else if(questionAnswer.getSequence() == 3) {
						health_info_attributes.setCholesterol_hdl(Float.parseFloat(questionAnswer.getAnswer()));
					
					} else if(questionAnswer.getSequence() == 4) {
						health_info_attributes.setLast_cholesterol_treatment(dateFormat.format(new SimpleDateFormat("dd-MMM-yyyy").parse("01-"+questionAnswer.getAnswer())));
					
					} else if(questionAnswer.getSequence() == 5) {
						health_info_attributes.setCholesterol_control_start(dateFormat.format(new SimpleDateFormat("dd-MMM-yyyy").parse("01-"+questionAnswer.getAnswer())));
					
					} else if(questionAnswer.getSequence() == 7) {
						health_info_attributes.setBp_systolic(Integer.parseInt(questionAnswer.getAnswer()));
					
					} else if(questionAnswer.getSequence() == 8) {
						health_info_attributes.setBp_diastolic(Integer.parseInt(questionAnswer.getAnswer()));
					
					} else if(questionAnswer.getSequence() == 9) {
						health_info_attributes.setLast_bp_treatment(dateFormat.format(new SimpleDateFormat("dd-MMM-yyyy").parse("01-"+questionAnswer.getAnswer())));
					
					} else if(questionAnswer.getSequence() == 10) {
						health_info_attributes.setBp_control_start(dateFormat.format(new SimpleDateFormat("dd-MMM-yyyy").parse("01-"+questionAnswer.getAnswer())));
					} 
			
				} else if(questionAnswer.getQsetId() == ApplicationConstants.familyhistoryQuestionSetID) {
					if(questionAnswer.getSequence() == 3) {
						familyAttribute.setCardiovascular_disease(questionAnswer.getAnswer());
						
					} else if(questionAnswer.getSequence() == 4) {
						familyAttribute.setCardiovascular_impairments(questionAnswer.getAnswer());
						
					} else if(questionAnswer.getSequence() == 5) {
						familyAttribute.setDiabetes(questionAnswer.getAnswer());
						
					} else if(questionAnswer.getSequence() == 6) {
						familyAttribute.setColon_cancer(questionAnswer.getAnswer());
						
					} else if(questionAnswer.getSequence() == 7) {
						familyAttribute.setBreast_cancer(questionAnswer.getAnswer());
						
					} else if(questionAnswer.getSequence() == 8) {
						familyAttribute.setOvarian_cancer(questionAnswer.getAnswer());
						
					} else if(questionAnswer.getSequence() == 9) {
						familyAttribute.setMalignant_melanoma(questionAnswer.getAnswer());
						
					} else if(questionAnswer.getSequence() == 10) {
						familyAttribute.setCoronary_artery_disease(questionAnswer.getAnswer());
						
					} else if(questionAnswer.getSequence() == 11) {
						familyAttribute.setCerebrovascular_disease(questionAnswer.getAnswer());
						
					} else if(questionAnswer.getSequence() == 12) {
						familyAttribute.setKidney_disease(questionAnswer.getAnswer());
						
					} else if(questionAnswer.getSequence() == 13) {
						familyAttribute.setParent(questionAnswer.getAnswer());
					
					} else if(questionAnswer.getSequence() == 14) {
						familyAttribute.setAge_of_contraction(questionAnswer.getAnswer());
						
					} else if(questionAnswer.getSequence() == 16) {
						familyAttribute.setAge_of_death(questionAnswer.getAnswer());
					}
				} else if(questionAnswer.getQsetId() == ApplicationConstants.drivinghistoryQuestionSetID) {
					if(questionAnswer.getSequence() == 1) {
						//notes_attribute.setLicense_suspended_last_5_yrs(Integer.parseInt(questionAnswer.getAnswer()) == 1);
						boolean ansVal = Integer.parseInt(questionAnswer.getAnswer()) == 1;
						text += ", license_suspended_last_5_yrs?" + ansVal;
					
					} else if(questionAnswer.getSequence() == 2) {
						//notes_attribute.setDrunk_driving(Integer.parseInt(questionAnswer.getAnswer()) == 1);
						boolean ansVal = Integer.parseInt(questionAnswer.getAnswer()) == 1;
						text += ", drunk_driving?" + ansVal;
					
					} else if(questionAnswer.getSequence() == 3) {
						//notes_attribute.setReckless_driving(Integer.parseInt(questionAnswer.getAnswer()) == 1);
						boolean ansVal = Integer.parseInt(questionAnswer.getAnswer()) == 1;
						text += ", reckless_driving?" + ansVal;
					
					} else if(questionAnswer.getSequence() == 4) {
						//notes_attribute.setLicense_revoked(Integer.parseInt(questionAnswer.getAnswer()) == 1);
						boolean ansVal = Integer.parseInt(questionAnswer.getAnswer()) == 1;
						text += ", license_revoked?" + ansVal;
					
					} else if(questionAnswer.getSequence() == 5) {
						//notes_attribute.setMore_than_one_accident(Integer.parseInt(questionAnswer.getAnswer()) == 1);
						boolean ansVal = Integer.parseInt(questionAnswer.getAnswer()) == 1;
						text += ", more_than_one_accident?" + ansVal;
					
					} else if(questionAnswer.getSequence() == 6) {
						//notes_attribute.setMoving_violations_last_5_yrs(Integer.parseInt(questionAnswer.getAnswer()) == 1);
						boolean ansVal = Integer.parseInt(questionAnswer.getAnswer()) == 1;
						text += ", moving_violations_last_5_yrs?" + ansVal;
					
					} else if(questionAnswer.getSequence() == 7) {
						health_info_attributes.setLast_dui_dwi(dateFormat.format(new SimpleDateFormat("dd-MMM-yyyy").parse("01-"+questionAnswer.getAnswer())));
					
					} else if(questionAnswer.getSequence() == 8) {
						health_info_attributes.setLast_reckless_driving(dateFormat.format(new SimpleDateFormat("dd-MMM-yyyy").parse("01-"+questionAnswer.getAnswer())));
					
					} else if(questionAnswer.getSequence() == 9) {
						health_info_attributes.setLast_dl_suspension(dateFormat.format(new SimpleDateFormat("dd-MMM-yyyy").parse("01-"+questionAnswer.getAnswer())));
					
					} else if(questionAnswer.getSequence() == 11) {
						moving_violation_history_attributes.setLast_6_mo(Integer.parseInt(questionAnswer.getAnswer()));
					
					} else if(questionAnswer.getSequence() == 12) {
						moving_violation_history_attributes.setLast_1_yr(Integer.parseInt(questionAnswer.getAnswer()));
					
					} else if(questionAnswer.getSequence() == 13) {
						moving_violation_history_attributes.setLast_2_yr(Integer.parseInt(questionAnswer.getAnswer()));
					
					} else if(questionAnswer.getSequence() == 14) {
						moving_violation_history_attributes.setLast_3_yr(Integer.parseInt(questionAnswer.getAnswer()));
					
					} else if(questionAnswer.getSequence() == 15) {
						moving_violation_history_attributes.setLast_5_yr(Integer.parseInt(questionAnswer.getAnswer()));
					} 
				} else if(questionAnswer.getQsetId() == 6) {
					if(questionAnswer.getSequence() == 1) {
						health_history_attributes.setAlcohol_abuse(Integer.parseInt(questionAnswer.getAnswer()) == 1);
					
					} else if(questionAnswer.getSequence() == 2) {
						//notes_attribute.setAlcohol_recent_treatment(dateFormat.format(new SimpleDateFormat("dd-MMM-yyyy").parse("01-"+questionAnswer.getAnswer())));
						text += ", alcohol_recent_treatment?" + dateFormat.format(new SimpleDateFormat("dd-MMM-yyyy").parse("01-"+questionAnswer.getAnswer()));
					
					} else if(questionAnswer.getSequence() == 3) {
						//notes_attribute.setDrug_abuse(Integer.parseInt(questionAnswer.getAnswer()) == 1);
						boolean ansVal = Integer.parseInt(questionAnswer.getAnswer()) == 1;
						text += ", drug_abuse?" + ansVal;
					
					} else if(questionAnswer.getSequence() == 4) {
						//notes_attribute.setDrug_abuse_recent_treatment(dateFormat.format(new SimpleDateFormat("dd-MMM-yyyy").parse("01-"+questionAnswer.getAnswer())));
						text += ", drug_abuse_recent_treatment?" + dateFormat.format(new SimpleDateFormat("dd-MMM-yyyy").parse("01-"+questionAnswer.getAnswer()));
					} 
				} else if(questionAnswer.getQsetId() == 7) {
					if(questionAnswer.getSequence() == 1) {
						crm_connection.setBirth_country(questionAnswer.getAnswer());
						
					} else if(questionAnswer.getSequence() == 4) {
						String annualIncome = questionAnswer.getAnswer();
						if(annualIncome != null) {
							annualIncome = annualIncome.replace("$", "");
							annualIncome = annualIncome.replace(",", "");
							financial_info_attributes.setAnnual_income(Integer.parseInt(annualIncome));
						}
					} else if(questionAnswer.getSequence() == 7) {
						fullNames = questionAnswer.getAnswer();
						
					} else if(questionAnswer.getSequence() == 8) {
						relationships = questionAnswer.getAnswer();
						//notes_attribute.setRelationship(relationships);
						text += ", relationship?" + relationships;
						
					} else if(questionAnswer.getSequence() == 9) {
						percentages = questionAnswer.getAnswer();
					}
				} else if(questionAnswer.getQsetId() == 8) {
					if(questionAnswer.getSequence() == 2) {
						//notes_attribute.setAlzheimer_disease(Integer.parseInt(questionAnswer.getAnswer()) == 1);
						boolean ansVal = Integer.parseInt(questionAnswer.getAnswer()) == 1;
						text += ", alzheimer_disease?" + ansVal;
						
					} else if(questionAnswer.getSequence() == 3) {
						health_history_attributes.setAsthma(Integer.parseInt(questionAnswer.getAnswer()) == 1);
						
					} else if(questionAnswer.getSequence() == 4) {
						//notes_attribute.setBasel_cell_skin_cancer(Integer.parseInt(questionAnswer.getAnswer()) == 1);
						boolean ansVal = Integer.parseInt(questionAnswer.getAnswer()) == 1;
						text += ", basel_cell_skin_cancer?" + ansVal;
						
					} else if(questionAnswer.getSequence() == 5) {
						//notes_attribute.setCancer(Integer.parseInt(questionAnswer.getAnswer()) == 1);
						boolean ansVal = Integer.parseInt(questionAnswer.getAnswer()) == 1;
						text += ", cancer?" + ansVal;
						
					} else if(questionAnswer.getSequence() == 6) {
						health_history_attributes.setCopd(Integer.parseInt(questionAnswer.getAnswer()) == 1);
						
					} else if(questionAnswer.getSequence() == 7) {
						health_history_attributes.setCrohns(Integer.parseInt(questionAnswer.getAnswer()) == 1);
						
					} else if(questionAnswer.getSequence() == 8) {
						health_history_attributes.setDepression(Integer.parseInt(questionAnswer.getAnswer()) == 1);
						
					} else if(questionAnswer.getSequence() == 9) {
						health_history_attributes.setDiabetes_1(Integer.parseInt(questionAnswer.getAnswer()) == 1);
						
					} else if(questionAnswer.getSequence() == 10) {
						health_history_attributes.setEpilepsy(Integer.parseInt(questionAnswer.getAnswer()) == 1);
						
					} else if(questionAnswer.getSequence() == 11) {
						health_history_attributes.setEmphysema(Integer.parseInt(questionAnswer.getAnswer()) == 1);
						
					} else if(questionAnswer.getSequence() == 14) {
						health_history_attributes.setMental_illness(Integer.parseInt(questionAnswer.getAnswer()) == 1);
						
					} else if(questionAnswer.getSequence() == 15) {
						//notes_attribute.setMultiple_sclerosis(Integer.parseInt(questionAnswer.getAnswer()) == 1);
						boolean ansVal = Integer.parseInt(questionAnswer.getAnswer()) == 1;
						text += ", multiple_sclerosis?" + ansVal;
						
					} else if(questionAnswer.getSequence() == 16) {
						health_history_attributes.setRheumatoid_arthritis(Integer.parseInt(questionAnswer.getAnswer()) == 1);
						
					} else if(questionAnswer.getSequence() == 17) {
						health_history_attributes.setSleep_apnea(Integer.parseInt(questionAnswer.getAnswer()) == 1);
						
					} else if(questionAnswer.getSequence() == 18) {
						health_history_attributes.setStroke(Integer.parseInt(questionAnswer.getAnswer()) == 1);
						
					} else if(questionAnswer.getSequence() == 19) {
						health_history_attributes.setUlcerative_colitis_iletis(Integer.parseInt(questionAnswer.getAnswer()) == 1);
						
					} else if(questionAnswer.getSequence() == 20) {
						health_history_attributes.setVascular_disease(Integer.parseInt(questionAnswer.getAnswer()) == 1);
						
					} else if(questionAnswer.getSequence() == 27) {
						health_history_attributes.setHeart_attack(Integer.parseInt(questionAnswer.getAnswer()) == 1);
						
					} else if(questionAnswer.getSequence() == 29) {
						health_info_attributes.setForeign_travel(Integer.parseInt(questionAnswer.getAnswer()) == 1);
					
					} else if(questionAnswer.getSequence() == 28) {
						health_info_attributes.setHazardous_avocation(Integer.parseInt(questionAnswer.getAnswer()) == 1);
					
					} else if(questionAnswer.getSequence() == 42) {
						crm_connection.setSsn(questionAnswer.getAnswer());
					
					} else if(questionAnswer.getSequence() == 44) {
						crm_connection.setDl_state_name(questionAnswer.getAnswer());
					} 
				}
			}
		}
		List<Relatives_disease> familyAttributes = this.constructFamilyDiseaseAttributes(familyAttribute);
		if(familyAttributes != null && !familyAttributes.isEmpty()) {
			health_info_attributes.setFamily_diseases_attributes(familyAttributes);
		}
		
		health_info_attributes.setHealth_history_attributes(health_history_attributes);
		health_info_attributes.setMoving_violation_history_attributes(moving_violation_history_attributes);
		
		crm_connection.setFinancial_info_attributes(financial_info_attributes);
		crm_connection.setHealth_info_attributes(health_info_attributes);
		crm_connection = this.constructBeneficieries(crm_connection, fullNames, percentages, relationships);
		if(quote != null) {
			//notes_attribute.setAm_best_rating(quote.getAmbestRating());
			text += ", am_best_rating?" + quote.getAmbestRating();
		}
		if(!text.isEmpty() && ",".equalsIgnoreCase(text.charAt(0)+"")) {
			text = text.replaceFirst(", ", "");
		}
		notes_attribute.setText(text);
		notes_attributes.add(notes_attribute);
		crm_connection.setNotes_attributes(notes_attributes);
		
		logger.logMethodExit(startTime);
		return crm_connection;
	}
	
	/*
	 * Used to construct family disease attributes
	 */
	private List<Relatives_disease> constructFamilyDiseaseAttributes(FamilyAttribute familyAttribute) {
		List<Relatives_disease> family_diseases_attributes = new ArrayList<Relatives_disease>();
		
		if(familyAttribute.getParent() != null) {
			int size = familyAttribute.getParent().split(",").length;
			
			for(int i = 0; i < size; i++) {
				Relatives_disease family_diseases_attribute = new Relatives_disease();
				
				String ansValue = null;
				
				if(familyAttribute.getCardiovascular_disease() != null) {
					ansValue = familyAttribute.getCardiovascular_disease().split(",")[i];
					family_diseases_attribute.setCardiovascular_disease(ansValue != null ? Integer.parseInt(ansValue) == 1 : false);
				}
				
				if(familyAttribute.getCardiovascular_impairments() != null) {
					ansValue = familyAttribute.getCardiovascular_impairments().split(",")[i];
					family_diseases_attribute.setCardiovascular_impairments(ansValue != null ? Integer.parseInt(ansValue) == 1 : false);
				}
				
				if(familyAttribute.getDiabetes() != null) {
					ansValue = familyAttribute.getDiabetes().split(",")[i];
					family_diseases_attribute.setDiabetes(ansValue != null ? Integer.parseInt(ansValue) == 1 : false);
				}
				
				if(familyAttribute.getColon_cancer() != null) {
					ansValue = familyAttribute.getColon_cancer().split(",")[i];
					family_diseases_attribute.setColon_cancer(ansValue != null ? Integer.parseInt(ansValue) == 1 : false);
				}
				
				if(familyAttribute.getBreast_cancer() != null) {
					ansValue = familyAttribute.getBreast_cancer().split(",")[i];
					family_diseases_attribute.setBreast_cancer(ansValue != null ? Integer.parseInt(ansValue) == 1 : false);
				}
				
				if(familyAttribute.getOvarian_cancer() != null) {
					ansValue = familyAttribute.getOvarian_cancer().split(",")[i];
					family_diseases_attribute.setOvarian_cancer(ansValue != null ? Integer.parseInt(ansValue) == 1 : false);
				}
				
				if(familyAttribute.getMalignant_melanoma() != null) {
					ansValue = familyAttribute.getMalignant_melanoma().split(",")[i];
					family_diseases_attribute.setMalignant_melanoma(ansValue != null ? Integer.parseInt(ansValue) == 1 : false);
				}
				
				if(familyAttribute.getCoronary_artery_disease() != null) {
					ansValue = familyAttribute.getCoronary_artery_disease().split(",")[i];
					family_diseases_attribute.setCoronary_artery_disease(ansValue != null ? Integer.parseInt(ansValue) == 1 : false);
				}
				
				if(familyAttribute.getCerebrovascular_disease() != null) {
					ansValue = familyAttribute.getCerebrovascular_disease().split(",")[i];
					family_diseases_attribute.setCerebrovascular_disease(ansValue != null ? Integer.parseInt(ansValue) == 1 : false);
				}
				
				if(familyAttribute.getKidney_disease() != null) {
					ansValue = familyAttribute.getKidney_disease().split(",")[i];
					family_diseases_attribute.setKidney_disease(ansValue != null ? Integer.parseInt(ansValue) == 1 : false);
				}
				
				if(familyAttribute.getParent() != null) {
					ansValue = familyAttribute.getParent().split(",")[i];
					family_diseases_attribute.setParent(ansValue != null ? Integer.parseInt(ansValue) == 1 : false);
				}
			
				if(familyAttribute.getAge_of_contraction() != null) {
					ansValue = familyAttribute.getAge_of_contraction().split(",")[i];
					family_diseases_attribute.setAge_of_contraction(ansValue != null ? Integer.parseInt(ansValue) : 0);
				}
				
				if(familyAttribute.getAge_of_death() != null) {
					ansValue = familyAttribute.getAge_of_death().split(",")[i];
					family_diseases_attribute.setAge_of_death((ansValue != null && Integer.parseInt(ansValue) != -1) ? Integer.parseInt(ansValue) : 0);
				}
				
				family_diseases_attributes.add(family_diseases_attribute);
			}
		}
		return family_diseases_attributes;
	}
	
	/*
	 * Used to construct the beneficiery details
	 */
	private Client constructBeneficieries(Client crm_connection, String fullNames, String percentages, String relationships) throws Exception {
		List<Policies> cases_attributes = new ArrayList<Policies>();
		Policies case_attribute = new Policies();
		
		List<Beneficiary> beneficiaries_attributes = new ArrayList<Beneficiary>();
		
		if(percentages != null) {
			int size = percentages.split(",").length;
			for(int i = 0; i < size; i++) {
				Beneficiary beneficiaries_attribute = new Beneficiary();
	
				beneficiaries_attribute.setFull_name(fullNames.split(",")[i]);
				if(Utils.loadRelationships().get(relationships.split(",")[i]) != null) {
					beneficiaries_attribute.setRelationship_id(Utils.loadRelationships().get(relationships.split(",")[i]));
				}
				beneficiaries_attribute.setPercentage(Integer.parseInt(percentages.split(",")[i]));
				
				beneficiaries_attributes.add(beneficiaries_attribute);
			}
		}
		if(beneficiaries_attributes != null && !beneficiaries_attributes.isEmpty()) {
			case_attribute.setBeneficiaries_attributes(beneficiaries_attributes);
		}
		cases_attributes.add(case_attribute);
		crm_connection.setCases_attributes(cases_attributes);
		
		return crm_connection;
	}
	
	/*
	 * Used to construct the approved quote attribute details
	 */
	private Policy_details constructApprovedDetailsAtrributes(UserProfile userProfile, Quote quote) throws Exception {
		Policy_details approved_details_attributes = new Policy_details();
		String annualPremium = quote.getAnnualPremium();
		if(annualPremium != null) {
			annualPremium = annualPremium.replace("$", "");
			annualPremium = annualPremium.replace(",", "");
			approved_details_attributes.setAnnual_premium(Double.parseDouble(annualPremium));
		}
		if(Utils.loadCarriers().get(quote.getCompanyName()) != null) {
			approved_details_attributes.setCarrier_id(Utils.loadCarriers().get(quote.getCompanyName()));
		}
		approved_details_attributes.setCategory_id(userProfile.getInsuranceTerm() == 10 ? 1 : 2);
		approved_details_attributes.setCategory_name(userProfile.getInsuranceTerm() + " Years");
		
		String monthly_premium = quote.getMonthlyPremium();
		if(monthly_premium != null) {
			monthly_premium = monthly_premium.replace("$", "");
			monthly_premium = monthly_premium.replace(",", "");
			approved_details_attributes.setMonthly_premium(Double.parseDouble(monthly_premium));
		}
		
		if(Utils.loadCategoryOptions().get(quote.getHealthCategory()) != null) {
			approved_details_attributes.setHealth(Utils.loadCategoryOptions().get(quote.getHealthCategory()));
		}
		if(Utils.loadHealthCategoryOptions().get(quote.getHealthCategory()) != null) {
			approved_details_attributes.setHealth_class_id(Utils.loadHealthCategoryOptions().get(quote.getHealthCategory()));
		}

		String planned_modal_premium = quote.getAnnualPremium();
		if(planned_modal_premium != null) {
			planned_modal_premium = planned_modal_premium.replace("$", "");
			planned_modal_premium = planned_modal_premium.replace(",", "");
			approved_details_attributes.setPlanned_modal_premium(Double.parseDouble(planned_modal_premium));
		}
		approved_details_attributes.setPlan_name(quote.getPolicyName());
		approved_details_attributes.setPolicy_type_id(termID);
		
		String insuranceCoverage = userProfile.getInsuranceCoverage();
		if(insuranceCoverage != null) {
			insuranceCoverage = insuranceCoverage.replace("$", "");
			insuranceCoverage = insuranceCoverage.replace(",", "");
			approved_details_attributes.setFace_amount(Integer.parseInt(insuranceCoverage));
		}
		return approved_details_attributes;
	}
	
	/*
	 * Used to construct the submitted quote attribute details
	 */
	private Policy_details constructSubmittedDetailsAttributes(UserProfile userProfile, Quote quote) throws Exception {
		Policy_details submitted_details_attributes = new Policy_details();
		String annualPremium = quote.getAnnualPremium();
		if(annualPremium != null) {
			annualPremium = annualPremium.replace("$", "");
			annualPremium = annualPremium.replace(",", "");
			submitted_details_attributes.setAnnual_premium(Double.parseDouble(annualPremium));
		}
		if(Utils.loadCarriers().get(quote.getCompanyName()) != null) {
			submitted_details_attributes.setCarrier_id(Utils.loadCarriers().get(quote.getCompanyName()));
		}
		submitted_details_attributes.setCategory_id(userProfile.getInsuranceTerm() == 10 ? 1 : 2);
		submitted_details_attributes.setCategory_name(userProfile.getInsuranceTerm() + " Years");
		
		String monthly_premium = quote.getMonthlyPremium();
		if(monthly_premium != null) {
			monthly_premium = monthly_premium.replace("$", "");
			monthly_premium = monthly_premium.replace(",", "");
			submitted_details_attributes.setMonthly_premium(Double.parseDouble(monthly_premium));
		}
		
		if(Utils.loadCategoryOptions().get(quote.getHealthCategory()) != null) {
			submitted_details_attributes.setHealth(Utils.loadCategoryOptions().get(quote.getHealthCategory()));
		}
		if(Utils.loadHealthCategoryOptions().get(quote.getHealthCategory()) != null) {
			submitted_details_attributes.setHealth_class_id(Utils.loadHealthCategoryOptions().get(quote.getHealthCategory()));
		}

		String planned_modal_premium = quote.getAnnualPremium();
		if(planned_modal_premium != null) {
			planned_modal_premium = planned_modal_premium.replace("$", "");
			planned_modal_premium = planned_modal_premium.replace(",", "");
			submitted_details_attributes.setPlanned_modal_premium(Double.parseDouble(planned_modal_premium));
		}
		submitted_details_attributes.setPlan_name(quote.getPolicyName());
		submitted_details_attributes.setPolicy_type_id(termID);
		
		String insuranceCoverage = userProfile.getInsuranceCoverage();
		if(insuranceCoverage != null) {
			insuranceCoverage = insuranceCoverage.replace("$", "");
			insuranceCoverage = insuranceCoverage.replace(",", "");
			submitted_details_attributes.setFace_amount(Integer.parseInt(insuranceCoverage));
		}
		return submitted_details_attributes;
	}
	
	/*
	 * This method has been used for loading the all failed pinney submission DB.
	 */
	public List<UserProfile> loadFailedPinneySubmision() throws ServiceException {
		final long startTime = logger.logMethodEntry();
		
		List<UserProfile> questionAnsList;
		try {
			questionAnsList = genericService.getPinneyFailedSubmit();
		} catch (ServiceException e) {
			logger.error("ERROR : " + e.getMessage());
			throw new ServiceException(e.getMessage());
		}
		logger.logMethodExit(startTime);
		return questionAnsList;
	}
}
