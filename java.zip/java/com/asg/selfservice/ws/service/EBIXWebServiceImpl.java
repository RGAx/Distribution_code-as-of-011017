package com.asg.selfservice.ws.service;

import java.io.StringWriter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletContext;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;

import org.apache.commons.lang.StringEscapeUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import com.asg.selfservice.common.logger.LogFactory;
import com.asg.selfservice.common.logger.SelfServiceLogger;
import com.asg.selfservice.common.utils.ApplicationConstants;
import com.asg.selfservice.common.utils.Utils;
import com.asg.selfservice.domain.QuestionAnswer;
import com.asg.selfservice.domain.Quote;
import com.asg.selfservice.domain.UserProfile;
import com.asg.selfservice.exception.ServiceException;
import com.ebix.lifelink.client.ApplicantType;
import com.ebix.lifelink.client.ClassDeterminationType;
import com.ebix.lifelink.client.ClientType;
import com.ebix.lifelink.client.DetAnswersType;
import com.ebix.lifelink.client.DetControlsType;
import com.ebix.lifelink.client.DetQuestionType;
import com.ebix.lifelink.client.DetermiatorAnswerXMLType;
import com.ebix.lifelink.client.DisplayedInformationType;
import com.ebix.lifelink.client.ErrorType;
import com.ebix.lifelink.client.ErrorTypeType;
import com.ebix.lifelink.client.InterfaceTypeType;
import com.ebix.lifelink.client.LLType;
import com.ebix.lifelink.client.LifeLinkType;
import com.ebix.lifelink.client.LifelinkXMLsvc;
import com.ebix.lifelink.client.LifelinkXMLsvcSoap;
import com.ebix.lifelink.client.LlXMLResponse.LlXMLResult;
import com.ebix.lifelink.client.ModalValueType;
import com.ebix.lifelink.client.NoteType;
import com.ebix.lifelink.client.ObjectFactory;
import com.ebix.lifelink.client.OutputTypeType;
import com.ebix.lifelink.client.ProdScenarioType;
import com.ebix.lifelink.client.ProductInformationType;
import com.ebix.lifelink.client.ProductListsType;
import com.ebix.lifelink.client.ProductScenariosType;
import com.ebix.lifelink.client.ProductsType;
import com.ebix.lifelink.client.ReturnType;
import com.ebix.lifelink.client.ScenarioType;
import com.ebix.lifelink.client.SexType;
import com.ebix.lifelink.client.SortType;
import com.ebix.lifelink.client.SortingType;
import com.ebix.lifelink.client.ToolType;
import com.ebix.lifelink.client.ToolTypeName;
import com.ebix.lifelink.client.UserInformationType;
import com.ebix.lifelink.client.VTProductOptionsType;
import com.ebix.lifelink.client.VTProductType;
import com.ebix.lifelink.client.VitalTermNetType;

/**
 * This class has been used for implementing the EBIX operations such as getting the quotes, 
 * constructing XML requests which can be used for getting the EBIX response for quotes.
 * 
 * @author M1030133
 *
 */
public class EBIXWebServiceImpl {
	private static final SelfServiceLogger logger = LogFactory.getInstance(EBIXWebServiceImpl.class);
	
	@Value("${service.ebix.username}")
	private String SERVICE_EBIX_USERNAME;
	
	@Value("${service.ebix.password}")
	private String SERVICE_EBIX_PASSWORD; 
	
	@Autowired
	private ServletContext context;
	
	public Quote getBestQuote(UserProfile userProfile, List<QuestionAnswer> questAnsList) throws ServiceException {
		final long startTime = logger.logMethodEntry();
		Quote product = null;
		
		try {
			String encodedXML = constructXMLRequest(userProfile, questAnsList);
			
			List<Quote> result = getLLXMLResult(encodedXML);
			if(result != null && !result.isEmpty()){
				product = result.get(0);
				logger.info("Best Quote : " + product);
			}
		} catch(ServiceException e) {
			logger.error("ERROR : "+e.getMessage());
			throw new ServiceException(e.getMessage());
		}
		logger.logMethodExit(startTime);
		return product;

	}
	
	/*
	 * This method has been used for loading the quotes after passing the constructed xml request
	 * to EBIX Service. 
	 */
	public List<Quote> loadQuotes(UserProfile userProfile, List<QuestionAnswer> userQuestAnsList) throws ServiceException {
		final long startTime = logger.logMethodEntry();
		
		try {
			String encodedXML = constructXMLRequest(userProfile, userQuestAnsList);
			
			logger.logMethodExit(startTime);
			return getLLXMLResult(encodedXML);
		} catch(ServiceException e) {
			logger.error("ERROR : "+e.getMessage());
			throw new ServiceException(e.getMessage());
		}
	}

	/*
	 * This method has been used for loading the preice expression range by
	 * passing the Preferred Tobacco and preferred Non tobacco underwriting
	 * class to EBIX Service.
	 */
	public String getPriceRange(UserProfile userProfile, List<QuestionAnswer> userQuestAnswer) throws ServiceException {
		final long startTime = logger.logMethodEntry();
		String priceExpression = null;

		try {
			constructXMLRequest(userProfile, userQuestAnswer);
		} catch(ServiceException e) {
			logger.error("ERROR : "+e.getMessage());
			throw new ServiceException(e.getMessage());
		}
		//LlXMLResult result = getLLXMLResult(encodedXML);

		logger.logMethodExit(startTime);
		return priceExpression;
	}
	
	/*
	 * Used for constructing the EBIX request based on user answer.
	 */
	private String constructXMLRequest(UserProfile userProfile, List<QuestionAnswer> questAnsList) throws ServiceException {
		final long startTime = logger.logMethodEntry();
		
		String encodedXML = null;
		try {
			LifeLinkType lifeLinkType = this.initializeLifeLinkType();
			lifeLinkType = this.loadUserClientInfo(lifeLinkType, userProfile);
			
			// VitalTermNet information
			VitalTermNetType vitalTermNet = new VitalTermNetType();
			ClassDeterminationType classDeterminationType = new ClassDeterminationType();
			DetermiatorAnswerXMLType determinatorAnswerXMLType = new DetermiatorAnswerXMLType();
			
			boolean healthFlag = false, smokingFlag = false, cholestrolFlag = false, bpFlag = false, familyFlag = false;
			boolean drivingFlag7 = false, drivingFlag8 = false, drivingFlag9 = false, additionalFlag = false, control4Flag = false;
			
			DetQuestionType healthQuestionType = new DetQuestionType();
			List<DetControlsType> healthControlTypeList = new DetAnswersType().getControl();
			
			DetQuestionType smokingQuestionType = new DetQuestionType();
			List<DetControlsType> smokingControlTypeList = new DetAnswersType().getControl();
			
			DetQuestionType cholestrolQuestionType = new DetQuestionType();
			List<DetControlsType> cholestrolControlTypeList = new DetAnswersType().getControl();
			
			DetQuestionType bpQuestionType = new DetQuestionType();
			List<DetControlsType> bpControlTypeList = new DetAnswersType().getControl();
			
			DetQuestionType familyQuestionType1 = new DetQuestionType();
			List<DetControlsType> familyControlTypeList1 = new DetAnswersType().getControl();
			
			DetQuestionType familyQuestionType2 = new DetQuestionType();
			List<DetControlsType> familyControlTypeList2 = new DetAnswersType().getControl();
			
			DetQuestionType familyQuestionType3 = new DetQuestionType();
			List<DetControlsType> familyControlTypeList3 = new DetAnswersType().getControl();
			
			DetQuestionType familyQuestionType4 = new DetQuestionType();
			List<DetControlsType> familyControlTypeList4 = new DetAnswersType().getControl();
			
			DetQuestionType familyQuestionType5 = new DetQuestionType();
			List<DetControlsType> familyControlTypeList5 = new DetAnswersType().getControl();
			
			DetQuestionType familyQuestionType6 = new DetQuestionType();
			List<DetControlsType> familyControlTypeList6 = new DetAnswersType().getControl();
			
			DetQuestionType familyQuestionType7 = new DetQuestionType();
			List<DetControlsType> familyControlTypeList7 = new DetAnswersType().getControl();
			
			DetQuestionType familyQuestionType8 = new DetQuestionType();
			List<DetControlsType> familyControlTypeList8 = new DetAnswersType().getControl();
			
			DetQuestionType drivingQuestionType7 = new DetQuestionType();
			List<DetControlsType> drivingControlTypeList7 = new DetAnswersType().getControl();
			
			DetQuestionType drivingQuestionType8 = new DetQuestionType();
			List<DetControlsType> drivingControlTypeList8 = new DetAnswersType().getControl();
			
			DetQuestionType drivingQuestionType9 = new DetQuestionType();
			List<DetControlsType> drivingControlTypeList9 = new DetAnswersType().getControl();
			
			DetQuestionType additionalQuestionType = new DetQuestionType();
			List<DetControlsType> additionalControlTypeList = new DetAnswersType().getControl();
			
			String control4Answer = "";
			
			int controlID12 = 0, controlID13 = 0, controlID14 = 0, controlID15 = 0;
			String controlType12 = null, controlType13 = null, controlType14 = null, controlType15 = null;
			String controlAns12 = null;
			String[]controlAns13 = new String[8], controlAns14 = new String[8], controlAns15 = new String[8];
			boolean familyControlFlag = false;
			String [] controlAns16 = new String[8];
			
			for(QuestionAnswer questAns : questAnsList) {
				if(questAns.getEbixQuesId() == 2 && questAns.getEbixControlId() == 78
						&& "0".equalsIgnoreCase(questAns.getAnswer())) {
					questAns.setAnswer("-1");
				}
				if(questAns.getEbixQuesId() == 5 && questAns.getEbixControlId() == 13
						&& "0".equalsIgnoreCase(questAns.getAnswer())) {
					questAns.setAnswer("-1");
				}
				if (questAns.getEbixControlId() == 15) {
					controlID15 = questAns.getEbixControlId();
					controlType15 = questAns.getEbixControlValueType();
					if(questAns.getAnswer() != null && !questAns.getAnswer().isEmpty()) {
						controlAns15 = questAns.getAnswer().split(",");
					}
				}
				if(!"0".equalsIgnoreCase(questAns.getAnswer())) {
					if(questAns.getEbixQuesId() == 1) {	// Health Questions				
						healthQuestionType.setQuesId(questAns.getEbixQuesId());
						healthQuestionType.setQuesType(questAns.getEbixQuesType());
						
						healthControlTypeList.add(this.constructDetControlsType(questAns));
						healthFlag = true;
					} else if(questAns.getEbixQuesId() == 2) { // Tobacco Questions
						smokingQuestionType.setQuesId(questAns.getEbixQuesId());
						smokingQuestionType.setQuesType(questAns.getEbixQuesType());
						
						DetControlsType detControlsType = this.constructDetControlsType(questAns);
						if(questAns.getEbixControlId() == 4) {
							control4Answer += questAns.getDefaultAnswer() + ",";
							if(!control4Flag) {
								control4Flag = true;
								smokingControlTypeList.add(detControlsType);
							}
						} else {
							smokingControlTypeList.add(detControlsType);
						}
						smokingFlag = true;
					} else if(questAns.getEbixQuesId() == 3) { // Cholestrol Questions
						cholestrolQuestionType.setQuesId(questAns.getEbixQuesId());
						cholestrolQuestionType.setQuesType(questAns.getEbixQuesType());
						
						cholestrolControlTypeList.add(this.constructDetControlsType(questAns));
						cholestrolFlag = true;
					} else if(questAns.getEbixQuesId() == 4) { // BP Questions
						bpQuestionType.setQuesId(questAns.getEbixQuesId());
						bpQuestionType.setQuesType(questAns.getEbixQuesType());
						
						bpControlTypeList.add(this.constructDetControlsType(questAns));
						bpFlag = true;
					} else if(questAns.getEbixQuesId() == 5) { // Family Questions
						familyQuestionType1.setQuesId(questAns.getEbixQuesId());
						familyQuestionType1.setQuesType(questAns.getEbixQuesType());
						
						familyQuestionType2.setQuesId(questAns.getEbixQuesId());
						familyQuestionType2.setQuesType(questAns.getEbixQuesType());
						
						familyQuestionType3.setQuesId(questAns.getEbixQuesId());
						familyQuestionType3.setQuesType(questAns.getEbixQuesType());
						
						familyQuestionType4.setQuesId(questAns.getEbixQuesId());
						familyQuestionType4.setQuesType(questAns.getEbixQuesType());
						
						familyQuestionType5.setQuesId(questAns.getEbixQuesId());
						familyQuestionType5.setQuesType(questAns.getEbixQuesType());
						
						familyQuestionType6.setQuesId(questAns.getEbixQuesId());
						familyQuestionType6.setQuesType(questAns.getEbixQuesType());
						
						familyQuestionType7.setQuesId(questAns.getEbixQuesId());
						familyQuestionType7.setQuesType(questAns.getEbixQuesType());
						
						familyQuestionType8.setQuesId(questAns.getEbixQuesId());
						familyQuestionType8.setQuesType(questAns.getEbixQuesType());
						
						if (questAns.getEbixControlId() == 16) {
							String ansValue = questAns.getAnswer();
							if(ansValue != null && !ansValue.isEmpty()) {
								controlAns16 = ansValue.split(",");
							}
						}
						if (questAns.getEbixControlId() == 12) {
							controlID12 = questAns.getEbixControlId();
							controlType12 = questAns.getEbixControlValueType();
							controlAns12 = questAns.getAnswer();
						}
						if (questAns.getEbixControlId() == 13) {
							controlID13 = questAns.getEbixControlId();
							controlType13 = questAns.getEbixControlValueType();
							if(questAns.getAnswer() != null && !questAns.getAnswer().isEmpty()) {
								controlAns13 = questAns.getAnswer().split(",");
							}
						}
						if (questAns.getEbixControlId() == 14) {
							controlID14 = questAns.getEbixControlId();
							controlType14 = questAns.getEbixControlValueType();
							if(questAns.getAnswer() != null && !questAns.getAnswer().isEmpty()) {
								controlAns14 = questAns.getAnswer().split(",");
							}
						}
						familyControlFlag = true;
					} else if(questAns.getEbixQuesId() == 7) { // Driving Questions
						drivingQuestionType7.setQuesId(questAns.getEbixQuesId());
						drivingQuestionType7.setQuesType(questAns.getEbixQuesType());
											
						if(questAns.getEbixControlId() == 44 ) {						
							String month = questAns.getAnswer().split("-")[0];
							String year = questAns.getAnswer().split("-")[1];
							
							DetControlsType detControlsType1 = new DetControlsType();
							detControlsType1.setId(questAns.getEbixControlId());
							detControlsType1.setControlValueType(questAns.getEbixControlValueType());
							detControlsType1.setAnswer(String.valueOf(Utils.loadMonthIndex(month)));
							drivingControlTypeList7.add(detControlsType1);
							DetControlsType detControlsType2 = new DetControlsType();
							detControlsType2.setId(questAns.getEbixControlId()+1);
							detControlsType2.setControlValueType(questAns.getEbixControlValueType());
							detControlsType2.setAnswer(year);
							drivingControlTypeList7.add(detControlsType2);						
						} else {
							drivingControlTypeList7.add(this.constructDetControlsType(questAns));
						}
						drivingFlag7 = true;
					} else if(questAns.getEbixQuesId() == 8) { // Driving Questions
						drivingQuestionType8.setQuesId(questAns.getEbixQuesId());
						drivingQuestionType8.setQuesType(questAns.getEbixQuesType());
						
						if(questAns.getEbixControlId() == 47 ) {
							String month = questAns.getAnswer().split("-")[0];
							String year = questAns.getAnswer().split("-")[1];
							
							DetControlsType detControlsType1 = new DetControlsType();
							detControlsType1.setId(questAns.getEbixControlId());
							detControlsType1.setControlValueType(questAns.getEbixControlValueType());
							detControlsType1.setAnswer(String.valueOf(Utils.loadMonthIndex(month)));
							drivingControlTypeList8.add(detControlsType1);
							DetControlsType detControlsType2 = new DetControlsType();
							detControlsType2.setId(questAns.getEbixControlId()+1);
							detControlsType2.setControlValueType(questAns.getEbixControlValueType());
							detControlsType2.setAnswer(year);
							drivingControlTypeList8.add(detControlsType2);						
						} else {
							drivingControlTypeList8.add(this.constructDetControlsType(questAns));
						}
						drivingFlag8 = true;
					} else if(questAns.getEbixQuesId() == 9) { // Driving Questions
						drivingQuestionType9.setQuesId(questAns.getEbixQuesId());
						drivingQuestionType9.setQuesType(questAns.getEbixQuesType());
						
						if(questAns.getEbixControlId() == 50) {
							String month = questAns.getAnswer().split("-")[0];
							String year = questAns.getAnswer().split("-")[1];
							
							DetControlsType detControlsType1 = new DetControlsType();
							detControlsType1.setId(questAns.getEbixControlId());
							detControlsType1.setControlValueType(questAns.getEbixControlValueType());
							detControlsType1.setAnswer(String.valueOf(Utils.loadMonthIndex(month)));
							drivingControlTypeList9.add(detControlsType1);
							DetControlsType detControlsType2 = new DetControlsType();
							detControlsType2.setId(questAns.getEbixControlId()+1);
							detControlsType2.setControlValueType(questAns.getEbixControlValueType());
							detControlsType2.setAnswer(year);
							drivingControlTypeList9.add(detControlsType2);						
						} else {
							drivingControlTypeList9.add(this.constructDetControlsType(questAns));
						}					
						drivingFlag9 = true;
					} else if(questAns.getEbixQuesId() == 10) { // Alcohol Questions
						additionalQuestionType.setQuesId(questAns.getEbixQuesId());
						additionalQuestionType.setQuesType(questAns.getEbixQuesType());
						
						if(questAns.getEbixControlId() == 53) {		
							String month = questAns.getAnswer().split("-")[0];
							String year = questAns.getAnswer().split("-")[1];
							
							long noOfYears = Utils.getDateDifference(Integer.parseInt(year), Utils.loadMonthIndex(month)); 
							DetControlsType detControlsType1 = new DetControlsType();
							detControlsType1.setId(questAns.getEbixControlId());
							detControlsType1.setControlValueType(questAns.getEbixControlValueType());
							detControlsType1.setAnswer(String.valueOf(noOfYears));
							additionalControlTypeList.add(detControlsType1);
							DetControlsType detControlsType2 = new DetControlsType();
							detControlsType2.setId(questAns.getEbixControlId()+1);
							detControlsType2.setControlValueType(questAns.getEbixControlValueType());
							detControlsType2.setAnswer("1");
							additionalControlTypeList.add(detControlsType2);						
						} else {
							additionalControlTypeList.add(this.constructDetControlsType(questAns));
						}
						additionalFlag = true;
					} 
				}
			}
			if(familyControlFlag && controlAns15 != null) {
				for(int i = 0; i < controlAns15.length; i++) {
					if(controlAns15[i] != null) {
						DetControlsType detControlsType1 = new DetControlsType();
						detControlsType1.setId(controlID12);
						detControlsType1.setControlValueType(controlType12);
						detControlsType1.setAnswer(controlAns12);
						
						DetControlsType detControlsType2 = new DetControlsType();
						detControlsType2.setId(controlID13);
						detControlsType2.setControlValueType(controlType13);
						
						String answer13 = null;
						if(controlAns13 != null && controlAns13.length > i && !controlAns13[i].isEmpty()) {
							answer13 = controlAns13[i];
							int ansValue = Integer.parseInt(answer13);
							if(ansValue == -1) {
								answer13 = "0";
							} else if(ansValue > 2) {
								answer13 = "2";
							}
						}
						detControlsType2.setAnswer(answer13);
						
						DetControlsType detControlsType3 = new DetControlsType();
						detControlsType3.setId(controlID14);
						detControlsType3.setControlValueType(controlType14);
						detControlsType3.setAnswer("0".equalsIgnoreCase(controlAns15[i]) ? controlAns14[i] : controlAns16[i]);
						
						DetControlsType detControlsType4 = new DetControlsType();
						detControlsType4.setId(controlID15);
						detControlsType4.setControlValueType(controlType15);
						detControlsType4.setAnswer(controlAns15[i]);
						
						if(i == 0) {
							familyControlTypeList1.add(detControlsType1);
							familyControlTypeList1.add(detControlsType2);
							familyControlTypeList1.add(detControlsType3);
							familyControlTypeList1.add(detControlsType4);
						} else if(i == 1) {
							familyControlTypeList2.add(detControlsType1);
							familyControlTypeList2.add(detControlsType2);
							familyControlTypeList2.add(detControlsType3);
							familyControlTypeList2.add(detControlsType4);
						} else if(i == 2) {
							familyControlTypeList3.add(detControlsType1);
							familyControlTypeList3.add(detControlsType2);
							familyControlTypeList3.add(detControlsType3);
							familyControlTypeList3.add(detControlsType4);
						} else if(i == 3) {
							familyControlTypeList4.add(detControlsType1);
							familyControlTypeList4.add(detControlsType2);
							familyControlTypeList4.add(detControlsType3);
							familyControlTypeList4.add(detControlsType4);
						} else if(i == 4) {
							familyControlTypeList5.add(detControlsType1);
							familyControlTypeList5.add(detControlsType2);
							familyControlTypeList5.add(detControlsType3);
							familyControlTypeList5.add(detControlsType4);
						} else if(i == 5) {
							familyControlTypeList6.add(detControlsType1);
							familyControlTypeList6.add(detControlsType2);
							familyControlTypeList6.add(detControlsType3);
							familyControlTypeList6.add(detControlsType4);
						} else if(i == 6) {
							familyControlTypeList7.add(detControlsType1);
							familyControlTypeList7.add(detControlsType2);
							familyControlTypeList7.add(detControlsType3);
							familyControlTypeList7.add(detControlsType4);
						} else if(i == 7) {
							familyControlTypeList8.add(detControlsType1);
							familyControlTypeList8.add(detControlsType2);
							familyControlTypeList8.add(detControlsType3);
							familyControlTypeList8.add(detControlsType4);
						}
						familyFlag = true;
					}
				}
			}
			
			if(healthFlag) {
				determinatorAnswerXMLType = this.constructDeterminatorAnswerXMLType(healthControlTypeList, healthQuestionType, determinatorAnswerXMLType);
			}
			if(smokingFlag) {
				for(DetControlsType dct : smokingControlTypeList) {
					if("ABSOLUTE_CHECKLIST".equalsIgnoreCase(dct.getControlValueType())) {
						dct.setAnswer(control4Answer.substring(0, control4Answer.length() - 1));
					}
				}
				determinatorAnswerXMLType = this.constructDeterminatorAnswerXMLType(smokingControlTypeList, smokingQuestionType, determinatorAnswerXMLType);
			}
			if(cholestrolFlag) {
				determinatorAnswerXMLType = this.constructDeterminatorAnswerXMLType(cholestrolControlTypeList, cholestrolQuestionType, determinatorAnswerXMLType);
			}
			if(bpFlag) {
				determinatorAnswerXMLType = this.constructDeterminatorAnswerXMLType(bpControlTypeList, bpQuestionType, determinatorAnswerXMLType);
			}
			if(familyFlag) {
				if(familyControlTypeList1 != null && !familyControlTypeList1.isEmpty())
					determinatorAnswerXMLType = this.constructDeterminatorAnswerXMLType(familyControlTypeList1, familyQuestionType1, determinatorAnswerXMLType);
				
				if(familyControlTypeList2 != null && !familyControlTypeList2.isEmpty())
					determinatorAnswerXMLType = this.constructDeterminatorAnswerXMLType(familyControlTypeList2, familyQuestionType2, determinatorAnswerXMLType);
				
				if(familyControlTypeList3 != null && !familyControlTypeList3.isEmpty())
					determinatorAnswerXMLType = this.constructDeterminatorAnswerXMLType(familyControlTypeList3, familyQuestionType3, determinatorAnswerXMLType);
				
				if(familyControlTypeList4 != null && !familyControlTypeList4.isEmpty())
					determinatorAnswerXMLType = this.constructDeterminatorAnswerXMLType(familyControlTypeList4, familyQuestionType4, determinatorAnswerXMLType);
				
				if(familyControlTypeList5 != null && !familyControlTypeList5.isEmpty())
					determinatorAnswerXMLType = this.constructDeterminatorAnswerXMLType(familyControlTypeList5, familyQuestionType5, determinatorAnswerXMLType);
				
				if(familyControlTypeList6 != null && !familyControlTypeList6.isEmpty())
					determinatorAnswerXMLType = this.constructDeterminatorAnswerXMLType(familyControlTypeList6, familyQuestionType6, determinatorAnswerXMLType);
				
				if(familyControlTypeList7 != null && !familyControlTypeList7.isEmpty())
					determinatorAnswerXMLType = this.constructDeterminatorAnswerXMLType(familyControlTypeList7, familyQuestionType7, determinatorAnswerXMLType);
				
				if(familyControlTypeList8 != null && !familyControlTypeList8.isEmpty())
					determinatorAnswerXMLType = this.constructDeterminatorAnswerXMLType(familyControlTypeList8, familyQuestionType8, determinatorAnswerXMLType);
			}
			if(drivingFlag7) {
				determinatorAnswerXMLType = this.constructDeterminatorAnswerXMLType(drivingControlTypeList7, drivingQuestionType7, determinatorAnswerXMLType);
			}		
			if(drivingFlag8) {
				determinatorAnswerXMLType = this.constructDeterminatorAnswerXMLType(drivingControlTypeList8, drivingQuestionType8, determinatorAnswerXMLType);
			}
			if(drivingFlag9) {
				determinatorAnswerXMLType = this.constructDeterminatorAnswerXMLType(drivingControlTypeList9, drivingQuestionType9, determinatorAnswerXMLType);
			}
			if(additionalFlag) {
				determinatorAnswerXMLType = this.constructDeterminatorAnswerXMLType(additionalControlTypeList, additionalQuestionType, determinatorAnswerXMLType);
			}
			
			classDeterminationType.setDeterminatorAnswerXML(determinatorAnswerXMLType);
			vitalTermNet.setUWClassDetermination(classDeterminationType);
					
			vitalTermNet.setProducts(this.constructProductType(userProfile));

			lifeLinkType.setVitalTermNet(vitalTermNet);
			ObjectFactory objectFactory = new ObjectFactory();
			JAXBElement<LifeLinkType>  jaxbObject= objectFactory.createLifeLink(lifeLinkType);
			logger.info("EBIX request : " + encodedXML);
			encodedXML = this.marshalXMLRequest(jaxbObject, encodedXML);
		} catch(Exception e) {
			logger.error("ERROR : "+e.getMessage());
			throw new ServiceException(e.getMessage());
		}
		
		logger.logMethodExit(startTime);
		return encodedXML;
	}

	/*
	 * Used to initialize the LifeLinkType.
	 */
	private LifeLinkType initializeLifeLinkType() {
		LifeLinkType lifeLinkType = new LifeLinkType();

		// LL type
		LLType llType = new LLType();
		llType.setUserName(SERVICE_EBIX_USERNAME);
		llType.setUserPassword(SERVICE_EBIX_PASSWORD);
		InterfaceTypeType interfaceType = InterfaceTypeType.NO_GUI;
		llType.setInterfaceType(interfaceType);
		OutputTypeType outputType = OutputTypeType.XML;
		llType.setOutputType(outputType);
		llType.setLogout(false);
		ToolType toolType = new ToolType();
		toolType.setName(ToolTypeName.VITAL_TERM_NET);
		llType.getTool().add(toolType);
		lifeLinkType.setLL(llType);
		
		return lifeLinkType;
	}
	
	/*
	 * used to load the user and client information into the LifeLinkType.
	 */
	private LifeLinkType loadUserClientInfo(LifeLinkType lifeLinkType, UserProfile userProfile) {
		// User Information
		UserInformationType userInformationType = new UserInformationType();
		userInformationType.setFirstName(userProfile.getFirstName());
		userInformationType.setLastName(userProfile.getLastName());
		lifeLinkType.setUserInformation(userInformationType);
		
		// Client information
		ClientType clientType = new ClientType();
		ApplicantType applicantType = new ApplicantType();
		applicantType.setAge(Utils.getDiffYears(userProfile.getDob(), new Date()));
		SexType sexType = userProfile.getGender() == "M" ? SexType.MALE : SexType.FEMALE;
		applicantType.setSex(sexType);
		clientType.setApplicant(applicantType);
		clientType.setStateOfIssue(userProfile.getAddressState());
		lifeLinkType.setClient(clientType);
		
		return lifeLinkType;
	}
	
	/*
	 * Used to intitialize the product options.
	 */
	private VTProductOptionsType initializeProductOptions() {
		//Product Options
		VTProductOptionsType vtProductOptions = new VTProductOptionsType();
		vtProductOptions.setBreakDownPremiums(ApplicationConstants.BreakDownPremiums);
		vtProductOptions.setCalcToPenny(ApplicationConstants.CalcToPenny);
		vtProductOptions.setDisplayProductClasses(ApplicationConstants.DisplayProductClasses);
		vtProductOptions.setGetCompanyInfo(ApplicationConstants.GetCompanyInfo);
		vtProductOptions.setShowCurrentRates(ApplicationConstants.ShowCurrentRates);
		vtProductOptions.setShowRemovedProducts(ApplicationConstants.ShowRemovedProducts);
		vtProductOptions.setShowProdInfoOnRemoval(ApplicationConstants.ShowProdInfoOnRemoval);
		vtProductOptions.setShowProdInfoOnly(ApplicationConstants.ShowProdInfoOnly);
		vtProductOptions.setShowPremiumsOnly(ApplicationConstants.ShowPremiumsOnly);
		vtProductOptions.setCalc1StYearModal(ApplicationConstants.Calc1StYearModal);
		
		return vtProductOptions;
	}
	
	/*
	 * Used to laod the sorting parameters.
	 */
	private SortingType loadSortingParameters() {
		//Sorting Parameters
		SortingType sortingType = new SortingType();
		List<SortType> sortList = sortingType.getSort();
		SortType sortType = new SortType();
		sortType.setName("GUARANTEEDPREMIUMS");
		sortType.setDirection(0);
		sortType.setStartYear(1);
		sortType.setEndYear(10);
		sortList.add(sortType);
		
		return sortingType;
	}
	
	/*
	 * Used for marshalling the XML request.
	 */
	private String marshalXMLRequest(JAXBElement<LifeLinkType> jaxbObject, String encodedXML) throws ServiceException {
		try {
			JAXBContext jc = JAXBContext.newInstance(ObjectFactory.class);
			Marshaller marshaller = jc.createMarshaller();
			marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
			StringWriter stringWriter = new StringWriter();
			marshaller.marshal(jaxbObject, stringWriter);
			String requestXML = stringWriter.toString();
			//logger.debug("EBIX Request XML"+requestXML);
			//System.out.println("EBIX Request XML"+requestXML);
			encodedXML = StringEscapeUtils.escapeXml(requestXML);
			logger.debug("Encoded XML :" + encodedXML);
		} catch (JAXBException e) {
			logger.error("JAXB Exception while marshalling the Request: "+e.getMessage());
			throw new ServiceException(e.getMessage());
		}
		return encodedXML;
	}
	
	/*
	 * Used for constructing the product type.
	 */
	private ProductsType constructProductType(UserProfile userProfile) {
		//Product			
		ProductsType productType = new ProductsType();
		VTProductOptionsType vtProductOptions = this.initializeProductOptions();
		
		vtProductOptions.setSorting(this.loadSortingParameters());
		productType.setProductOptions(vtProductOptions);
		
		//Product Lists
		ProductListsType productList = new ProductListsType();
		productList.getYearsLevel().add(userProfile.getInsuranceTerm());
		productType.setProductLists(productList);
		
		//Product Scenario Type
		ProductScenariosType productScenariosType = new ProductScenariosType();
		ProdScenarioType scenarioType = new ProdScenarioType();
		scenarioType.setFaceAmount((userProfile.getInsuranceCoverage()+"").replace("$","").replace(",", ""));
		scenarioType.setPaymentMode(3);
		productScenariosType.getScenario().add(scenarioType);
		productType.setProductScenarios(productScenariosType); 	
		
		return productType;
	}
	
	/*
	 * Used for constructing the controls type.
	 */
	private DetControlsType constructDetControlsType(QuestionAnswer questAns) {
		DetControlsType detControlsType = new DetControlsType();
		detControlsType.setId(questAns.getEbixControlId());
		detControlsType.setControlValueType(questAns.getEbixControlValueType());
		
		if("16+".equalsIgnoreCase(questAns.getAnswer())) {
			questAns.setAnswer("16");
		} else if("350+".equalsIgnoreCase(questAns.getAnswer())) {
			questAns.setAnswer("350");
		} else if("Less than 80".equalsIgnoreCase(questAns.getAnswer())) {
			questAns.setAnswer("80");
		}
		detControlsType.setAnswer(questAns.getAnswer());
			
		return detControlsType;
	}
	
	/*
	 * Used for constructing the answer xml type.
	 */
	private DetermiatorAnswerXMLType constructDeterminatorAnswerXMLType(
			List<DetControlsType> controlTypeList,
			DetQuestionType questionType,
			DetermiatorAnswerXMLType determinatorAnswerXMLType) {
		DetAnswersType detAnswersType = new DetAnswersType(); 
		detAnswersType.getControl().addAll(controlTypeList);
		questionType.setAnswers(detAnswersType);
		determinatorAnswerXMLType.getQuestion().add(questionType);
		
		return determinatorAnswerXMLType;
	}
	
	/*
	 * Used for getting the Quotes from EBIX Webservice
	 * 
	 */
	private List<Quote> getLLXMLResult(String encodedXML) throws ServiceException {
		final long startTime = logger.logMethodEntry();
		
		List<Quote> quoteList = new ArrayList<Quote>();
		LifelinkXMLsvc llService = null;
		LlXMLResult result = null;
		int count = 0;
		
		try {
			if(null == context.getAttribute("ebixService")) {
				llService = new LifelinkXMLsvc();
				context.setAttribute("ebixService", llService);
			} else {
				llService = (LifelinkXMLsvc)context.getAttribute("ebixService");
			}		
			
			LifelinkXMLsvcSoap soapPort = llService.getLifelinkXMLsvcSoap();
			result = soapPort.llXML(encodedXML);
			JAXBElement jaxbObject = (JAXBElement) result.getContent().get(0);
			LifeLinkType lifelinkType = (LifeLinkType)jaxbObject.getValue();
			ErrorType error = lifelinkType.getError().get(0);
			
			if(error.getType().equals(ErrorTypeType.ERROR)) {
				logger.debug("Error Description ::"+error.getDescription());
			} else if(error.getType().equals(ErrorTypeType.MESSAGE)) {
				ProductsType productType = lifelinkType.getVitalTermNet().getProducts();
				List<VTProductType> productList = productType.getProduct();
				for(VTProductType products : productList) {
					if(count <= 3){						
						Quote quote = new Quote();
						quote.setProductName(products.getName());
						ScenarioType scenarioType = products.getScenario();
						ReturnType returnType = scenarioType.getReturn();
						DisplayedInformationType displayedInformation = returnType.getDisplayedInformation();
						
						if(null != displayedInformation.getPremiumInformation()) {
							List<ModalValueType> premiumList = displayedInformation.getPremiumInformation().getFirstYearModalPremiums().getPremium();
							String premiumValue = null;
							if(premiumList != null) {
								if(premiumList.get(3) != null) {
									premiumValue = premiumList.get(3).getValue();
									quote.setMonthlyPremium(premiumValue);
								}
								if(premiumList.get(0) != null) {
									premiumValue = premiumList.get(0).getValue();
									quote.setAnnualPremium(premiumValue);
								}
							}
							
							ProductInformationType productInformation = displayedInformation.getProductInformation();
							quote.setPolicyName(productInformation.getDisplayName());
							
							if(products.getCompanyInfo() != null) {
								quote.setCompanyName(products.getCompanyInfo().getName());
								if(products.getCompanyInfo().getRatings() != null) {
									quote.setAmbestRating(products.getCompanyInfo().getRatings().getAMBest());
								}
							}
							if(productInformation.getUnderwritingClasses() != null) {
								quote.setHealthCategory(productInformation.getUnderwritingClasses().getClassNameRan());
							}
							if((quote.getCompanyName() != null && quote.getCompanyName().contains("AG"))
									|| (quote.getPolicyName() != null && quote.getPolicyName().contains("AG"))) {
								quote.setCompanyLogo("AIG_logo");
							} else if((quote.getCompanyName() != null && quote.getCompanyName().contains("Banner"))
									|| (quote.getPolicyName() != null && quote.getPolicyName().contains("Banner"))) {
								quote.setCompanyLogo("Banner_logo");
							} else if((quote.getCompanyName() != null && quote.getCompanyName().contains("Principal"))
									|| (quote.getPolicyName() != null && quote.getPolicyName().contains("Principal"))) {
								quote.setCompanyLogo("Principal_logo");
							} else if((quote.getCompanyName() != null && quote.getCompanyName().contains("Protective"))
									|| (quote.getPolicyName() != null && quote.getPolicyName().contains("Protective"))) {
								quote.setCompanyLogo("Protectivelife_logo");
							} else if((quote.getCompanyName() != null && quote.getCompanyName().contains("Sagicor"))
									|| (quote.getPolicyName() != null && quote.getPolicyName().contains("Sagicor"))) {
								quote.setCompanyLogo("Sagicor_logo");
							}else if((quote.getCompanyName() != null && quote.getCompanyName().contains("Paclife"))
									|| (quote.getPolicyName() != null && quote.getPolicyName().contains("Paclife"))) {
								quote.setCompanyLogo("Paclife_logo");
							}
							quoteList.add(quote);
							logger.debug(count + " Quote : " + quote);
							count ++;
						} else {
							List<NoteType> reasonList = products.getScenario().getReturn().getRemovedInformation().getReasons().getReason();
							if(reasonList.size() > 0 && null != reasonList.get(0))
								logger.debug("Reason Text for First Product : " + reasonList.get(0).getText());	
							if(reasonList.size() > 1 && null != reasonList.get(1))
								logger.debug("Reason Text for Second Product : " + reasonList.get(1).getText());	
							if(reasonList.size() > 2 && null != reasonList.get(2))
								logger.debug("Reason Text for Third Product : " + reasonList.get(2).getText());	
						}
					}
				}
			}
			/*JAXBContext jc = JAXBContext.newInstance(LlXMLResponse.LlXMLResult.class);
			Marshaller marshaller = jc.createMarshaller();
			marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
			StringWriter stringWriter = new StringWriter();
			marshaller.marshal(result, stringWriter);
			logger.debug("EBIX WebServie ::: response : "+stringWriter.toString());*/		
			//System.out.println("EBIX WebServie ::: response : "+stringWriter.toString());
		} /*catch (JAXBException e) {
			logger.error("JAXB Exception while marshalling the Response: "+e.getMessage());
			throw new ServiceException(e.getMessage());
		} */catch (Exception e) {
			logger.error("Exception while marshalling the Response: "+e.getMessage());
			throw new ServiceException(e.getMessage());
		}
		logger.logMethodExit(startTime);
		return quoteList;
	}
	
}
