package com.rga.rgility.common.logger;

/**
 * Used to implement logger.
 * 
 * @author M1030133
 *
 */
@SuppressWarnings("rawtypes")
public class LogFactory {
	public static MyLifeCoveredLogger getInstance() {
		return new ExtJourneyLoggerImpl();
	}

	public static MyLifeCoveredLogger getInstance(String className) {
		return new ExtJourneyLoggerImpl(className);
	}

	public static MyLifeCoveredLogger getInstance(Class clazz) {
		return new ExtJourneyLoggerImpl(clazz.getCanonicalName());
	}
}