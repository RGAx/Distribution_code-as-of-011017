
package com.ebix.lifelink.client;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for VTProductOptionsType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="VTProductOptionsType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="BreakDownPremiums" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="CalcToPenny" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="DisplayProductClasses" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="DisplayProductTableRatings" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="GetCompanyInfo" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="ShowCurrentRates" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="ShowRemovedProducts" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="ShowProdInfoOnRemoval" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="RetrieveProductListIDs" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="ShowProdInfoOnly" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="ShowPremiumsOnly" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="RetrieveNarrative" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="YearsToCalc" type="{urn:lifelink-schema}CalcYearsType" minOccurs="0"/>
 *         &lt;element name="Calc1stYearModal" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="Sorting" type="{urn:lifelink-schema}SortingType" minOccurs="0"/>
 *         &lt;element name="Filtering" type="{urn:lifelink-schema}FilteringType" minOccurs="0"/>
 *         &lt;element name="XMLAltClass" type="{urn:lifelink-schema}AltClassType" minOccurs="0"/>
 *         &lt;element name="ShowAvailableRiders" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="XMLClassOverride" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="ReRun" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="FormatPremiums" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="RetrieveStateApprovals" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="RetrieveInfoNoClient" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="IgnoreValidations" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="RetrieveAllRawInfo" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="UseExternalCalcs" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="ReadVSDataFromFile" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="LockDownUnderwriting" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "VTProductOptionsType", propOrder = {
    "breakDownPremiums",
    "calcToPenny",
    "displayProductClasses",
    "displayProductTableRatings",
    "getCompanyInfo",
    "showCurrentRates",
    "showRemovedProducts",
    "showProdInfoOnRemoval",
    "retrieveProductListIDs",
    "showProdInfoOnly",
    "showPremiumsOnly",
    "retrieveNarrative",
    "yearsToCalc",
    "calc1StYearModal",
    "sorting",
    "filtering",
    "xmlAltClass",
    "showAvailableRiders",
    "xmlClassOverride",
    "reRun",
    "formatPremiums",
    "retrieveStateApprovals",
    "retrieveInfoNoClient",
    "ignoreValidations",
    "retrieveAllRawInfo",
    "useExternalCalcs",
    "readVSDataFromFile",
    "lockDownUnderwriting"
})
public class VTProductOptionsType {

    @XmlElement(name = "BreakDownPremiums")
    protected Boolean breakDownPremiums;
    @XmlElement(name = "CalcToPenny")
    protected Boolean calcToPenny;
    @XmlElement(name = "DisplayProductClasses")
    protected Boolean displayProductClasses;
    @XmlElement(name = "DisplayProductTableRatings")
    protected Boolean displayProductTableRatings;
    @XmlElement(name = "GetCompanyInfo")
    protected Boolean getCompanyInfo;
    @XmlElement(name = "ShowCurrentRates")
    protected Boolean showCurrentRates;
    @XmlElement(name = "ShowRemovedProducts")
    protected Boolean showRemovedProducts;
    @XmlElement(name = "ShowProdInfoOnRemoval")
    protected Boolean showProdInfoOnRemoval;
    @XmlElement(name = "RetrieveProductListIDs")
    protected Boolean retrieveProductListIDs;
    @XmlElement(name = "ShowProdInfoOnly")
    protected Boolean showProdInfoOnly;
    @XmlElement(name = "ShowPremiumsOnly")
    protected Boolean showPremiumsOnly;
    @XmlElement(name = "RetrieveNarrative")
    protected Boolean retrieveNarrative;
    @XmlElement(name = "YearsToCalc")
    protected CalcYearsType yearsToCalc;
    @XmlElement(name = "Calc1stYearModal")
    protected Boolean calc1StYearModal;
    @XmlElement(name = "Sorting")
    protected SortingType sorting;
    @XmlElement(name = "Filtering")
    protected FilteringType filtering;
    @XmlElement(name = "XMLAltClass")
    protected AltClassType xmlAltClass;
    @XmlElement(name = "ShowAvailableRiders")
    protected Boolean showAvailableRiders;
    @XmlElement(name = "XMLClassOverride")
    protected Boolean xmlClassOverride;
    @XmlElement(name = "ReRun")
    protected Boolean reRun;
    @XmlElement(name = "FormatPremiums")
    protected Boolean formatPremiums;
    @XmlElement(name = "RetrieveStateApprovals")
    protected Boolean retrieveStateApprovals;
    @XmlElement(name = "RetrieveInfoNoClient")
    protected Boolean retrieveInfoNoClient;
    @XmlElement(name = "IgnoreValidations")
    protected Boolean ignoreValidations;
    @XmlElement(name = "RetrieveAllRawInfo")
    protected Boolean retrieveAllRawInfo;
    @XmlElement(name = "UseExternalCalcs")
    protected Boolean useExternalCalcs;
    @XmlElement(name = "ReadVSDataFromFile")
    protected Boolean readVSDataFromFile;
    @XmlElement(name = "LockDownUnderwriting")
    protected Boolean lockDownUnderwriting;

    /**
     * Gets the value of the breakDownPremiums property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isBreakDownPremiums() {
        return breakDownPremiums;
    }

    /**
     * Sets the value of the breakDownPremiums property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setBreakDownPremiums(Boolean value) {
        this.breakDownPremiums = value;
    }

    /**
     * Gets the value of the calcToPenny property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isCalcToPenny() {
        return calcToPenny;
    }

    /**
     * Sets the value of the calcToPenny property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setCalcToPenny(Boolean value) {
        this.calcToPenny = value;
    }

    /**
     * Gets the value of the displayProductClasses property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isDisplayProductClasses() {
        return displayProductClasses;
    }

    /**
     * Sets the value of the displayProductClasses property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setDisplayProductClasses(Boolean value) {
        this.displayProductClasses = value;
    }

    /**
     * Gets the value of the displayProductTableRatings property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isDisplayProductTableRatings() {
        return displayProductTableRatings;
    }

    /**
     * Sets the value of the displayProductTableRatings property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setDisplayProductTableRatings(Boolean value) {
        this.displayProductTableRatings = value;
    }

    /**
     * Gets the value of the getCompanyInfo property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isGetCompanyInfo() {
        return getCompanyInfo;
    }

    /**
     * Sets the value of the getCompanyInfo property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setGetCompanyInfo(Boolean value) {
        this.getCompanyInfo = value;
    }

    /**
     * Gets the value of the showCurrentRates property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isShowCurrentRates() {
        return showCurrentRates;
    }

    /**
     * Sets the value of the showCurrentRates property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setShowCurrentRates(Boolean value) {
        this.showCurrentRates = value;
    }

    /**
     * Gets the value of the showRemovedProducts property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isShowRemovedProducts() {
        return showRemovedProducts;
    }

    /**
     * Sets the value of the showRemovedProducts property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setShowRemovedProducts(Boolean value) {
        this.showRemovedProducts = value;
    }

    /**
     * Gets the value of the showProdInfoOnRemoval property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isShowProdInfoOnRemoval() {
        return showProdInfoOnRemoval;
    }

    /**
     * Sets the value of the showProdInfoOnRemoval property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setShowProdInfoOnRemoval(Boolean value) {
        this.showProdInfoOnRemoval = value;
    }

    /**
     * Gets the value of the retrieveProductListIDs property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isRetrieveProductListIDs() {
        return retrieveProductListIDs;
    }

    /**
     * Sets the value of the retrieveProductListIDs property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setRetrieveProductListIDs(Boolean value) {
        this.retrieveProductListIDs = value;
    }

    /**
     * Gets the value of the showProdInfoOnly property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isShowProdInfoOnly() {
        return showProdInfoOnly;
    }

    /**
     * Sets the value of the showProdInfoOnly property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setShowProdInfoOnly(Boolean value) {
        this.showProdInfoOnly = value;
    }

    /**
     * Gets the value of the showPremiumsOnly property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isShowPremiumsOnly() {
        return showPremiumsOnly;
    }

    /**
     * Sets the value of the showPremiumsOnly property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setShowPremiumsOnly(Boolean value) {
        this.showPremiumsOnly = value;
    }

    /**
     * Gets the value of the retrieveNarrative property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isRetrieveNarrative() {
        return retrieveNarrative;
    }

    /**
     * Sets the value of the retrieveNarrative property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setRetrieveNarrative(Boolean value) {
        this.retrieveNarrative = value;
    }

    /**
     * Gets the value of the yearsToCalc property.
     * 
     * @return
     *     possible object is
     *     {@link CalcYearsType }
     *     
     */
    public CalcYearsType getYearsToCalc() {
        return yearsToCalc;
    }

    /**
     * Sets the value of the yearsToCalc property.
     * 
     * @param value
     *     allowed object is
     *     {@link CalcYearsType }
     *     
     */
    public void setYearsToCalc(CalcYearsType value) {
        this.yearsToCalc = value;
    }

    /**
     * Gets the value of the calc1StYearModal property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isCalc1StYearModal() {
        return calc1StYearModal;
    }

    /**
     * Sets the value of the calc1StYearModal property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setCalc1StYearModal(Boolean value) {
        this.calc1StYearModal = value;
    }

    /**
     * Gets the value of the sorting property.
     * 
     * @return
     *     possible object is
     *     {@link SortingType }
     *     
     */
    public SortingType getSorting() {
        return sorting;
    }

    /**
     * Sets the value of the sorting property.
     * 
     * @param value
     *     allowed object is
     *     {@link SortingType }
     *     
     */
    public void setSorting(SortingType value) {
        this.sorting = value;
    }

    /**
     * Gets the value of the filtering property.
     * 
     * @return
     *     possible object is
     *     {@link FilteringType }
     *     
     */
    public FilteringType getFiltering() {
        return filtering;
    }

    /**
     * Sets the value of the filtering property.
     * 
     * @param value
     *     allowed object is
     *     {@link FilteringType }
     *     
     */
    public void setFiltering(FilteringType value) {
        this.filtering = value;
    }

    /**
     * Gets the value of the xmlAltClass property.
     * 
     * @return
     *     possible object is
     *     {@link AltClassType }
     *     
     */
    public AltClassType getXMLAltClass() {
        return xmlAltClass;
    }

    /**
     * Sets the value of the xmlAltClass property.
     * 
     * @param value
     *     allowed object is
     *     {@link AltClassType }
     *     
     */
    public void setXMLAltClass(AltClassType value) {
        this.xmlAltClass = value;
    }

    /**
     * Gets the value of the showAvailableRiders property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isShowAvailableRiders() {
        return showAvailableRiders;
    }

    /**
     * Sets the value of the showAvailableRiders property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setShowAvailableRiders(Boolean value) {
        this.showAvailableRiders = value;
    }

    /**
     * Gets the value of the xmlClassOverride property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isXMLClassOverride() {
        return xmlClassOverride;
    }

    /**
     * Sets the value of the xmlClassOverride property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setXMLClassOverride(Boolean value) {
        this.xmlClassOverride = value;
    }

    /**
     * Gets the value of the reRun property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isReRun() {
        return reRun;
    }

    /**
     * Sets the value of the reRun property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setReRun(Boolean value) {
        this.reRun = value;
    }

    /**
     * Gets the value of the formatPremiums property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isFormatPremiums() {
        return formatPremiums;
    }

    /**
     * Sets the value of the formatPremiums property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setFormatPremiums(Boolean value) {
        this.formatPremiums = value;
    }

    /**
     * Gets the value of the retrieveStateApprovals property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isRetrieveStateApprovals() {
        return retrieveStateApprovals;
    }

    /**
     * Sets the value of the retrieveStateApprovals property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setRetrieveStateApprovals(Boolean value) {
        this.retrieveStateApprovals = value;
    }

    /**
     * Gets the value of the retrieveInfoNoClient property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isRetrieveInfoNoClient() {
        return retrieveInfoNoClient;
    }

    /**
     * Sets the value of the retrieveInfoNoClient property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setRetrieveInfoNoClient(Boolean value) {
        this.retrieveInfoNoClient = value;
    }

    /**
     * Gets the value of the ignoreValidations property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIgnoreValidations() {
        return ignoreValidations;
    }

    /**
     * Sets the value of the ignoreValidations property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIgnoreValidations(Boolean value) {
        this.ignoreValidations = value;
    }

    /**
     * Gets the value of the retrieveAllRawInfo property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isRetrieveAllRawInfo() {
        return retrieveAllRawInfo;
    }

    /**
     * Sets the value of the retrieveAllRawInfo property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setRetrieveAllRawInfo(Boolean value) {
        this.retrieveAllRawInfo = value;
    }

    /**
     * Gets the value of the useExternalCalcs property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isUseExternalCalcs() {
        return useExternalCalcs;
    }

    /**
     * Sets the value of the useExternalCalcs property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setUseExternalCalcs(Boolean value) {
        this.useExternalCalcs = value;
    }

    /**
     * Gets the value of the readVSDataFromFile property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isReadVSDataFromFile() {
        return readVSDataFromFile;
    }

    /**
     * Sets the value of the readVSDataFromFile property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setReadVSDataFromFile(Boolean value) {
        this.readVSDataFromFile = value;
    }

    /**
     * Gets the value of the lockDownUnderwriting property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isLockDownUnderwriting() {
        return lockDownUnderwriting;
    }

    /**
     * Sets the value of the lockDownUnderwriting property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setLockDownUnderwriting(Boolean value) {
        this.lockDownUnderwriting = value;
    }

}
