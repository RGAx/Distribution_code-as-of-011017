
package com.ebix.lifelink.client;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for GenericJointPolicyType.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="GenericJointPolicyType">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="SING"/>
 *     &lt;enumeration value="MARR"/>
 *     &lt;enumeration value="W/SP"/>
 *     &lt;enumeration value="W/OTH"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "GenericJointPolicyType")
@XmlEnum
public enum GenericJointPolicyType {

    SING("SING"),
    MARR("MARR"),
    @XmlEnumValue("W/SP")
    W_SP("W/SP"),
    @XmlEnumValue("W/OTH")
    W_OTH("W/OTH");
    private final String value;

    GenericJointPolicyType(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static GenericJointPolicyType fromValue(String v) {
        for (GenericJointPolicyType c: GenericJointPolicyType.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
