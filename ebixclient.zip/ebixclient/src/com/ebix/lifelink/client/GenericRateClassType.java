
package com.ebix.lifelink.client;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for GenericRateClassType.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="GenericRateClassType">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="PREF"/>
 *     &lt;enumeration value="STD"/>
 *     &lt;enumeration value="SUB1"/>
 *     &lt;enumeration value="SUB2"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "GenericRateClassType")
@XmlEnum
public enum GenericRateClassType {

    PREF("PREF"),
    STD("STD"),
    @XmlEnumValue("SUB1")
    SUB_1("SUB1"),
    @XmlEnumValue("SUB2")
    SUB_2("SUB2");
    private final String value;

    GenericRateClassType(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static GenericRateClassType fromValue(String v) {
        for (GenericRateClassType c: GenericRateClassType.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
