
package com.ebix.lifelink.client;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ButtonTypeType.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="ButtonTypeType">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="VT_Compare_Select"/>
 *     &lt;enumeration value="VT_Compare_Next"/>
 *     &lt;enumeration value="VT_Reports_View"/>
 *     &lt;enumeration value="VT_Quick_View"/>
 *     &lt;enumeration value="VT_All_Views"/>
 *     &lt;enumeration value="VLTC_Compare_Select"/>
 *     &lt;enumeration value="VLTC_Compare_Next"/>
 *     &lt;enumeration value="VLTC_Reports_View"/>
 *     &lt;enumeration value="VS_Reports_View"/>
 *     &lt;enumeration value="VF_Package_View"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "ButtonTypeType")
@XmlEnum
public enum ButtonTypeType {

    @XmlEnumValue("VT_Compare_Select")
    VT_COMPARE_SELECT("VT_Compare_Select"),
    @XmlEnumValue("VT_Compare_Next")
    VT_COMPARE_NEXT("VT_Compare_Next"),
    @XmlEnumValue("VT_Reports_View")
    VT_REPORTS_VIEW("VT_Reports_View"),
    @XmlEnumValue("VT_Quick_View")
    VT_QUICK_VIEW("VT_Quick_View"),
    @XmlEnumValue("VT_All_Views")
    VT_ALL_VIEWS("VT_All_Views"),
    @XmlEnumValue("VLTC_Compare_Select")
    VLTC_COMPARE_SELECT("VLTC_Compare_Select"),
    @XmlEnumValue("VLTC_Compare_Next")
    VLTC_COMPARE_NEXT("VLTC_Compare_Next"),
    @XmlEnumValue("VLTC_Reports_View")
    VLTC_REPORTS_VIEW("VLTC_Reports_View"),
    @XmlEnumValue("VS_Reports_View")
    VS_REPORTS_VIEW("VS_Reports_View"),
    @XmlEnumValue("VF_Package_View")
    VF_PACKAGE_VIEW("VF_Package_View");
    private final String value;

    ButtonTypeType(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static ButtonTypeType fromValue(String v) {
        for (ButtonTypeType c: ButtonTypeType.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
