
package com.ebix.lifelink.client;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for RiderRequestInfoType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="RiderRequestInfoType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="UnitAmount" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/>
 *         &lt;element name="UseMaxUnits" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="ChildAgeYoungest" type="{urn:lifelink-schema}ValueTypeAttributeType" minOccurs="0"/>
 *         &lt;element name="ADBFaceAmount" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="UseADBMaxFace" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "RiderRequestInfoType", propOrder = {
    "unitAmount",
    "useMaxUnits",
    "childAgeYoungest",
    "adbFaceAmount",
    "useADBMaxFace"
})
public class RiderRequestInfoType {

    @XmlElement(name = "UnitAmount")
    protected Double unitAmount;
    @XmlElement(name = "UseMaxUnits")
    protected Boolean useMaxUnits;
    @XmlElement(name = "ChildAgeYoungest")
    protected ValueTypeAttributeType childAgeYoungest;
    @XmlElement(name = "ADBFaceAmount")
    protected Long adbFaceAmount;
    @XmlElement(name = "UseADBMaxFace")
    protected Boolean useADBMaxFace;

    /**
     * Gets the value of the unitAmount property.
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getUnitAmount() {
        return unitAmount;
    }

    /**
     * Sets the value of the unitAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setUnitAmount(Double value) {
        this.unitAmount = value;
    }

    /**
     * Gets the value of the useMaxUnits property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isUseMaxUnits() {
        return useMaxUnits;
    }

    /**
     * Sets the value of the useMaxUnits property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setUseMaxUnits(Boolean value) {
        this.useMaxUnits = value;
    }

    /**
     * Gets the value of the childAgeYoungest property.
     * 
     * @return
     *     possible object is
     *     {@link ValueTypeAttributeType }
     *     
     */
    public ValueTypeAttributeType getChildAgeYoungest() {
        return childAgeYoungest;
    }

    /**
     * Sets the value of the childAgeYoungest property.
     * 
     * @param value
     *     allowed object is
     *     {@link ValueTypeAttributeType }
     *     
     */
    public void setChildAgeYoungest(ValueTypeAttributeType value) {
        this.childAgeYoungest = value;
    }

    /**
     * Gets the value of the adbFaceAmount property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getADBFaceAmount() {
        return adbFaceAmount;
    }

    /**
     * Sets the value of the adbFaceAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setADBFaceAmount(Long value) {
        this.adbFaceAmount = value;
    }

    /**
     * Gets the value of the useADBMaxFace property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isUseADBMaxFace() {
        return useADBMaxFace;
    }

    /**
     * Sets the value of the useADBMaxFace property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setUseADBMaxFace(Boolean value) {
        this.useADBMaxFace = value;
    }

}
