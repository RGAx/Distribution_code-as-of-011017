
package com.ebix.lifelink.client;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for DetProductType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DetProductType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;attribute name="ProductId" use="required" type="{http://www.w3.org/2001/XMLSchema}long" />
 *       &lt;attribute name="ClassId" type="{http://www.w3.org/2001/XMLSchema}long" />
 *       &lt;attribute name="Message" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="ResponseType" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="ClassName" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="IsTableRated" type="{http://www.w3.org/2001/XMLSchema}boolean" />
 *       &lt;attribute name="TableRatingID" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="TableRatingName" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="IsXRaeDetermined" type="{http://www.w3.org/2001/XMLSchema}boolean" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DetProductType")
public class DetProductType {

    @XmlAttribute(name = "ProductId", required = true)
    protected long productId;
    @XmlAttribute(name = "ClassId")
    protected Long classId;
    @XmlAttribute(name = "Message")
    protected String message;
    @XmlAttribute(name = "ResponseType")
    protected String responseType;
    @XmlAttribute(name = "ClassName")
    protected String className;
    @XmlAttribute(name = "IsTableRated")
    protected Boolean isTableRated;
    @XmlAttribute(name = "TableRatingID")
    protected String tableRatingID;
    @XmlAttribute(name = "TableRatingName")
    protected String tableRatingName;
    @XmlAttribute(name = "IsXRaeDetermined")
    protected Boolean isXRaeDetermined;

    /**
     * Gets the value of the productId property.
     * 
     */
    public long getProductId() {
        return productId;
    }

    /**
     * Sets the value of the productId property.
     * 
     */
    public void setProductId(long value) {
        this.productId = value;
    }

    /**
     * Gets the value of the classId property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getClassId() {
        return classId;
    }

    /**
     * Sets the value of the classId property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setClassId(Long value) {
        this.classId = value;
    }

    /**
     * Gets the value of the message property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMessage() {
        return message;
    }

    /**
     * Sets the value of the message property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMessage(String value) {
        this.message = value;
    }

    /**
     * Gets the value of the responseType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getResponseType() {
        return responseType;
    }

    /**
     * Sets the value of the responseType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setResponseType(String value) {
        this.responseType = value;
    }

    /**
     * Gets the value of the className property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getClassName() {
        return className;
    }

    /**
     * Sets the value of the className property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setClassName(String value) {
        this.className = value;
    }

    /**
     * Gets the value of the isTableRated property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIsTableRated() {
        return isTableRated;
    }

    /**
     * Sets the value of the isTableRated property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIsTableRated(Boolean value) {
        this.isTableRated = value;
    }

    /**
     * Gets the value of the tableRatingID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTableRatingID() {
        return tableRatingID;
    }

    /**
     * Sets the value of the tableRatingID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTableRatingID(String value) {
        this.tableRatingID = value;
    }

    /**
     * Gets the value of the tableRatingName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTableRatingName() {
        return tableRatingName;
    }

    /**
     * Sets the value of the tableRatingName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTableRatingName(String value) {
        this.tableRatingName = value;
    }

    /**
     * Gets the value of the isXRaeDetermined property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIsXRaeDetermined() {
        return isXRaeDetermined;
    }

    /**
     * Sets the value of the isXRaeDetermined property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIsXRaeDetermined(Boolean value) {
        this.isXRaeDetermined = value;
    }

}
