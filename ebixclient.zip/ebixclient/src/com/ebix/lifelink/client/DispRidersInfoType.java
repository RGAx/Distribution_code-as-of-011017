
package com.ebix.lifelink.client;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for DispRidersInfoType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DispRidersInfoType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="Rider" type="{urn:lifelink-schema}DispRiderInfoType" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DispRidersInfoType", propOrder = {
    "rider"
})
public class DispRidersInfoType {

    @XmlElement(name = "Rider")
    protected DispRiderInfoType rider;

    /**
     * Gets the value of the rider property.
     * 
     * @return
     *     possible object is
     *     {@link DispRiderInfoType }
     *     
     */
    public DispRiderInfoType getRider() {
        return rider;
    }

    /**
     * Sets the value of the rider property.
     * 
     * @param value
     *     allowed object is
     *     {@link DispRiderInfoType }
     *     
     */
    public void setRider(DispRiderInfoType value) {
        this.rider = value;
    }

}
