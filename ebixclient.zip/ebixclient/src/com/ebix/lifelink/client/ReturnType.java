
package com.ebix.lifelink.client;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ReturnType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ReturnType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="DisplayedInformation" type="{urn:lifelink-schema}DisplayedInformationType" minOccurs="0"/>
 *         &lt;element name="RemovedInformation" type="{urn:lifelink-schema}RemovedInformationType" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ReturnType", propOrder = {
    "displayedInformation",
    "removedInformation"
})
public class ReturnType {

    @XmlElement(name = "DisplayedInformation")
    protected DisplayedInformationType displayedInformation;
    @XmlElement(name = "RemovedInformation")
    protected RemovedInformationType removedInformation;

    /**
     * Gets the value of the displayedInformation property.
     * 
     * @return
     *     possible object is
     *     {@link DisplayedInformationType }
     *     
     */
    public DisplayedInformationType getDisplayedInformation() {
        return displayedInformation;
    }

    /**
     * Sets the value of the displayedInformation property.
     * 
     * @param value
     *     allowed object is
     *     {@link DisplayedInformationType }
     *     
     */
    public void setDisplayedInformation(DisplayedInformationType value) {
        this.displayedInformation = value;
    }

    /**
     * Gets the value of the removedInformation property.
     * 
     * @return
     *     possible object is
     *     {@link RemovedInformationType }
     *     
     */
    public RemovedInformationType getRemovedInformation() {
        return removedInformation;
    }

    /**
     * Sets the value of the removedInformation property.
     * 
     * @param value
     *     allowed object is
     *     {@link RemovedInformationType }
     *     
     */
    public void setRemovedInformation(RemovedInformationType value) {
        this.removedInformation = value;
    }

}
