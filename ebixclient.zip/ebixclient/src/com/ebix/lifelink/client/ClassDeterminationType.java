
package com.ebix.lifelink.client;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ClassDeterminationType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ClassDeterminationType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="DeterminatorAnswerXML" type="{urn:lifelink-schema}DetermiatorAnswerXMLType" minOccurs="0"/>
 *         &lt;element name="DeterminatorOutputXML" type="{urn:lifelink-schema}DeterminatorOutputType" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ClassDeterminationType", propOrder = {
    "determinatorAnswerXML",
    "determinatorOutputXML"
})
public class ClassDeterminationType {

    @XmlElement(name = "DeterminatorAnswerXML")
    protected DetermiatorAnswerXMLType determinatorAnswerXML;
    @XmlElement(name = "DeterminatorOutputXML")
    protected DeterminatorOutputType determinatorOutputXML;

    /**
     * Gets the value of the determinatorAnswerXML property.
     * 
     * @return
     *     possible object is
     *     {@link DetermiatorAnswerXMLType }
     *     
     */
    public DetermiatorAnswerXMLType getDeterminatorAnswerXML() {
        return determinatorAnswerXML;
    }

    /**
     * Sets the value of the determinatorAnswerXML property.
     * 
     * @param value
     *     allowed object is
     *     {@link DetermiatorAnswerXMLType }
     *     
     */
    public void setDeterminatorAnswerXML(DetermiatorAnswerXMLType value) {
        this.determinatorAnswerXML = value;
    }

    /**
     * Gets the value of the determinatorOutputXML property.
     * 
     * @return
     *     possible object is
     *     {@link DeterminatorOutputType }
     *     
     */
    public DeterminatorOutputType getDeterminatorOutputXML() {
        return determinatorOutputXML;
    }

    /**
     * Sets the value of the determinatorOutputXML property.
     * 
     * @param value
     *     allowed object is
     *     {@link DeterminatorOutputType }
     *     
     */
    public void setDeterminatorOutputXML(DeterminatorOutputType value) {
        this.determinatorOutputXML = value;
    }

}
