
package com.ebix.lifelink.client;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for VitalSignsType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="VitalSignsType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="Reports" type="{urn:lifelink-schema}VSReportsType" minOccurs="0"/>
 *         &lt;element name="Companies" type="{urn:lifelink-schema}VSCompaniesType" minOccurs="0"/>
 *         &lt;element name="Output" type="{urn:lifelink-schema}VSOutputType" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "VitalSignsType", propOrder = {
    "reports",
    "companies",
    "output"
})
public class VitalSignsType {

    @XmlElement(name = "Reports")
    protected VSReportsType reports;
    @XmlElement(name = "Companies")
    protected VSCompaniesType companies;
    @XmlElement(name = "Output")
    protected VSOutputType output;

    /**
     * Gets the value of the reports property.
     * 
     * @return
     *     possible object is
     *     {@link VSReportsType }
     *     
     */
    public VSReportsType getReports() {
        return reports;
    }

    /**
     * Sets the value of the reports property.
     * 
     * @param value
     *     allowed object is
     *     {@link VSReportsType }
     *     
     */
    public void setReports(VSReportsType value) {
        this.reports = value;
    }

    /**
     * Gets the value of the companies property.
     * 
     * @return
     *     possible object is
     *     {@link VSCompaniesType }
     *     
     */
    public VSCompaniesType getCompanies() {
        return companies;
    }

    /**
     * Sets the value of the companies property.
     * 
     * @param value
     *     allowed object is
     *     {@link VSCompaniesType }
     *     
     */
    public void setCompanies(VSCompaniesType value) {
        this.companies = value;
    }

    /**
     * Gets the value of the output property.
     * 
     * @return
     *     possible object is
     *     {@link VSOutputType }
     *     
     */
    public VSOutputType getOutput() {
        return output;
    }

    /**
     * Sets the value of the output property.
     * 
     * @param value
     *     allowed object is
     *     {@link VSOutputType }
     *     
     */
    public void setOutput(VSOutputType value) {
        this.output = value;
    }

}
