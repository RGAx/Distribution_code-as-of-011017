
package com.ebix.lifelink.client;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ProductInformationType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ProductInformationType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="DisplayName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="NAICCertified" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="RateCard" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SoftwareVersion" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PolicyFormNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="AgeNearestLast" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CalculatedAge" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="ModalFactors" type="{urn:lifelink-schema}ModalFactorType" minOccurs="0"/>
 *         &lt;element name="ExtraFees" type="{urn:lifelink-schema}ExtraFeesType" minOccurs="0"/>
 *         &lt;element name="YearsLevel" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="GuaranteedPeriod" type="{urn:lifelink-schema}ValueTypeAttributeType" minOccurs="0"/>
 *         &lt;element name="MaxYearsToShow" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="MaturityAge" type="{urn:lifelink-schema}ValueTypeAttributeType" minOccurs="0"/>
 *         &lt;element name="PremiumDiscount" type="{urn:lifelink-schema}PremiumDiscountType" minOccurs="0"/>
 *         &lt;element name="IssueAges" type="{urn:lifelink-schema}MinMaxType" minOccurs="0"/>
 *         &lt;element name="FaceAmounts" type="{urn:lifelink-schema}MinMaxType" minOccurs="0"/>
 *         &lt;element name="MinimumPremium" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Reentry" type="{urn:lifelink-schema}TextType" minOccurs="0"/>
 *         &lt;element name="Conversion" type="{urn:lifelink-schema}TextType" minOccurs="0"/>
 *         &lt;element name="IsROPProduct" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="Narratives" type="{urn:lifelink-schema}NarrativesType" minOccurs="0"/>
 *         &lt;element name="UnderwritingClasses" type="{urn:lifelink-schema}UnderwritingClassType" minOccurs="0"/>
 *         &lt;element name="RiderInformation" type="{urn:lifelink-schema}RiderInfoType" minOccurs="0"/>
 *         &lt;element name="AvailableRiders" type="{urn:lifelink-schema}VTAvailRidersType" minOccurs="0"/>
 *         &lt;element name="StatesApproved" type="{urn:lifelink-schema}StateApprovalType" minOccurs="0"/>
 *         &lt;element name="GuaranteedInterestRate" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="LoanRate" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="MaximumLoanRate" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="InterestCreditedPolicyLoans" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="LoadsFees" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SurrenderCharges" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="LoanType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PremiumType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="RateType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ProductInformationType", propOrder = {
    "displayName",
    "naicCertified",
    "rateCard",
    "softwareVersion",
    "policyFormNumber",
    "ageNearestLast",
    "calculatedAge",
    "modalFactors",
    "extraFees",
    "yearsLevel",
    "guaranteedPeriod",
    "maxYearsToShow",
    "maturityAge",
    "premiumDiscount",
    "issueAges",
    "faceAmounts",
    "minimumPremium",
    "reentry",
    "conversion",
    "isROPProduct",
    "narratives",
    "underwritingClasses",
    "riderInformation",
    "availableRiders",
    "statesApproved",
    "guaranteedInterestRate",
    "loanRate",
    "maximumLoanRate",
    "interestCreditedPolicyLoans",
    "loadsFees",
    "surrenderCharges",
    "loanType",
    "premiumType",
    "rateType"
})
public class ProductInformationType {

    @XmlElement(name = "DisplayName")
    protected String displayName;
    @XmlElement(name = "NAICCertified")
    protected Boolean naicCertified;
    @XmlElement(name = "RateCard")
    protected String rateCard;
    @XmlElement(name = "SoftwareVersion")
    protected String softwareVersion;
    @XmlElement(name = "PolicyFormNumber")
    protected String policyFormNumber;
    @XmlElement(name = "AgeNearestLast")
    protected String ageNearestLast;
    @XmlElement(name = "CalculatedAge")
    protected Integer calculatedAge;
    @XmlElement(name = "ModalFactors")
    protected ModalFactorType modalFactors;
    @XmlElement(name = "ExtraFees")
    protected ExtraFeesType extraFees;
    @XmlElement(name = "YearsLevel")
    protected String yearsLevel;
    @XmlElement(name = "GuaranteedPeriod")
    protected ValueTypeAttributeType guaranteedPeriod;
    @XmlElement(name = "MaxYearsToShow")
    protected Integer maxYearsToShow;
    @XmlElement(name = "MaturityAge")
    protected ValueTypeAttributeType maturityAge;
    @XmlElement(name = "PremiumDiscount")
    protected PremiumDiscountType premiumDiscount;
    @XmlElement(name = "IssueAges")
    protected MinMaxType issueAges;
    @XmlElement(name = "FaceAmounts")
    protected MinMaxType faceAmounts;
    @XmlElement(name = "MinimumPremium")
    protected String minimumPremium;
    @XmlElement(name = "Reentry")
    protected TextType reentry;
    @XmlElement(name = "Conversion")
    protected TextType conversion;
    @XmlElement(name = "IsROPProduct")
    protected Boolean isROPProduct;
    @XmlElement(name = "Narratives")
    protected NarrativesType narratives;
    @XmlElement(name = "UnderwritingClasses")
    protected UnderwritingClassType underwritingClasses;
    @XmlElement(name = "RiderInformation")
    protected RiderInfoType riderInformation;
    @XmlElement(name = "AvailableRiders")
    protected VTAvailRidersType availableRiders;
    @XmlElement(name = "StatesApproved")
    protected StateApprovalType statesApproved;
    @XmlElement(name = "GuaranteedInterestRate")
    protected String guaranteedInterestRate;
    @XmlElement(name = "LoanRate")
    protected String loanRate;
    @XmlElement(name = "MaximumLoanRate")
    protected String maximumLoanRate;
    @XmlElement(name = "InterestCreditedPolicyLoans")
    protected String interestCreditedPolicyLoans;
    @XmlElement(name = "LoadsFees")
    protected String loadsFees;
    @XmlElement(name = "SurrenderCharges")
    protected String surrenderCharges;
    @XmlElement(name = "LoanType")
    protected String loanType;
    @XmlElement(name = "PremiumType")
    protected String premiumType;
    @XmlElement(name = "RateType")
    protected String rateType;

    /**
     * Gets the value of the displayName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDisplayName() {
        return displayName;
    }

    /**
     * Sets the value of the displayName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDisplayName(String value) {
        this.displayName = value;
    }

    /**
     * Gets the value of the naicCertified property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isNAICCertified() {
        return naicCertified;
    }

    /**
     * Sets the value of the naicCertified property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setNAICCertified(Boolean value) {
        this.naicCertified = value;
    }

    /**
     * Gets the value of the rateCard property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRateCard() {
        return rateCard;
    }

    /**
     * Sets the value of the rateCard property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRateCard(String value) {
        this.rateCard = value;
    }

    /**
     * Gets the value of the softwareVersion property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSoftwareVersion() {
        return softwareVersion;
    }

    /**
     * Sets the value of the softwareVersion property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSoftwareVersion(String value) {
        this.softwareVersion = value;
    }

    /**
     * Gets the value of the policyFormNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPolicyFormNumber() {
        return policyFormNumber;
    }

    /**
     * Sets the value of the policyFormNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPolicyFormNumber(String value) {
        this.policyFormNumber = value;
    }

    /**
     * Gets the value of the ageNearestLast property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAgeNearestLast() {
        return ageNearestLast;
    }

    /**
     * Sets the value of the ageNearestLast property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAgeNearestLast(String value) {
        this.ageNearestLast = value;
    }

    /**
     * Gets the value of the calculatedAge property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getCalculatedAge() {
        return calculatedAge;
    }

    /**
     * Sets the value of the calculatedAge property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setCalculatedAge(Integer value) {
        this.calculatedAge = value;
    }

    /**
     * Gets the value of the modalFactors property.
     * 
     * @return
     *     possible object is
     *     {@link ModalFactorType }
     *     
     */
    public ModalFactorType getModalFactors() {
        return modalFactors;
    }

    /**
     * Sets the value of the modalFactors property.
     * 
     * @param value
     *     allowed object is
     *     {@link ModalFactorType }
     *     
     */
    public void setModalFactors(ModalFactorType value) {
        this.modalFactors = value;
    }

    /**
     * Gets the value of the extraFees property.
     * 
     * @return
     *     possible object is
     *     {@link ExtraFeesType }
     *     
     */
    public ExtraFeesType getExtraFees() {
        return extraFees;
    }

    /**
     * Sets the value of the extraFees property.
     * 
     * @param value
     *     allowed object is
     *     {@link ExtraFeesType }
     *     
     */
    public void setExtraFees(ExtraFeesType value) {
        this.extraFees = value;
    }

    /**
     * Gets the value of the yearsLevel property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getYearsLevel() {
        return yearsLevel;
    }

    /**
     * Sets the value of the yearsLevel property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setYearsLevel(String value) {
        this.yearsLevel = value;
    }

    /**
     * Gets the value of the guaranteedPeriod property.
     * 
     * @return
     *     possible object is
     *     {@link ValueTypeAttributeType }
     *     
     */
    public ValueTypeAttributeType getGuaranteedPeriod() {
        return guaranteedPeriod;
    }

    /**
     * Sets the value of the guaranteedPeriod property.
     * 
     * @param value
     *     allowed object is
     *     {@link ValueTypeAttributeType }
     *     
     */
    public void setGuaranteedPeriod(ValueTypeAttributeType value) {
        this.guaranteedPeriod = value;
    }

    /**
     * Gets the value of the maxYearsToShow property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getMaxYearsToShow() {
        return maxYearsToShow;
    }

    /**
     * Sets the value of the maxYearsToShow property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setMaxYearsToShow(Integer value) {
        this.maxYearsToShow = value;
    }

    /**
     * Gets the value of the maturityAge property.
     * 
     * @return
     *     possible object is
     *     {@link ValueTypeAttributeType }
     *     
     */
    public ValueTypeAttributeType getMaturityAge() {
        return maturityAge;
    }

    /**
     * Sets the value of the maturityAge property.
     * 
     * @param value
     *     allowed object is
     *     {@link ValueTypeAttributeType }
     *     
     */
    public void setMaturityAge(ValueTypeAttributeType value) {
        this.maturityAge = value;
    }

    /**
     * Gets the value of the premiumDiscount property.
     * 
     * @return
     *     possible object is
     *     {@link PremiumDiscountType }
     *     
     */
    public PremiumDiscountType getPremiumDiscount() {
        return premiumDiscount;
    }

    /**
     * Sets the value of the premiumDiscount property.
     * 
     * @param value
     *     allowed object is
     *     {@link PremiumDiscountType }
     *     
     */
    public void setPremiumDiscount(PremiumDiscountType value) {
        this.premiumDiscount = value;
    }

    /**
     * Gets the value of the issueAges property.
     * 
     * @return
     *     possible object is
     *     {@link MinMaxType }
     *     
     */
    public MinMaxType getIssueAges() {
        return issueAges;
    }

    /**
     * Sets the value of the issueAges property.
     * 
     * @param value
     *     allowed object is
     *     {@link MinMaxType }
     *     
     */
    public void setIssueAges(MinMaxType value) {
        this.issueAges = value;
    }

    /**
     * Gets the value of the faceAmounts property.
     * 
     * @return
     *     possible object is
     *     {@link MinMaxType }
     *     
     */
    public MinMaxType getFaceAmounts() {
        return faceAmounts;
    }

    /**
     * Sets the value of the faceAmounts property.
     * 
     * @param value
     *     allowed object is
     *     {@link MinMaxType }
     *     
     */
    public void setFaceAmounts(MinMaxType value) {
        this.faceAmounts = value;
    }

    /**
     * Gets the value of the minimumPremium property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMinimumPremium() {
        return minimumPremium;
    }

    /**
     * Sets the value of the minimumPremium property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMinimumPremium(String value) {
        this.minimumPremium = value;
    }

    /**
     * Gets the value of the reentry property.
     * 
     * @return
     *     possible object is
     *     {@link TextType }
     *     
     */
    public TextType getReentry() {
        return reentry;
    }

    /**
     * Sets the value of the reentry property.
     * 
     * @param value
     *     allowed object is
     *     {@link TextType }
     *     
     */
    public void setReentry(TextType value) {
        this.reentry = value;
    }

    /**
     * Gets the value of the conversion property.
     * 
     * @return
     *     possible object is
     *     {@link TextType }
     *     
     */
    public TextType getConversion() {
        return conversion;
    }

    /**
     * Sets the value of the conversion property.
     * 
     * @param value
     *     allowed object is
     *     {@link TextType }
     *     
     */
    public void setConversion(TextType value) {
        this.conversion = value;
    }

    /**
     * Gets the value of the isROPProduct property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIsROPProduct() {
        return isROPProduct;
    }

    /**
     * Sets the value of the isROPProduct property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIsROPProduct(Boolean value) {
        this.isROPProduct = value;
    }

    /**
     * Gets the value of the narratives property.
     * 
     * @return
     *     possible object is
     *     {@link NarrativesType }
     *     
     */
    public NarrativesType getNarratives() {
        return narratives;
    }

    /**
     * Sets the value of the narratives property.
     * 
     * @param value
     *     allowed object is
     *     {@link NarrativesType }
     *     
     */
    public void setNarratives(NarrativesType value) {
        this.narratives = value;
    }

    /**
     * Gets the value of the underwritingClasses property.
     * 
     * @return
     *     possible object is
     *     {@link UnderwritingClassType }
     *     
     */
    public UnderwritingClassType getUnderwritingClasses() {
        return underwritingClasses;
    }

    /**
     * Sets the value of the underwritingClasses property.
     * 
     * @param value
     *     allowed object is
     *     {@link UnderwritingClassType }
     *     
     */
    public void setUnderwritingClasses(UnderwritingClassType value) {
        this.underwritingClasses = value;
    }

    /**
     * Gets the value of the riderInformation property.
     * 
     * @return
     *     possible object is
     *     {@link RiderInfoType }
     *     
     */
    public RiderInfoType getRiderInformation() {
        return riderInformation;
    }

    /**
     * Sets the value of the riderInformation property.
     * 
     * @param value
     *     allowed object is
     *     {@link RiderInfoType }
     *     
     */
    public void setRiderInformation(RiderInfoType value) {
        this.riderInformation = value;
    }

    /**
     * Gets the value of the availableRiders property.
     * 
     * @return
     *     possible object is
     *     {@link VTAvailRidersType }
     *     
     */
    public VTAvailRidersType getAvailableRiders() {
        return availableRiders;
    }

    /**
     * Sets the value of the availableRiders property.
     * 
     * @param value
     *     allowed object is
     *     {@link VTAvailRidersType }
     *     
     */
    public void setAvailableRiders(VTAvailRidersType value) {
        this.availableRiders = value;
    }

    /**
     * Gets the value of the statesApproved property.
     * 
     * @return
     *     possible object is
     *     {@link StateApprovalType }
     *     
     */
    public StateApprovalType getStatesApproved() {
        return statesApproved;
    }

    /**
     * Sets the value of the statesApproved property.
     * 
     * @param value
     *     allowed object is
     *     {@link StateApprovalType }
     *     
     */
    public void setStatesApproved(StateApprovalType value) {
        this.statesApproved = value;
    }

    /**
     * Gets the value of the guaranteedInterestRate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGuaranteedInterestRate() {
        return guaranteedInterestRate;
    }

    /**
     * Sets the value of the guaranteedInterestRate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGuaranteedInterestRate(String value) {
        this.guaranteedInterestRate = value;
    }

    /**
     * Gets the value of the loanRate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLoanRate() {
        return loanRate;
    }

    /**
     * Sets the value of the loanRate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLoanRate(String value) {
        this.loanRate = value;
    }

    /**
     * Gets the value of the maximumLoanRate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMaximumLoanRate() {
        return maximumLoanRate;
    }

    /**
     * Sets the value of the maximumLoanRate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMaximumLoanRate(String value) {
        this.maximumLoanRate = value;
    }

    /**
     * Gets the value of the interestCreditedPolicyLoans property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getInterestCreditedPolicyLoans() {
        return interestCreditedPolicyLoans;
    }

    /**
     * Sets the value of the interestCreditedPolicyLoans property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setInterestCreditedPolicyLoans(String value) {
        this.interestCreditedPolicyLoans = value;
    }

    /**
     * Gets the value of the loadsFees property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLoadsFees() {
        return loadsFees;
    }

    /**
     * Sets the value of the loadsFees property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLoadsFees(String value) {
        this.loadsFees = value;
    }

    /**
     * Gets the value of the surrenderCharges property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSurrenderCharges() {
        return surrenderCharges;
    }

    /**
     * Sets the value of the surrenderCharges property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSurrenderCharges(String value) {
        this.surrenderCharges = value;
    }

    /**
     * Gets the value of the loanType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLoanType() {
        return loanType;
    }

    /**
     * Sets the value of the loanType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLoanType(String value) {
        this.loanType = value;
    }

    /**
     * Gets the value of the premiumType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPremiumType() {
        return premiumType;
    }

    /**
     * Sets the value of the premiumType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPremiumType(String value) {
        this.premiumType = value;
    }

    /**
     * Gets the value of the rateType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRateType() {
        return rateType;
    }

    /**
     * Sets the value of the rateType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRateType(String value) {
        this.rateType = value;
    }

}
