
package com.ebix.lifelink.client;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for QuotesType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="QuotesType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="VLTCQuote" type="{urn:lifelink-schema}QuoteType" maxOccurs="unbounded"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "QuotesType", propOrder = {
    "vltcQuote"
})
public class QuotesType {

    @XmlElement(name = "VLTCQuote", required = true)
    protected List<QuoteType> vltcQuote;

    /**
     * Gets the value of the vltcQuote property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the vltcQuote property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getVLTCQuote().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link QuoteType }
     * 
     * 
     */
    public List<QuoteType> getVLTCQuote() {
        if (vltcQuote == null) {
            vltcQuote = new ArrayList<QuoteType>();
        }
        return this.vltcQuote;
    }

}
