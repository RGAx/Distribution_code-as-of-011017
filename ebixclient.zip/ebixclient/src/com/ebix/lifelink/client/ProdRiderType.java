
package com.ebix.lifelink.client;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ProdRiderType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ProdRiderType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="IssueAges" type="{urn:lifelink-schema}MinMaxType" minOccurs="0"/>
 *         &lt;element name="FaceAmounts" type="{urn:lifelink-schema}MinMaxType" minOccurs="0"/>
 *         &lt;element name="MaturityAge" type="{urn:lifelink-schema}ValueTypeAttributeType" minOccurs="0"/>
 *         &lt;element name="MaturityAgeInsured" type="{urn:lifelink-schema}ValueTypeAttributeType" minOccurs="0"/>
 *         &lt;element name="Units" type="{urn:lifelink-schema}MinMaxValueType" minOccurs="0"/>
 *       &lt;/sequence>
 *       &lt;attribute name="name" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="id" type="{http://www.w3.org/2001/XMLSchema}int" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ProdRiderType", propOrder = {
    "issueAges",
    "faceAmounts",
    "maturityAge",
    "maturityAgeInsured",
    "units"
})
public class ProdRiderType {

    @XmlElement(name = "IssueAges")
    protected MinMaxType issueAges;
    @XmlElement(name = "FaceAmounts")
    protected MinMaxType faceAmounts;
    @XmlElement(name = "MaturityAge")
    protected ValueTypeAttributeType maturityAge;
    @XmlElement(name = "MaturityAgeInsured")
    protected ValueTypeAttributeType maturityAgeInsured;
    @XmlElement(name = "Units")
    protected MinMaxValueType units;
    @XmlAttribute(name = "name")
    protected String name;
    @XmlAttribute(name = "id")
    protected Integer id;

    /**
     * Gets the value of the issueAges property.
     * 
     * @return
     *     possible object is
     *     {@link MinMaxType }
     *     
     */
    public MinMaxType getIssueAges() {
        return issueAges;
    }

    /**
     * Sets the value of the issueAges property.
     * 
     * @param value
     *     allowed object is
     *     {@link MinMaxType }
     *     
     */
    public void setIssueAges(MinMaxType value) {
        this.issueAges = value;
    }

    /**
     * Gets the value of the faceAmounts property.
     * 
     * @return
     *     possible object is
     *     {@link MinMaxType }
     *     
     */
    public MinMaxType getFaceAmounts() {
        return faceAmounts;
    }

    /**
     * Sets the value of the faceAmounts property.
     * 
     * @param value
     *     allowed object is
     *     {@link MinMaxType }
     *     
     */
    public void setFaceAmounts(MinMaxType value) {
        this.faceAmounts = value;
    }

    /**
     * Gets the value of the maturityAge property.
     * 
     * @return
     *     possible object is
     *     {@link ValueTypeAttributeType }
     *     
     */
    public ValueTypeAttributeType getMaturityAge() {
        return maturityAge;
    }

    /**
     * Sets the value of the maturityAge property.
     * 
     * @param value
     *     allowed object is
     *     {@link ValueTypeAttributeType }
     *     
     */
    public void setMaturityAge(ValueTypeAttributeType value) {
        this.maturityAge = value;
    }

    /**
     * Gets the value of the maturityAgeInsured property.
     * 
     * @return
     *     possible object is
     *     {@link ValueTypeAttributeType }
     *     
     */
    public ValueTypeAttributeType getMaturityAgeInsured() {
        return maturityAgeInsured;
    }

    /**
     * Sets the value of the maturityAgeInsured property.
     * 
     * @param value
     *     allowed object is
     *     {@link ValueTypeAttributeType }
     *     
     */
    public void setMaturityAgeInsured(ValueTypeAttributeType value) {
        this.maturityAgeInsured = value;
    }

    /**
     * Gets the value of the units property.
     * 
     * @return
     *     possible object is
     *     {@link MinMaxValueType }
     *     
     */
    public MinMaxValueType getUnits() {
        return units;
    }

    /**
     * Sets the value of the units property.
     * 
     * @param value
     *     allowed object is
     *     {@link MinMaxValueType }
     *     
     */
    public void setUnits(MinMaxValueType value) {
        this.units = value;
    }

    /**
     * Gets the value of the name property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the value of the name property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setName(String value) {
        this.name = value;
    }

    /**
     * Gets the value of the id property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getId() {
        return id;
    }

    /**
     * Sets the value of the id property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setId(Integer value) {
        this.id = value;
    }

}
