
package com.ebix.lifelink.client;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for TableRatingsType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="TableRatingsType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="RatingsList" type="{urn:lifelink-schema}RatingsListType" minOccurs="0"/>
 *         &lt;element name="RatingRan" type="{urn:lifelink-schema}ClassType" minOccurs="0"/>
 *         &lt;element name="RatingAges" type="{urn:lifelink-schema}MinMaxType" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "TableRatingsType", propOrder = {
    "ratingsList",
    "ratingRan",
    "ratingAges"
})
public class TableRatingsType {

    @XmlElement(name = "RatingsList")
    protected RatingsListType ratingsList;
    @XmlElement(name = "RatingRan")
    protected ClassType ratingRan;
    @XmlElement(name = "RatingAges")
    protected MinMaxType ratingAges;

    /**
     * Gets the value of the ratingsList property.
     * 
     * @return
     *     possible object is
     *     {@link RatingsListType }
     *     
     */
    public RatingsListType getRatingsList() {
        return ratingsList;
    }

    /**
     * Sets the value of the ratingsList property.
     * 
     * @param value
     *     allowed object is
     *     {@link RatingsListType }
     *     
     */
    public void setRatingsList(RatingsListType value) {
        this.ratingsList = value;
    }

    /**
     * Gets the value of the ratingRan property.
     * 
     * @return
     *     possible object is
     *     {@link ClassType }
     *     
     */
    public ClassType getRatingRan() {
        return ratingRan;
    }

    /**
     * Sets the value of the ratingRan property.
     * 
     * @param value
     *     allowed object is
     *     {@link ClassType }
     *     
     */
    public void setRatingRan(ClassType value) {
        this.ratingRan = value;
    }

    /**
     * Gets the value of the ratingAges property.
     * 
     * @return
     *     possible object is
     *     {@link MinMaxType }
     *     
     */
    public MinMaxType getRatingAges() {
        return ratingAges;
    }

    /**
     * Sets the value of the ratingAges property.
     * 
     * @param value
     *     allowed object is
     *     {@link MinMaxType }
     *     
     */
    public void setRatingAges(MinMaxType value) {
        this.ratingAges = value;
    }

}
