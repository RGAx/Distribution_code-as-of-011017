
package com.ebix.lifelink.client;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for GenericReturnOfPremiumType.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="GenericReturnOfPremiumType">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="NO"/>
 *     &lt;enumeration value="ROP"/>
 *     &lt;enumeration value="FOP"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "GenericReturnOfPremiumType")
@XmlEnum
public enum GenericReturnOfPremiumType {

    NO,
    ROP,
    FOP;

    public String value() {
        return name();
    }

    public static GenericReturnOfPremiumType fromValue(String v) {
        return valueOf(v);
    }

}
