
package com.ebix.lifelink.client;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ToolLocationType.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="ToolLocationType">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="VT_Client"/>
 *     &lt;enumeration value="VT_Compare"/>
 *     &lt;enumeration value="VT_Reports"/>
 *     &lt;enumeration value="VLTC_Client"/>
 *     &lt;enumeration value="VLTC_Products"/>
 *     &lt;enumeration value="VLTC_Preview"/>
 *     &lt;enumeration value="VLTC_Compare"/>
 *     &lt;enumeration value="VLTC_Reports"/>
 *     &lt;enumeration value="VLTC_ProductDetails"/>
 *     &lt;enumeration value="VLTC_FeatureComp"/>
 *     &lt;enumeration value="VLTC_PremMatrix"/>
 *     &lt;enumeration value="VS_Default"/>
 *     &lt;enumeration value="VSNET_Default"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "ToolLocationType")
@XmlEnum
public enum ToolLocationType {

    @XmlEnumValue("VT_Client")
    VT_CLIENT("VT_Client"),
    @XmlEnumValue("VT_Compare")
    VT_COMPARE("VT_Compare"),
    @XmlEnumValue("VT_Reports")
    VT_REPORTS("VT_Reports"),
    @XmlEnumValue("VLTC_Client")
    VLTC_CLIENT("VLTC_Client"),
    @XmlEnumValue("VLTC_Products")
    VLTC_PRODUCTS("VLTC_Products"),
    @XmlEnumValue("VLTC_Preview")
    VLTC_PREVIEW("VLTC_Preview"),
    @XmlEnumValue("VLTC_Compare")
    VLTC_COMPARE("VLTC_Compare"),
    @XmlEnumValue("VLTC_Reports")
    VLTC_REPORTS("VLTC_Reports"),
    @XmlEnumValue("VLTC_ProductDetails")
    VLTC_PRODUCT_DETAILS("VLTC_ProductDetails"),
    @XmlEnumValue("VLTC_FeatureComp")
    VLTC_FEATURE_COMP("VLTC_FeatureComp"),
    @XmlEnumValue("VLTC_PremMatrix")
    VLTC_PREM_MATRIX("VLTC_PremMatrix"),
    @XmlEnumValue("VS_Default")
    VS_DEFAULT("VS_Default"),
    @XmlEnumValue("VSNET_Default")
    VSNET_DEFAULT("VSNET_Default");
    private final String value;

    ToolLocationType(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static ToolLocationType fromValue(String v) {
        for (ToolLocationType c: ToolLocationType.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
