
package com.ebix.lifelink.client;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for DispUWInfoType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DispUWInfoType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="ClassIDRan" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="ClassNameRan" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="TableRatings" type="{urn:lifelink-schema}RanTBLRateInfoType" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DispUWInfoType", propOrder = {
    "classIDRan",
    "classNameRan",
    "tableRatings"
})
public class DispUWInfoType {

    @XmlElement(name = "ClassIDRan")
    protected Boolean classIDRan;
    @XmlElement(name = "ClassNameRan")
    protected Boolean classNameRan;
    @XmlElement(name = "TableRatings")
    protected RanTBLRateInfoType tableRatings;

    /**
     * Gets the value of the classIDRan property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isClassIDRan() {
        return classIDRan;
    }

    /**
     * Sets the value of the classIDRan property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setClassIDRan(Boolean value) {
        this.classIDRan = value;
    }

    /**
     * Gets the value of the classNameRan property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isClassNameRan() {
        return classNameRan;
    }

    /**
     * Sets the value of the classNameRan property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setClassNameRan(Boolean value) {
        this.classNameRan = value;
    }

    /**
     * Gets the value of the tableRatings property.
     * 
     * @return
     *     possible object is
     *     {@link RanTBLRateInfoType }
     *     
     */
    public RanTBLRateInfoType getTableRatings() {
        return tableRatings;
    }

    /**
     * Sets the value of the tableRatings property.
     * 
     * @param value
     *     allowed object is
     *     {@link RanTBLRateInfoType }
     *     
     */
    public void setTableRatings(RanTBLRateInfoType value) {
        this.tableRatings = value;
    }

}
