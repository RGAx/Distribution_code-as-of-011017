
package com.ebix.lifelink.client;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for GenericPaymentModeType.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="GenericPaymentModeType">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="YEAR"/>
 *     &lt;enumeration value="SEMI"/>
 *     &lt;enumeration value="QTR"/>
 *     &lt;enumeration value="MONTH"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "GenericPaymentModeType")
@XmlEnum
public enum GenericPaymentModeType {

    YEAR,
    SEMI,
    QTR,
    MONTH;

    public String value() {
        return name();
    }

    public static GenericPaymentModeType fromValue(String v) {
        return valueOf(v);
    }

}
