
package com.ebix.lifelink.client;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for InterfaceTypeType.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="InterfaceTypeType">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="GUI"/>
 *     &lt;enumeration value="NoGUI"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "InterfaceTypeType")
@XmlEnum
public enum InterfaceTypeType {

    GUI("GUI"),
    @XmlEnumValue("NoGUI")
    NO_GUI("NoGUI");
    private final String value;

    InterfaceTypeType(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static InterfaceTypeType fromValue(String v) {
        for (InterfaceTypeType c: InterfaceTypeType.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
