
package com.ebix.lifelink.client;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ProductsType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ProductsType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="ProductOptions" type="{urn:lifelink-schema}VTProductOptionsType" minOccurs="0"/>
 *         &lt;element name="ProductLists" type="{urn:lifelink-schema}ProductListsType" minOccurs="0"/>
 *         &lt;element name="Reports" type="{urn:lifelink-schema}ReportsType" minOccurs="0"/>
 *         &lt;element name="ProductScenarios" type="{urn:lifelink-schema}ProductScenariosType" minOccurs="0"/>
 *         &lt;element name="RequestedProductInfo" type="{urn:lifelink-schema}RequestedProductInfoType" minOccurs="0"/>
 *         &lt;element name="NumberOfProductsQuoted" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="NumberOfProductsRemoved" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="Product" type="{urn:lifelink-schema}VTProductType" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ProductsType", propOrder = {
    "productOptions",
    "productLists",
    "reports",
    "productScenarios",
    "requestedProductInfo",
    "numberOfProductsQuoted",
    "numberOfProductsRemoved",
    "product"
})
public class ProductsType {

    @XmlElement(name = "ProductOptions")
    protected VTProductOptionsType productOptions;
    @XmlElement(name = "ProductLists")
    protected ProductListsType productLists;
    @XmlElement(name = "Reports")
    protected ReportsType reports;
    @XmlElement(name = "ProductScenarios")
    protected ProductScenariosType productScenarios;
    @XmlElement(name = "RequestedProductInfo")
    protected RequestedProductInfoType requestedProductInfo;
    @XmlElement(name = "NumberOfProductsQuoted")
    protected Integer numberOfProductsQuoted;
    @XmlElement(name = "NumberOfProductsRemoved")
    protected Integer numberOfProductsRemoved;
    @XmlElement(name = "Product")
    protected List<VTProductType> product;

    /**
     * Gets the value of the productOptions property.
     * 
     * @return
     *     possible object is
     *     {@link VTProductOptionsType }
     *     
     */
    public VTProductOptionsType getProductOptions() {
        return productOptions;
    }

    /**
     * Sets the value of the productOptions property.
     * 
     * @param value
     *     allowed object is
     *     {@link VTProductOptionsType }
     *     
     */
    public void setProductOptions(VTProductOptionsType value) {
        this.productOptions = value;
    }

    /**
     * Gets the value of the productLists property.
     * 
     * @return
     *     possible object is
     *     {@link ProductListsType }
     *     
     */
    public ProductListsType getProductLists() {
        return productLists;
    }

    /**
     * Sets the value of the productLists property.
     * 
     * @param value
     *     allowed object is
     *     {@link ProductListsType }
     *     
     */
    public void setProductLists(ProductListsType value) {
        this.productLists = value;
    }

    /**
     * Gets the value of the reports property.
     * 
     * @return
     *     possible object is
     *     {@link ReportsType }
     *     
     */
    public ReportsType getReports() {
        return reports;
    }

    /**
     * Sets the value of the reports property.
     * 
     * @param value
     *     allowed object is
     *     {@link ReportsType }
     *     
     */
    public void setReports(ReportsType value) {
        this.reports = value;
    }

    /**
     * Gets the value of the productScenarios property.
     * 
     * @return
     *     possible object is
     *     {@link ProductScenariosType }
     *     
     */
    public ProductScenariosType getProductScenarios() {
        return productScenarios;
    }

    /**
     * Sets the value of the productScenarios property.
     * 
     * @param value
     *     allowed object is
     *     {@link ProductScenariosType }
     *     
     */
    public void setProductScenarios(ProductScenariosType value) {
        this.productScenarios = value;
    }

    /**
     * Gets the value of the requestedProductInfo property.
     * 
     * @return
     *     possible object is
     *     {@link RequestedProductInfoType }
     *     
     */
    public RequestedProductInfoType getRequestedProductInfo() {
        return requestedProductInfo;
    }

    /**
     * Sets the value of the requestedProductInfo property.
     * 
     * @param value
     *     allowed object is
     *     {@link RequestedProductInfoType }
     *     
     */
    public void setRequestedProductInfo(RequestedProductInfoType value) {
        this.requestedProductInfo = value;
    }

    /**
     * Gets the value of the numberOfProductsQuoted property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getNumberOfProductsQuoted() {
        return numberOfProductsQuoted;
    }

    /**
     * Sets the value of the numberOfProductsQuoted property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setNumberOfProductsQuoted(Integer value) {
        this.numberOfProductsQuoted = value;
    }

    /**
     * Gets the value of the numberOfProductsRemoved property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getNumberOfProductsRemoved() {
        return numberOfProductsRemoved;
    }

    /**
     * Sets the value of the numberOfProductsRemoved property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setNumberOfProductsRemoved(Integer value) {
        this.numberOfProductsRemoved = value;
    }

    /**
     * Gets the value of the product property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the product property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getProduct().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link VTProductType }
     * 
     * 
     */
    public List<VTProductType> getProduct() {
        if (product == null) {
            product = new ArrayList<VTProductType>();
        }
        return this.product;
    }

}
