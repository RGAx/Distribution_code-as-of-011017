
package com.ebix.lifelink.client;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for GenericPaymentPlanType.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="GenericPaymentPlanType">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="ALL"/>
 *     &lt;enumeration value="CASH"/>
 *     &lt;enumeration value="INDEM"/>
 *     &lt;enumeration value="REIMB"/>
 *     &lt;enumeration value="PART"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "GenericPaymentPlanType")
@XmlEnum
public enum GenericPaymentPlanType {

    ALL,
    CASH,
    INDEM,
    REIMB,
    PART;

    public String value() {
        return name();
    }

    public static GenericPaymentPlanType fromValue(String v) {
        return valueOf(v);
    }

}
