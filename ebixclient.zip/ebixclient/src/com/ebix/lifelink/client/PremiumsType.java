
package com.ebix.lifelink.client;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for PremiumsType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="PremiumsType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="TotalPremiums" type="{urn:lifelink-schema}VTPremiumType" minOccurs="0"/>
 *         &lt;element name="BasePremiums" type="{urn:lifelink-schema}VTPremiumType" minOccurs="0"/>
 *         &lt;element name="RiderPremiums" type="{urn:lifelink-schema}RiderPremiumsType" minOccurs="0"/>
 *       &lt;/sequence>
 *       &lt;attribute name="type" use="required" type="{http://www.w3.org/2001/XMLSchema}string" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "PremiumsType", propOrder = {
    "totalPremiums",
    "basePremiums",
    "riderPremiums"
})
public class PremiumsType {

    @XmlElement(name = "TotalPremiums")
    protected VTPremiumType totalPremiums;
    @XmlElement(name = "BasePremiums")
    protected VTPremiumType basePremiums;
    @XmlElement(name = "RiderPremiums")
    protected RiderPremiumsType riderPremiums;
    @XmlAttribute(name = "type", required = true)
    protected String type;

    /**
     * Gets the value of the totalPremiums property.
     * 
     * @return
     *     possible object is
     *     {@link VTPremiumType }
     *     
     */
    public VTPremiumType getTotalPremiums() {
        return totalPremiums;
    }

    /**
     * Sets the value of the totalPremiums property.
     * 
     * @param value
     *     allowed object is
     *     {@link VTPremiumType }
     *     
     */
    public void setTotalPremiums(VTPremiumType value) {
        this.totalPremiums = value;
    }

    /**
     * Gets the value of the basePremiums property.
     * 
     * @return
     *     possible object is
     *     {@link VTPremiumType }
     *     
     */
    public VTPremiumType getBasePremiums() {
        return basePremiums;
    }

    /**
     * Sets the value of the basePremiums property.
     * 
     * @param value
     *     allowed object is
     *     {@link VTPremiumType }
     *     
     */
    public void setBasePremiums(VTPremiumType value) {
        this.basePremiums = value;
    }

    /**
     * Gets the value of the riderPremiums property.
     * 
     * @return
     *     possible object is
     *     {@link RiderPremiumsType }
     *     
     */
    public RiderPremiumsType getRiderPremiums() {
        return riderPremiums;
    }

    /**
     * Sets the value of the riderPremiums property.
     * 
     * @param value
     *     allowed object is
     *     {@link RiderPremiumsType }
     *     
     */
    public void setRiderPremiums(RiderPremiumsType value) {
        this.riderPremiums = value;
    }

    /**
     * Gets the value of the type property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getType() {
        return type;
    }

    /**
     * Sets the value of the type property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setType(String value) {
        this.type = value;
    }

}
