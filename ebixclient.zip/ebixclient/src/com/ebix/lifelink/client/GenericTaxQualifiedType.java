
package com.ebix.lifelink.client;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for GenericTaxQualifiedType.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="GenericTaxQualifiedType">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="TQ"/>
 *     &lt;enumeration value="NTQ"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "GenericTaxQualifiedType")
@XmlEnum
public enum GenericTaxQualifiedType {

    TQ,
    NTQ;

    public String value() {
        return name();
    }

    public static GenericTaxQualifiedType fromValue(String v) {
        return valueOf(v);
    }

}
