
package com.ebix.lifelink.client;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ToolTypeName.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="ToolTypeName">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="Test"/>
 *     &lt;enumeration value="VitalTerm"/>
 *     &lt;enumeration value="VitalTerm_Net"/>
 *     &lt;enumeration value="VitalTerm_Fili"/>
 *     &lt;enumeration value="VitalTerm_EasyQuote"/>
 *     &lt;enumeration value="VitalUL"/>
 *     &lt;enumeration value="VitalLTC"/>
 *     &lt;enumeration value="VitalSigns"/>
 *     &lt;enumeration value="VitalForms"/>
 *     &lt;enumeration value="VITALSIGNSNEW"/>
 *     &lt;enumeration value="WinFlex"/>
 *     &lt;enumeration value="VQMobile"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "ToolTypeName")
@XmlEnum
public enum ToolTypeName {

    @XmlEnumValue("Test")
    TEST("Test"),
    @XmlEnumValue("VitalTerm")
    VITAL_TERM("VitalTerm"),
    @XmlEnumValue("VitalTerm_Net")
    VITAL_TERM_NET("VitalTerm_Net"),
    @XmlEnumValue("VitalTerm_Fili")
    VITAL_TERM_FILI("VitalTerm_Fili"),
    @XmlEnumValue("VitalTerm_EasyQuote")
    VITAL_TERM_EASY_QUOTE("VitalTerm_EasyQuote"),
    @XmlEnumValue("VitalUL")
    VITAL_UL("VitalUL"),
    @XmlEnumValue("VitalLTC")
    VITAL_LTC("VitalLTC"),
    @XmlEnumValue("VitalSigns")
    VITAL_SIGNS("VitalSigns"),
    @XmlEnumValue("VitalForms")
    VITAL_FORMS("VitalForms"),
    VITALSIGNSNEW("VITALSIGNSNEW"),
    @XmlEnumValue("WinFlex")
    WIN_FLEX("WinFlex"),
    @XmlEnumValue("VQMobile")
    VQ_MOBILE("VQMobile");
    private final String value;

    ToolTypeName(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static ToolTypeName fromValue(String v) {
        for (ToolTypeName c: ToolTypeName.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
