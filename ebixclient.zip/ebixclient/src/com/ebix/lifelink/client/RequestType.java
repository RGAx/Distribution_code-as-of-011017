
package com.ebix.lifelink.client;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for RequestType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="RequestType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="FaceAmount" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Premium" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PaymentMode" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="UnderwritingClassInfo" type="{urn:lifelink-schema}UWClassInfoType" minOccurs="0"/>
 *         &lt;element name="Riders" type="{urn:lifelink-schema}RidersType" minOccurs="0"/>
 *         &lt;element name="FlatExtras" type="{urn:lifelink-schema}FlatExtrasType" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "RequestType", propOrder = {
    "faceAmount",
    "premium",
    "paymentMode",
    "underwritingClassInfo",
    "riders",
    "flatExtras"
})
public class RequestType {

    @XmlElement(name = "FaceAmount")
    protected String faceAmount;
    @XmlElement(name = "Premium")
    protected String premium;
    @XmlElement(name = "PaymentMode")
    protected Integer paymentMode;
    @XmlElement(name = "UnderwritingClassInfo")
    protected UWClassInfoType underwritingClassInfo;
    @XmlElement(name = "Riders")
    protected RidersType riders;
    @XmlElement(name = "FlatExtras")
    protected FlatExtrasType flatExtras;

    /**
     * Gets the value of the faceAmount property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFaceAmount() {
        return faceAmount;
    }

    /**
     * Sets the value of the faceAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFaceAmount(String value) {
        this.faceAmount = value;
    }

    /**
     * Gets the value of the premium property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPremium() {
        return premium;
    }

    /**
     * Sets the value of the premium property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPremium(String value) {
        this.premium = value;
    }

    /**
     * Gets the value of the paymentMode property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getPaymentMode() {
        return paymentMode;
    }

    /**
     * Sets the value of the paymentMode property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setPaymentMode(Integer value) {
        this.paymentMode = value;
    }

    /**
     * Gets the value of the underwritingClassInfo property.
     * 
     * @return
     *     possible object is
     *     {@link UWClassInfoType }
     *     
     */
    public UWClassInfoType getUnderwritingClassInfo() {
        return underwritingClassInfo;
    }

    /**
     * Sets the value of the underwritingClassInfo property.
     * 
     * @param value
     *     allowed object is
     *     {@link UWClassInfoType }
     *     
     */
    public void setUnderwritingClassInfo(UWClassInfoType value) {
        this.underwritingClassInfo = value;
    }

    /**
     * Gets the value of the riders property.
     * 
     * @return
     *     possible object is
     *     {@link RidersType }
     *     
     */
    public RidersType getRiders() {
        return riders;
    }

    /**
     * Sets the value of the riders property.
     * 
     * @param value
     *     allowed object is
     *     {@link RidersType }
     *     
     */
    public void setRiders(RidersType value) {
        this.riders = value;
    }

    /**
     * Gets the value of the flatExtras property.
     * 
     * @return
     *     possible object is
     *     {@link FlatExtrasType }
     *     
     */
    public FlatExtrasType getFlatExtras() {
        return flatExtras;
    }

    /**
     * Sets the value of the flatExtras property.
     * 
     * @param value
     *     allowed object is
     *     {@link FlatExtrasType }
     *     
     */
    public void setFlatExtras(FlatExtrasType value) {
        this.flatExtras = value;
    }

}
