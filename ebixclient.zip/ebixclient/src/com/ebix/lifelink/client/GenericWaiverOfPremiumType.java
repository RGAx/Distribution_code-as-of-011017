
package com.ebix.lifelink.client;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for GenericWaiverOfPremiumType.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="GenericWaiverOfPremiumType">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="NO"/>
 *     &lt;enumeration value="SWOP"/>
 *     &lt;enumeration value="JWOP"/>
 *     &lt;enumeration value="SJWOP"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "GenericWaiverOfPremiumType")
@XmlEnum
public enum GenericWaiverOfPremiumType {

    NO,
    SWOP,
    JWOP,
    SJWOP;

    public String value() {
        return name();
    }

    public static GenericWaiverOfPremiumType fromValue(String v) {
        return valueOf(v);
    }

}
