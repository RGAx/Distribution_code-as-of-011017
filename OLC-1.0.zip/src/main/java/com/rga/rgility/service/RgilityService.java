/**
 * 
 */
package com.rga.rgility.service;

import com.rga.rgility.exception.ServiceException;

/**
 * @author M1029563
 *
 */
public interface RgilityService {
	
	public String postRgilityRequestJson(String rgilityreqJson) throws ServiceException;
	
}
