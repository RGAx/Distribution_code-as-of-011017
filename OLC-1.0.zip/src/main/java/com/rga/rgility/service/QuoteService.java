/**
 * 
 */
package com.rga.rgility.service;

import com.rga.rgility.exception.ServiceException;
import com.rga.rgility.model.UserCoverage;
import com.rga.rgility.valueobjects.AppliedQuoteVO;
import com.rga.rgility.valueobjects.ProfileVO;

/**
 * @author M1029563
 *
 */
public interface QuoteService {
	
	public void savequoteinfoVO(ProfileVO profileVO,AppliedQuoteVO appliedQuoteVO) throws ServiceException;
	
	public AppliedQuoteVO constructAppliedQuoteVO(UserCoverage userCoverage) throws ServiceException;
	
}
