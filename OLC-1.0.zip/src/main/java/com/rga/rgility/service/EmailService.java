package com.rga.rgility.service;

import com.itextpdf.text.Document;
import com.itextpdf.text.pdf.PdfWriter;
import com.rga.rgility.exception.ServiceException;
import com.rga.rgility.model.UserCoverage;
import com.rga.rgility.valueobjects.AppliedQuoteVO;
import com.rga.rgility.valueobjects.DemographicInfoVO;
import com.rga.rgility.valueobjects.ProfileVO;

public interface EmailService {
	public void sendMail(String from, String to, String subject, String msg)
			throws ServiceException;
	
	public void generatePDF(Document document, PdfWriter writer,
			ProfileVO profileVO)
			throws ServiceException, Exception;
	
	public String sendemailtoUser(ProfileVO profileVo,AppliedQuoteVO appliedQuoteVO) throws ServiceException;
	
	public void sendContactUsEmail(UserCoverage user,ProfileVO profileVO,String phoneNumber,String src) throws ServiceException;
	
	public void sendQuoteFollowUpEmail(DemographicInfoVO demoVO) throws ServiceException;
	
	public void sendApplyNowEmail(ProfileVO profileVO, AppliedQuoteVO appliedQuoteVO) throws ServiceException;
}
