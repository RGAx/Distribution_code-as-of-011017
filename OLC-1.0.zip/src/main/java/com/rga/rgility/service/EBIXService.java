package com.rga.rgility.service;

import java.util.Map;

import com.rga.rgility.exception.ServiceException;
import com.rga.rgility.valueobjects.ProfileVO;

/**
 * Interface to call EBIX web service to fetch premium per month.
 * @author Nagendra
 *
 */
public interface EBIXService {
	
	public Map<String,Double> getMonthlyPremium(ProfileVO profileVO) throws ServiceException;

}
