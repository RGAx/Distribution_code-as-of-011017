package com.rga.rgility.common.logger.impl;

/**
 * 
 * @author M1030133
 *
 */
import org.apache.log4j.Level;
import org.apache.log4j.Logger;

import com.rga.rgility.common.logger.MyLifeCoveredLogger;

public class MyLifeCoveredLoggerImpl implements MyLifeCoveredLogger {

	private static final int GET_CALLING_METHOD_NAME_DEPTH = 2;
	Logger log4JLogger;// = new Log4JLogger();

	public MyLifeCoveredLoggerImpl() {
		log4JLogger = Logger.getRootLogger();
	}

	public MyLifeCoveredLoggerImpl(String className) {
		log4JLogger = Logger.getLogger(className);
	}

	public void debug(Object arg0) {
		log4JLogger.debug(arg0);

	}

	public void debug(Object arg0, Throwable arg1) {
		log4JLogger.debug(arg0, arg1);

	}

	public void error(Object arg0) {
		log4JLogger.error(arg0);

	}

	public void error(Object arg0, Throwable arg1) {
		log4JLogger.error(arg0, arg1);

	}

	public void fatal(Object arg0) {
		log4JLogger.fatal(arg0);

	}

	public void fatal(Object arg0, Throwable arg1) {
		log4JLogger.fatal(arg0, arg1);

	}

	public void info(Object arg0) {
		log4JLogger.info(arg0);

	}

	public void info(Object arg0, Throwable arg1) {
		log4JLogger.info(arg0, arg1);

	}

	public boolean isDebugEnabled() {
		return log4JLogger.isEnabledFor(Level.DEBUG);
	}

	public boolean isErrorEnabled() {
		return log4JLogger.isEnabledFor(Level.ERROR);
	}

	public boolean isFatalEnabled() {
		return log4JLogger.isEnabledFor(Level.FATAL);
	}

	public boolean isInfoEnabled() {
		return log4JLogger.isInfoEnabled();
	}

	public boolean isTraceEnabled() {
		return log4JLogger.isTraceEnabled();
	}

	public boolean isWarnEnabled() {
		return log4JLogger.isEnabledFor(Level.WARN);
	}

	public void trace(Object arg0) {
		log4JLogger.trace(arg0);
	}

	public void trace(Object arg0, Throwable arg1) {
		log4JLogger.trace(arg0, arg1);
	}

	public void warn(Object arg0) {
		log4JLogger.warn(arg0);
	}

	public void warn(Object arg0, Throwable arg1) {
		log4JLogger.warn(arg0, arg1);
	}

	public final long logMethodEntry() {
		final long startTime = System.currentTimeMillis();
		if (this.isDebugEnabled()) {
			this.debug("Entering : " + getCallingMethodName()
					+ " Entry Time in msec : " + startTime);
		}
		return startTime;
	}

	public final void logMethodExit(final long startTime) {
		final long endTime = System.currentTimeMillis();
		if (this.isDebugEnabled()) {
			this.debug("Exiting : " + getCallingMethodName()
					+ " Exit Time in msec : " + endTime + " Time Taken :"
					+ (endTime - startTime));
		}
	}

	private static String getCallingMethodName() {
		return Thread.currentThread().getStackTrace()[GET_CALLING_METHOD_NAME_DEPTH]
				.getMethodName() + "()";
	}
}