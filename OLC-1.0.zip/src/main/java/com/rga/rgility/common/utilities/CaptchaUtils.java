package com.rga.rgility.common.utilities;


import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;

import javax.net.ssl.HttpsURLConnection;

import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.rga.rgility.common.constants.ApplicationConstants;
import com.rga.rgility.common.logger.LogFactory;
import com.rga.rgility.common.logger.MyLifeCoveredLogger;

public class CaptchaUtils {

	private static final MyLifeCoveredLogger LOGGER = LogFactory.getInstance(CaptchaUtils.class);
	public static final String url = "https://www.google.com/recaptcha/api/siteverify";
	public static final String secret = ApplicationConstants.CAPTCHA_SECRET_KEY;
	/*private final static String USER_AGENT = "Mozilla/5.0";*/

	public static boolean verifyCaptcha(String gRecaptchaResponse) throws IOException {
		if (gRecaptchaResponse == null || "".equals(gRecaptchaResponse)) {
			return false;
		}
		Gson gson = new Gson();
		try{
		URL obj = new URL(url);
		HttpsURLConnection con = (HttpsURLConnection) obj.openConnection();

		// add reuqest header
		con.setRequestMethod("POST");
		//con.setRequestProperty("User-Agent", USER_AGENT);
		con.setRequestProperty("Accept-Language", "en-US,en;q=0.5");

		/*String postParams = "secret=" + secret + "&response="+ gRecaptchaResponse;*/

		// Send post request
		con.setDoOutput(true);
		DataOutputStream wr = new DataOutputStream(con.getOutputStream());
		wr.writeBytes("secret=" + secret + "&response="+ gRecaptchaResponse);
		wr.flush();
		wr.close();

		/*int responseCode = con.getResponseCode();*/
/*		System.out.println("\nSending 'POST' request to URL : " + url);
		System.out.println("Post parameters : " + postParams);
		System.out.println("Response Code : " + responseCode);*/
		LOGGER.debug("calling google service start here");
		BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
		LOGGER.debug("calling google service ends here");
		String inputLine;
		StringBuffer response = new StringBuffer();

		while ((inputLine = in.readLine()) != null) {
			response.append(inputLine);
		}
		in.close();

		// print result
/*		System.out.println(response.toString());*/
		
		//parse JSON response and return 'success' value
	  /*JsonReader jsonReader = gson.toJson(response);//Json.createReader(new StringReader(response.toString()));
		JsonObject jsonObject = jsonReader.readObject();
		jsonReader.close();*/
		
		JsonElement jElement = gson.fromJson(response.toString(), JsonElement.class);
		if(null ==jElement) 
			return false;
		/*JsonObject jsonObject = jElement.getAsJsonObject();
		jsonObject.getAsBoolean();
		System.out.println("-->>"+jsonObject.getAsJsonPrimitive("success"));*/
		/*return jsonObject.getBoolean("success");*/
		return Boolean.parseBoolean(jElement.getAsJsonObject().getAsJsonPrimitive(ApplicationConstants.CAPTCHA_STATUS).toString());
		}catch(Exception e){
			LOGGER.debug("error in exception block is here"+e);
			e.printStackTrace();
			return false;
		}
	}
}