package com.rga.rgility.common.config;

import org.springframework.security.web.context.*;

/**
 * 
 * @author M1038606
 *
 */
public class SecurityWebApplicationInitializer extends AbstractSecurityWebApplicationInitializer {

}
