package com.rga.rgility.common.config;

import javax.servlet.ServletContext;
import javax.servlet.ServletRegistration;

import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.web.WebApplicationInitializer;
import org.springframework.web.context.ContextLoaderListener;
import org.springframework.web.context.support.AnnotationConfigWebApplicationContext;
import org.springframework.web.servlet.DispatcherServlet;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

import com.rga.rgility.common.logger.LogFactory;
import com.rga.rgility.common.logger.MyLifeCoveredLogger;
/**
 * 
 * @author M1038606
 *
 */
@Configuration
@EnableWebMvc
@PropertySource("classpath:application.properties")
public class WebMvcConfigInitializer implements WebApplicationInitializer {
	private static final MyLifeCoveredLogger LOGGER = LogFactory.getInstance(WebMvcConfigInitializer.class);
	@Override
	public void onStartup(ServletContext container) {
		// Create the 'root' Spring application context
		LOGGER.debug("Started  configuring  dispatcher servlet");
		AnnotationConfigWebApplicationContext rootContext = new AnnotationConfigWebApplicationContext();
		rootContext.register(ApplicationConfig.class);

		// Manage the lifecycle of the root application context
		container.addListener(new ContextLoaderListener(rootContext));

		// Create the dispatcher servlet's Spring application context
		AnnotationConfigWebApplicationContext dispatcherContext = new AnnotationConfigWebApplicationContext();
		dispatcherContext.register(WebApplicationConfig.class);

		// Register and map the dispatcher servlet
		ServletRegistration.Dynamic dispatcher = container.addServlet("dispatcher",
				new DispatcherServlet(dispatcherContext));
		dispatcher.setLoadOnStartup(1);
		dispatcher.addMapping("*.do");
		LOGGER.debug("Dispatcher servlet configured successfully");
	}

}
