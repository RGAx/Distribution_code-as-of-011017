package com.rga.rgility.common.listener;

import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;

import com.rga.rgility.common.constants.ApplicationConstants;
import com.rga.rgility.common.logger.LogFactory;
import com.rga.rgility.common.logger.MyLifeCoveredLogger;

public class OurLifeCoveredSessionListener implements HttpSessionListener {
	private static final MyLifeCoveredLogger LOGGER = LogFactory.getInstance(OurLifeCoveredSessionListener.class);

	public void sessionCreated(HttpSessionEvent event) {
		LOGGER.debug("........... Session Created  .............");
		LOGGER.debug("Session Created with Id =" + "" + event.getSession().getId() + "created at ="
				+ event.getSession().getCreationTime());
		event.getSession().setMaxInactiveInterval(ApplicationConstants.SESSION_TIMEOUT_IN_SECONDS);
	}

	public void sessionDestroyed(HttpSessionEvent event) {
		LOGGER.debug("............  Session Destroyed ..............");
		LOGGER.debug("Session destroyed for Id =" + "" + event.getSession().getId() + "last accessed at ="
				+ event.getSession().getLastAccessedTime() + "phone no="
				+ event.getSession().getAttribute("phoneNumber"));
	}
}