package com.rga.rgility.common.logger;

import com.rga.rgility.common.logger.impl.MyLifeCoveredLoggerImpl;

/**
 * 
 * @author M1030133
 *
 */
@SuppressWarnings("rawtypes")
public class LogFactory {
	public static MyLifeCoveredLogger getInstance() {
		return new MyLifeCoveredLoggerImpl();
	}

	public static MyLifeCoveredLogger getInstance(String className) {
		return new MyLifeCoveredLoggerImpl(className);
	}

	public static MyLifeCoveredLogger getInstance(Class clazz) {
		return new MyLifeCoveredLoggerImpl(clazz.getCanonicalName());
	}
}