package com.rga.rgility.common.config;

import java.util.Properties;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;
import org.springframework.core.env.Environment;
import org.springframework.core.io.ClassPathResource;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.transaction.annotation.TransactionManagementConfigurer;

import com.rga.rgility.dao.OurLifeCoveredDAO;
import com.rga.rgility.dao.QuoteDAO;
import com.rga.rgility.dao.impl.OurLifeCoveredDAOImpl;
import com.rga.rgility.dao.impl.QuoteDAOImpl;
import com.rga.rgility.service.EBIXService;
import com.rga.rgility.service.EmailService;
import com.rga.rgility.service.HealthIQService;
import com.rga.rgility.service.OurLifeCoveredService;
import com.rga.rgility.service.QuoteService;
import com.rga.rgility.service.RgilityService;
import com.rga.rgility.service.impl.EBIXServiceImpl;
import com.rga.rgility.service.impl.EmailServiceImpl;
import com.rga.rgility.service.impl.HealthIQServiceImpl;
import com.rga.rgility.service.impl.OurLifeCoveredServiceImpl;
import com.rga.rgility.service.impl.QuoteServiceImpl;
import com.rga.rgility.service.impl.RgilityServiceImpl;

/**
 * 
 * @author M1038606
 *
 */
@ComponentScan(basePackages = "com.rga.rgility")
@EnableTransactionManagement
@PropertySource("classpath:application.properties")
@Configuration
public class ApplicationConfig implements TransactionManagementConfigurer {
	@Autowired
	private Environment environment;

	@Autowired
	public DataSource dataSource;

	@Autowired
	JdbcTemplate jdbcTemplate;

	@Bean
	public DataSource getDataSource() {
		DriverManagerDataSource dataSource = new DriverManagerDataSource();
		dataSource.setUsername(environment.getProperty("JDBC.USERNAME"));
		dataSource.setPassword(environment.getProperty("JDBC.PASSWORD"));
		dataSource.setDriverClassName(environment.getProperty("JDBC.DRIVER"));
		dataSource.setUrl(environment.getProperty("JDBC.CONNECTION.URL"));
		return dataSource;
	}

	@Bean
	public JavaMailSender mailSender() {
		JavaMailSenderImpl mailSender = new JavaMailSenderImpl();
		mailSender.setHost(environment.getProperty("email.host"));
		mailSender.setPort(Integer.parseInt(environment.getProperty("email.port")));
		mailSender.setUsername(environment.getProperty("email.username"));
		mailSender.setPassword(environment.getProperty("email.password"));
		mailSender.setJavaMailProperties(this.javaMailProperties());
		return mailSender;
	}

	private Properties javaMailProperties() {
		Properties properties = new Properties();
		properties.put("mail.transport.protocol", environment.getProperty("email.protocol"));
		properties.put("mail.smtp.auth", environment.getProperty("email.auth"));
		properties.put("mail.smtp.starttls.enable", environment.getProperty("email.starttls.enable"));
		properties.put("mail.debug", environment.getProperty("email.debug"));
		return properties;
	}

	@Bean
	public JdbcTemplate jdbcTemplate() {
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
		return jdbcTemplate;
	}

	@Bean
	public static PropertySourcesPlaceholderConfigurer propertyConfigurer() {
		PropertySourcesPlaceholderConfigurer postProcessor = new PropertySourcesPlaceholderConfigurer();
		postProcessor.setLocation(new ClassPathResource("application.properties"));
		return postProcessor;
	}

	@Bean
	public OurLifeCoveredService ourLifeCoveredService() {
		return new OurLifeCoveredServiceImpl();
	}

	@Bean
	public EmailService emailService() {
		return new EmailServiceImpl();
	}

	@Bean
	public QuoteService quoteService() {
		return new QuoteServiceImpl();
	}

	@Bean
	public RgilityService rgilityService() {
		return new RgilityServiceImpl();
	}

	@Bean
	public OurLifeCoveredDAO ourLifeCoveredDAO() {
		OurLifeCoveredDAO ourLifeCoveredDAO = new OurLifeCoveredDAOImpl();
		ourLifeCoveredDAO.setJdbcTemplate(jdbcTemplate);
		return ourLifeCoveredDAO;
	}

	@Bean
	public QuoteDAO quoteDAO() {
		QuoteDAO quoteDAO = new QuoteDAOImpl();
		quoteDAO.setJdbcTemplate(jdbcTemplate);
		return quoteDAO;
	}

	@Bean
	public EBIXService ebixWebService() {
		return new EBIXServiceImpl();
	}

	@Bean
	public HealthIQService healthService() {
		return new HealthIQServiceImpl();
	}

	@Bean
	public DataSourceTransactionManager transactionManager() {
		DataSourceTransactionManager dsTransactionManager = new DataSourceTransactionManager();
		dsTransactionManager.setDataSource(dataSource);
		return dsTransactionManager;
	}

	@Bean
	public PlatformTransactionManager txManager() {
		return new DataSourceTransactionManager(dataSource);
	}

	@Override
	public PlatformTransactionManager annotationDrivenTransactionManager() {
		return txManager();
	}
}