package com.rga.rgility.common.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.*;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.web.session.HttpSessionEventPublisher;

import com.rga.rgility.common.listener.OurLifeCoveredSessionListener;
import com.rga.rgility.common.logger.LogFactory;
import com.rga.rgility.common.logger.MyLifeCoveredLogger;

/**
 * 
 * @author M1038606
 *
 */
@Configuration
@EnableWebSecurity
public class SecurityConfig extends WebSecurityConfigurerAdapter {
	private static final MyLifeCoveredLogger LOGGER = LogFactory.getInstance(SecurityConfig.class);
	@Autowired
	public void configureGlobal(AuthenticationManagerBuilder auth) throws Exception {
		auth.inMemoryAuthentication().withUser("olc").password("olc").roles("USER");
	}

	@Bean
	public HttpSessionEventPublisher httpSessionEventPublisher() {
		return new HttpSessionEventPublisher();
	}

	@Override
	protected void configure(HttpSecurity http) throws Exception {
		http.sessionManagement().maximumSessions(1).expiredUrl("/").maxSessionsPreventsLogin(true);
		http.sessionManagement().sessionCreationPolicy(SessionCreationPolicy.IF_REQUIRED);
		http.sessionManagement().sessionFixation().migrateSession();
		http.sessionManagement().invalidSessionUrl("/");
		http.sessionManagement().enableSessionUrlRewriting(true);
		http.csrf().disable();
		LOGGER.debug("Security configurations completed successfully");
	}

	@Override
	public void configure(WebSecurity web) throws Exception {
		web.debug(false);
	}

}