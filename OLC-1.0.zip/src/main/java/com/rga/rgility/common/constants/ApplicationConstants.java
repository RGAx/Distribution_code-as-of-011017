/**
 * 
 */
package com.rga.rgility.common.constants;

/**
 * @author M1030133
 * 
 */
public class ApplicationConstants {

	public static final int IDONT_KNOW_PATH_ID = 1;
	public static final int IKNOW_PATH_ID = 2;
	public static final int IAM_NEW_PATH_ID = 4;
	public static final int TWENTY_FIVE_DOLLARS = 3;
	public static final String DATE_PATTERN = "MMddyyyy";

	public static final boolean BreakDownPremiums = false;
	public static final boolean CalcToPenny = true;
	public static final boolean DisplayProductClasses = false;
	public static final boolean GetCompanyInfo = false;
	public static final boolean ShowCurrentRates = false;
	public static final boolean ShowRemovedProducts = true;
	public static final boolean ShowProdInfoOnRemoval = false;
	public static final boolean ShowProdInfoOnly = false;
	public static final boolean ShowPremiumsOnly = false;
	public static final boolean Calc1StYearModal = true;
	
	public static final String PUBLIC = "Public";
	public static final String PRIVATE = "Private";
	//current MLC page - How Much Do I Need
	public static final String CALCULATE_NEED = "calculateneed";
	//Calculate coverage based on premium that user can Afford 
	public static final String AFFORDABILITY = "affordability";
	//User knows how much coverage he need
	public static final String I_KNOW_WHAT_I_WANT = "iknowwhatiwant";
	public static final String MLC_MAIN = "mlcmain";
	public static final String HOME = "home";
	
	public static final String SUCCESS = "success";
	public static final String FAILED = "failed";
	public static final String CAPTCHA_SITE_KEY = "6LdK6w4UAAAAANjpS275dBIEfBbY0-4iVGQW6N4n";
	public static final String CAPTCHA_SECRET_KEY = "6LdK6w4UAAAAAD1yRKyrZdb7Th54yWZJNkq0hZxN";
	public static final String CAPTCHA_STATUS = "success";
	
	
}
