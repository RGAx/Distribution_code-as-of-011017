/**
 * 
 */
package com.rga.rgility.valueobjects;

import java.util.Date;

/**
 * @author M1030133
 *
 */
public class DemographicInfoVO implements java.io.Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String quotePhone;
	public String getQuotePhone() {
		return quotePhone;
	}
	public void setQuotePhone(String quotePhone) {
		this.quotePhone = quotePhone;
	}
	private int demographicInfoId;
	private Date dateOfBirth;
	private String gender;
	private String smokerStatus;
	private String isUsCitizen;
	private String isPolicyOwner;
	private String isConsentReplacementPolicy;
	private String emailAddress;
	private String state;
	private String isAllowMarketing;
	private String firstName;
	private String phone;
	private int profileId;
	private int emailCount;
	
	public int getProfileId() {
		return profileId;
	}
	public void setProfileId(int profileId) {
		this.profileId = profileId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getIsAllowMarketing() {
		return isAllowMarketing;
	}
	public void setIsAllowMarketing(String isAllowMarketing) {
		this.isAllowMarketing = isAllowMarketing;
	}
	/**
	 * @return the demographicInfoId
	 */
	public int getDemographicInfoId() {
		return demographicInfoId;
	}
	/**
	 * @param demographicInfoId the demographicInfoId to set
	 */
	public void setDemographicInfoId(int demographicInfoId) {
		this.demographicInfoId = demographicInfoId;
	}
	/**
	 * @return the dateOfBirth
	 */
	public Date getDateOfBirth() {
		return dateOfBirth;
	}
	/**
	 * @param dateOfBirth the dateOfBirth to set
	 */
	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	/**
	 * @return the gender
	 */
	public String getGender() {
		return gender;
	}
	/**
	 * @param gender the gender to set
	 */
	public void setGender(String gender) {
		this.gender = gender;
	}
	/**
	 * @return the smokerStatus
	 */
	public String getSmokerStatus() {
		return smokerStatus;
	}
	/**
	 * @param smokerStatus the smokerStatus to set
	 */
	public void setSmokerStatus(String smokerStatus) {
		this.smokerStatus = smokerStatus;
	}
	/**
	 * @return the isUsCitizen
	 */
	public String getIsUsCitizen() {
		return isUsCitizen;
	}
	/**
	 * @param isUsCitizen the isUsCitizen to set
	 */
	public void setIsUsCitizen(String isUsCitizen) {
		this.isUsCitizen = isUsCitizen;
	}
	/**
	 * @return the isPolicyOwner
	 */
	public String getIsPolicyOwner() {
		return isPolicyOwner;
	}
	/**
	 * @param isPolicyOwner the isPolicyOwner to set
	 */
	public void setIsPolicyOwner(String isPolicyOwner) {
		this.isPolicyOwner = isPolicyOwner;
	}
	/**
	 * @return the isConsentReplacementPolicy
	 */
	public String getIsConsentReplacementPolicy() {
		return isConsentReplacementPolicy;
	}
	/**
	 * @param isConsentReplacementPolicy the isConsentReplacementPolicy to set
	 */
	public void setIsConsentReplacementPolicy(String isConsentReplacementPolicy) {
		this.isConsentReplacementPolicy = isConsentReplacementPolicy;
	}
	/**
	 * @return the emailAddress
	 */
	public String getEmailAddress() {
		return emailAddress;
	}
	/**
	 * @param emailAddress the emailAddress to set
	 */
	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}
	/**
	 * @return the state
	 */
	public String getState() {
		return state;
	}
	/**
	 * @param state the state to set
	 */
	public void setState(String state) {
		this.state = state;
	}
	/**
	 * 
	 * @return emailCount
	 */
	public int getEmailCount() {
		return emailCount;
	}
	public void setEmailCount(int emailCount) {
		this.emailCount = emailCount;
	}

	
}
