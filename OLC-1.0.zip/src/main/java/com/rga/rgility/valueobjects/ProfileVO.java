/**
 * 
 */
package com.rga.rgility.valueobjects;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

/**
 * @author M1030133
 *
 */
@Component
public class ProfileVO implements java.io.Serializable,Cloneable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private int profileId;
	private int pathId;
	private String firstName;
	private String lastName;
	private double coverage;
	private int term;
	private double retirementSavings;
	private double otherSavings;
	private double annualIncome;
	private double existingLifeInsurance;
	private int yearsIncomeProvided;
	private double finalExpenses;
	private double outstandingMortgage;
	private double otherOutstandingDebt;
	private int estimatedInflationRate;
	private int estimatedInvestmentReturn;
	private double totalIncomeToBeProvided;
	private double totalIncomeNeeds;
	private double estimatedPrivateCollegeExpenses;
	private double estimatedPublicCollegeExpenses;
	private double totalCollegeExpenses;
	private double totalOneTimeNeeds;
	public int privateChildrenCount;
	public String vanityPhoneNo; 
	private int affordablePremium;
	private int affordableClassCheck;

	private DemographicInfoVO demographicVO;
	private AppliedQuoteVO appliedQuoteVO;
	public int publicChildrenCount;

	private List<ChildrenVO> children = new ArrayList<ChildrenVO>();
	private int childCount;
	
	public int getAffordableClassCheck() {
		return affordableClassCheck;
	}

	public void setAffordableClassCheck(int affordableClassCheck) {
		this.affordableClassCheck = affordableClassCheck;
	}

	public int getPrivateChildrenCount() {
		return privateChildrenCount;
	}

	public void setPrivateChildrenCount(int privateChildrenCount) {
		this.privateChildrenCount = privateChildrenCount;
	}

	public int getPublicChildrenCount() {
		return publicChildrenCount;
	}

	public void setPublicChildrenCount(int publicChildrenCount) {
		this.publicChildrenCount = publicChildrenCount;
	}

	public int getProfileId() {
		return profileId;
	}

	public void setProfileId(int profileId) {
		this.profileId = profileId;
	}

	public int getPathId() {
		return pathId;
	}

	public void setPathId(int pathId) {
		this.pathId = pathId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public double getCoverage() {
		return coverage;
	}

	public void setCoverage(double coverage) {
		this.coverage = coverage;
	}

	public int getTerm() {
		return term;
	}

	public void setTerm(int term) {
		this.term = term;
	}

	public double getRetirementSavings() {
		return retirementSavings;
	}

	public void setRetirementSavings(double retirementSavings) {
		this.retirementSavings = retirementSavings;
	}

	public double getOtherSavings() {
		return otherSavings;
	}

	public void setOtherSavings(double otherSavings) {
		this.otherSavings = otherSavings;
	}

	public double getAnnualIncome() {
		return annualIncome;
	}

	public void setAnnualIncome(double annualIncome) {
		this.annualIncome = annualIncome;
	}

	public double getExistingLifeInsurance() {
		return existingLifeInsurance;
	}

	public void setExistingLifeInsurance(double existingLifeInsurance) {
		this.existingLifeInsurance = existingLifeInsurance;
	}

	public int getYearsIncomeProvided() {
		return yearsIncomeProvided;
	}

	public void setYearsIncomeProvided(int yearsIncomeProvided) {
		this.yearsIncomeProvided = yearsIncomeProvided;
	}

	public double getFinalExpenses() {
		return finalExpenses;
	}

	public void setFinalExpenses(double finalExpenses) {
		this.finalExpenses = finalExpenses;
	}

	public double getOutstandingMortgage() {
		return outstandingMortgage;
	}

	public void setOutstandingMortgage(double outstandingMortgage) {
		this.outstandingMortgage = outstandingMortgage;
	}

	public double getOtherOutstandingDebt() {
		return otherOutstandingDebt;
	}

	public void setOtherOutstandingDebt(double otherOutstandingDebt) {
		this.otherOutstandingDebt = otherOutstandingDebt;
	}

	public int getEstimatedInflationRate() {
		return estimatedInflationRate;
	}

	public void setEstimatedInflationRate(int estimatedInflationRate) {
		this.estimatedInflationRate = estimatedInflationRate;
	}

	public int getEstimatedInvestmentReturn() {
		return estimatedInvestmentReturn;
	}

	public void setEstimatedInvestmentReturn(int estimatedInvestmentReturn) {
		this.estimatedInvestmentReturn = estimatedInvestmentReturn;
	}

	public double getTotalIncomeToBeProvided() {
		return totalIncomeToBeProvided;
	}

	public void setTotalIncomeToBeProvided(double totalIncomeToBeProvided) {
		this.totalIncomeToBeProvided = totalIncomeToBeProvided;
	}

	public double getTotalIncomeNeeds() {
		return totalIncomeNeeds;
	}

	public void setTotalIncomeNeeds(double totalIncomeNeeds) {
		this.totalIncomeNeeds = totalIncomeNeeds;
	}

	public double getTotalCollegeExpenses() {
		return totalCollegeExpenses;
	}

	public void setTotalCollegeExpenses(double totalCollegeExpenses) {
		this.totalCollegeExpenses = totalCollegeExpenses;
	}

	public double getTotalOneTimeNeeds() {
		return totalOneTimeNeeds;
	}

	public void setTotalOneTimeNeeds(double totalOneTimeNeeds) {
		this.totalOneTimeNeeds = totalOneTimeNeeds;
	}

	public List<ChildrenVO> getChildren() {
		return children;
	}

	public void setChildren(List<ChildrenVO> children) {
		this.children = children;
	}

	public int getChildCount() {
		return childCount;
	}

	public void setChildCount(int childCount) {
		this.childCount = childCount;
	}

	public DemographicInfoVO getDemographicVO() {
		return demographicVO;
	}

	public void setDemographicVO(DemographicInfoVO demographicVO) {
		this.demographicVO = demographicVO;
	}

	public AppliedQuoteVO getAppliedQuoteVO() {
		return appliedQuoteVO;
	}

	public void setAppliedQuoteVO(AppliedQuoteVO appliedQuoteVO) {
		this.appliedQuoteVO = appliedQuoteVO;
	}

	public double getEstimatedPrivateCollegeExpenses() {
		return estimatedPrivateCollegeExpenses;
	}

	public void setEstimatedPrivateCollegeExpenses(
			double estimatedPrivateCollegeExpenses) {
		this.estimatedPrivateCollegeExpenses = estimatedPrivateCollegeExpenses;
	}

	public double getEstimatedPublicCollegeExpenses() {
		return estimatedPublicCollegeExpenses;
	}

	public void setEstimatedPublicCollegeExpenses(
			double estimatedPublicCollegeExpenses) {
		this.estimatedPublicCollegeExpenses = estimatedPublicCollegeExpenses;
	}
	

	public String getVanityPhoneNo() {
		return vanityPhoneNo;
	}

	public void setVanityPhoneNo(String vanityPhoneNo) {
		this.vanityPhoneNo = vanityPhoneNo;
	}
	
	public int getAffordablePremium() {
		return affordablePremium;
	}

	public void setAffordablePremium(int affordablePremium) {
		this.affordablePremium = affordablePremium;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	
	@Override
	public String toString() {
		return "ProfileVO [profileId=" + profileId + ", pathId=" + pathId + ", firstName=" + firstName + ", coverage="
				+ coverage + ", term=" + term + ", retirementSavings=" + retirementSavings + ", otherSavings="
				+ otherSavings + ", annualIncome=" + annualIncome + ", existingLifeInsurance=" + existingLifeInsurance
				+ ", yearsIncomeProvided=" + yearsIncomeProvided + ", finalExpenses=" + finalExpenses
				+ ", outstandingMortgage=" + outstandingMortgage + ", otherOutstandingDebt=" + otherOutstandingDebt
				+ ", estimatedInflationRate=" + estimatedInflationRate + ", estimatedInvestmentReturn="
				+ estimatedInvestmentReturn + ", totalIncomeToBeProvided=" + totalIncomeToBeProvided
				+ ", totalIncomeNeeds=" + totalIncomeNeeds + ", estimatedPrivateCollegeExpenses="
				+ estimatedPrivateCollegeExpenses + ", estimatedPublicCollegeExpenses=" + estimatedPublicCollegeExpenses
				+ ", totalCollegeExpenses=" + totalCollegeExpenses + ", totalOneTimeNeeds=" + totalOneTimeNeeds
				+ ", privateChildrenCount=" + privateChildrenCount + ", vanityPhoneNo=" + vanityPhoneNo
				+ ", publicChildrenCount=" + publicChildrenCount + ", children=" + children + ", childCount="
				+ childCount + ", demographicVO=" + demographicVO + ", appliedQuoteVO=" + appliedQuoteVO + ", lastName=" + lastName + "]";
	}

	public Object clone() throws CloneNotSupportedException{
		return super.clone();
	}
}
