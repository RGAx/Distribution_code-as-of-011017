/**
 * 
 */
package com.rga.rgility.dao.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;

import com.rga.rgility.common.constants.QueryConstants;
import com.rga.rgility.common.logger.LogFactory;
import com.rga.rgility.common.logger.MyLifeCoveredLogger;
import com.rga.rgility.dao.QuoteDAO;
import com.rga.rgility.exception.DAOException;
import com.rga.rgility.valueobjects.AppliedQuoteVO;

/**
 * @author M1029563
 *
 */
public class QuoteDAOImpl implements QuoteDAO {
	
	private static final MyLifeCoveredLogger LOGGER = LogFactory.getInstance(QuoteDAOImpl.class);
			
	@Autowired
	private JdbcTemplate jdbcTemplate;

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}
	
	/* (non-Javadoc)
	 * @see com.rga.rgility.dao.QuoteDAO#savequoteDetailsVO(com.rga.rgility.valueobjects.AppliedQuoteVO)
	 */
	@Override
	public void savequoteDetailsVO(AppliedQuoteVO appliedQuoteVO) throws DAOException {
		
		try{
			Object[] args = new Object[] { appliedQuoteVO.getProfileId(),
					appliedQuoteVO.getCoverage(), appliedQuoteVO.getTerm(),
					appliedQuoteVO.getBestPremiumPerMonth(),
					appliedQuoteVO.getStandardPremiumPerMonth(),
					appliedQuoteVO.getSystemInFocus(),
					appliedQuoteVO.getAppliedStatus(),
					new java.sql.Timestamp(new java.util.Date().getTime()),
					"APPLICATION" ,
					appliedQuoteVO.getStandardCoverage()};
			int count = jdbcTemplate.update(
					QueryConstants.INSERT_APPLIED_QUOTEDETAILS, args);
			LOGGER.info("QUOTE DETAILS INSERTED WITH STATUS AS ["+count+"]FOR THE PROFILEID"+appliedQuoteVO.getProfileId());
		}catch(Exception e){
			LOGGER.info("GOT EXCEPTION WHILE INSERTED QUOTE DETAILS FOR THE PROFILEID"+appliedQuoteVO.getProfileId());
			e.printStackTrace();
			throw new DAOException(e.getMessage());
		}
		

	}

}
