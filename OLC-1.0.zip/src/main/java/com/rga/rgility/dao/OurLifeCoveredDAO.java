/**
 * 
 */
package com.rga.rgility.dao;

import java.util.List;

import com.rga.rgility.exception.DAOException;
import com.rga.rgility.model.UserCoverage;
import com.rga.rgility.valueobjects.ChildrenVO;
import com.rga.rgility.valueobjects.DemographicInfoVO;
import com.rga.rgility.valueobjects.PathVO;
import com.rga.rgility.valueobjects.ProfileVO;

/**
 * @author M1030133
 *
 */
public interface OurLifeCoveredDAO {
	public List<PathVO> loadPaths() throws DAOException;

	public ProfileVO saveProfile(ProfileVO profileVO) throws DAOException;

	public DemographicInfoVO saveDemographicInfo(ProfileVO profileVO)
			throws DAOException;

	/**
	 * @param children
	 */
	public void saveChildren(List<ChildrenVO> children) throws DAOException;

	/**
	 * @param profileVO
	 * @return
	 */
	public void updateProfile(ProfileVO profileVO) throws DAOException;
	
	/**
	 * @param DemographicInfoVO
	 * @return
	 */
	public void updateDemographicInfo(ProfileVO profileVO) throws DAOException;

	/**
	 * @param children
	 * @throws DAOException
	 */
	public void deleteChildren(int profileId) throws DAOException;
	
	/**
	 * @param sliderVisit
	 * @throws DAOException
	 */
	public void updateSliderVisitFlag(ProfileVO profileVO,final boolean sliderVisit) throws DAOException;
	
	public List<DemographicInfoVO> getSliderVisitsThreeAttempts();
	
	public List<DemographicInfoVO> getSliderVisitsGrtThreeAttempts();
	
	public void incrementEmailCount(DemographicInfoVO demoVO);
	
	public void updateSliderVisitFlagThruJob(ProfileVO profileVO,final boolean sliderVisit) throws DAOException;
	
	public void saveContactUsDetails(UserCoverage user,ProfileVO userProfileFromSession) throws DAOException;
	
	public int updateUnsubscribeEmail(String email) throws DAOException;
}
