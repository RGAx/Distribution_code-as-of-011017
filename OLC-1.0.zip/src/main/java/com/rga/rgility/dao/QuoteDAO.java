package com.rga.rgility.dao;

import org.springframework.jdbc.core.JdbcTemplate;

import com.rga.rgility.exception.DAOException;
import com.rga.rgility.valueobjects.AppliedQuoteVO;

/**
 * @author M1029563
 *
 */
public interface QuoteDAO {
	
	public void savequoteDetailsVO(AppliedQuoteVO appliedQuoteVO) throws DAOException;
	public void setJdbcTemplate(JdbcTemplate jdbcTemplate);
}
