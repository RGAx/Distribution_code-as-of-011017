package com.rga.rgility.dao;

import com.rga.rgility.exception.DAOException;
import com.rga.rgility.valueobjects.AppliedQuoteVO;

/**
 * @author M1029563
 *
 */
public interface QuoteDAO {
	
	public void savequoteDetailsVO(AppliedQuoteVO appliedQuoteVO) throws DAOException;
}
