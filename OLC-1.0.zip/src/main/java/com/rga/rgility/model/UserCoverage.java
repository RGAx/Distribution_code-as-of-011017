/**
 * 
 */
package com.rga.rgility.model;

import org.springframework.stereotype.Component;

/**
 * @author m1013091
 *
 */
@Component
public class UserCoverage {

	private String quotePhone;
	public String getQuotePhone() {
		return quotePhone;
	}
	public void setQuotePhone(String quotePhone) {
		this.quotePhone = quotePhone;
	}

	private String coverageAmount;
	private String policyTerm;
	private String birthDate;
	private String gender;
	private String smoker;
	private String emailAddress;
	private String state;
	private boolean isUSCitizen = true;
	private boolean isPolicyOwner = true;
	private boolean isReplacementPolicy = true;
	private String providerName;
	private String providerCoveragePerMonth;
	
	private String selectedCoverageAmnt;
	private String selectedPolicyTerm;
	private String selectedCoveragePerMonth;
	
	private String firstName;
	private String lastName;
	private String currentSavings;
	private String currentIncome;
	private String currentLifeInsurance;
	
	private String yearsIncomeProvided;
	private String currentRetirementSavings;
	private String finalExpenses;
	private String outstandingMortgage;
	
	private int childCount;
	private int publicCollegeChildren;
	private int privateCollegeChildren;
	private String outstandingDebt;
	
	private String spouseIncome;
	private String spouseYearsOfWork;
	
	private String selectedPath;
	private String pdfEmailAddress;
	private String noOfYearsToMaintainCoverage;
	private String affordablePremium;
	private String standardCoverageAmnt;
		
	public String getStandardCoverageAmnt() {
		return standardCoverageAmnt;
	}
	public void setStandardCoverageAmnt(String standardCoverageAmnt) {
		this.standardCoverageAmnt = standardCoverageAmnt;
	}
	public String getNoOfYearsToMaintainCoverage() {
		return noOfYearsToMaintainCoverage;
	}
	public void setNoOfYearsToMaintainCoverage(String noOfYearsToMaintainCoverage) {
		this.noOfYearsToMaintainCoverage = noOfYearsToMaintainCoverage;
	}

	//Contact us
	private String email;
	private String phone;
	private String bestTimeToCall;
	private String comments;
	private String name;
	private String cntfirstName;
	private boolean allowMarketing;
	private String annualIncome;
	private String timeZone;
	private String captchaResponse;
	
	public String getAnnualIncome() {
		return annualIncome;
	}
	public void setAnnualIncome(String annualIncome) {
		this.annualIncome = annualIncome;
	}
	public boolean isAllowMarketing() {
		return allowMarketing;
	}
	public void setAllowMarketing(boolean allowMarketing) {
		this.allowMarketing = allowMarketing;
	}
	public String getCntfirstName() {
		return cntfirstName;
	}
	public void setCntfirstName(String cntfirstName) {
		this.cntfirstName = cntfirstName;
	}
	public String getDob() {
		return dob;
	}
	public void setDob(String dob) {
		this.dob = dob;
	}
	public String getCntEmailAddress() {
		return cntEmailAddress;
	}
	public void setCntEmailAddress(String cntEmailAddress) {
		this.cntEmailAddress = cntEmailAddress;
	}
	public String getCntGender() {
		return cntGender;
	}
	public void setCntGender(String cntGender) {
		this.cntGender = cntGender;
	}
	public String getCntState() {
		return cntState;
	}
	public void setCntState(String cntState) {
		this.cntState = cntState;
	}
	public String getUs() {
		return us;
	}
	public void setUs(String us) {
		this.us = us;
	}
	public String getChkPolicyOwner() {
		return chkPolicyOwner;
	}
	public void setChkPolicyOwner(String chkPolicyOwner) {
		this.chkPolicyOwner = chkPolicyOwner;
	}
	public String getReplacement() {
		return replacement;
	}
	public void setReplacement(String replacement) {
		this.replacement = replacement;
	}
	public String getCurrentAnnualIncome() {
		return currentAnnualIncome;
	}
	public void setCurrentAnnualIncome(String currentAnnualIncome) {
		this.currentAnnualIncome = currentAnnualIncome;
	}
	public String getTimeZone() {
		return timeZone;
	}
	public void setTimeZone(String timeZone) {
		this.timeZone = timeZone;
	}
	public String getCaptchaResponse() {
		return captchaResponse;
	}
	public void setCaptchaResponse(String captchaResponse) {
		this.captchaResponse = captchaResponse;
	}

	private String dob;
	private String cntEmailAddress;
	private String Smoker;
	private String cntGender;
	private String cntState;
	private String us;
	private String chkPolicyOwner;
	private String replacement;
	private String currentAnnualIncome;
	
	
	
	/**
	 * @return name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * @return comments
	 */
	public String getComments() {
		return comments;
	}
	/**
	 * @param comments
	 */
	public void setComments(String comments) {
		this.comments = comments;
	}
	/**
	 * @return email.
	 */
	public String getEmail() {
		return email;
	}
	/**
	 * @param email
	 */
	public void setEmail(String email) {
		this.email = email;
	}
	/**
	 * @return phone
	 */
	public String getPhone() {
		return phone;
	}
	/**
	 * @param phone
	 */
	public void setPhone(String phone) {
		this.phone = phone;
	}
	/**
	 * @return bestTimeToCall
	 */
	public String getBestTimeToCall() {
		return bestTimeToCall;
	}
	/**
	 * @param bestTimeToCall
	 */
	public void setBestTimeToCall(String bestTimeToCall) {
		this.bestTimeToCall = bestTimeToCall;
	}
	
	private String bestPremiumPerMonth;
	private String standardPremiumPerMonth;
	
	/**
	 * @return the coverageAmount
	 */
	public String getCoverageAmount() {
		return coverageAmount;
	}
	/**
	 * @param coverageAmount the coverageAmount to set
	 */
	public void setCoverageAmount(String coverageAmount) {
		this.coverageAmount = coverageAmount;
	}
	/**
	 * @return the policyTerm
	 */
	public String getPolicyTerm() {
		return policyTerm;
	}
	/**
	 * @param policyTerm the policyTerm to set
	 */
	public void setPolicyTerm(String policyTerm) {
		this.policyTerm = policyTerm;
	}
	/**
	 * @return the birthDate
	 */
	public String getBirthDate() {
		return birthDate;
	}
	/**
	 * @param birthDate the birthDate to set
	 */
	public void setBirthDate(String birthDate) {
		this.birthDate = birthDate;
	}
	/**
	 * @return the gender
	 */
	public String getGender() {
		return gender;
	}
	/**
	 * @param gender the gender to set
	 */
	public void setGender(String gender) {
		this.gender = gender;
	}
	/**
	 * @return the smoker
	 */
	public String getSmoker() {
		return smoker;
	}
	/**
	 * @param smoker the smoker to set
	 */
	public void setSmoker(String smoker) {
		this.smoker = smoker;
	}
	/**
	 * @return the isUSCitizen
	 */
	public boolean isUSCitizen() {
		return isUSCitizen;
	}
	/**
	 * @param isUSCitizen the isUSCitizen to set
	 */
	public void setUSCitizen(boolean isUSCitizen) {
		this.isUSCitizen = isUSCitizen;
	}
	/**
	 * @return the isPolicyOwner
	 */
	public boolean isPolicyOwner() {
		return isPolicyOwner;
	}
	/**
	 * @param isPolicyOwner the isPolicyOwner to set
	 */
	public void setPolicyOwner(boolean isPolicyOwner) {
		this.isPolicyOwner = isPolicyOwner;
	}
	/**
	 * @return the isReplacementPolicy
	 */
	public boolean isReplacementPolicy() {
		return isReplacementPolicy;
	}
	/**
	 * @param isReplacementPolicy the isReplacementPolicy to set
	 */
	public void setReplacementPolicy(boolean isReplacementPolicy) {
		this.isReplacementPolicy = isReplacementPolicy;
	}
	/**
	 * @return the emailAddress
	 */
	public String getEmailAddress() {
		return emailAddress;
	}
	/**
	 * @param emailAddress the emailAddress to set
	 */
	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}
	/**
	 * @return the state
	 */
	public String getState() {
		return state;
	}
	/**
	 * @param state the state to set
	 */
	public void setState(String state) {
		this.state = state;
	}
	/**
	 * @return the providerName
	 */
	public String getProviderName() {
		return providerName;
	}
	/**
	 * @param providerName the providerName to set
	 */
	public void setProviderName(String providerName) {
		this.providerName = providerName;
	}
	/**
	 * @return the providerCoveragePerMonth
	 */
	public String getProviderCoveragePerMonth() {
		return providerCoveragePerMonth;
	}
	/**
	 * @param providerCoveragePerMonth the providerCoveragePerMonth to set
	 */
	public void setProviderCoveragePerMonth(String providerCoveragePerMonth) {
		this.providerCoveragePerMonth = providerCoveragePerMonth;
	}
	/**
	 * @return the selectedCoverageAmnt
	 */
	public String getSelectedCoverageAmnt() {
		return selectedCoverageAmnt;
	}
	/**
	 * @param selectedCoverageAmnt the selectedCoverageAmnt to set
	 */
	public void setSelectedCoverageAmnt(String selectedCoverageAmnt) {
		this.selectedCoverageAmnt = selectedCoverageAmnt;
	}
	/**
	 * @return the selectedPolicyTerm
	 */
	public String getSelectedPolicyTerm() {
		return selectedPolicyTerm;
	}
	/**
	 * @param selectedPolicyTerm the selectedPolicyTerm to set
	 */
	public void setSelectedPolicyTerm(String selectedPolicyTerm) {
		this.selectedPolicyTerm = selectedPolicyTerm;
	}
	/**
	 * @return the selectedCoveragePerMonth
	 */
	public String getSelectedCoveragePerMonth() {
		return selectedCoveragePerMonth;
	}
	/**
	 * @param selectedCoveragePerMonth the selectedCoveragePerMonth to set
	 */
	public void setSelectedCoveragePerMonth(String selectedCoveragePerMonth) {
		this.selectedCoveragePerMonth = selectedCoveragePerMonth;
	}
	/**
	 * @return the firstName
	 */
	public String getFirstName() {
		return firstName;
	}
	/**
	 * @param firstName the firstName to set
	 */
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	/**
	 * @return the currentSavings
	 */
	public String getCurrentSavings() {
		return currentSavings;
	}
	/**
	 * @param currentSavings the currentSavings to set
	 */
	public void setCurrentSavings(String currentSavings) {
		this.currentSavings = currentSavings;
	}
	/**
	 * @return the currentIncome
	 */
	public String getCurrentIncome() {
		return currentIncome;
	}
	/**
	 * @param currentIncome the currentIncome to set
	 */
	public void setCurrentIncome(String currentIncome) {
		this.currentIncome = currentIncome;
	}
	/**
	 * @return the currentLifeInsurance
	 */
	public String getCurrentLifeInsurance() {
		return currentLifeInsurance;
	}
	/**
	 * @param currentLifeInsurance the currentLifeInsurance to set
	 */
	public void setCurrentLifeInsurance(String currentLifeInsurance) {
		this.currentLifeInsurance = currentLifeInsurance;
	}
	/**
	 * @return the yearsIncomeProvided
	 */
	public String getYearsIncomeProvided() {
		return yearsIncomeProvided;
	}
	/**
	 * @param yearsIncomeProvided the yearsIncomeProvided to set
	 */
	public void setYearsIncomeProvided(String yearsIncomeProvided) {
		this.yearsIncomeProvided = yearsIncomeProvided;
	}
	/**
	 * @return the currentRetirementSavings
	 */
	public String getCurrentRetirementSavings() {
		return currentRetirementSavings;
	}
	/**
	 * @param currentRetirementSavings the currentRetirementSavings to set
	 */
	public void setCurrentRetirementSavings(String currentRetirementSavings) {
		this.currentRetirementSavings = currentRetirementSavings;
	}
	/**
	 * @return the finalExpenses
	 */
	public String getFinalExpenses() {
		return finalExpenses;
	}
	/**
	 * @param finalExpenses the finalExpenses to set
	 */
	public void setFinalExpenses(String finalExpenses) {
		this.finalExpenses = finalExpenses;
	}
	/**
	 * @return the outstandingMortgage
	 */
	public String getOutstandingMortgage() {
		return outstandingMortgage;
	}
	/**
	 * @param outstandingMortgage the outstandingMortgage to set
	 */
	public void setOutstandingMortgage(String outstandingMortgage) {
		this.outstandingMortgage = outstandingMortgage;
	}
	/**
	 * @return the childCount
	 */
	public int getChildCount() {
		return childCount;
	}
	/**
	 * @param childCount the childCount to set
	 */
	public void setChildCount(int childCount) {
		this.childCount = childCount;
	}
	/**
	 * @return the publicCollegeChildren
	 */
	public int getPublicCollegeChildren() {
		return publicCollegeChildren;
	}
	/**
	 * @param publicCollegeChildren the publicCollegeChildren to set
	 */
	public void setPublicCollegeChildren(int publicCollegeChildren) {
		this.publicCollegeChildren = publicCollegeChildren;
	}
	/**
	 * @return the privateCollegeChildren
	 */
	public int getPrivateCollegeChildren() {
		return privateCollegeChildren;
	}
	/**
	 * @param privateCollegeChildren the privateCollegeChildren to set
	 */
	public void setPrivateCollegeChildren(int privateCollegeChildren) {
		this.privateCollegeChildren = privateCollegeChildren;
	}
	/**
	 * @return the outstandingDebt
	 */
	public String getOutstandingDebt() {
		return outstandingDebt;
	}
	/**
	 * @param outstandingDebt the outstandingDebt to set
	 */
	public void setOutstandingDebt(String outstandingDebt) {
		this.outstandingDebt = outstandingDebt;
	}
	/**
	 * @return the spouseIncome
	 */
	public String getSpouseIncome() {
		return spouseIncome;
	}
	/**
	 * @param spouseIncome the spouseIncome to set
	 */
	public void setSpouseIncome(String spouseIncome) {
		this.spouseIncome = spouseIncome;
	}
	/**
	 * @return the spouseYearsOfWork
	 */
	public String getSpouseYearsOfWork() {
		return spouseYearsOfWork;
	}
	/**
	 * @param spouseYearsOfWork the spouseYearsOfWork to set
	 */
	public void setSpouseYearsOfWork(String spouseYearsOfWork) {
		this.spouseYearsOfWork = spouseYearsOfWork;
	}
	/**
	 * @return the selectedPath
	 */
	public String getSelectedPath() {
		return selectedPath;
	}
	/**
	 * @param selectedPath the selectedPath to set
	 */
	public void setSelectedPath(String selectedPath) {
		this.selectedPath = selectedPath;
	}
	/**
	 * @return the pdfEmailAddress
	 */
	public String getPdfEmailAddress() {
		return pdfEmailAddress;
	}
	/**
	 * @param pdfEmailAddress the pdfEmailAddress to set
	 */
	public void setPdfEmailAddress(String pdfEmailAddress) {
		this.pdfEmailAddress = pdfEmailAddress;
	}
	/**
	 * @return the bestPremiumPerMonth
	 */
	public String getBestPremiumPerMonth() {
		return bestPremiumPerMonth;
	}
	/**
	 * @param bestPremiumPerMonth the bestPremiumPerMonth to set
	 */
	public void setBestPremiumPerMonth(String bestPremiumPerMonth) {
		this.bestPremiumPerMonth = bestPremiumPerMonth;
	}

	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	@Override
	public String toString() {
		return "UserCoverage [coverageAmount=" + coverageAmount
				+ ", policyTerm=" + policyTerm + ", birthDate=" + birthDate
				+ ", gender=" + gender + ", smoker=" + smoker
				+ ", emailAddress=" + emailAddress + ", state=" + state
				+ ", isUSCitizen=" + isUSCitizen + ", isPolicyOwner="
				+ isPolicyOwner + ", isReplacementPolicy="
				+ isReplacementPolicy + ", providerName=" + providerName
				+ ", providerCoveragePerMonth=" + providerCoveragePerMonth
				+ ", selectedCoverageAmnt=" + selectedCoverageAmnt
				+ ", selectedPolicyTerm=" + selectedPolicyTerm
				+ ", selectedCoveragePerMonth=" + selectedCoveragePerMonth
				+ ", firstName=" + firstName + ", currentSavings="
				+ currentSavings + ", currentIncome=" + currentIncome
				+ ", currentLifeInsurance=" + currentLifeInsurance
				+ ", yearsIncomeProvided=" + yearsIncomeProvided
				+ ", currentRetirementSavings=" + currentRetirementSavings
				+ ", finalExpenses=" + finalExpenses + ", outstandingMortgage="
				+ outstandingMortgage + ", childCount=" + childCount
				+ ", publicCollegeChildren=" + publicCollegeChildren
				+ ", privateCollegeChildren=" + privateCollegeChildren
				+ ", outstandingDebt=" + outstandingDebt + ", spouseIncome="
				+ spouseIncome + ", spouseYearsOfWork=" + spouseYearsOfWork
				+ ", selectedPath=" + selectedPath + ", pdfEmailAddress="
				+ pdfEmailAddress + ", email=" + email + ", phone=" + phone
				+ ", bestTimeToCall=" + bestTimeToCall + ", comments="
				+ comments + ", name=" + name + ", cntfirstName="
				+ cntfirstName + ", dob=" + dob + ", cntEmailAddress="
				+ cntEmailAddress + ", Smoker=" + Smoker + ", cntGender="
				+ cntGender + ", cntState=" + cntState + ", us=" + us
				+ ", chkPolicyOwner=" + chkPolicyOwner + ", replacement="
				+ replacement + ", currentAnnualIncome=" + currentAnnualIncome
				+ ", bestPremiumPerMonth=" + bestPremiumPerMonth
				+ ", standardPremiumPerMonth=" + standardPremiumPerMonth 
				+ ", affordablePremium=" + affordablePremium 
				+ ", lastName=" + lastName +"]";
	}
	/**
	 * @return the standardPremiumPerMonth
	 */
	public String getStandardPremiumPerMonth() {
		return standardPremiumPerMonth;
	}
	/**
	 * @param standardPremiumPerMonth the standardPremiumPerMonth to set
	 */
	public void setStandardPremiumPerMonth(String standardPremiumPerMonth) {
		this.standardPremiumPerMonth = standardPremiumPerMonth;
	}
	

	public String getAffordablePremium() {
		return affordablePremium;
	}
	public void setAffordablePremium(String affordablePremium) {
		this.affordablePremium = affordablePremium;
	}
	
}
