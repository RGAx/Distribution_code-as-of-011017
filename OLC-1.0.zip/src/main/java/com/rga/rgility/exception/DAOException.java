package com.rga.rgility.exception;

/**
 * 
 * @author M1030133
 *
 */
public class DAOException extends BaseException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@SuppressWarnings("unused")
	private String errorCode = "Unknown_Dao_Exception";

	/**
	 * 
	 */
	public DAOException() {
		super();
	}

	/**
	 * @param message
	 */
	public DAOException(String message) {
		super(message);
	}

	/**
	 * @param message
	 * @param errorCode
	 */
	public DAOException(String message, String errorCode) {
		super(message);
		this.errorCode = errorCode;
	}
}
