/**
 * 
 */
package com.rga.rgility.controller;


import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.google.gson.Gson;
import com.rga.rgility.common.constants.ApplicationConstants;
import com.rga.rgility.common.logger.LogFactory;
import com.rga.rgility.common.logger.MyLifeCoveredLogger;
import com.rga.rgility.service.OurLifeCoveredService;
import com.rga.rgility.valueobjects.ProfileVO;

/**
 * @author M1030133
 * 
 */
@Controller
public class HowMuchDoINeedController {

	private static final MyLifeCoveredLogger LOGGER = LogFactory.getInstance(HowMuchDoINeedController.class);

	@Autowired
	private OurLifeCoveredService ourLifeCoveredService;
	
	@Autowired
	private HttpSession session;
	
	@Autowired
	OurLifeCoveredController ourLifeCoveredController;

	@RequestMapping("life-help.do")
	public String loadLifeHelpPage(Model model) {
		return "life-help";
	}
	
	@RequestMapping("calculator.do")
	public String loadCalculatorPage(Model model) {		
		if (OurLifeCoveredController.icalculateflag == true)
			return "calculator";
		else
			return "quote-form-icalculate-natlang";
	}
	/**
	 * @param profileVO
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/insuranceNeeds.do", method=RequestMethod.POST)
	@ResponseBody
	public String calculateInsuranceNeeds(@ModelAttribute("profileVO")ProfileVO profileVO) throws Exception {
		try {
			LOGGER.debug("inside howmuchdoineed flow");
			ModelAndView model = new ModelAndView("insuranceNeeds");
			profileVO.setPathId(1);
			profileVO = ourLifeCoveredService.calculateInsuranceNeeds(profileVO);
			
			ProfileVO sessionProfile = ourLifeCoveredController.getUserProfileFromSession();
			if(sessionProfile != null) {
				profileVO.setProfileId(sessionProfile.getProfileId());
			}
			profileVO = ourLifeCoveredService.saveProfileAndChild(profileVO);
			session.setAttribute("src", ApplicationConstants.CALCULATE_NEED);
			ourLifeCoveredController.setUserProfileToSession(profileVO);
			model.addObject("profileVO", profileVO);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return new Gson().toJson(profileVO);
	}
	}