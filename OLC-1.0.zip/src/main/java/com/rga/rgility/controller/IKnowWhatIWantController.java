/**
 * 
 */
package com.rga.rgility.controller;


import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.rga.rgility.common.constants.ApplicationConstants;
import com.rga.rgility.common.logger.LogFactory;
import com.rga.rgility.common.logger.MyLifeCoveredLogger;
import com.rga.rgility.model.UserCoverage;
import com.rga.rgility.valueobjects.ProfileVO;

/**
 * @author M1030133
 * 
 */
@Controller
public class IKnowWhatIWantController {

	private static final MyLifeCoveredLogger LOGGER = LogFactory.getInstance(IKnowWhatIWantController.class);
	
	@Autowired
	private HttpSession session;
	
	@Autowired
	OurLifeCoveredController ourLifeCoveredController;
	
	@RequestMapping("quick-iknow-form.do")
	public String loadQuickIKNowPage(Model model) {
		session.setAttribute("src", ApplicationConstants.I_KNOW_WHAT_I_WANT);
		LOGGER.debug("inside iknowwhatiwant flow");
		if (OurLifeCoveredController.iknowflag == true) {
			return "quote-form-iknow";
		} else {
			return "quote-form-iknow-natlang";
		}
	}
	
	@RequestMapping("life-need.do")
	public String loadLifeNeedPage(Model model) {
		return "life-need";
	}
	
	@RequestMapping("quote.do")
	public String loadQuotePage(Model model) {
		session.setAttribute("src", ApplicationConstants.I_KNOW_WHAT_I_WANT);
		return "quote";
	}
	
	@RequestMapping(value="mainQuote.do",method = RequestMethod.POST)
	public ModelAndView mainPageQuotePage(@ModelAttribute("maincoverageform") UserCoverage user,Model model) throws Exception {
		ProfileVO profileVO = new ProfileVO();
		profileVO.setCoverage(Double.parseDouble(user.getCoverageAmount()));
		profileVO.setPathId(1);
		ModelAndView modelView = new ModelAndView("quote");
		session.setAttribute("src", ApplicationConstants.I_KNOW_WHAT_I_WANT);
		ourLifeCoveredController.setUserProfileToSession(profileVO);
		return modelView;
	}
	
	/**
	 * Method for Vanity Dropdown flow.
	 * @param user
	 * @param model
	 * @return String
	 */
	@RequestMapping(value="selectedCoverage.do",method = RequestMethod.POST)
	public ModelAndView saveSelectedCoverage(@ModelAttribute("selectcoverageform") UserCoverage user,Model model) throws Exception {
		ProfileVO profileVO = new ProfileVO();
		profileVO.setCoverage(Double.parseDouble(user.getCoverageAmount()));
		profileVO.setPathId(1);
		String vanityPhoneNo=(String)session.getAttribute("phoneNumber");
		profileVO.setVanityPhoneNo(vanityPhoneNo);
		//ourLifeCoveredService.saveProfile(profileVO);
		ModelAndView modelView = new ModelAndView("quote");
		ourLifeCoveredController.setUserProfileToSession(profileVO);
		return modelView;
	}
}