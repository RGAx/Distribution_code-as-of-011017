/**
 * 
 */
package com.rga.rgility.controller;


import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.net.URL;
import java.text.DecimalFormat;
import java.util.Calendar;
import java.util.Optional;

import javax.servlet.ServletContext;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.Image;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.pdf.PdfContentByte;
import com.itextpdf.text.pdf.PdfGState;
import com.itextpdf.text.pdf.PdfWriter;
import com.rga.rgility.common.constants.ApplicationConstants;
import com.rga.rgility.common.logger.LogFactory;
import com.rga.rgility.common.logger.MyLifeCoveredLogger;
import com.rga.rgility.common.utilities.CaptchaUtils;
import com.rga.rgility.common.utilities.OurLifeCoveredUtils;
import com.rga.rgility.exception.BaseException;
import com.rga.rgility.exception.ServiceException;
import com.rga.rgility.model.UserCoverage;
import com.rga.rgility.service.EmailService;
import com.rga.rgility.service.OurLifeCoveredService;
import com.rga.rgility.service.QuoteService;
import com.rga.rgility.service.RgilityService;
import com.rga.rgility.valueobjects.AppliedQuoteVO;
import com.rga.rgility.valueobjects.DemographicInfoVO;
import com.rga.rgility.valueobjects.ProfileVO;

/**
 * @author M1030133
 * 
 */
@Controller
public class OurLifeCoveredController {
	
	private static final MyLifeCoveredLogger LOGGER = LogFactory.getInstance(OurLifeCoveredController.class);
	
	private static final String CHECKBOX_SELECTED = "1";
	private static final String CHECKBOX_DESELECTED = "0";
	private static final int MIN_AGE = 18;
	private static final int MAX_AGE = 80;
	
	public static boolean  iknowflag, iaffordflag, icalculateflag = true;
	
	@Autowired
	private OurLifeCoveredService ourLifeCoveredService;

	
	@Autowired
	private QuoteService quoteService;
	
	@Autowired
	private EmailService emailService;
	
	@Autowired
	private HttpSession session;
	
	@Autowired
	private RgilityService rgilityService;
	
	@Value("#{'${pdf.font.lato.path}'}")
	private String fontLato;
	
	@Value("#{'${pdf.font.oswald.path}'}")
	private String fontOswald;
	
	@Value("#{'${pdf.background.image.path}'}")
	private String imagePath;

	@RequestMapping("/calculateCoverageNeeds.do")
	@ResponseBody
	public void resetSessionOnEachClick() {
		session.invalidate();
	}
	
	@RequestMapping("home.do")
	public String loadWelcomePage(Model model,@RequestParam(value = "phoneNo", required=true)  String phoneNumber ,@RequestParam("src") String source) {
		
		if (iknowflag == false)
			iknowflag = true;
		else
			iknowflag = false;

		if (iaffordflag == false)
			iaffordflag = true;
		else
			iaffordflag = false;

		if (icalculateflag == false)
			icalculateflag = true;
		else
			icalculateflag = false;
		
		UserCoverage user = new UserCoverage();
		model.addAttribute("userForm", user);
		user.setCoverageAmount("500000");
		user.setPolicyTerm("20");
		session.setAttribute("src", source);
		session.setAttribute("srcHome", source);
		session.setAttribute("phoneNumber", phoneNumber);		
		
		/**Condition for single carrier and multi carrier here*/
		if(source.equalsIgnoreCase("multihome"))
			session.setAttribute("isMultiCarrier", true);
		else if(source.equalsIgnoreCase("home"))
			session.setAttribute("isMultiCarrier", false);
		else
			session.setAttribute("isMultiCarrier", false);
		/**flow redirecting based on the source*/ 
		if (source.equalsIgnoreCase(ApplicationConstants.CALCULATE_NEED))			
			if (icalculateflag == true)
				return "calculator";
			else
				return "quote-form-icalculate-natlang";	
		else if (source.equalsIgnoreCase(ApplicationConstants.AFFORDABILITY))
			return "affordability";
		else if (source.equalsIgnoreCase(ApplicationConstants.I_KNOW_WHAT_I_WANT))			
			if (iknowflag == true)
				return "quote-form-iknow";
			else
				return "quote-form-iknow-natlang";
			
		else if(source.equalsIgnoreCase(ApplicationConstants.MLC_MAIN))
			return "welcome";
		else if(source.equalsIgnoreCase(ApplicationConstants.HOME))
			return "home";
		
		return "home";
	}
		
	@RequestMapping("selectedWorkFlow.do")
	public String loadQuotePages(Model model,@RequestParam("preference") String selectedFlow) {
		if(selectedFlow.equalsIgnoreCase(ApplicationConstants.AFFORDABILITY)) {
			session.setAttribute("src", ApplicationConstants.AFFORDABILITY);
			return "affordability";			
		}
		else if(selectedFlow.equalsIgnoreCase(ApplicationConstants.CALCULATE_NEED)) {
			session.setAttribute("src", ApplicationConstants.CALCULATE_NEED);			
			if (icalculateflag == true)
				return "calculator";
			else
				return "quote-form-icalculate-natlang";	
		}
		else if(selectedFlow.equalsIgnoreCase(ApplicationConstants.I_KNOW_WHAT_I_WANT)) {
			session.setAttribute("src", ApplicationConstants.I_KNOW_WHAT_I_WANT);			
			if (iknowflag == true)
				return "quote-form-iknow";
			else
				return "quote-form-iknow-natlang";	
			
		}
		session.setAttribute("src","home");
		return "home";
	}
	
	@RequestMapping("quizQuestionOne-form.do")
	public String loadQuizQuestionOne(Model model) {
		session.setAttribute("src", ApplicationConstants.I_KNOW_WHAT_I_WANT);		
		if (iknowflag == true)
			return "quote-form-iknow";
		else
			return "quote-form-iknow-natlang";
	}
	
	@RequestMapping("quizQuestionTwo-form.do")
	public String loadQuizQuestionTwo(Model model) {
		session.setAttribute("src", ApplicationConstants.I_KNOW_WHAT_I_WANT);		
		if (iknowflag == true)
			return "quote-form-iknow";
		else
			return "quote-form-iknow-natlang";	
	}
	
	@RequestMapping("quizQuestionThree-form.do")
	public String loadQuizQuestionThree(Model model) {
		session.setAttribute("src", ApplicationConstants.CALCULATE_NEED);		
		if (icalculateflag == true)
			return "calculator";
		else
			return "quote-form-icalculate-natlang";	
	}
	
	@RequestMapping("getQuote-form.do")
	public String loadQuoteLinkPage(Model model) {
		session.setAttribute("src", ApplicationConstants.I_KNOW_WHAT_I_WANT);		
		if (iknowflag == true)
			return "quote-form-iknow";
		else
			return "quote-form-iknow-natlang";	
	}
	
	@RequestMapping("insurance101.do")
	public String loadInsurance101Page(Model model) {
		return "insurance101";
	}
	
	@RequestMapping("quote-singlecarrier.do")
	public String loadSingleCarrierPage(Model model) {
		ProfileVO profileVO = getUserProfileFromSession();
		if(null != profileVO)
			return "quote-singlecarrier";
		
		return "home";
	}
	
	@RequestMapping("quote-multicarrier.do")
	public String loadMulticarrierCarrierPage(Model model) {
		ProfileVO profileVO = getUserProfileFromSession();
		if(null != profileVO)
			return "quote-multicarrier";
		
		return "home";
	}

	/*@RequestMapping("basics.do")
	public String loadBasicsPage(Model model) {
		return "basics";
	}*/
	
	@RequestMapping("misconceptions.do")
	public String loadMisconceptionPage(Model model) {
		return "misconceptions";
	}
	
	@RequestMapping("aboutus.do")
	public String loadAboutusPage(Model model) {
		return "aboutus";
	}
	
	@RequestMapping("privacypolicy.do")
	public String loadPrivacyPolicyPage(Model model) {
		return "privacypolicy";
	}
	
	@RequestMapping("terms.do")
	public String loadTermsPage(Model model) {
		return "terms";
	}
	
	@RequestMapping("legalInformation.do")
	public String loadLegalInformationPage(Model model) {
		return "legalInformation";
	}
	
	@RequestMapping("policyForms.do")
	public String loadPolicyFormsPage(Model model) {
		return "policyForms";
	}
	
	@RequestMapping("financialRatings.do")
	public String loadFinancialRatingsPage(Model model) {
		return "financialRatings";
	}
	/* This method for mlc main determine coverage flow.
	 * this method is use for enter annual income and made coverage as 10 times of annual income.
	 */	
	/*@RequestMapping("calculatorForMain.do")
	public ModelAndView loadCalculatorFromMainPage(@ModelAttribute("mainDetermineCoverageForm") UserCoverage user,Model model) {
		ModelAndView modelView = new ModelAndView("calculatorForMain");
		ProfileVO profileVO = new ProfileVO();
				try {
					profileVO.setPathId(1);
					profileVO.setAnnualIncome(Double.parseDouble(user.getAnnualIncome().replace(",", "")));
					profileVO = ourLifeCoveredService.calculateInsuranceNeeds(profileVO);
					if(profileVO.getAnnualIncome()>0)
						profileVO.setCoverage(OurLifeCoveredUtils.convertToNearestCoverage((int)profileVO.getAnnualIncome()*10));
					
					ProfileVO sessionProfile = this.getUserProfileFromSession();
					if(sessionProfile != null) {
						profileVO.setProfileId(sessionProfile.getProfileId());
					}
					profileVO = ourLifeCoveredService.saveProfileAndChild(profileVO);
					if(profileVO.getCoverage()>2000000) {
						if (profileVO != null) {
							if(profileVO.getCoverage() > 2000000) {
								String msg = "Our calculations indicate that your need is for "+formatAmount(profileVO.getCoverage())+". Our online process offers a maximum coverage amount of $2,000,000. You can contact us to assist you with a larger amounts";
								model.addAttribute("contactusintrotext", msg);			
							} else if (profileVO.getCoverage() > 20 * profileVO.getAnnualIncome()) {
								String msg = "Well this is rare! Your request for coverage exceeds our online processing boundaries. If you would like, you can reduce your coverage request to 16-18x your income and proceed. If you really feel that you need the coverage you requested, please complete this form and we will be in touch shortly to assist you in getting this protection.";
								model.addAttribute("contactusintrotext", msg);
							}
						}	
						modelView = new ModelAndView("contactus");
					}
					session.setAttribute("src", ApplicationConstants.CALCULATE_NEED);
					setUserProfileToSession(profileVO);
					//model.addObject("profileVO", profileVO);
				} catch (Exception e) {
					e.printStackTrace();
				}
		return modelView;
	}*/
	
	@RequestMapping("contactus.do")
	public String loadContactusPage(Model model) {
		return "contactus";
	}
	
	@RequestMapping("loadNYContactus.do")
	public String loadNYContactusPage(Model model) {
		model.addAttribute("contactuscommentstext", "I live in NY and would like to have someone contact me.");
		return "contactus";
	}
	
	@RequestMapping("findPath.do")
	public ModelAndView loadFindPage(Model model) {			
		
		if (session.getAttribute("src").toString().equalsIgnoreCase(ApplicationConstants.CALCULATE_NEED))
			//return new ModelAndView("calculator");
			if (icalculateflag == true)
				return new ModelAndView("calculator");
			else
				return new ModelAndView("quote-form-icalculate-natlang");
		else if (session.getAttribute("src").toString().equalsIgnoreCase(ApplicationConstants.AFFORDABILITY)) {
			return new ModelAndView("quote-form-affordability");
		} else if (session.getAttribute("src").toString().equalsIgnoreCase(ApplicationConstants.I_KNOW_WHAT_I_WANT))			
			if (iknowflag == true)
				return new ModelAndView("quote-form-iknow");
			else
				return new ModelAndView("quote-form-iknow-natlang");

		else if(session.getAttribute("src").toString().equalsIgnoreCase(ApplicationConstants.HOME))
			return new ModelAndView("home");			
		
		if (icalculateflag == true)
			return new ModelAndView("calculator");
		else
			return new ModelAndView("quote-form-icalculate-natlang");
	}
		
	/**
	 * @param profileVO
	 * @return
	 * @throws Exception
	 *//*
	@RequestMapping(value="/main10X.do", method=RequestMethod.POST)
	@ResponseBody
	public String calculateInsuranceNeedsForMain(@ModelAttribute("profileVO")ProfileVO profileVO) throws Exception {
		//ModelAndView model = new ModelAndView("insuranceNeeds");
		try {
			profileVO.setPathId(1);
			profileVO = ourLifeCoveredService.calculateInsuranceNeeds(profileVO);
			if(profileVO.getAnnualIncome()>0)
				profileVO.setCoverage(MyLifeCoveredUtils.convertToNearestCoverage((int)profileVO.getAnnualIncome()*10));
			
			ProfileVO sessionProfile = this.getUserProfileFromSession();
			if(sessionProfile != null) {
				profileVO.setProfileId(sessionProfile.getProfileId());
			}
			profileVO = ourLifeCoveredService.saveProfileAndChild(profileVO);
			
			this.setUserProfileToSession(profileVO);
			//model.addObject("profileVO", profileVO);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "calculatorForMain";
	}
	*/
	
	/**
	 * 
	 * @param unsubscribeMail
	 * @return
	 */
	@RequestMapping("unsubscribe.do")
	public ModelAndView loadUnsubscribePage(@RequestParam("unsubscribeMail") String unsubscribeMail){
		ModelAndView model = new ModelAndView("unsubscribe");
		model.addObject("unsubscribeMail",unsubscribeMail);
		return model;
	}
	
	@RequestMapping("twomillioncontact.do")
	public String load2MContactusPage(Model model) {
		ProfileVO profileVO = getUserProfileFromSession();
		if (profileVO != null) {
			if(profileVO.getCoverage() > 2000000) {
				String msg = "Our calculations indicate that your need is for "+formatAmount(profileVO.getCoverage())+". Our online process offers a maximum coverage amount of $2,000,000. You can contact us to assist you with a larger amounts";
				model.addAttribute("contactusintrotext", msg);			
			} else if (profileVO.getCoverage() > 20 * profileVO.getAnnualIncome()) {
				String msg = "Well this is rare! Your request for coverage exceeds our online processing boundaries. If you would like, you can reduce your coverage request to 16-18x your income and proceed. If you really feel that you need the coverage you requested, please complete this form and we will be in touch shortly to assist you in getting this protection.";
				model.addAttribute("contactusintrotext", msg);
			}
		}		
		return "contactus";
	}
	
	@RequestMapping("noproductsfound.do")
	public String noProductsFoundContactusPage(Model model) {
		String msg = "Here's great news. You definitely have protection needs and we can help you. We cannot do this online. Please complete this form and we will be in touch shortly to assist you in getting the needed coverage";
		model.addAttribute("contactusintrotext", msg);
		return "contactus";
	}
	
	@RequestMapping("affordabledifference.do")
	public String affordableDifferenceContactusPage(Model model) {
		String msg = "Here's great news. You definitely have protection needs and we can help you. We cannot do this online. Please complete this form and we will be in touch shortly to assist you in getting the needed coverage";
		model.addAttribute("contactusintrotext", msg);
		return "contactus";
	}
	
	@RequestMapping(value="/application.do",  method=RequestMethod.POST)
	public String loadApplication(Model model,HttpServletRequest request) {
		ProfileVO profileVO = getUserProfileFromSession();
		
		UserCoverage user = new UserCoverage();
		model.addAttribute("userForm", user);
		
		String pathId = request.getParameter("pathId");
		int path = Integer.parseInt(pathId);
		
		user.setSelectedPath(pathId);
		
		if(!OurLifeCoveredUtils.isEmpty(profileVO)){
			setProfileVOToUserCoverage(profileVO, user);
			
			if(!OurLifeCoveredUtils.isEmpty(profileVO.getDemographicVO())){
				setDemographicInfoVOToUserCoverage(profileVO.getDemographicVO(), user);
			}
		}
		
		if(ApplicationConstants.IDONT_KNOW_PATH_ID == path) {
			
		} else if(ApplicationConstants.IKNOW_PATH_ID == path) {
			
		}
		return "application";
	}

	/**
	 * 
	 * @param request
	 * @throws Exception
	 */
	@RequestMapping(value="sendEmailWithPDF.do", method=RequestMethod.POST)
	public void sendEmailWithPDF(HttpServletRequest request) throws Exception{
		@SuppressWarnings("unused")
		String emailAddress = request.getParameter("emailAddress");
		
		@SuppressWarnings("unused")
		ProfileVO profileVO = getUserProfileFromSession();
		//emailService.sendPdfReport(emailAddress,profileVO);
	}
	
	/**
	 * 
	 * @param user
	 * @param result
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/getQuote.do", method = RequestMethod.POST)
	@ResponseBody
	public String getQuote(
			@ModelAttribute("userForm") UserCoverage user,
			BindingResult result, Model model) {
		ProfileVO profileVO = null;
		Gson gson = new Gson();
		JsonObject jsonObject = new JsonObject();
		try {
			
			if(Integer.parseInt(user.getSelectedPath()) == ApplicationConstants.IKNOW_PATH_ID ){
				profileVO = new ProfileVO();
				setUserCoverageToProfileVO(user,profileVO, 2);
				profileVO.setPathId(Integer.parseInt(user.getSelectedPath()));
			}else if(Integer.parseInt(user.getSelectedPath()) == ApplicationConstants.TWENTY_FIVE_DOLLARS) {
				/*profileVO = new ProfileVO();
				setUserCoverageToProfileVO(user,profileVO, 2);
				profileVO.setCoverage(OurLifeCoveredUtils.convertToNearestCoverage(Integer.parseInt(user.getCoverageAmount())));
				profileVO.setPathId(Integer.parseInt(user.getSelectedPath()));*/
				profileVO = getUserProfileFromSession();
				setUserCoverageToProfileVO(user,profileVO, 1);
			}else{
				profileVO = getUserProfileFromSession();
				setUserCoverageToProfileVO(user,profileVO, 1);
			}
			
			DemographicInfoVO infoVO = setUserCoverageToDemographicInfoVO(user);
			if( null != profileVO.getDemographicVO()) {
				if(profileVO.getDemographicVO().getDemographicInfoId() > 0) {
					infoVO.setDemographicInfoId(profileVO.getDemographicVO().getDemographicInfoId());
				}
			}
			profileVO.setDemographicVO(infoVO);
			profileVO.setVanityPhoneNo((String)session.getAttribute("phoneNumber"));
			
			int startAge = OurLifeCoveredUtils.getStartDateDiffYears(infoVO.getDateOfBirth(), Calendar.getInstance().getTime());
			int endAge = OurLifeCoveredUtils.getEndDateDiffYears(infoVO.getDateOfBirth(), Calendar.getInstance().getTime());
			if(startAge < MIN_AGE){
				jsonObject.addProperty("errorMessage", "You must be at least 18 years of age in order to get a quote.");
			} else if(endAge > MAX_AGE){
				jsonObject.addProperty("errorMessage", "You must be under 80 years old in order to get a quote.");
			} /*else if(profileVO.getCoverage() > 20 * profileVO.getAnnualIncome()){
				jsonObject.addProperty("errorMessage", "You cannot apply online for a coverage amount exceeding 20 times your current income. To apply for this amount, <a href='twomillioncontact.do' class='open-contact-form secondary'>contact us.</a>");
			} */else if(OurLifeCoveredUtils.isEmpty(infoVO.getState())){
				jsonObject.addProperty("errorMessage", "Please select a state.");
			} else{
				profileVO = ourLifeCoveredService.getQuote(profileVO);
				jsonObject.addProperty("profileVO", gson.toJson(profileVO));
				jsonObject.addProperty("errorMessage", "");
				
				if(session.getAttribute("srcHome").toString().equalsIgnoreCase("multihome"))
					jsonObject.addProperty("isMultiCarrier", true);
				else
					jsonObject.addProperty("isMultiCarrier", false);
				session.setAttribute("affordableSmokerDesc", ( (profileVO.getDemographicVO().getSmokerStatus().equalsIgnoreCase("1"))?"Smoker":"Non-Smoker") );
				setUserProfileToSession(profileVO);
				ourLifeCoveredService.updateSliderVisitFlag(profileVO, true);
			}
		} catch (BaseException e) {
			jsonObject.addProperty("errorMessage", "Please try again.");
			e.printStackTrace();
		}
		return gson.toJson(jsonObject);
	}
	
	/**
	 * 
	 * @param user
	 * @param result
	 * @param model
	 * @return
	 */
	@RequestMapping(value = "/getUpdatedQuote.do", method = RequestMethod.POST)
	@ResponseBody
	public String getUpdatedQuote(@ModelAttribute("userForm") UserCoverage user,
			BindingResult result, Model model) {
		Gson gson = new Gson();
		ProfileVO profileVO = null;
		try {
			profileVO = getUserProfileFromSession();
			if(!OurLifeCoveredUtils.isEmpty(user.getSelectedCoverageAmnt())){
				profileVO.setCoverage(Long.parseLong(user.getSelectedCoverageAmnt()));
			}
			if(!OurLifeCoveredUtils.isEmpty(user.getSelectedPolicyTerm())){
				profileVO.setTerm(Integer.parseInt(user.getSelectedPolicyTerm()));
			}
			if(null != user.getSelectedPath()) {
				if(Integer.parseInt(user.getSelectedPath()) == ApplicationConstants.TWENTY_FIVE_DOLLARS){
					profileVO.setAffordablePremium(Integer.parseInt(user.getAffordablePremium()));
				}
			}
			if(profileVO.getPathId() == ApplicationConstants.TWENTY_FIVE_DOLLARS) {
				ProfileVO changedProfileVO = null;
				try {
					changedProfileVO = (ProfileVO) profileVO.clone();
				} catch (CloneNotSupportedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				if (null != changedProfileVO) {
					changedProfileVO.setPathId(1);
					profileVO = ourLifeCoveredService.getPremiumPerMonth(changedProfileVO);
					changedProfileVO = null;
				}
				
			} else {
				profileVO = ourLifeCoveredService.getPremiumPerMonth(profileVO);
			}
			
		} catch (BaseException e) {
			e.printStackTrace();
		}
		return gson.toJson(profileVO.getAppliedQuoteVO());
	}
	
	/**This method is wrapper method for setUserCoverageToProfileVO method*/
	public ProfileVO makeProfileVO(UserCoverage user,ProfileVO profileVO, int pathId) {	
		return setUserCoverageToProfileVO(user,profileVO,pathId);
	}
	
	/**
	 * 
	 * @param user
	 * @param profileVO
	 * @return
	 */
	private ProfileVO setUserCoverageToProfileVO(UserCoverage user,ProfileVO profileVO, int pathId){
		if(!OurLifeCoveredUtils.isEmpty(user.getCoverageAmount())){
			long coverageAmount = Long.parseLong(user.getCoverageAmount());
			if (coverageAmount >= 2000000) {
				profileVO.setCoverage(2000000);
			} else {
				profileVO.setCoverage(Long.parseLong(user.getCoverageAmount()));
			}	
		}
		LOGGER.debug("Term selected: "+user.getNoOfYearsToMaintainCoverage());
		if(!OurLifeCoveredUtils.isEmpty(user.getNoOfYearsToMaintainCoverage())){
			profileVO.setTerm(Integer.parseInt(user.getNoOfYearsToMaintainCoverage()));
		}
		if(!OurLifeCoveredUtils.isEmpty(user.getFirstName())){
			profileVO.setFirstName(user.getFirstName());
		}
		if(!OurLifeCoveredUtils.isEmpty(user.getLastName())){
			profileVO.setLastName(user.getLastName());
		}
		/*if(!MyLifeCoveredUtils.isEmpty(user.getCurrentSavings())){
			profileVO.setOtherSavings(Long.parseLong(user.getCurrentSavings()));
		}*/
		if(pathId == ApplicationConstants.IKNOW_PATH_ID && !OurLifeCoveredUtils.isEmpty(user.getCurrentIncome())){
			profileVO.setAnnualIncome(Long.parseLong(user.getCurrentIncome()));
		}
		/*if(!MyLifeCoveredUtils.isEmpty(user.getYearsIncomeProvided())){
			profileVO.setYearsIncomeProvided(Integer.parseInt(user.getYearsIncomeProvided()));
		}
		if(!MyLifeCoveredUtils.isEmpty(user.getCurrentRetirementSavings())){
			profileVO.setRetirementSavings(Long.parseLong(user.getCurrentRetirementSavings()));
		}
		if(!MyLifeCoveredUtils.isEmpty(user.getFinalExpenses())){
			profileVO.setFinalExpenses(Long.parseLong(user.getFinalExpenses()));
		}
		if(!MyLifeCoveredUtils.isEmpty(user.getOutstandingMortgage())){
			profileVO.setOutstandingMortgage(Integer.parseInt(user.getOutstandingMortgage()));
		}
		if(!MyLifeCoveredUtils.isEmpty(user.getChildCount())){
			profileVO.setChildCount(user.getChildCount());
		}
		if(!MyLifeCoveredUtils.isEmpty(user.getOutstandingDebt())){
			profileVO.setOtherOutstandingDebt(Long.parseLong(user.getOutstandingDebt()));
		}*/
		if(!OurLifeCoveredUtils.isEmpty(user.getAffordablePremium())){
			profileVO.setAffordablePremium(Integer.parseInt(user.getAffordablePremium()));
		}
		return profileVO;
	}
	
	/**
	 * 
	 * @param profileVO
	 * @param user
	 * @return
	 */
	private UserCoverage setProfileVOToUserCoverage(ProfileVO profileVO,UserCoverage user){
		if(!OurLifeCoveredUtils.isZero(profileVO.getCoverage())){
			user.setCoverageAmount(""+(int)profileVO.getCoverage());
		}
		if(!OurLifeCoveredUtils.isZero(profileVO.getTerm())){
			user.setPolicyTerm(""+(int)profileVO.getTerm());
		}
		
		if(!OurLifeCoveredUtils.isEmpty(profileVO.getFirstName())){
			user.setFirstName(profileVO.getFirstName());
		}
		if(!OurLifeCoveredUtils.isEmpty(profileVO.getLastName())){
			user.setFirstName(profileVO.getLastName());
		}
		if(!OurLifeCoveredUtils.isEmpty(profileVO.getAnnualIncome())){
			user.setCurrentIncome(""+(int)profileVO.getAnnualIncome());
		}
		/*if(!MyLifeCoveredUtils.isZero(profileVO.getOtherSavings())){
			user.setCurrentSavings(""+(int)profileVO.getOtherSavings());
		}
		if(!MyLifeCoveredUtils.isZero(profileVO.getYearsIncomeProvided())){
			user.setYearsIncomeProvided(""+(int)profileVO.getYearsIncomeProvided());
		}
		if(!MyLifeCoveredUtils.isZero(profileVO.getRetirementSavings())){
			user.setCurrentRetirementSavings(""+(int)profileVO.getRetirementSavings());
		}
		if(!MyLifeCoveredUtils.isZero(profileVO.getFinalExpenses())){
			user.setFinalExpenses(""+(int)profileVO.getFinalExpenses());
		}
		if(!MyLifeCoveredUtils.isZero(profileVO.getOutstandingMortgage())){
			user.setOutstandingMortgage(""+(int)profileVO.getOutstandingMortgage());
		}
		if(!MyLifeCoveredUtils.isZero(profileVO.getChildCount())){
			user.setChildCount(profileVO.getChildCount());
		}
		if(!MyLifeCoveredUtils.isZero(profileVO.getOtherOutstandingDebt())){
			user.setOutstandingDebt(""+(int)profileVO.getOtherOutstandingDebt());
		}*/
		return user;
	}
	
	/**This method is wrapper method for setUserCoverageToDemographicInfoVO*/
	public DemographicInfoVO makeDemographicInfoVO(UserCoverage user) {
		try {
			return setUserCoverageToDemographicInfoVO(user);
		} catch (BaseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	
	/**
	 * 
	 * @param user
	 * @return
	 * @throws BaseException 
	 */
	private DemographicInfoVO setUserCoverageToDemographicInfoVO(UserCoverage user) throws BaseException{
		DemographicInfoVO infoVO = new DemographicInfoVO();
		if(!OurLifeCoveredUtils.isEmpty(user.getBirthDate())){
			infoVO.setDateOfBirth(OurLifeCoveredUtils.convertStringToDate(ApplicationConstants.DATE_PATTERN, user.getBirthDate()));
		}
		if(!OurLifeCoveredUtils.isEmpty(user.getGender())){
			infoVO.setGender(user.getGender());
		}
		if(!OurLifeCoveredUtils.isEmpty(user.getSmoker())){
			infoVO.setSmokerStatus(user.getSmoker());
		}
		if(!OurLifeCoveredUtils.isEmpty(user.getEmailAddress())){
			infoVO.setEmailAddress(user.getEmailAddress());
		}
		if(!OurLifeCoveredUtils.isEmpty(user.getState())){
			infoVO.setState(user.getState());
		}
		if(user.isUSCitizen()){
			infoVO.setIsUsCitizen(CHECKBOX_SELECTED);
		}else{
			infoVO.setIsUsCitizen(CHECKBOX_DESELECTED);
		}
		
		if(user.isPolicyOwner()){
			infoVO.setIsPolicyOwner(CHECKBOX_SELECTED);
		}else{
			infoVO.setIsPolicyOwner(CHECKBOX_DESELECTED);
		}
		
		if(user.isReplacementPolicy()){
			infoVO.setIsConsentReplacementPolicy(CHECKBOX_SELECTED);
		}else{
			infoVO.setIsConsentReplacementPolicy(CHECKBOX_DESELECTED);
		}
		
		if(user.isAllowMarketing()){
			infoVO.setIsAllowMarketing(CHECKBOX_SELECTED);
		}else{
			infoVO.setIsAllowMarketing(CHECKBOX_DESELECTED);
		}
		
		if(!OurLifeCoveredUtils.isEmpty(user.getQuotePhone())){
			infoVO.setQuotePhone(user.getQuotePhone());
		}
		
		return infoVO;
	}

	/**
	 * 
	 * @param infoVO
	 * @param user
	 * @return
	 */
	private UserCoverage setDemographicInfoVOToUserCoverage(DemographicInfoVO infoVO, UserCoverage user) {
		
		if(!OurLifeCoveredUtils.isEmpty(infoVO.getDateOfBirth())){
			user.setBirthDate(OurLifeCoveredUtils.convertDateToString(ApplicationConstants.DATE_PATTERN, infoVO.getDateOfBirth()));
		}
		if(!OurLifeCoveredUtils.isEmpty(infoVO.getGender())){
			user.setGender(infoVO.getGender());
		}
		if(!OurLifeCoveredUtils.isEmpty(infoVO.getSmokerStatus())){
			user.setSmoker(infoVO.getSmokerStatus());
		}
		if(!OurLifeCoveredUtils.isEmpty(infoVO.getEmailAddress())){
			user.setEmailAddress(infoVO.getEmailAddress());
		}
		if(!OurLifeCoveredUtils.isEmpty(infoVO.getState())){
			user.setState(infoVO.getState());
		}
		if(CHECKBOX_SELECTED.equals(infoVO.getIsUsCitizen())){
			user.setUSCitizen(true);
		}else{
			user.setUSCitizen(false);
		}
		if(CHECKBOX_SELECTED.equals(infoVO.getIsPolicyOwner())){
			user.setPolicyOwner(true);
		}else{
			user.setPolicyOwner(false);
		}
		if(CHECKBOX_SELECTED.equals(infoVO.getIsConsentReplacementPolicy())){
			user.setReplacementPolicy(true);
		}else{
			user.setReplacementPolicy(false);
		}
		return user;
	}
	
	/**
	 * 
	 * @param user
	 * @param model
	 * @return
	 */
	@RequestMapping(value="/applyKnowCoverage.do",method = RequestMethod.POST)
	public @ResponseBody String applyquoteCoverage(@ModelAttribute("userForm") UserCoverage user,Model model){
		
		String response = "";
		try{
			@SuppressWarnings("unused")
			DemographicInfoVO demographicInfoVO = null;
			ProfileVO profileVO = getUserProfileFromSession();
			AppliedQuoteVO appliedQuoteVO = null;
			if(null != profileVO && null != profileVO.getDemographicVO()){
				
				demographicInfoVO = profileVO.getDemographicVO();
				appliedQuoteVO = quoteService.constructAppliedQuoteVO(user);
				
				quoteService.savequoteinfoVO(profileVO,appliedQuoteVO);
				
				/*if((null != demographicInfoVO.getIsUsCitizen() && demographicInfoVO.getIsUsCitizen().equals("1"))
						|| (null != demographicInfoVO.getIsPolicyOwner() && demographicInfoVO.getIsPolicyOwner().equals("1")) 
						|| (null != demographicInfoVO.getIsConsentReplacementPolicy() && demographicInfoVO.getIsConsentReplacementPolicy().equals("1"))){
					try {
						LOGGER.info("Sending Email to StakeHolder with Application details");
						emailService.sendemailtoUser(profileVO,appliedQuoteVO);
						response = "success";
					} catch (Exception e) {
						LOGGER.error("Got an Exception while Triggering email with application details"+e.getMessage());
						//e.printStackTrace();
						response = "failure";
						throw new ServiceException(e.getMessage());
					}
				}else{*/
					LOGGER.info("Consuming the Rgility Webservice ENDPoint URL");
					try{
						String jsonrgilitySource = ourLifeCoveredService.constructRgilityserviceRequest(profileVO, appliedQuoteVO);
						if(null != jsonrgilitySource && !jsonrgilitySource.isEmpty()){
							response = rgilityService.postRgilityRequestJson(jsonrgilitySource);
							ourLifeCoveredService.updateSliderVisitFlag(profileVO, false);
							session.removeAttribute("sessionProfile");
						}
					}catch(Exception e){
						LOGGER.error("Got an Exception while Consuming Rgility Webservice. Sending an email to consumer and Todd. "+e.getMessage());
						//throw new ServiceException(e.getMessage());
						//emailService.sendApplyNowEmail(profileVO,appliedQuoteVO);
					}
				}
			//}
		}catch(ServiceException e){
			LOGGER.error("Got an Exception while Applying Quote and Sending Email or COnsuming webservice"+e.getMessage());			
		}
	
		return response;
	}
	
	/**
	 * Method to send a email to Rgility.
	 * @param user
	 * @param model
	 * @return String
	 */
	@RequestMapping(value="/submitContactInfo.do",method = RequestMethod.POST)
	public @ResponseBody String contactUs(@ModelAttribute("contactForm") UserCoverage user,HttpServletRequest request) throws Exception {
		try {
			
			/*LOGGER.debug("g-recaptcha-response-->"+user.getCaptchaResponse());
			Boolean captchaStatus = CaptchaUtils.verifyCaptcha(user.getCaptchaResponse());
			if(!captchaStatus) {
				return "captchaFailed";
			}*/
			String phoneNumber = (String)session.getAttribute("phoneNumber");
			String src = (String)session.getAttribute("src");
			//Method to save contact us details-yet to implement
			ourLifeCoveredService.saveContactUsDetails(user,getUserProfileFromSession());
			emailService.sendContactUsEmail(user,getUserProfileFromSession(),phoneNumber,src);
			return "success";
		} catch (ServiceException e) {
			LOGGER.error("ERROR while sending email: "+e.getMessage());
			throw new Exception(e.getMessage());
		}
	}
	
	/**
	 * 
	 * @param user
	 * @param redirectAttributes
	 * @return
	 */
	@RequestMapping(value="/emailUnsubscribe.do",method=RequestMethod.POST)
	public String unsubscribeEmail(@ModelAttribute("unsubscribeMail") UserCoverage user,RedirectAttributes redirectAttributes){
		try {
			int count = ourLifeCoveredService.updateUnsubscribeEmail(user.getEmail());
			if (count > 0) {
				redirectAttributes.addFlashAttribute(ApplicationConstants.SUCCESS, "Unsubscribed Successfully!");
				LOGGER.info("EMAIL_ID : "+user.getEmail()+", EMAIL_COUNT is updated Successfully");
			} else {
				LOGGER.error("Email not exist in DB : "+user.getEmail());
				redirectAttributes.addFlashAttribute(ApplicationConstants.FAILED, "Unsubscribde Failed!");
			}
		} catch (ServiceException e) {
			e.printStackTrace();
		}
		return "redirect:unsubscribe.do?unsubscribeMail="+user.getEmail();
	}
		
	@RequestMapping(value="/downloadPdf.do")
	@ResponseBody
	public void downloadPdf(HttpServletRequest request, HttpServletResponse  response) throws Exception {
		 try {
	           
	            // step 1
			 	Rectangle pageSize = new Rectangle(612,792);
			   // pageSize.setBackgroundColor(BaseColor.DARK_GRAY);
				Document document = new Document(pageSize);
				ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
				PdfWriter writer = PdfWriter.getInstance(document, byteArrayOutputStream);
				ServletContext servletContext = request.getSession().getServletContext();
				
				//Registering Fonts for PDF
				String oswaldPath = servletContext.getRealPath(fontOswald);
				FontFactory.register(oswaldPath,"oswald");
				String latoPath = servletContext.getRealPath(fontLato);
				FontFactory.register(latoPath,"lato");
				
	            // step 2
	            if(null != getUserProfileFromSession()){
	            	//emailService.generatePDF(document,writer,getUserProfileFromSession());
	            }
	          //set background image to pdf
				URL url = servletContext.getResource(imagePath);
				//document.open();
				PdfContentByte canvas2 = writer.getDirectContentUnder();
	            Image image = //new ImageIcon(url).getImage();
	            		Image.getInstance(url);
	            image.scaleAbsolute(new Rectangle(792,792));
	            image.setAbsolutePosition(0, 0);
	            canvas2.saveState();
	            PdfGState state = new PdfGState();
	            state.setFillOpacity(1.5f);
	           // canvas2.setGState(state);
	            canvas2.addImage(image);
	            canvas2.restoreState();
	            document.close();
	            response.setHeader("Expires", "0");
	            response.setHeader("Cache-Control","must-revalidate, post-check=0, pre-check=0");
	            response.setHeader("Pragma", "public");
	            response.setContentType("application/pdf");
	            response.addHeader("Content-Disposition", "attachment; filename=InsuranceNeeds.pdf");
	            response.setContentLength(byteArrayOutputStream.size());
	            ServletOutputStream outputStream = response.getOutputStream();
	            byteArrayOutputStream.writeTo(outputStream);
	            outputStream.flush();
	            outputStream.close();
	        }
	        catch(DocumentException e) {
	            throw new IOException(e.getMessage());
	        }catch (Exception e) {
				throw new Exception(e.getMessage());
			}
		 
	    }
	
	/**
	 * 
	 * @return
	 */
	protected ProfileVO getUserProfileFromSession(){
		ProfileVO infoVO = null;
		if(null != session.getAttribute("sessionProfile") && !"".equals(session.getAttribute("sessionProfile"))){
			infoVO = (ProfileVO)session.getAttribute("sessionProfile");
		}	
		return infoVO;
	}

	/**
	 * 
	 * @param infoVO
	 */
	protected void setUserProfileToSession(ProfileVO profileVO){
		session.setAttribute("sessionProfile", profileVO);
	}

	
	/**
	 * Method to return the formatted amount.
	 * @param amount
	 * @return String
	 */
	private static String formatAmount(final double amount) {
		DecimalFormat format = new DecimalFormat("#0,000,000");
		String formattedNumber = format.format(amount);
		return "$"+formattedNumber;
	}

}