/**
 * 
 */
package com.rga.rgility.controller;


import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.rga.rgility.common.constants.ApplicationConstants;
import com.rga.rgility.common.logger.LogFactory;
import com.rga.rgility.common.logger.MyLifeCoveredLogger;
import com.rga.rgility.common.utilities.OurLifeCoveredUtils;
import com.rga.rgility.dao.OurLifeCoveredDAO;
import com.rga.rgility.model.UserCoverage;
import com.rga.rgility.service.OurLifeCoveredService;
import com.rga.rgility.valueobjects.DemographicInfoVO;
import com.rga.rgility.valueobjects.ProfileVO;

/**
 * @author M1030133
 * 
 */
@Controller
public class AffordabilityController {

	private static final MyLifeCoveredLogger LOGGER = LogFactory.getInstance(AffordabilityController.class);
	
	@Autowired
	private HttpSession session;
	
	@Autowired
	private OurLifeCoveredController ourLifeCoveredController;
	
	@Autowired
	private OurLifeCoveredService ourLifeCoveredService;
	
	@Autowired
	private UserCoverage user;
	
	@Autowired
	private OurLifeCoveredDAO ourLifeCoveredDAO;

	@RequestMapping("quote-form-affordability.do")
	public String loadQuoteDemoPage(Model model, @RequestParam("affordablePremium") String affordablePremium,
			@RequestParam("totalCoverage") String coverage, @RequestParam("affordableGender") String gender, @RequestParam("first-name") String firstName, @RequestParam("email-address") String emailAddress, @RequestParam("affordableSmoker") String affordableSmoker ) {
		DemographicInfoVO demographicInfoVO = null;
		ProfileVO profileVO = new ProfileVO();
		try {
			ProfileVO sessionProfile = ourLifeCoveredController.getUserProfileFromSession();
			session.setAttribute("coverage", coverage);
			session.setAttribute("gender", gender);
			session.setAttribute("affordablePremium", affordablePremium);
			session.setAttribute("affordableSmoker", affordableSmoker);
			//session.setAttribute("src", ApplicationConstants.AFFORDABILITY);
			LOGGER.debug("inside affordability flow");
			/*set the values to usercoverage*/
			user.setCoverageAmount(OurLifeCoveredUtils.removeCommasString(coverage, ",", "$"));
			user.setFirstName(firstName);
			user.setGender(gender);
			user.setEmailAddress(emailAddress);
			user.setSelectedPath("3");
			user.setPolicyTerm("10");
			user.setSmoker(affordableSmoker);
			
			/*set the values to profile*/
			profileVO.setCoverage(OurLifeCoveredUtils.removeCommasDouble(coverage, ",", "$"));
			profileVO.setFirstName(firstName);
			profileVO.setPathId(ApplicationConstants.TWENTY_FIVE_DOLLARS);
			profileVO.setTerm(10);
			
			profileVO = ourLifeCoveredController.makeProfileVO(user,profileVO, 2);
			DemographicInfoVO infoVO = ourLifeCoveredController.makeDemographicInfoVO(user);
			infoVO.setFirstName(firstName);
			infoVO.setGender((gender.equalsIgnoreCase("female"))?"F":"M");
			infoVO.setState("");
			infoVO.setSmokerStatus(affordableSmoker);
			
			profileVO.setDemographicVO(infoVO);
			profileVO.setVanityPhoneNo((String)session.getAttribute("phoneNumber"));
			
			if(sessionProfile != null) {
				if(sessionProfile.getPathId() == ApplicationConstants.TWENTY_FIVE_DOLLARS) {
					profileVO.setProfileId(sessionProfile.getProfileId());
					//infoVO.setDemographicInfoId(sessionProfile.getDemographicVO().getDemographicInfoId());
					infoVO = sessionProfile.getDemographicVO();
					infoVO.setEmailAddress(emailAddress);
					infoVO.setFirstName(firstName);
					infoVO.setGender((gender.equalsIgnoreCase("female"))?"F":"M");
					infoVO.setSmokerStatus(affordableSmoker);
					profileVO.setDemographicVO(infoVO);
				}
			}
			
			if(profileVO.getProfileId() <= 0) {
				profileVO = ourLifeCoveredService.saveProfile(profileVO);
				if(profileVO.getDemographicVO()!= null) {
					demographicInfoVO = ourLifeCoveredDAO.saveDemographicInfo(profileVO);
					profileVO.setDemographicVO(demographicInfoVO);
				}
			} else {
				ourLifeCoveredService.updateProfile(profileVO);
				if(profileVO.getDemographicVO()!= null)
					ourLifeCoveredDAO.updateDemographicInfo(profileVO);
			}
			ourLifeCoveredController.setUserProfileToSession(profileVO);
			
		}catch(Exception e) {
			e.printStackTrace();
		}
		if (OurLifeCoveredController.iaffordflag == true) {
			return "quote-form-affordability";
		} else {
			return "quote-form-iafford-natlang";
		}
	}
	
	@RequestMapping("affordability.do")
	public String loadAffordabilityPage(Model model) {
		session.setAttribute("src", ApplicationConstants.AFFORDABILITY);
		return "affordability";
	}
	
	@RequestMapping("quick-affordability-form.do")
	public String loadQuickAffordabilityPage(Model model) {
		session.setAttribute("src", ApplicationConstants.AFFORDABILITY);		
		if (OurLifeCoveredController.iaffordflag == true) {
			return "quote-form-affordability";
		} else {
			return "quote-form-iafford-natlang";
		}
	}
	
	@RequestMapping("life-afford.do")
	public String loadLifeAffordPage(Model model) {
		return "life-afford";
	}

	/*affordability flow to show coverage*/
/*	@RequestMapping("quoteForTwentyFiveDollars.do")
	public String loadQquoteForTwentyFiveDollarsPage(Model model) {
		if(null == session.getAttribute("affordablePremium"))
			session.setAttribute("affordablePremium", 25);
		
		session.setAttribute("src", ApplicationConstants.AFFORDABILITY);
		return "quoteForTwentyFiveDollars";
	}*/
	/*affordability flow to show coverage*/
/*	@RequestMapping("mainPageForTwentyFiveDollars.do")
	public String mainPageQquoteForTwentyFiveDollarsPage(Model model,@RequestParam("affordablePremium") String affordablePremium) {
		if(affordablePremium.equalsIgnoreCase("twentyfive"))
			session.setAttribute("affordablePremium", 25);
		else if(affordablePremium.equalsIgnoreCase("fifty"))
			session.setAttribute("affordablePremium", 50);
		else if(affordablePremium.equalsIgnoreCase("onehundred"))
			session.setAttribute("affordablePremium", 100);
		else
			session.setAttribute("affordablePremium", 25);
		
		session.setAttribute("src", ApplicationConstants.AFFORDABILITY);
		return "quoteForTwentyFiveDollars";
	}*/
	
	/*affordability flow to show monthly premium*/
	@RequestMapping("twentyFiveDollarsToNeedFlow.do")
	public String twentyFiveDollarsToQuoteCoveragePage(Model model,@RequestParam("affordablePremium") String affordablePremium, @RequestParam("totalCoverage") String coverage,@RequestParam("affordableGender") String gender) {
		session.setAttribute("coverage", coverage);
		session.setAttribute("gender", gender);
		session.setAttribute("src", ApplicationConstants.AFFORDABILITY);
		return "quoteForAffordability";
	}
	
	@RequestMapping("twentyFiveDollarsLanding.do")
	public ModelAndView loadTwentyFiveDollarsPage(Model model) {
		return new ModelAndView("welcomeTwentyFiveDollars");
	}
}