/**
 * 
 */
package com.rga.rgility.controller;


import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.rga.rgility.common.constants.ApplicationConstants;
import com.rga.rgility.common.logger.LogFactory;
import com.rga.rgility.common.logger.MyLifeCoveredLogger;

/**
 * @author M1030133
 * 
 */
@Controller
public class AffordabilityController {

	private static final MyLifeCoveredLogger LOGGER = LogFactory.getInstance(AffordabilityController.class);
	
	@Autowired
	private HttpSession session;
	
	@Autowired
	OurLifeCoveredController ourLifeCoveredController;

	@RequestMapping("quote-form-affordability.do")
	public String loadQuoteDemoPage(Model model,@RequestParam("affordablePremium") String affordablePremium, @RequestParam("totalCoverage") String coverage,@RequestParam("affordableGender") String gender) {
		session.setAttribute("coverage", coverage);
		session.setAttribute("gender", gender);
		session.setAttribute("affordablePremium", affordablePremium);
		//session.setAttribute("src", ApplicationConstants.AFFORDABILITY);
		LOGGER.debug("inside affordability flow");
		//return "quote-form-affordability";
		if (OurLifeCoveredController.iaffordflag == true) {
			return "quote-form-affordability";
		} else {
			return "quote-form-iafford-natlang";
		}
	}
	
	@RequestMapping("affordability.do")
	public String loadAffordabilityPage(Model model) {
		session.setAttribute("src", ApplicationConstants.AFFORDABILITY);
		return "affordability";
	}
	
	@RequestMapping("quick-affordability-form.do")
	public String loadQuickAffordabilityPage(Model model) {
		session.setAttribute("src", ApplicationConstants.AFFORDABILITY);		
		if (OurLifeCoveredController.iaffordflag == true) {
			return "quote-form-affordability";
		} else {
			return "quote-form-iafford-natlang";
		}
	}
	
	@RequestMapping("life-afford.do")
	public String loadLifeAffordPage(Model model) {
		return "life-afford";
	}

	/*affordability flow to show coverage*/
/*	@RequestMapping("quoteForTwentyFiveDollars.do")
	public String loadQquoteForTwentyFiveDollarsPage(Model model) {
		if(null == session.getAttribute("affordablePremium"))
			session.setAttribute("affordablePremium", 25);
		
		session.setAttribute("src", ApplicationConstants.AFFORDABILITY);
		return "quoteForTwentyFiveDollars";
	}*/
	/*affordability flow to show coverage*/
/*	@RequestMapping("mainPageForTwentyFiveDollars.do")
	public String mainPageQquoteForTwentyFiveDollarsPage(Model model,@RequestParam("affordablePremium") String affordablePremium) {
		if(affordablePremium.equalsIgnoreCase("twentyfive"))
			session.setAttribute("affordablePremium", 25);
		else if(affordablePremium.equalsIgnoreCase("fifty"))
			session.setAttribute("affordablePremium", 50);
		else if(affordablePremium.equalsIgnoreCase("onehundred"))
			session.setAttribute("affordablePremium", 100);
		else
			session.setAttribute("affordablePremium", 25);
		
		session.setAttribute("src", ApplicationConstants.AFFORDABILITY);
		return "quoteForTwentyFiveDollars";
	}*/
	
	/*affordability flow to show monthly premium*/
	@RequestMapping("twentyFiveDollarsToNeedFlow.do")
	public String twentyFiveDollarsToQuoteCoveragePage(Model model,@RequestParam("affordablePremium") String affordablePremium, @RequestParam("totalCoverage") String coverage,@RequestParam("affordableGender") String gender) {
		session.setAttribute("coverage", coverage);
		session.setAttribute("gender", gender);
		session.setAttribute("src", ApplicationConstants.AFFORDABILITY);
		return "quoteForAffordability";
	}
	
	@RequestMapping("twentyFiveDollarsLanding.do")
	public ModelAndView loadTwentyFiveDollarsPage(Model model) {
		return new ModelAndView("welcomeTwentyFiveDollars");
	}
}