package com.asg.selfservice.junit;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.view;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.mock.web.MockServletContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.asg.selfservice.common.utils.ApplicationConstants;
import com.asg.selfservice.domain.UserProfile;
import com.asg.selfservice.services.GenericService;
import com.asg.selfservice.services.ProfileService;

/**
 * This class is used to Test the Health Controller Functionalities like
 * Saving/Updating details in to DB and retrieving the Details from DB.
 * 
 * @author M1030133
 *
 */

@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@ContextConfiguration("/junit-application-context.xml")
public class HealthControllerTest {

	private MockMvc mockMvc;

	@Autowired
	private WebApplicationContext webappContext;

	@Autowired
	private ProfileService profileService;

	@Autowired
	private GenericService genericService;

	@Autowired
	MockHttpSession session;

	@Autowired
	MockHttpServletRequest request;

	@Autowired
	MockServletContext context;

	private UserProfile userProfile;

	@Before
	public void setup() {
		this.mockMvc = MockMvcBuilders.webAppContextSetup(this.webappContext).build();
	}

	/*
	 * This junit method has been implemented for the HealthController
	 * loadHealthPage method where tobacco page info will be loaded.
	 */
	@Test
	public void loadHealthInfo() throws Exception {
		this.userProfile = profileService.loadUserProfileById(1);
		session.setAttribute(ApplicationConstants.PAGE_FROM, ApplicationConstants.LOGIN);
		mockMvc.perform(
				post("/" + ApplicationConstants.HEALTH).session(session)
						.sessionAttr("sessionUser", userProfile))
				.andExpect(status().isOk())
				.andExpect(view().name(ApplicationConstants.HEALTH));
	}

	/*
	 * This junit method has been implemented for the HealthController
	 * updateHealthInfo method where tobacco page info will be updated to the
	 * DB.
	 */
	@Test
	public void saveUpdateHealthInfo() throws Exception {
		this.userProfile = profileService.loadUserProfileById(1);
		session.setAttribute(ApplicationConstants.PAGE_FROM, ApplicationConstants.HEALTH);
		genericService.loadQuestAnsUIdQSetIdSeqIdMap(userProfile);

		mockMvc.perform(
				post("/" + ApplicationConstants.HEALTH).session(session)
						.sessionAttr("sessionUser", userProfile)
						.param("requestParam", "next").param("healthSeq1", "M")
						.param("healthSeq2", "13/Aug/1988")
						.param("healthSeq3", "Alabama")
						.param("healthSeq11", "5").param("healthSeq12", "6")
						.param("healthSeq5", "84").param("healthSeq6", "1"))
				.andExpect(status().isMovedTemporarily())
				.andExpect(view().name("redirect:" + ApplicationConstants.SMOKING + ".html"));
	}
}
