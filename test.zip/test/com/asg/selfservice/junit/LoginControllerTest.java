package com.asg.selfservice.junit;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.view;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.mock.web.MockServletContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.asg.selfservice.common.utils.ApplicationConstants;
import com.asg.selfservice.services.LoginService;

/**
 * This class is used to Test the Login Controller Functionalities like
 * Login/Forgot Password details in to DB and retrieving the Details from DB.
 * 
 * @author M1030133
 *
 */
@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@ContextConfiguration("/junit-application-context.xml")
public class LoginControllerTest {

	private MockMvc mockMvc;

	@Autowired
	private WebApplicationContext webappContext;

	@Autowired
	private LoginService loginService;
	
	@Autowired
	MockHttpSession session;

	@Autowired
	MockHttpServletRequest request;

	@Autowired
	MockServletContext context;

	@Before
	public void setup() {
		this.mockMvc = MockMvcBuilders.webAppContextSetup(this.webappContext).build();
	}

	/*
	 * This junit method has been implemented to test the LoginController
	 * onUserLogin method where the user passes the username and password for
	 * login and it has been validated from DB and redirected to welcome page on
	 * success.
	 */
	@Test
	public void onUserLogin() throws Exception {
		session.setAttribute("sessionUser", null);
		session.setAttribute(ApplicationConstants.PAGE_FROM, ApplicationConstants.LOGIN);
		mockMvc.perform(
				post("/" + ApplicationConstants.LOGIN).param("login", "login")
						.param("emailAddress", "skumar.techn@gmail.com")
						.param("password", "testing123"))
				.andExpect(status().isMovedTemporarily())
				.andExpect(view().name("redirect:" + ApplicationConstants.HEALTH + ".html"));
	}

	/*
	 * This junit method has been implemented to test the LoginController
	 * onForgotPassword method where username is a required field for user to
	 * complete the forgot password operation. On successful validation of the
	 * username, a mail has to be triggered to the user email id with the
	 * auto-generated password.
	 */
	@Test
	public void onForgotPassword() throws Exception {
		mockMvc.perform(
				post("/forgotPassword").param("forgotPassword",
						"forgotPassword").param("username",
						"skumar.techn@gmail.com"))
				.andExpect(status().isMovedTemporarily())
				.andExpect(view().name("redirect:" + ApplicationConstants.LOGIN + ".html"));
	}
}
