/**
 * 
 */
package com.asg.selfservice.junit;

/*****
 * FamilyControllerTest class is used to Test the FamilyController Functionalities like Saving/Updating details in to DB and retrieving the Details
 * from DB. 
 * @author M1029563
 *
 */

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.view;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.mock.web.MockServletContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.asg.selfservice.common.utils.ApplicationConstants;
import com.asg.selfservice.domain.UserProfile;
import com.asg.selfservice.services.FamilyService;

@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@ContextConfiguration( "/junit-application-context.xml" )

public class FamilyControllerTest {

	private MockMvc mockMvc;

	@Autowired
	private WebApplicationContext webappContext;

	@Autowired
	private FamilyService familyService;

	@Autowired 
	MockHttpSession session;

	@Autowired 
	MockHttpServletRequest request;

	@Autowired
	MockServletContext context;

	@Before
	public void setup() {
		this.mockMvc = MockMvcBuilders.webAppContextSetup(this.webappContext).build();
	}

	/*
	 * This method is used to Test the Save Method service for the Family Controller.
	 * 
	 */
	@Test
	public void savedatatoTable() throws Exception{
		UserProfile userProfile = new UserProfile();

		userProfile.setUserId(1);
		userProfile.setFirstName("Test User");
		session.setAttribute("sessionUser", userProfile);
		
		mockMvc.perform(post("/"+ApplicationConstants.FAMILY).session(session)
				.param("familySeq1", "1")
				.param("familySeq2", "1")
				.param("familySeq3", "0")
				.param("familySeq4", "1")
				.param("familySeq5", "1")
				.param("familySeq6", "1")
				.param("familySeq7", "1")
				.param("familySeq13", "Sister,Brother")
				.param("familySeq14", "94,89")
				.param("familySeq15", "1,0")
				.param("familySeq16", "98")
				.param("action", "save")
				.sessionAttr("userId", userProfile.getUserId())
				)
				.andExpect(status().isMovedTemporarily())
				.andExpect(view().name("redirect:"+ApplicationConstants.CUSTOMERCALLBACK+".html"));
	}

	/*
	 * This method is used to test the functionality of fetching the results from the DB for the Family Controller. 
	 */
	@Test
	public void getdetailsforUser() throws Exception{
		UserProfile userProfile = new UserProfile();
		session.setAttribute(ApplicationConstants.PAGE_FROM, ApplicationConstants.MEDICAL_PROFILE);

		userProfile.setUserId(1);
		userProfile.setFirstName("Test User");

		session.setAttribute("sessionUser", userProfile);
		mockMvc.perform(post("/"+ApplicationConstants.FAMILY).session(session)
				.sessionAttr("userId", userProfile.getUserId()))
				.andExpect(status().isOk())
				.andExpect(view().name(ApplicationConstants.FAMILY));

	}
}
