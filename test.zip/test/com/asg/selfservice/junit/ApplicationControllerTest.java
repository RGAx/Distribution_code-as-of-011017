package com.asg.selfservice.junit;

/**
 * ApplicationControllerTest class is used to test the ApplicationController related functionalities like Saving/Updating and retrieving details from DB
 * @author M1029563
 *
 */
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.view;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.mock.web.MockServletContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.asg.selfservice.common.utils.ApplicationConstants;
import com.asg.selfservice.domain.UserApplicationDetail;
import com.asg.selfservice.domain.UserProfile;


@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@ContextConfiguration( "/junit-application-context.xml" )

public class ApplicationControllerTest {
	
private MockMvc mockMvc;
	
	@Autowired
	private WebApplicationContext webappContext;
	
	@Autowired 
	MockHttpSession session;
	
	@Autowired 
	MockHttpServletRequest request;
	
	@Autowired
	MockServletContext context;
	 
	 @Before
	  public void setup() {
	    this.mockMvc = MockMvcBuilders.webAppContextSetup(this.webappContext).build();
	  }
	 
	 /*
	  * This method is used to test the functionality of SaveUserDetails Method in Application Controller and return Message SUCCESS or FAILURE
	  */
	 @Test
	 public void savedatatoTable() throws Exception{
		 
		UserProfile user = new UserProfile();
	        
	 	user.setUserId(1);
	 	user.setFirstName("Test User");
        session.setAttribute("sessionUser", user);
        
        UserApplicationDetail userApplicationDetail = new UserApplicationDetail();
        
        userApplicationDetail.setCountry("Armenia");
        userApplicationDetail.setState("California");
        userApplicationDetail.setGrossIncome("450000");
        userApplicationDetail.setResidencyStatus("true");
        userApplicationDetail.setReaInsurance("Personal");
        userApplicationDetail.setPrefpaymentPeriod("Yearly Premium");
        userApplicationDetail.setBeneficiaryfullName("Test Beneficiary");
        userApplicationDetail.setBeneficiaryrelShip("Daughter");
        userApplicationDetail.setBeneficiaryPercentage("100");
        
        session.setAttribute("userApplicationDetail", userApplicationDetail);
        
        mockMvc.perform(post("/"+ApplicationConstants.APPLICATION).session(session)
        	.param("country", "Armenia")
        	.param("state", "California")
        	.param("residencyStatus", "true")
        	.param("grossIncome", "450000")
        	.param("reaInsurance","Personal")
        	.param("prefpaymentPeriod", "Yearly Premium")
        	.param("beneficiaryfullName", "Test Beneficiary")
        	.param("beneficiaryrelShip", "Daughter")
        	.param("beneficiaryPercentage", "100")
        	.param("action", "save")
        	.sessionAttr("userId", user.getUserId())

        )
        	.andExpect(status().isMovedTemporarily())
        	.andExpect(view().name("redirect:"+ApplicationConstants.CUSTOMERCALLBACK+".html"));
	 }
	 
	 /*
	  * This method is used to test the functionality of ApplicationPage Method in ApplicationController and return Message SUCCESS or FAILURE 
	  */
	 @Test
	 public void getdetailsforUser() throws Exception{
		 
		UserProfile user = new UserProfile();
		session.setAttribute(ApplicationConstants.PAGE_FROM, ApplicationConstants.QUOTE);
	        
		user.setUserId(1);
		user.setFirstName("Test User");
        session.setAttribute("sessionUser", user);
        
		mockMvc.perform(post("/"+ApplicationConstants.APPLICATION).session(session)
				.sessionAttr("userId", user.getUserId())
				)
				.andExpect(status().isOk())
				.andExpect(view().name(ApplicationConstants.APPLICATION));		 
	 }

}
