package com.asg.selfservice.junit;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.view;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.mock.web.MockServletContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.asg.selfservice.common.utils.ApplicationConstants;
import com.asg.selfservice.domain.UserProfile;
import com.asg.selfservice.services.GenericService;
import com.asg.selfservice.services.ProfileService;

/**
 * This class is used to Test the Smoking Controller Functionalities like
 * Saving/Updating details in to DB and retrieving the Details from DB.
 * 
 * @author M1030133
 *
 */

@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@ContextConfiguration("/junit-application-context.xml")
public class SmokingControllerTest {

	private MockMvc mockMvc;

	@Autowired
	private WebApplicationContext webappContext;

	@Autowired
	private ProfileService profileService;

	@Autowired
	private GenericService genericService;

	@Autowired
	MockHttpSession session;

	@Autowired
	MockHttpServletRequest request;

	@Autowired
	MockServletContext context;

	private UserProfile userProfile;

	@Before
	public void setup() {
		this.mockMvc = MockMvcBuilders.webAppContextSetup(this.webappContext)
				.build();
	}

	/*
	 * This junit method has been implemented for the SmokingController
	 * loadSmokingInfo method where tobacco page info will be loaded.
	 */
	@Test
	public void loadSmokingInfo() throws Exception {
		this.userProfile = profileService.loadUserProfileById(1);
		session.setAttribute(ApplicationConstants.PAGE_FROM, ApplicationConstants.HEALTH);
		mockMvc.perform(
				post("/" + ApplicationConstants.SMOKING).session(session)
						.sessionAttr("sessionUser", userProfile))
				.andExpect(status().isOk())
				.andExpect(view().name(ApplicationConstants.SMOKING));
	}

	/*
	 * This junit method has been implemented for the SmokingController
	 * saveUpdateSmokingInfo method where tobacco page info will be updated to
	 * the DB.
	 */
	@Test
	public void saveUpdateSmokingInfo() throws Exception {
		this.userProfile = profileService.loadUserProfileById(1);

		session.setAttribute(ApplicationConstants.PAGE_FROM, ApplicationConstants.SMOKING);
		genericService.loadQuestAnsUIdQSetIdSeqIdMap(userProfile);

		mockMvc.perform(
				post("/" + ApplicationConstants.SMOKING).session(session)
						.sessionAttr("sessionUser", userProfile)
						.param("requestParam", "next")
						.param("smokingSeq2", "1").param("smokingSeq3", "1")
						.param("smokingSeq4", "1").param("smokingSeq5", "1")
						.param("smokingSeq6", "1").param("smokingSeq7", "1")
						.param("smokingSeq8", "1")
						.param("smokingSeq9", "Jun-2012")
						.param("smokingSeq10", "5")
						.param("smokingSeq11", "Mar-2013")
						.param("smokingSeq12", "8")
						.param("smokingSeq13", "Apr-2011")
						.param("smokingSeq14", "4")
						.param("smokingSeq15", "May-2012")
						.param("smokingSeq16", "5")
						.param("smokingSeq17", "Jun-2014")
						.param("smokingSeq18", "2")
						.param("smokingSeq19", "Jun-2015")
						.param("smokingSeq20", "9"))
				.andExpect(status().isMovedTemporarily())
				.andExpect(view().name("redirect:medicalprofile.html"));
	}
}
