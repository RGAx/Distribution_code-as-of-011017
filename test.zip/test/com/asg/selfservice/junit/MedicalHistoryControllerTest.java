package com.asg.selfservice.junit;

/*****
 * MedicalHistoryControllerTest class is used to Test the Medical History Controller Functionalities like Saving/Updating details in to DB and retrieving the Details
 * from DB. 
 * @author M1029563
 *
 */
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.view;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.mock.web.MockServletContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.asg.selfservice.common.utils.ApplicationConstants;
import com.asg.selfservice.domain.MedicalHistoryAnswer;
import com.asg.selfservice.domain.UserProfile;
import com.asg.selfservice.services.MedicalHistoryService;

@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@ContextConfiguration( "/junit-application-context.xml" )

public class MedicalHistoryControllerTest {

	private MockMvc mockMvc;

	@Autowired
	private WebApplicationContext webappContext;

	@Autowired
	private MedicalHistoryService medicalHistoryService;

	@Autowired 
	MockHttpSession session;

	@Autowired 
	MockHttpServletRequest request;

	@Autowired
	MockServletContext context;

	@Before
	public void setup() {
		this.mockMvc = MockMvcBuilders.webAppContextSetup(this.webappContext).build();
	}

	/*
	 * This method is used to Test the Save Method service for the Medical History Controller.
	 * 
	 */
	@Test
	public void savedatatoTable() throws Exception{
		UserProfile userProfile = new UserProfile();

		userProfile.setUserId(1);
		userProfile.setFirstName("Test User");
		session.setAttribute("sessionUser", userProfile);

		MedicalHistoryAnswer medicalHistoryAnswer = new MedicalHistoryAnswer();

		medicalHistoryAnswer.setCholestrolSeq1("yes");
		medicalHistoryAnswer.setCholestrolSeq2("140");
		medicalHistoryAnswer.setCholestrolSeq3("8.6");
		medicalHistoryAnswer.setCholestrolSeq4("Jan-2015");
		medicalHistoryAnswer.setCholestrolSeq5("Feb-2014");

		medicalHistoryAnswer.setBloodpressureSeq6("yes");
		medicalHistoryAnswer.setBloodpressureSeq7("145");
		medicalHistoryAnswer.setBloodpressureSeq8("90");
		medicalHistoryAnswer.setBloodpressureSeq9("Feb-2015");
		medicalHistoryAnswer.setBloodpressureSeq10("Mar-2014");

		session.setAttribute("MedicalHistoryAnswer",medicalHistoryAnswer);

		mockMvc.perform(post("/"+ApplicationConstants.MEDICAL_PROFILE).session(session)
				.param("cholestrolSeq1", "yes")
				.param("cholestrolSeq2", "140")
				.param("cholestrolSeq3", "140")
				.param("cholestrol.cholestrolanswer4", "8.6")
				.param("cholestrolSeq4", "Jan-2015")
				.param("cholestrolSeq5", "Feb-2014")
				.param("bloodpressureSeq6", "yes")
				.param("bloodpressureSeq7", "145")
				.param("bloodpressureSeq8", "90")
				.param("bloodpressureSeq9", "Feb-2015")
				.param("bloodpressureSeq10", "Mar-2014")
				.param("action", "save")
				.sessionAttr("userId", userProfile.getUserId())
				)
				.andExpect(status().isMovedTemporarily())
				.andExpect(view().name("redirect:"+ApplicationConstants.CUSTOMERCALLBACK+".html"));
	}

	/*
	 * This method is used to test the functionality of fetching the results from the DB for the Medical History Controller. 
	 */
	@Test
	public void getdetailsforUser() throws Exception{
		UserProfile userProfile = new UserProfile();
		session.setAttribute(ApplicationConstants.PAGE_FROM, ApplicationConstants.SMOKING);

		userProfile.setUserId(1);
		userProfile.setFirstName("Test User");

		session.setAttribute("sessionUser", userProfile);
		mockMvc.perform(post("/"+ApplicationConstants.MEDICAL_PROFILE).session(session)
				.sessionAttr("userId", userProfile.getUserId()))
				.andExpect(status().isOk())
				.andExpect(view().name(ApplicationConstants.MEDICAL_PROFILE));

	}

}
