package com.asg.selfservice.junit;


import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.view;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.mock.web.MockServletContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.asg.selfservice.common.utils.ApplicationConstants;
import com.asg.selfservice.domain.MedicalConditionsAnswer;
import com.asg.selfservice.domain.UserProfile;


/**
 * MedicalConditionsPageSecondTest class is used to Test the MedicalConditionsController functionalities like Saving/Updating
 * details in to DB and retrieving details from DB.
 * 
 * @author M1029563
 *
 */
@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@ContextConfiguration( "/junit-application-context.xml" )
public class MedicalConditionsControllerTest {

	private MockMvc mockMvc;

	@Autowired 
	MockHttpSession session;

	@Autowired 
	MockHttpServletRequest request;

	@Autowired
	MockServletContext context;
	@Autowired
	private WebApplicationContext webappContext;


	@Before
	public void setup() {
		this.mockMvc = MockMvcBuilders.webAppContextSetup(this.webappContext).build();
	}

	/*
	 * SaveDataToTable method is used to test the functionality of updateMedicalConditionsInfoPage Method in MedicalconditionsController
	 * where the values will be Saved/Updated in to the DB.
	 * 
	 */
	@Test
	public void savedatatoTable() throws Exception{
		UserProfile userProfile = new UserProfile();

		userProfile.setUserId(1);
		userProfile.setFirstName("Test User");
		
		session.setAttribute("sessionUser", userProfile);

		MedicalConditionsAnswer medCondAns = new MedicalConditionsAnswer();
		
		medCondAns.setConditionsQuestAns1("1");
		medCondAns.setConditionsQuestAns28("1");
		medCondAns.setConditionsQuestAns29("1");
		medCondAns.setConditionsQuestAns31("0");
		medCondAns.setConditionsQuestAns32("Spouse");
		medCondAns.setConditionsQuestAns33("ABC");
		medCondAns.setConditionsQuestAns34("XYZ");
		medCondAns.setConditionsQuestAns35("8971867565");
		medCondAns.setConditionsQuestAns38("1");
		medCondAns.setConditionsQuestAns39("Test Carrier");
		medCondAns.setConditionsQuestAns40("Test Policy");
		
		mockMvc.perform(post("/"+ApplicationConstants.MEDICALCONDITIONS).session(session)
                .param("conditionsQuestAns1","1")
                .param("conditionsQuestAns28","1")
                .param("conditionsQuestAns29","1")
                .param("conditionsQuestAns31","0")
                .param("conditionsQuestAns32","Spouse")
                .param("conditionsQuestAns33","ABC")
                .param("conditionsQuestAns34","XYZ")
                .param("conditionsQuestAns35","8971867565")
                .param("conditionsQuestAns38","1")
                .param("conditionsQuestAns39","Test Carrier")
                .param("conditionsQuestAns40","Test Policy")
                .param("buttonClick", "save")
        )
                .andExpect(status().isMovedTemporarily())
                .andExpect(view().name("redirect:"+ApplicationConstants.CUSTOMERCALLBACK+".html"));
	}
	
	/*
	 * GetDetailsForUser Method is used to test the functionality of loadMedicalConditionsSecondPage Method in MedicalCondtiondController for loading
	 * the page i.e pre-populating the saved details from the DB. 
	 */
	@Test
	public void getdetailsforUser() throws Exception{
		UserProfile userProfile = new UserProfile();
		session.setAttribute(ApplicationConstants.PAGE_FROM, ApplicationConstants.APPLICATION);
        
		userProfile.setUserId(1);
		userProfile.setFirstName("Test User");
        session.setAttribute("sessionUser", userProfile);
		mockMvc.perform(post("/"+ApplicationConstants.MEDICALCONDITIONS).session(session)
				)
				.andExpect(status().isOk())
				.andExpect(view().name(ApplicationConstants.MEDICALCONDITIONS));
				
	}

}
