package com.asg.selfservice.junit;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.view;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.mock.web.MockServletContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.asg.selfservice.common.utils.ApplicationConstants;
import com.asg.selfservice.domain.Prospect;
import com.asg.selfservice.exception.ServiceException;
import com.asg.selfservice.services.ProspectService;

/**
 * 
 */

/**
 * This class is used to Test the Prospect Controller Functionalities like loading prospect details, 
 * inserting into user profile and updating checkboxHits, landingPageHits.
 * @author M1027376
 *
 */

@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@ContextConfiguration( "/junit-application-context.xml" )

public class ProspectControllerTest {

	private MockMvc mockMvc;
	
	@Autowired
	private WebApplicationContext webappContext;
	
	@Autowired
	private ProspectService prosService;
	
	@Autowired 
	 MockHttpSession session;
	 
	@Autowired 
	MockHttpServletRequest request;
	 
	@Autowired
	MockServletContext context;
	
	Prospect prospect;
	
	 @Before
	  public void setup() {
	    this.mockMvc = MockMvcBuilders.webAppContextSetup(this.webappContext).build();
	  }
	  
	 /*
	  * This Junit method has been implemented to test the Get Prospect data service for the Prospect Controller.
	  * 
	  */
	 @Test
	 public void onClickUrl() throws Exception {
		 prospect = new Prospect();
		 prospect.setNavigationPage("landingPage");
		 String encryptedUId = "ABCDEFGH-0123-4567-89IJ-KLMNOPQRSTUV";
		 
		 mockMvc.perform(get("/home").param("userID", encryptedUId))
					.andExpect(status().isOk()).andExpect(view().name("landingPage"));
	 }
	
	 /*
	  * This Junit method has been implemented to test insertion into user profile 
	  * and update the checkboxHits, landingPageHits for the Prospect Controller.
	  */
	@Test
	public void checkbox() throws Exception {
		
		prospect = prosService.getProspectData("ABCDEFGH-0123-4567-89IJ-KLMNOPQRSTUV");
		prospect.setCheckboxHits(0);
		
		mockMvc.perform(
				post("/checkbox")
				.param("encryptedUId", "ABCDEFGH-0123-4567-89IJ-KLMNOPQRSTUV"))
				.andExpect(status().isMovedTemporarily())
				.andExpect(view().name("redirect:"+ApplicationConstants.HEALTH+".html"));
	}
	
}
