package com.asg.selfservice.junit;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.view;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.mock.web.MockServletContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.asg.selfservice.common.utils.ApplicationConstants;
import com.asg.selfservice.domain.UserProfile;
import com.asg.selfservice.services.LoginService;
import com.asg.selfservice.services.ProfileService;

@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@ContextConfiguration("/junit-application-context.xml")
public class ProfileControllerTest {

	private MockMvc mockMvc;

	@Autowired
	private WebApplicationContext webappContext;

	@Autowired
	private LoginService loginService;
	
	@Autowired
	private ProfileService profileService;
	
	@Autowired
	MockHttpSession session;

	@Autowired
	MockHttpServletRequest request;

	@Autowired
	MockServletContext context;

	@Before
	public void setup() {
		this.mockMvc = MockMvcBuilders.webAppContextSetup(this.webappContext).build();
	}
	
	@Test
	public void updateUserProfileInfo() throws Exception {
		UserProfile userProfile = profileService.loadUserProfileById(1);
		session.setAttribute(ApplicationConstants.PAGE_FROM, ApplicationConstants.PROFILE);
		
		mockMvc.perform(
				post("/" + ApplicationConstants.PROFILE).session(session)
						.sessionAttr("sessionUser", userProfile)
						.param("emailAddress", "skumar.techn@gmail.com")
						.param("phoneNumber", "123-234-1234")
						.param("newPassword", ""))
				.andExpect(status().isMovedTemporarily())
				.andExpect(view().name("redirect:" + ApplicationConstants.HEALTH + ".html"));
	}
}
