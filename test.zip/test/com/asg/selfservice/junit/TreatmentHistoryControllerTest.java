/**
 * 
 */
package com.asg.selfservice.junit;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.view;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.mock.web.MockServletContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.asg.selfservice.common.utils.ApplicationConstants;
import com.asg.selfservice.domain.Prospect;
import com.asg.selfservice.domain.UserProfile;
import com.asg.selfservice.services.ProfileService;
import com.asg.selfservice.services.ProspectService;
import com.asg.selfservice.services.TreatmentService;

/**
 * @author M1027376
 *
 */

@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@ContextConfiguration( "/junit-application-context.xml" )

public class TreatmentHistoryControllerTest {

	private MockMvc mockMvc;
	
	@Autowired
	private WebApplicationContext webappContext;
	
	@Autowired
	private TreatmentService treatmentService;
	
	@Autowired
	private ProfileService profileService;
	
	@Autowired 
	 MockHttpSession session;
	 
	@Autowired 
	MockHttpServletRequest request;
	 
	@Autowired
	MockServletContext context;
	
	private UserProfile userProfile;
	
	 @Before
	  public void setup() {
	    this.mockMvc = MockMvcBuilders.webAppContextSetup(this.webappContext).build();
	  }
 
	 /*
	  * This junit method has been implemented for the TreatmentHistoryController loadTreatmentHistInfo method
	  * where treatment history page info will be loaded.
	  */
	 @Test
	 public void loadTreatmentHistInfo() throws Exception {
		this.userProfile = profileService.loadUserProfileById(1);
		context.setAttribute(ApplicationConstants.PAGE_FROM, ApplicationConstants.DRIVING);
		mockMvc.perform(
				post("/"+ApplicationConstants.TREATMENT).session(session)
						.sessionAttr("sessionUser", userProfile))
				.andExpect(status().isOk())
				.andExpect(view().name("treatmentHistory"));
	 	}
	 
	 /*
	  * This junit method has been implemented for the TreatmentHistoryController
	  * saveUpdateTreatmentInfo method where treatment history info will be updated to the DB.
	  */
	 @Test
	 public void saveUpdateTreatmentInfo() throws Exception {
			this.userProfile = profileService.loadUserProfileById(1);
			context.setAttribute(ApplicationConstants.PAGE_FROM, ApplicationConstants.TREATMENT);

			mockMvc.perform(
					post("/"+ApplicationConstants.TREATMENT).session(session)
							.sessionAttr("sessionUser", userProfile)
							.param("requestParam", "save")
							.param("treatmentHistorySeq1", "1")
							.param("treatmentHistorySeq2", "Jan-2010")
							.param("treatmentHistorySeq3", "1")
							.param("treatmentHistorySeq4", "Feb-2010"))
					.andExpect(status().isMovedTemporarily())
					.andExpect(view().name("redirect:"+ApplicationConstants.CUSTOMERCALLBACK+".html"));
		}
	 
	 
	 
}
