/**
 * 
 */
package com.asg.selfservice.junit;

/*****
 * FamilyControllerTest class is used to Test the FamilyController Functionalities like Saving/Updating details in to DB and retrieving the Details
 * from DB. 
 * @author M1029563
 *
 */

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.view;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.mock.web.MockServletContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.asg.selfservice.common.utils.ApplicationConstants;
import com.asg.selfservice.domain.UserProfile;
import com.asg.selfservice.services.FamilyService;

@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@ContextConfiguration( "/junit-application-context.xml" )
public class DrivingControllerTest {
	
	private MockMvc mockMvc;

	@Autowired
	private WebApplicationContext webappContext;

	@Autowired
	private FamilyService drivingService;

	@Autowired 
	MockHttpSession session;

	@Autowired 
	MockHttpServletRequest request;

	@Autowired
	MockServletContext context;

	@Before
	public void setup() {
		this.mockMvc = MockMvcBuilders.webAppContextSetup(this.webappContext).build();
	}

	/*
	 * This method is used to Test the Save Method service for the DrivingHistory Controller.
	 * 
	 */
	@Test
	public void savedatatoTable() throws Exception{
		UserProfile userProfile = new UserProfile();

		userProfile.setUserId(1);
		userProfile.setFirstName("Test User");
		session.setAttribute("sessionUser", userProfile);
		
		mockMvc.perform(post("/"+ApplicationConstants.DRIVING).session(session)
				.param("drivingSeq1", "1")
				.param("drivingSeq2", "1")
				.param("drivingSeq3", "1")
				.param("drivingSeq4", "0")
				.param("drivingSeq5", "0")
				.param("drivingSeq6", "1")
				.param("drivingSeq7", "Jan-2015")
				.param("drivingSeq8", "Feb-2014")
				.param("drivingSeq11", "5")
				.param("drivingSeq12", "4")
				.param("drivingSeq14", "5")
				.param("action", "save")
				.sessionAttr("userId", userProfile.getUserId())
				)
				.andExpect(status().isMovedTemporarily())
				.andExpect(view().name("redirect:"+ApplicationConstants.CUSTOMERCALLBACK+".html"));
	}

	/*
	 * This method is used to test the functionality of fetching the results from the DB for the DrivingHistory Controller. 
	 */
	@Test
	public void getdetailsforUser() throws Exception{
		
		UserProfile userProfile = new UserProfile();
		session.setAttribute(ApplicationConstants.PAGE_FROM, ApplicationConstants.FAMILY);

		userProfile.setUserId(1);
		userProfile.setFirstName("Test User");

		session.setAttribute("sessionUser", userProfile);
		mockMvc.perform(post("/"+ApplicationConstants.DRIVING).session(session)
				.sessionAttr("userId", userProfile.getUserId()))
				.andExpect(status().isOk())
				.andExpect(view().name(ApplicationConstants.DRIVING));

	}
}
