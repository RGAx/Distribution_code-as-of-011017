    
      	

$(document).ready(function()
{
   
	loadDependents();	
	$('#dob').keyup(function() {
	

var pswd = $(this).val();

//validate the length
if ( pswd.length > 0 ) 
{
 $('#dob').css('background','url(resources/images/u135.png)no-repeat 98% 50%');
} else {
    $('#dob').css('background','#fff');
}
});


	$('#gender').change(function() {
	
var gender = $(this).val();


//validate the length
if (( gender=='Male' || gender=='Female' )) 
{

 $('#gender').css('background','url(resources/images/u135.png)no-repeat 98% 50%');
	
} else {
	$('#gender').css('background','url(resources/images/dropdown.png)no-repeat 98% 50%');
}

});





	/*$('#zipcode').keyup(function() {
	

var zipcode = $(this).val();

//validate the length
if ( zipcode.length > 0 ) 
{

 $('#zipcode').css('background','url(resources/images/u135.png)no-repeat 98% 50%');
	
} else {
    $('#zipcode').css('background','#fff');
}

});*/



	$('#annual').keyup(function() {
	

var annual = $(this).val();

//validate the length
if ( annual.length > 0 && annual != "$") 
{

 $('#annual').css('background','url(resources/images/u135.png)no-repeat 98% 50%');
	
} else {
    $('#annual').css('background','#fff');
}

});









	$('#smoke').change(function() {
	
	
var smoke = $(this).val();


//validate the length
if (( smoke=='1' || smoke=='0' )) 
{

 $('#smoke').css('background','url(resources/images/u135.png)no-repeat 98% 50%');
	
} 
else
{
	 $('#smoke').css('background','url(resources/images/dropdown.png)no-repeat 98% 50%');
}

});

function loadDependents() {
		var dependents = $("#dependents").val();


		//validate the length
		if (dependents=='1' ) 
		{
		 $('#dependents').css({'background':'url(resources/images/u135.png) no-repeat 212px 10px', 'width':'240px'});
		 $('.select2').css('width','240px');
		 $('#count').show();
		 
			
		} 
		else if ( dependents=='0' ) 
		{

		 $('#dependents').css({'background':'url(resources/images/u135.png) no-repeat 212px 10px', 'width':'240px'});
		 $('.select2').css('width','240px');
		 $('#count_input').css('background','#fff');
		 $('#count').hide();
		 	
		} 
		else
		{
			$('#dependents').css({'background':'url(resources/images/dropdown.png) no-repeat 98% 50%', 'width':'100%'});
			 $('#count_input').css('background','#fff');
			 $('.select2').css('width','440px');
		    $('#count').hide();
		}
	}


	$('#dependents').change(function() {
		loadDependents();

});



	$('#count_input').keyup(function() {
	

var count_input = $(this).val();

//validate the length
if ( count_input.length > 0 ) 
{

$('#count_input').css({'background':'url(resources/images/u135.png) no-repeat 98% 50%', 'width':'100%'});
	
} else {
    $('#count_input').css('background','#fff');
}
});

$('select#state').on('change',function(){
	
	var state=$('#state').val();
	if(state != null && state != '' && state != "default"){
		$('#state').css({'background':'url(resources/images/u135.png) no-repeat 98% 50%', 'width':'100%'});
	}else{
		$('#state').css({'background':'url(resources/images/dropdown.png) no-repeat 98% 50%', 'width':'100%'});
	}	
});

$('#heart_tips').css('display','none');
	 
	 var mainhgt=$(document).height(); 
	var hgt =$(".content").height();
	var result =mainhgt-hgt;
	var acthgt=result+hgt-60;
	// alert(+acthgt);
	document.getElementById("footer_text").style.top = acthgt+'px';

		
		

	});


