
package com.connbenefits.services;

import com.connbenefits.exception.DAOException;
import com.connbenefits.exception.ServiceException;

/**
 * @author M1029563
 * This is an interface which having the shedulerexcelReportJob method declaration
 */
public interface ScheduleJob {

	public void shedulerexcelReportJob() throws ServiceException, DAOException;
}
