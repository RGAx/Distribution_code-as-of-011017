package com.connbenefits.services;

import com.connbenefits.domain.ProfileQuestion;
import com.connbenefits.domain.UserAnswer;
import com.connbenefits.exception.ServiceException;

/**
 * used for defining the operations such as loading & updating the userAnswer,
 * updating the profile
 * 
 * @author m1033511
 */
public interface QuestionsService {

	public int saveUpdateUserAnswer(ProfileQuestion ProfileQuestion,
			boolean flag) throws ServiceException;

	public UserAnswer loadUserAnswer(int profileId) throws ServiceException;
	public boolean validateFaceValuesWithEBIX(ProfileQuestion profileQuestion) throws ServiceException;
}
