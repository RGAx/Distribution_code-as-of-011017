package com.connbenefits.services.impl;

import java.text.ParseException;
import java.text.SimpleDateFormat;

import org.springframework.stereotype.Service;

import com.connbenefits.common.logger.ExtJourneyLogger;
import com.connbenefits.common.logger.LogFactory;
import com.connbenefits.common.utils.Utils;
import com.connbenefits.constants.ApplicationConstants;
import com.connbenefits.domain.Profile;
import com.connbenefits.domain.rest.BasicInfo;
import com.connbenefits.domain.rest.ContactInfo;
import com.connbenefits.domain.rest.ErrorDetails;
import com.connbenefits.domain.rest.ExtJourney;
import com.connbenefits.domain.rest.IncomeInfo;
import com.connbenefits.domain.rest.UserProfile;
import com.connbenefits.exception.ServiceException;
import com.connbenefits.services.RestService;
import com.connbenefits.validator.EmailValidator;

/**
 * Used for implementing the rest profile operations such as loading/validating
 * the rest profile etc.
 * 
 * @author M1030133
 *
 */
@Service
public class RestServiceImpl implements RestService {

	private static final ExtJourneyLogger LOGGER = LogFactory
			.getInstance(RestService.class);

	/*
	 * Used for loading the rest profile.
	 * 
	 * @see
	 * com.connbenefits.services.RestService#loadRestProfile(com.connbenefits.domain.rest
	 * .ExtJourney)
	 */
	@Override
	public Profile loadRestProfile(ExtJourney extJourney)
			throws ServiceException {
		final long startTime = LOGGER.logMethodEntry();
		Profile profile = null;
		UserProfile userProfile = null;
		try {
			if (extJourney != null)
				userProfile = extJourney.getUserProfile();

			if (userProfile != null) {
				BasicInfo basicInfo = userProfile.getBasicInfo();
				ContactInfo contactInfo = userProfile.getContactInfo();
				IncomeInfo incomeInfo = userProfile.getIncomeInfo();

				profile = new Profile();
				if (basicInfo != null) {
					profile.setFirstName(basicInfo.getFirstName());
					profile.setLastName(basicInfo.getLastName());
					profile.setGender(basicInfo.getGender());
					if (profile.getGender() != null) {
						if ("M".equalsIgnoreCase(profile.getGender())
								|| "male".equalsIgnoreCase(profile.getGender())) {
							profile.setGender("Male");
						} else if ("F".equalsIgnoreCase(profile.getGender())
								|| "female".equalsIgnoreCase(profile
										.getGender())) {
							profile.setGender("Female");
						}
					}
					if (basicInfo.getDateOfBirth() != null
							&& !basicInfo.getDateOfBirth().trim().isEmpty()) {
						profile.setDateOfBirth(Utils.getFormattedDate(basicInfo
								.getDateOfBirth()));
					}
				}
				if (contactInfo != null) {
					profile.setPhoneNumber(contactInfo.getPhoneNumber());
					profile.setZipCode(contactInfo.getZipCode());
					profile.setState(contactInfo.getStateCode());
					profile.setCity(contactInfo.getCity());
					profile.setEmailAddress(contactInfo.getEmailAddress());
				}
				if (incomeInfo != null) {
					profile.setAnnualIncome(incomeInfo.getAnnualIncome());
				}
				profile.setRestProfileId(userProfile.getProfileId());
			}
		} catch (ParseException e) {
			throw new ServiceException(e.getMessage());
		} catch (Exception e) {
			throw new ServiceException(e.getMessage());
		}
		LOGGER.logMethodExit(startTime);
		return profile;
	}

	/*
	 * Used for validating the rest profile.
	 * 
	 * @see
	 * com.connbenefits.services.RestService#validateRestProfile(com.connbenefits.domain
	 * .Profile)
	 */
	@Override
	public ErrorDetails validateRestProfile(Profile profile)
			throws ServiceException {
		final long startTime = LOGGER.logMethodEntry();
		String errorCode = "";
		String errorMessage = "";

		if (profile != null) {
			String firstName = profile.getFirstName();
			String lastName = profile.getLastName();
			String emailAddress = profile.getEmailAddress();
			String phoneNumber = profile.getPhoneNumber();
			
			String zipCode = profile.getZipCode();
			String stateCode = profile.getState();

			if (profile.getRestProfileId() != ApplicationConstants.REST_PROFILE_ID) {
				errorCode = ApplicationConstants.PROFILE_NOT_VALID_CODE;
				errorMessage = ApplicationConstants.PROFILE_NOT_VALID_MESSAGE;

			} else if ((firstName == null || firstName.trim().isEmpty())
					&& (lastName == null || lastName.trim().isEmpty())
					&& (emailAddress == null || emailAddress.trim().isEmpty())
					&& (phoneNumber == null || phoneNumber.trim().isEmpty())
					&& (stateCode == null || stateCode.trim().isEmpty())) {
				errorCode = ApplicationConstants.ALL_MANDATORY_FIELDS_EMPTY_CODE;
				errorMessage = ApplicationConstants.ALL_MANDATORY_FIELDS_EMPTY_MESSAGE;
			
			} else if ((firstName == null || firstName.trim().isEmpty())
					&& (lastName == null || lastName.trim().isEmpty())
					&& (emailAddress == null || emailAddress.trim().isEmpty())
					&& (phoneNumber == null || phoneNumber.trim().isEmpty())) {
				errorCode = ApplicationConstants.FIRSTNAME_LASTNAME_EMAILADDRESS_PHONENUMBER_EMPTY_CODE;
				errorMessage = ApplicationConstants.FIRSTNAME_LASTNAME_EMAILADDRESS_PHONENUMBER_EMPTY_MESSAGE;

			}  else if ((firstName == null || firstName.trim().isEmpty())
					&& (lastName == null || lastName.trim().isEmpty())
					&& (emailAddress == null || emailAddress.trim().isEmpty())
					&& (stateCode == null || stateCode.trim().isEmpty())) {
				errorCode = ApplicationConstants.FIRSTNAME_LASTNAME_EMAILADDRESS_STATECODE_EMPTY_CODE;
				errorMessage = ApplicationConstants.FIRSTNAME_LASTNAME_EMAILADDRESS_STATECODE_EMPTY_MESSAGE;

			}  else if ((firstName == null || firstName.trim().isEmpty())
					&& (lastName == null || lastName.trim().isEmpty())
					&& (stateCode == null || stateCode.trim().isEmpty())
					&& (phoneNumber == null || phoneNumber.trim().isEmpty())) {
				errorCode = ApplicationConstants.FIRSTNAME_LASTNAME_PHONENUMBER_STATECODE_EMPTY_CODE;
				errorMessage = ApplicationConstants.FIRSTNAME_LASTNAME_PHONENUMBER_STATECODE_EMPTY_MESSAGE;

			}  else if ((firstName == null || firstName.trim().isEmpty())
					&& (stateCode == null || stateCode.trim().isEmpty())
					&& (emailAddress == null || emailAddress.trim().isEmpty())
					&& (phoneNumber == null || phoneNumber.trim().isEmpty())) {
				errorCode = ApplicationConstants.FIRSTNAME_EMAILADDRESS_PHONENUMBER_STATECODE_EMPTY_CODE;
				errorMessage = ApplicationConstants.FIRSTNAME_EMAILADDRESS_PHONENUMBER_STATECODE_EMPTY_MESSAGE;

			}  else if ((stateCode == null || stateCode.trim().isEmpty())
					&& (lastName == null || lastName.trim().isEmpty())
					&& (emailAddress == null || emailAddress.trim().isEmpty())
					&& (phoneNumber == null || phoneNumber.trim().isEmpty())) {
				errorCode = ApplicationConstants.LASTNAME_EMAILADDRESS_PHONENUMBER_STATECODE_EMPTY_CODE;
				errorMessage = ApplicationConstants.LASTNAME_EMAILADDRESS_PHONENUMBER_STATECODE_EMPTY_MESSAGE;

			
			} else if ((firstName == null || firstName.trim().isEmpty())
					&& (lastName == null || lastName.trim().isEmpty())
					&& (emailAddress == null || emailAddress.trim().isEmpty())) {
				errorCode = ApplicationConstants.FIRSTNAME_LASTNAME_EMAILADDRESS_EMPTY_CODE;
				errorMessage = ApplicationConstants.FIRSTNAME_LASTNAME_EMAILADDRESS_EMPTY_MESSAGE;

			} else if ((firstName == null || firstName.trim().isEmpty())
					&& (lastName == null || lastName.trim().isEmpty())
					&& (phoneNumber == null || phoneNumber.trim().isEmpty())) {
				errorCode = ApplicationConstants.FIRSTNAME_LASTNAME_PHONENUMBER_EMPTY_CODE;
				errorMessage = ApplicationConstants.FIRSTNAME_LASTNAME_PHONENUMBER_EMPTY_MESSAGE;

			} else if ((firstName == null || firstName.trim().isEmpty())
					&& (lastName == null || lastName.trim().isEmpty())
					&& (stateCode == null || stateCode.trim().isEmpty())) {
				errorCode = ApplicationConstants.FIRSTNAME_LASTNAME_STATECODE_EMPTY_CODE;
				errorMessage = ApplicationConstants.FIRSTNAME_LASTNAME_STATECODE_EMPTY_MESSAGE;

			} else if ((firstName == null || firstName.trim().isEmpty())
					&& (emailAddress == null || emailAddress.trim().isEmpty())
					&& (phoneNumber == null || phoneNumber.trim().isEmpty())) {
				errorCode = ApplicationConstants.FIRSTNAME_EMAILADDRESS_PHONENUMBER_EMPTY_CODE;
				errorMessage = ApplicationConstants.FIRSTNAME_EMAILADDRESS_PHONENUMBER_EMPTY_MESSAGE;

			} else if ((firstName == null || firstName.trim().isEmpty())
					&& (emailAddress == null || emailAddress.trim().isEmpty())
					&& (stateCode == null || stateCode.trim().isEmpty())) {
				errorCode = ApplicationConstants.FIRSTNAME_EMAILADDRESS_STATECODE_EMPTY_CODE;
				errorMessage = ApplicationConstants.FIRSTNAME_EMAILADDRESS_STATECODE_EMPTY_MESSAGE;

			} else if ((firstName == null || firstName.trim().isEmpty())
					&& (phoneNumber == null || phoneNumber.trim().isEmpty())
					&& (stateCode == null || stateCode.trim().isEmpty())) {
				errorCode = ApplicationConstants.FIRSTNAME_PHONENUMBER_STATECODE_EMPTY_CODE;
				errorMessage = ApplicationConstants.FIRSTNAME_PHONENUMBER_STATECODE_EMPTY_MESSAGE;
			
			} else if ((lastName == null || lastName.trim().isEmpty())
					&& (emailAddress == null || emailAddress.trim().isEmpty())
					&& (phoneNumber == null || phoneNumber.trim().isEmpty())) {
				errorCode = ApplicationConstants.LASTNAME_EMAILADDRESS_PHONENUMBER_EMPTY_CODE;
				errorMessage = ApplicationConstants.LASTNAME_EMAILADDRESS_PHONENUMBER_EMPTY_MESSAGE;

			} else if ((lastName == null || lastName.trim().isEmpty())
					&& (emailAddress == null || emailAddress.trim().isEmpty())
					&& (stateCode == null || stateCode.trim().isEmpty())) {
				errorCode = ApplicationConstants.LASTNAME_EMAILADDRESS_STATECODE_EMPTY_CODE;
				errorMessage = ApplicationConstants.LASTNAME_EMAILADDRESS_STATECODE_EMPTY_MESSAGE;

			} else if ((lastName == null || lastName.trim().isEmpty())
					&& (phoneNumber == null || phoneNumber.trim().isEmpty())
					&& (stateCode == null || stateCode.trim().isEmpty())) {
				errorCode = ApplicationConstants.LASTNAME_PHONENUMBER_STATECODE_EMPTY_CODE;
				errorMessage = ApplicationConstants.LASTNAME_PHONENUMBER_STATECODE_EMPTY_MESSAGE;

			} else if ((emailAddress == null || emailAddress.trim().isEmpty())
					&& (phoneNumber == null || phoneNumber.trim().isEmpty())
					&& (stateCode == null || stateCode.trim().isEmpty())) {
				errorCode = ApplicationConstants.EMAILADDRESS_PHONENUMBER_STATECODE_EMPTY_CODE;
				errorMessage = ApplicationConstants.EMAILADDRESS_PHONENUMBER_STATECODE_EMPTY_MESSAGE;

			
			} else if ((firstName == null || firstName.trim().isEmpty())
					&& (lastName == null || lastName.trim().isEmpty())) {
				errorCode = ApplicationConstants.FIRSTNAME_LASTNAME_EMPTY_CODE;
				errorMessage = ApplicationConstants.FIRSTNAME_LASTNAME_EMPTY_MESSAGE;

			} else if ((firstName == null || firstName.trim().isEmpty())
					&& (emailAddress == null || emailAddress.trim().isEmpty())) {
				errorCode = ApplicationConstants.FIRSTNAME_EMAILADDRESS_EMPTY_CODE;
				errorMessage = ApplicationConstants.FIRSTNAME_EMAILADDRESS_EMPTY_MESSAGE;

			} else if ((firstName == null || firstName.trim().isEmpty())
					&& (phoneNumber == null || phoneNumber.trim().isEmpty())) {
				errorCode = ApplicationConstants.FIRSTNAME_PHONENUMBER_EMPTY_CODE;
				errorMessage = ApplicationConstants.FIRSTNAME_PHONENUMBER_EMPTY_MESSAGE;

			} else if ((firstName == null || firstName.trim().isEmpty())
					&& (stateCode == null || stateCode.trim().isEmpty())) {
				errorCode = ApplicationConstants.FIRSTNAME_STATECODE_EMPTY_CODE;
				errorMessage = ApplicationConstants.FIRSTNAME_STATECODE_EMPTY_MESSAGE;

			} else if ((lastName == null || lastName.trim().isEmpty())
					&& (emailAddress == null || emailAddress.trim().isEmpty())) {
				errorCode = ApplicationConstants.LASTNAME_EMAILADDRESS_EMPTY_CODE;
				errorMessage = ApplicationConstants.LASTNAME_EMAILADDRESS_EMPTY_MESSAGE;

			} else if ((lastName == null || lastName.trim().isEmpty())
					&& (phoneNumber == null || phoneNumber.trim().isEmpty())) {
				errorCode = ApplicationConstants.LASTNAME_PHONENUMBER_EMPTY_CODE;
				errorMessage = ApplicationConstants.LASTNAME_PHONENUMBER_EMPTY_MESSAGE;

			} else if ((lastName == null || lastName.trim().isEmpty())
					&& (stateCode == null || stateCode.trim().isEmpty())) {
				errorCode = ApplicationConstants.LASTNAME_STATECODE_EMPTY_CODE;
				errorMessage = ApplicationConstants.LASTNAME_STATECODE_EMPTY_MESSAGE;

			} else if ((emailAddress == null || emailAddress.trim().isEmpty())
					&& (phoneNumber == null || phoneNumber.trim().isEmpty())) {
				errorCode = ApplicationConstants.EMAILADDRESS_PHONENUMBER_EMPTY_CODE;
				errorMessage = ApplicationConstants.EMAILADDRESS_PHONENUMBER_EMPTY_MESSAGE;

			} else if ((emailAddress == null || emailAddress.trim().isEmpty())
					&& (stateCode == null || stateCode.trim().isEmpty())) {
				errorCode = ApplicationConstants.EMAILADDRESS_STATECODE_EMPTY_CODE;
				errorMessage = ApplicationConstants.EMAILADDRESS_STATECODE_EMPTY_MESSAGE;

			} else if ((phoneNumber == null || phoneNumber.trim().isEmpty())
					&& (stateCode == null || stateCode.trim().isEmpty())) {
				errorCode = ApplicationConstants.PHONENUMBER_STATECODE_EMPTY_CODE;
				errorMessage = ApplicationConstants.PHONENUMBER_STATECODE_EMPTY_MESSAGE;

				
			} else if (firstName == null || firstName.trim().isEmpty()) {
				errorCode = ApplicationConstants.FIRST_NAME_EMPTY_CODE;
				errorMessage = ApplicationConstants.FIRST_NAME_EMPTY_MESSAGE;

			} else if (lastName == null || lastName.trim().isEmpty()) {
				errorCode = ApplicationConstants.LAST_NAME_EMPTY_CODE;
				errorMessage = ApplicationConstants.LAST_NAME_EMPTY_MESSAGE;

			} else if (emailAddress == null || emailAddress.trim().isEmpty()) {
				errorCode = ApplicationConstants.EMAIL_EMPTY_CODE;
				errorMessage = ApplicationConstants.EMAIL_EMPTY_MESSAGE;

			} else if (phoneNumber == null || phoneNumber.trim().isEmpty()) {
				errorCode = ApplicationConstants.PHONE_NUMBER_EMPTY_CODE;
				errorMessage = ApplicationConstants.PHONE_NUMBER_EMPTY_MESSAGE;

			} else if (stateCode == null || stateCode.trim().isEmpty()) {
				errorCode = ApplicationConstants.STATE_CODE_EMPTY_CODE;
				errorMessage = ApplicationConstants.STATE_CODE_EMPTY_MESSAGE;

			} else if (!(new EmailValidator().validate(emailAddress))) {
				errorCode = ApplicationConstants.EMAIL_NOT_VALID_CODE;
				errorMessage = ApplicationConstants.EMAIL_NOT_VALID_MESSAGE;

			} else if ("0000000000".equalsIgnoreCase(phoneNumber) || phoneNumber.length() != 10 || !Utils.isNumeric(phoneNumber)) {
				errorCode = ApplicationConstants.PHONE_NUMBER_NOT_VALID_CODE;
				errorMessage = ApplicationConstants.PHONE_NUMBER_NOT_VALID_MESSAGE;

			} else if (zipCode != null && !zipCode.trim().isEmpty()
					&& ("00000".equalsIgnoreCase(zipCode) || !Utils.isNumeric(zipCode) || zipCode.length() != 5)) {
				errorCode = ApplicationConstants.ZIP_CODE_NOT_VALID_CODE;
				errorMessage = ApplicationConstants.ZIP_CODE_NOT_VALID_MESSAGE;

			} else if (profile.getGender() != null
					&& !profile.getGender().trim().isEmpty()
					&& !("Male".equalsIgnoreCase(profile.getGender())
							|| "Female".equalsIgnoreCase(profile.getGender())
							|| "M".equalsIgnoreCase(profile.getGender()) || "F"
								.equalsIgnoreCase(profile.getGender()))) {
				errorCode = ApplicationConstants.GENDER_NOT_VALID_CODE;
				errorMessage = ApplicationConstants.GENDER_NOT_VALID_MESSAGE;

			}
			if (!errorCode.trim().isEmpty() && !errorMessage.trim().isEmpty()) {
				return new ErrorDetails(errorCode, errorMessage);
			} else {
				return null;
			}
		}
		LOGGER.logMethodExit(startTime);
		return null;
	}

	/*
	 * Used for validating the date of birth for the rest profile.
	 * 
	 * @see
	 * com.connbenefits.services.RestService#validateDateOfBirth(com.connbenefits.domain
	 * .rest.ExtJourney)
	 */
	@Override
	public ErrorDetails validateDateOfBirth(ExtJourney extJourney)
			throws ServiceException {
		final long startTime = LOGGER.logMethodEntry();
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		
		boolean validFlag = false;
		if (extJourney != null
				&& extJourney.getUserProfile() != null
				&& extJourney.getUserProfile().getBasicInfo() != null
				&& extJourney.getUserProfile().getBasicInfo().getDateOfBirth() != null) {
			String dob = extJourney.getUserProfile().getBasicInfo()
					.getDateOfBirth();
			if (dob != null && !dob.trim().isEmpty() && dob.split("-") != null
					&& dob.split("-").length > 0 && dob.split("-")[0] != null
					&& !dob.split("-")[0].trim().isEmpty()) {
				int yearLength = dob.split("-")[0].length();
				if (yearLength != 4) {
					validFlag = true;
				}
			}
			try {
				dateFormat.setLenient(false);
				if(dob != null)
					dateFormat.parse(dob);
			} catch (ParseException e) {
				validFlag = true;
			}
		}
		if (validFlag) {
			return new ErrorDetails(ApplicationConstants.DOB_NOT_VALID_CODE,
					ApplicationConstants.DOB_NOT_VALID_MESSAGE);
		}
		LOGGER.logMethodExit(startTime);
		return null;
	}
}
