/**
 * 
 */
package com.connbenefits.services.impl;

import java.util.List;

import javax.servlet.ServletContext;

import org.springframework.beans.factory.annotation.Autowired;

import com.connbenefits.common.logger.ExtJourneyLogger;
import com.connbenefits.common.logger.LogFactory;
import com.connbenefits.dao.GenericDAO;
import com.connbenefits.domain.MultiplierRateDetails;
import com.connbenefits.exception.DAOException;
import com.connbenefits.exception.ServiceException;
import com.connbenefits.services.GenericService;

/**
 * @author M1029563
 *
 */
public class GenericServiceImpl implements GenericService{

	private static final ExtJourneyLogger logger = LogFactory.getInstance(GenericServiceImpl.class);
	
	@Autowired
	private GenericDAO genericDao;
	
	@Autowired
	private ServletContext  context;
	
	/* This method is used to load Multiplierrate details from the Table MULTIPLIERRATE TABLE once and place that value in the context
	 * attribute.
	 * @returns contextMultiplierrateList;
	 * @see com.connbenefits.services.GenericService#loadMultiplierrateList()
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<MultiplierRateDetails> loadMultiplierrateList() throws ServiceException{
		final long startTime = logger.logMethodEntry();
		List<MultiplierRateDetails> contextMultiplierrateList = null;
		try{
			if(context.getAttribute("contextMultiplierratedata") != null){
				contextMultiplierrateList = (List<MultiplierRateDetails>) context.getAttribute("contextMultiplierratedata");
			}
			else{
				contextMultiplierrateList = genericDao.loadMultiplierrateDetails();
				context.setAttribute("contextMultiplierratedata",contextMultiplierrateList);
			}
			logger.logMethodExit(startTime);
			
			return contextMultiplierrateList;
		}catch(DAOException e){
			logger.error("ERROR : "+ e.getMessage());
			throw new ServiceException(e.getMessage());
		}		
		
	}

}
