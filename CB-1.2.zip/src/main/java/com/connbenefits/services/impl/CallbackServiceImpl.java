package com.connbenefits.services.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.servlet.ModelAndView;

import com.connbenefits.dao.CallbackDAO;
import com.connbenefits.domain.CustomerCallback;
import com.connbenefits.domain.Profile;
import com.connbenefits.domain.ProfileCustomerCallback;
import com.connbenefits.exception.DAOException;
import com.connbenefits.exception.ServiceException;
import com.connbenefits.services.CallbackService;

/**
 * used for implementing the services like saving the profileCustomerCallback 
 * 
 * @author m1033511
 */
@Service
public class CallbackServiceImpl implements CallbackService {

	@Autowired
	private CallbackDAO callbackDao;
	/*
	 * used for saving the profileCustomerCallback in database
	 * 
	 * @see
	 * com.connbenefits.services.CallbackService#saveCallbackDetails(com.connbenefits
	 * .domain.ProfileCustomerCallback)
	 */
	@Override
	public int saveCallbackDetails(ProfileCustomerCallback profileCustomerCallback,Profile profile)	throws ServiceException {
		
		try{
			return callbackDao.saveCallbackDetails(profileCustomerCallback,profile);
		}catch(DAOException e){
			throw new ServiceException(e.getMessage());
		}
	}

	/*
     *used for adding profile customerCallback to model and loading times in callbackPage
     *
     */
	@Override
	public ModelAndView loadCallbackPage(ModelAndView model, Profile profile)
			throws ServiceException {
		CustomerCallback customerCallback = new CustomerCallback();
		
		//customerCallback.setPhoneNumber(String.valueOf(profile.getPhoneNumber()));
		model.addObject("sessionProfile",profile);
		model.addObject("customerCallback",customerCallback);
		model.addObject("callbackTimes", this.loadCallbackTimes());
		return model;
	}

	/*used for loading the time in callbackPage
	 *
	 */
	private List<String> loadCallbackTimes() {
		List<String> callbackTimes = new ArrayList<String>();
		callbackTimes.add("09.00 am - 09.30 am (EST)");
		callbackTimes.add("09.30 am - 10.00 am (EST)");
		callbackTimes.add("10.00 am - 10.30 am (EST)");
		callbackTimes.add("10.30 am - 11.00 am (EST)");
		callbackTimes.add("11.00 am - 11.30 am (EST)");
		callbackTimes.add("11.30 am - 12.00 pm (EST)");
		callbackTimes.add("12.00 pm - 12.30 pm (EST)");
		callbackTimes.add("12.30 pm - 01.00 pm (EST)");
		callbackTimes.add("01.00 pm - 01.30 pm (EST)");
		callbackTimes.add("01.30 pm - 02.00 pm (EST)");
		callbackTimes.add("02.00 pm - 02.30 pm (EST)");
		callbackTimes.add("02.30 pm - 03.00 pm (EST)");
		callbackTimes.add("03.00 pm - 03.30 pm (EST)");
		callbackTimes.add("03.30 pm - 04.00 pm (EST)");
		callbackTimes.add("04.00 pm - 04.30 pm (EST)");
		callbackTimes.add("04.30 pm - 05.00 pm (EST)");
		callbackTimes.add("05.00 pm - 05.30 pm (EST)");
		callbackTimes.add("05.30 pm - 06.00 pm (EST)");
		callbackTimes.add("06.00 pm - 06.30 pm (EST)");
		callbackTimes.add("06.30 pm - 07.00 pm (EST)");
		callbackTimes.add("07.00 pm - 07.30 pm (EST)");
		callbackTimes.add("07.30 pm - 08.00 pm (EST)");
		callbackTimes.add("08.00 pm - 08.30 pm (EST)");
		callbackTimes.add("08.30 pm - 09.00 pm (EST)");
		
		return callbackTimes;
	}
}
