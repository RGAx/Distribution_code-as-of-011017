package com.connbenefits.services;

import com.connbenefits.domain.CustomerCallback;
import com.connbenefits.domain.Profile;
import com.connbenefits.exception.ServiceException;

/**
 * Used for email communication.
 * 
 * @author M1030133
 *
 */
public interface EmailService {
	public void sendMail(String from, String to, String subject, String msg)
			throws ServiceException;

	public void sendCallbackMail(Profile profile,
			CustomerCallback customerCallback) throws ServiceException;
	
	public void sendConfirmationEmailWithAttachment(int noOfRecords) throws ServiceException;
	
	public void sendConfirmationEmailWithoutAttachment() throws ServiceException;
}
