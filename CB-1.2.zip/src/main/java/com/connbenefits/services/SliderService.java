package com.connbenefits.services;

import java.util.List;

import com.connbenefits.domain.SliderFaceValue;
import com.connbenefits.exception.ServiceException;

/**
 * @author M1029563
 * This class is used as a service Layer implementation for SliderPage
 *
 */
public interface SliderService {
	
	public List<Integer> loadSliderFaceValues(int idealMinFaceValue, int idealMaxFaceValue, int recommendedFaceVale, int scaleUnit);
	
	public SliderFaceValue loadSliderPage() throws ServiceException;
}
