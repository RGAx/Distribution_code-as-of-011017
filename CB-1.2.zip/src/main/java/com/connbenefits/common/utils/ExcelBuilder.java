package com.connbenefits.common.utils;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.ParseException;
import java.util.Date;
import java.util.List;

import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.connbenefits.common.logger.ExtJourneyLogger;
import com.connbenefits.common.logger.LogFactory;
import com.connbenefits.domain.ExcelReport;


/**
 * @author M1029563
 * This class is used to generate an excel sheet and write it to a Folder in the Server Path
 */
@Component("excelbuild")
public class ExcelBuilder {

	private static final ExtJourneyLogger LOGGER = LogFactory.getInstance(ExcelBuilder.class);

	@Value("#{'${cb.ext.journey.folderpath}'}")
	private String folderPath;
	
	/*
	 * This method is used to generate excel document with List<ExcelReport> userreportDetails.
	 */
	public void buildExcelDocument(List<ExcelReport> userreportDetails){
		
		String date="";
		try {
			date = Utils.getyesterdaysDate(new Date());
		} catch (ParseException pe) {
			LOGGER.error("ERROR:"+pe.getMessage());
		}
		String excelName = "ConnectedBenefits_DATA_REPORT_"+date;
		
		HSSFWorkbook workbook = new HSSFWorkbook();
		HSSFSheet sheet = workbook.createSheet("ConnectedBenefits_DATA_REPORT");
		sheet.setDefaultColumnWidth(30);
		
		// create style for header cells
		CellStyle style = workbook.createCellStyle();
		Font font = workbook.createFont();
		font.setFontName(HSSFFont.FONT_ARIAL);
		style.setFont(font);
		
		HSSFRow header = sheet.createRow(0);
		header.createCell(0).setCellValue("S.NO");
		header.getCell(0).setCellStyle(style);
		
		header.createCell(1).setCellValue("SOURCE");
		header.getCell(1).setCellStyle(style);
		
		header.createCell(2).setCellValue("FIRST_NAME");
		header.getCell(2).setCellStyle(style);
		
		header.createCell(3).setCellValue("LAST_NAME");
		header.getCell(3).setCellStyle(style);
		
		header.createCell(4).setCellValue("EMAIL_ADDRESS");
		header.getCell(4).setCellStyle(style);
		
		header.createCell(5).setCellValue("PHONE_NUMBER");
		header.getCell(5).setCellStyle(style);
		
		header.createCell(6).setCellValue("DOB");
		header.getCell(6).setCellStyle(style);
		
		header.createCell(7).setCellValue("GENDER");
		header.getCell(7).setCellStyle(style);
		
		header.createCell(8).setCellValue("STATE");
		header.getCell(8).setCellStyle(style);
		
		header.createCell(9).setCellValue("ANNUAL_INCOME");
		header.getCell(9).setCellStyle(style);
		
		header.createCell(10).setCellValue("SMOKING_STATUS");
		header.getCell(10).setCellStyle(style);
		
		header.createCell(11).setCellValue("DEPENDENTS_FLAG");
		header.getCell(11).setCellStyle(style);
		
		header.createCell(12).setCellValue("DEPENDENTS_COUNT");
		header.getCell(12).setCellStyle(style);
		
		header.createCell(13).setCellValue("HEALTH_STATUS");
		header.getCell(13).setCellStyle(style);		
		
		header.createCell(14).setCellValue("COVERAGE");
		header.getCell(14).setCellStyle(style);
		
		header.createCell(15).setCellValue("TERM");
		header.getCell(15).setCellStyle(style);
		
		header.createCell(16).setCellValue("EBIX_MONTHLY_ESTIMATE");
		header.getCell(16).setCellStyle(style);
		
		header.createCell(17).setCellValue("PINNEY_SUBMISSION_DATE");
		header.getCell(17).setCellStyle(style);
		
		header.createCell(18).setCellValue("CALLBACK_DATE");
		header.getCell(18).setCellStyle(style);
		
		header.createCell(19).setCellValue("CALLBACK_TIME");
		header.getCell(19).setCellStyle(style);
		
		// create data rows
		int rowCount = 1;
		int rowNum = 1;
		for(ExcelReport userReport:userreportDetails){
			
			HSSFRow datarow = sheet.createRow(rowCount++);
			datarow.createCell(0).setCellValue(rowNum);
			datarow.getCell(0).setCellStyle(style);
			
			datarow.createCell(1).setCellValue(userReport.getSource() != null ? userReport.getSource():"" );
			datarow.getCell(1).setCellStyle(style);
			
			datarow.createCell(2).setCellValue(!userReport.getFirstName().equals("null") ? userReport.getFirstName() : "");
			datarow.getCell(2).setCellStyle(style);
			
			datarow.createCell(3).setCellValue(!userReport.getLastName().equals("null") ? userReport.getLastName():"");
			datarow.getCell(3).setCellStyle(style);
			
			datarow.createCell(4).setCellValue(!userReport.getEmailAddress().equals("null") ? userReport.getEmailAddress():"");
			datarow.getCell(4).setCellStyle(style);
			
			datarow.createCell(5).setCellValue(!userReport.getPhoneNumber().equals("null") ? userReport.getPhoneNumber():"");
			datarow.getCell(5).setCellStyle(style);
			
			try{
				datarow.createCell(6).setCellValue(!userReport.getDateofBirth().equals("null") ? 
						Utils.getDateInstance("yyyy-MM-dd").format(Utils.getFormattedDate(userReport.getDateofBirth())): "");
				datarow.getCell(6).setCellStyle(style);
			}catch(ParseException pe1){
				LOGGER.error("ERROR While Parsing the Date:"+pe1.getMessage());
			}
			
			datarow.createCell(7).setCellValue(!userReport.getGender().equals("null") ? userReport.getGender():"");
			datarow.getCell(7).setCellStyle(style);
			
			datarow.createCell(8).setCellValue(!userReport.getState().equals("null") ? userReport.getState():"");
			datarow.getCell(8).setCellStyle(style);
			
			datarow.createCell(9).setCellValue(!userReport.getAnnualIncome().equals("null") ? userReport.getAnnualIncome():"");
			datarow.getCell(9).setCellStyle(style);
			
			datarow.createCell(10).setCellValue(!userReport.getSmokingStatus().equals("null") ? (userReport.getSmokingStatus().equals("1") ? "Y" : "N"):"");
			datarow.getCell(10).setCellStyle(style);
			
			datarow.createCell(11).setCellValue(!userReport.getDependentsStatus().equals("null") ? (userReport.getDependentsStatus().equals("1") ? "Y" : "N") :"");
			datarow.getCell(11).setCellStyle(style);
			
			datarow.createCell(12).setCellValue(!userReport.getDependentsCount().equals("null") ? userReport.getDependentsCount():"");
			datarow.getCell(12).setCellStyle(style);
			
			datarow.createCell(13).setCellValue(!userReport.getHealthStatus().equals("null") ? userReport.getHealthStatus():"");
			datarow.getCell(13).setCellStyle(style);
			
			datarow.createCell(14).setCellValue(!userReport.getCoverage().equals("null") ? userReport.getCoverage()  :"");
			datarow.getCell(14).setCellStyle(style);
			
			datarow.createCell(15).setCellValue(!userReport.getTerm().equals("null") ? userReport.getTerm() :"");
			datarow.getCell(15).setCellStyle(style);
			
			datarow.createCell(16).setCellValue(!userReport.getEbix_monthlyEstimate().equals("null") ? userReport.getEbix_monthlyEstimate() :"");
			datarow.getCell(16).setCellStyle(style);
			
			datarow.createCell(17).setCellValue(userReport.getLastpinneyProcessedDate());
			datarow.getCell(17).setCellStyle(style);
			
			datarow.createCell(18).setCellValue(userReport.getCallbackDate());
			datarow.getCell(18).setCellStyle(style);
			
			datarow.createCell(19).setCellValue(userReport.getCallbackTime());
			datarow.getCell(19).setCellStyle(style);
			
			rowNum++;
		}
		
		try{
			File file = new File(folderPath);
			if(!file.exists()){
				file.mkdir();
			}
			file = new File(file.getAbsolutePath()+"\\"+excelName+".xls");
			if(!file.exists()){
				file.createNewFile();
				FileOutputStream fout = new FileOutputStream(file);
				workbook.write(fout);
				fout.close();
			}			
		}catch(FileNotFoundException fe){
			LOGGER.error("ERROR"+fe.getMessage());
		}catch(IOException e){
			LOGGER.error("ERROR"+e.getMessage());
		}catch(Exception e){
			LOGGER.error("ERROR"+e.getMessage());
		}
	}
}
