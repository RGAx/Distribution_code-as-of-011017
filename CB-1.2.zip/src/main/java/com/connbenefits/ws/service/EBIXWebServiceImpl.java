package com.connbenefits.ws.service;

import java.io.StringWriter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletContext;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;

import org.apache.commons.lang.StringEscapeUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import com.connbenefits.common.logger.ExtJourneyLogger;
import com.connbenefits.common.logger.LogFactory;
import com.connbenefits.common.utils.Utils;
import com.connbenefits.constants.ApplicationConstants;
import com.connbenefits.domain.ProfileQuestion;
import com.connbenefits.exception.ServiceException;
import com.ebix.lifelink.client.ApplicantType;
import com.ebix.lifelink.client.ClientType;
import com.ebix.lifelink.client.DisplayedInformationType;
import com.ebix.lifelink.client.ErrorType;
import com.ebix.lifelink.client.ErrorTypeType;
import com.ebix.lifelink.client.InterfaceTypeType;
import com.ebix.lifelink.client.LLType;
import com.ebix.lifelink.client.LifeLinkType;
import com.ebix.lifelink.client.LifelinkXMLsvc;
import com.ebix.lifelink.client.LifelinkXMLsvcSoap;
import com.ebix.lifelink.client.LlXMLResponse.LlXMLResult;
import com.ebix.lifelink.client.ModalValueType;
import com.ebix.lifelink.client.ObjectFactory;
import com.ebix.lifelink.client.OutputTypeType;
import com.ebix.lifelink.client.ProdScenarioType;
import com.ebix.lifelink.client.ProductListsType;
import com.ebix.lifelink.client.ProductScenariosType;
import com.ebix.lifelink.client.ProductTypeType;
import com.ebix.lifelink.client.ProductsType;
import com.ebix.lifelink.client.RequestType;
import com.ebix.lifelink.client.ReturnType;
import com.ebix.lifelink.client.ScenarioType;
import com.ebix.lifelink.client.SexType;
import com.ebix.lifelink.client.ToolType;
import com.ebix.lifelink.client.ToolTypeName;
import com.ebix.lifelink.client.UWClassInfoType;
import com.ebix.lifelink.client.UserInformationType;
import com.ebix.lifelink.client.VTProductOptionsType;
import com.ebix.lifelink.client.VTProductType;
import com.ebix.lifelink.client.VitalTermNetType;

/**
 * This class has been used for implementing the EBIX operations such as getting the quotes, 
 * constructing XML requests which can be used for getting the EBIX response for quotes.
 * 
 * @author M1033511
 *
 */
public class EBIXWebServiceImpl {
	private static final ExtJourneyLogger logger = LogFactory.getInstance(EBIXWebServiceImpl.class);
	
	@Value("${service.ebix.username}")
	private String SERVICE_EBIX_USERNAME;
	
	@Value("${service.ebix.password}")
	private String SERVICE_EBIX_PASSWORD;
	
	@Value("${service.ebix.carrier}")
	private String SERVICE_EBIX_CARRIER;
	
	@Value("${service.ebix.principal}")
	private String SERVICE_EBIX_PRINCIPAL;	
	
	@Value("#{'${service.ebix.stateCodes}'.split(',')}")
	private List<String> stateCodes;
	
	@Autowired
	private ServletContext context;
	
	public Map<Integer, Double> getMonthlyPremium(
			ProfileQuestion profileQuestion, List<Integer> faceAmountList) throws ServiceException {
		final long startTime = logger.logMethodEntry();
		Map<Integer, Double> faceAmountPremiumMap = null;
		
		try {
			String encodedXML = constructXMLRequest(profileQuestion, faceAmountList);			
			faceAmountPremiumMap = getLLXMLResult(encodedXML);
			
		} catch(ServiceException e) {
			logger.error("ERROR : "+e.getMessage());
			throw new ServiceException(e.getMessage());
		}
		logger.logMethodExit(startTime);
		return faceAmountPremiumMap;

	}
	
	/*
	 * Used for constructing the EBIX request based on user answer.
	 */
	private String constructXMLRequest(ProfileQuestion profileQuestion, List<Integer> faceAmountList) throws ServiceException {
		final long startTime = logger.logMethodEntry();
				
		String encodedXML = null;
		try {
			LifeLinkType lifeLinkType = this.initializeLifeLinkType();
			
			lifeLinkType = this.loadUserClientInfo(lifeLinkType, profileQuestion);
			
			// VitalTermNet information
			VitalTermNetType vitalTermNet = new VitalTermNetType();					
			vitalTermNet.setProducts(this.constructProductType(profileQuestion, faceAmountList));

			lifeLinkType.setVitalTermNet(vitalTermNet);
			ObjectFactory objectFactory = new ObjectFactory();
			JAXBElement<LifeLinkType>  jaxbObject= objectFactory.createLifeLink(lifeLinkType);
			//logger.info("EBIX request : " + encodedXML);
			encodedXML = this.marshalXMLRequest(jaxbObject, encodedXML);
		} catch(Exception e) {
			logger.error("ERROR : "+e.getMessage());
			throw new ServiceException(e.getMessage());
		}
		
		logger.logMethodExit(startTime);
		return encodedXML;
	}
	
	/*
	 * Used to initialize the LifeLinkType.
	 */
	private LifeLinkType initializeLifeLinkType() {
		LifeLinkType lifeLinkType = new LifeLinkType();

		// LL type
		LLType llType = new LLType();
		llType.setUserName(SERVICE_EBIX_USERNAME);
		llType.setUserPassword(SERVICE_EBIX_PASSWORD);
		InterfaceTypeType interfaceType = InterfaceTypeType.NO_GUI;
		llType.setInterfaceType(interfaceType);
		OutputTypeType outputType = OutputTypeType.XML;
		llType.setOutputType(outputType);
		llType.setLogout(false);
		ToolType toolType = new ToolType();
		toolType.setName(ToolTypeName.VITAL_TERM_NET);
		llType.getTool().add(toolType);
		lifeLinkType.setLL(llType);
		
		return lifeLinkType;
	}

	/*
	 * used to load the user and client information into the LifeLinkType.
	 */
	private LifeLinkType loadUserClientInfo(LifeLinkType lifeLinkType, ProfileQuestion profileQuestion) {
		// User Information
		UserInformationType userInformationType = new UserInformationType();
		userInformationType.setFirstName(profileQuestion.getProfile().getFirstName());
		userInformationType.setLastName(profileQuestion.getProfile().getLastName());
		lifeLinkType.setUserInformation(userInformationType);
		
		// Client information
		ClientType clientType = new ClientType();
		ApplicantType applicantType = new ApplicantType();
		applicantType.setAge(Utils.getDiffInYearsInJodaTime(profileQuestion.getProfile().getDateOfBirth()));
		SexType sexType = "Male".equalsIgnoreCase(profileQuestion.getProfile().getGender()) ? SexType.MALE : SexType.FEMALE;
		applicantType.setSex(sexType);
		clientType.setApplicant(applicantType);
		
		String stateCode = profileQuestion.getProfile().getState();
		logger.debug("stateCode before validation: " + stateCode);
		if(stateCode != null && !stateCode.isEmpty() && stateCodes != null && !stateCodes.isEmpty()
				&& !stateCodes.contains(stateCode.toUpperCase())) {
			stateCode = "NY";
		}
		logger.debug("stateCode after validation: " + stateCode);
		clientType.setStateOfIssue(stateCode);
		lifeLinkType.setClient(clientType);
		
		return lifeLinkType;
	}
	
	/*
	 * Used for constructing the product type.
	 */
	private ProductsType constructProductType(ProfileQuestion profileQuestion, List<Integer> faceAmountList) throws ServiceException{
		//Product			
		ProductsType productType = new ProductsType();
		VTProductOptionsType vtProductOptions = this.initializeProductOptions();
		productType.setProductOptions(vtProductOptions);
	
		//ProductLists		
		ProductListsType productList = new ProductListsType();
		if(profileQuestion.getProfile().getSource().equalsIgnoreCase("CB")) {
			productList.setListName(SERVICE_EBIX_CARRIER);	
		} else {
			productList.setListName(SERVICE_EBIX_PRINCIPAL);
		}
		productList.getYearsLevel().add(20);
		productList.getProductType().add(ProductTypeType.TERM);
		productType.setProductLists(productList);
		
		// Product Scenario Type
		productType.setProductScenarios(this.loadProductScenarios(profileQuestion, faceAmountList));
		return productType;
	}

	private VTProductOptionsType initializeProductOptions() {
		//Product Options
		VTProductOptionsType vtProductOptions = new VTProductOptionsType();
		vtProductOptions.setBreakDownPremiums(ApplicationConstants.BreakDownPremiums);
		vtProductOptions.setCalcToPenny(ApplicationConstants.CalcToPenny);
		vtProductOptions.setDisplayProductClasses(ApplicationConstants.DisplayProductClasses);
		vtProductOptions.setGetCompanyInfo(ApplicationConstants.GetCompanyInfo);
		vtProductOptions.setShowCurrentRates(ApplicationConstants.ShowCurrentRates);
		vtProductOptions.setShowRemovedProducts(ApplicationConstants.ShowRemovedProducts);
		vtProductOptions.setShowProdInfoOnRemoval(ApplicationConstants.ShowProdInfoOnRemoval);
		vtProductOptions.setShowProdInfoOnly(ApplicationConstants.ShowProdInfoOnly);
		vtProductOptions.setShowPremiumsOnly(ApplicationConstants.ShowPremiumsOnly);
		vtProductOptions.setCalc1StYearModal(ApplicationConstants.Calc1StYearModal);
		
		return vtProductOptions;
	}
	
	
	/**
	 * @param profileQuestion
	 * @param faceAmountList
	 * @return
	 * @throws ServiceException
	 */
	private ProductScenariosType loadProductScenarios(ProfileQuestion profileQuestion, List<Integer> faceAmountList) throws ServiceException{
		// Product Scenario Type
		ProductScenariosType productScenariosType = new ProductScenariosType();
		//Add Product Scenarios for each FaceAmount
		
		for(Integer faceAmount : faceAmountList) {
			ProdScenarioType scenarioType = new ProdScenarioType();
			UWClassInfoType underWritingClassInfoType = new UWClassInfoType();
			
			scenarioType.setFaceAmount(faceAmount+"");
			scenarioType.setPaymentMode(0);
			
			underWritingClassInfoType.setType("VT");
			underWritingClassInfoType.setClazz(5);
			//In db smoking status 1 = Yes & 0 = No
			if(profileQuestion.getUserAnswer().getSmokingStatus() == 1 ){
				underWritingClassInfoType.setSmokingStatus(3);// smoking status 3 = Yes 
			}else{
				underWritingClassInfoType.setSmokingStatus(1);// smoking status 1 = No
			}
			scenarioType.setUnderwritingClassInfo(underWritingClassInfoType);
			productScenariosType.getScenario().add(scenarioType);	
		}
		return productScenariosType;
	}
	
	/*
	 * Used for marshalling the XML request.
	 */
	private String marshalXMLRequest(JAXBElement<LifeLinkType> jaxbObject, String encodedXML) throws ServiceException {
		try {
			JAXBContext jc = JAXBContext.newInstance(ObjectFactory.class);
			Marshaller marshaller = jc.createMarshaller();
			marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
			StringWriter stringWriter = new StringWriter();
			marshaller.marshal(jaxbObject, stringWriter);
			String requestXML = stringWriter.toString();
			//logger.debug("EBIX Request XML"+requestXML);
			encodedXML = StringEscapeUtils.escapeXml(requestXML);
			//logger.debug("Encoded XML :" + encodedXML);
		} catch (JAXBException e) {
			logger.error("JAXB Exception while marshalling the Request: "+e.getMessage());
			throw new ServiceException(e.getMessage());
		}
		return encodedXML;
	}
	
	
	/*
	 * Used for getting the Quotes from EBIX Webservice
	 * 
	 */
	@SuppressWarnings("rawtypes")
	private Map<Integer, Double> getLLXMLResult(String encodedXML) throws ServiceException {
		final long startTime = logger.logMethodEntry();
		
		Map<Integer, Double> faceAmountPremiumMap = new HashMap<Integer, Double>(); 
		LifelinkXMLsvc llService = null;
		LlXMLResult result = null;
		try {
			if(null == context.getAttribute("ebixService")) {
				llService = new LifelinkXMLsvc();
				context.setAttribute("ebixService", llService);
			} else {
				llService = (LifelinkXMLsvc)context.getAttribute("ebixService");
			}		
			
			LifelinkXMLsvcSoap soapPort = llService.getLifelinkXMLsvcSoap();
			result = soapPort.llXML(encodedXML);
			JAXBElement jaxbObject = (JAXBElement) result.getContent().get(0);
			LifeLinkType lifelinkType = (LifeLinkType)jaxbObject.getValue();
			ErrorType error = lifelinkType.getError().get(0);
			
			if(error.getType().equals(ErrorTypeType.ERROR)) {
				logger.debug("Error Description ::"+error.getDescription());
			} else if(error.getType().equals(ErrorTypeType.MESSAGE)) {
				ProductsType productType = lifelinkType.getVitalTermNet().getProducts();
				List<VTProductType> productList = productType.getProduct();
				
				if(productList != null && !productList.isEmpty()) {
					for(VTProductType products : productList) {
						ScenarioType scenarioType = products.getScenario();
						RequestType requestType = scenarioType.getRequest();
						int faceAmount = Integer.parseInt(requestType.getFaceAmount());
						
						ReturnType returnType = scenarioType.getReturn();
						DisplayedInformationType displayedInformation = returnType.getDisplayedInformation();
						
						if(null != displayedInformation.getPremiumInformation()) {
							List<ModalValueType> premiumList = displayedInformation.getPremiumInformation().getFirstYearModalPremiums().getPremium();
							double premiumValue = 0.0;
							if(premiumList != null) {
								if(premiumList.get(3) != null) {
									String premValue = premiumList.get(3).getValue();
									premValue = premValue.replace("$", "");
									premValue = premValue.replace(",", "");
									premValue = premValue.replace(",", "");
									
									premiumValue = Double.parseDouble(premValue);
									faceAmountPremiumMap.put(faceAmount, premiumValue);
								}
							}/* else {
								List<NoteType> reasonList = products.getScenario().getReturn().getRemovedInformation().getReasons().getReason();
								if(reasonList.size() > 0 && null != reasonList.get(0))
									logger.debug("Reason Text for Product : " + reasonList.get(0).getText());	
							}*/
						}
					}
				}
			}
			/*JAXBContext jc = JAXBContext.newInstance(LlXMLResponse.LlXMLResult.class);
			Marshaller marshaller = jc.createMarshaller();
			marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
			StringWriter stringWriter = new StringWriter();
			marshaller.marshal(result, stringWriter);*/
			//logger.debug("EBIX WebServie ::: response : "+stringWriter.toString());		
			//System.out.println("EBIX WebServie ::: response : "+stringWriter.toString());
		} /*catch (JAXBException e) {
			logger.error("JAXB Exception while marshalling the Response: "+e.getMessage());
			throw new ServiceException(e.getMessage());
		} */catch (Exception e) {
			logger.error("Exception while marshalling the Response: "+e.getMessage());
			throw new ServiceException(e.getMessage());
		}
		logger.logMethodExit(startTime);
		return faceAmountPremiumMap;
	}
	
}
