package com.connbenefits.controller;

import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.ModelAndView;

import com.connbenefits.common.logger.ExtJourneyLogger;
import com.connbenefits.common.logger.LogFactory;
import com.connbenefits.constants.ApplicationConstants;
 
@ControllerAdvice
public class ExceptionControllerAdvice {
 
	private static final ExtJourneyLogger LOGGER = LogFactory.getInstance(ExceptionControllerAdvice.class);
	
    @ExceptionHandler(Exception.class)
    public String exception(Exception e) {
        ModelAndView mav = new ModelAndView(ApplicationConstants.ERROR);
        mav.addObject("name", e.getClass().getSimpleName());
        mav.addObject("message", e.getMessage());
 
        LOGGER.debug("ERROR NAME: " + e.getClass().getSimpleName() + ", ERROR MESSAGE: " + e.getMessage());
        return "redirect:"+ApplicationConstants.ERROR+".html";
    }
}