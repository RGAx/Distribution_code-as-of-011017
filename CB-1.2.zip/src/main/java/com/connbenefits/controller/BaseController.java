package com.connbenefits.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.connbenefits.common.logger.ExtJourneyLogger;
import com.connbenefits.common.logger.LogFactory;
import com.connbenefits.constants.ApplicationConstants;
import com.connbenefits.domain.Profile;
import com.connbenefits.exception.ServiceException;

/**
 * Used as a base controller where the common operations can be implemented.
 * 
 * @author M1030133
 *
 */
@Controller
public class BaseController {

	private static final ExtJourneyLogger LOGGER = LogFactory
			.getInstance(BaseController.class);

	@Autowired
	private HttpSession session;

	@RequestMapping("/extJourney")
	public String loadExtJourneyPage() {
		return "extJourney";
	}

	/*
	 * Used to load the error page.
	 */
	@RequestMapping("/"+ApplicationConstants.ERROR)
	public String loadErrorPage() throws Exception {
		return ApplicationConstants.ERROR;
	}

	/*
	 * This method loads the default page
	 */
	@RequestMapping("/")
	public String loadDefaultPage() throws Exception {
		return "redirect:extJourney.html";
	}

	@RequestMapping("/connectPage")
	public String loadConnectPage() throws ServiceException, Exception {
		return "connectPage";
	}

	/*
	 * This method has been used to load the caller page from call back page.
	 */
	@RequestMapping("/backToPage")
	public String loadCallbackPage() {
		long startTime = LOGGER.logMethodEntry();

		Profile profile = (Profile) session.getAttribute("sessionProfile");
		String pageFrom = (String) session
				.getAttribute(ApplicationConstants.PAGE_FROM);

		if (pageFrom != null && !pageFrom.isEmpty() && profile != null) {
			if ("landingPage".equalsIgnoreCase(pageFrom)) {
				return "redirect:landingPage.html?source="+
						profile.getSource();

			} else if ("questionsPage".equalsIgnoreCase(pageFrom)) {
				return "redirect:questionsPage.html";

			} else if ("sliderPage".equalsIgnoreCase(pageFrom)) {
				return "redirect:sliderPage.html";
			}
		}
		LOGGER.logMethodExit(startTime);
		return ApplicationConstants.ERROR;
	}
}
