package com.connbenefits.controller;

import java.text.SimpleDateFormat;
import java.util.List;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.connbenefits.constants.ApplicationConstants;
import com.connbenefits.domain.MultiplierRateDetails;
import com.connbenefits.domain.Profile;
import com.connbenefits.domain.ProfileQuestion;
import com.connbenefits.domain.UserAnswer;
import com.connbenefits.exception.ServiceException;
import com.connbenefits.services.GenericService;
import com.connbenefits.services.ProfileService;
import com.connbenefits.services.QuestionsService;
import com.connbenefits.common.logger.ExtJourneyLogger;
import com.connbenefits.common.logger.LogFactory;
import com.connbenefits.common.utils.Utils;

/**
 * This controller is used to handle the requests and calls methods to store
 * data in db
 * 
 * @author m1033511
 */
@Controller
public class QuestionsController {
	
	private static final ExtJourneyLogger logger = LogFactory.getInstance(QuestionsController.class);

	@Autowired
	private HttpSession session;

	@Autowired
	private QuestionsService questionsService;
	
	@Autowired
	private ProfileService profileService;

	@Autowired
	private ServletContext context;
	
	@Autowired
	private GenericService genericService;

	/*
	 * This method is used to get the questionsPage
	 */
	@RequestMapping(value = "/questionsPage")
	public String loadQuestionsPage(Model model) throws Exception {
		Profile profile = null;
		UserAnswer userAnswer = null;
		
		if (null != session.getAttribute("sessionProfile")) {
			profile = (Profile) session.getAttribute("sessionProfile");
		} else {
			return "redirect:"+ApplicationConstants.FAILURE_PAGE+".html";
		}
		
		
		if(profile != null) {
			// changing the date format from yyyy/MM/dd to MM/dd/yyyy
			SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
			String newDate = "";
			if(profile.getDateOfBirth() != null) {
				newDate = dateFormat.format(profile.getDateOfBirth());
			}
			ProfileQuestion profileQuestion = new ProfileQuestion();
			profile.setStrAnnualIncome(profile.getAnnualIncome() + "");
			profileQuestion.setProfile(profile);
	
			try{
				userAnswer = questionsService.loadUserAnswer(profile
							.getProfileId());
			}catch(ServiceException e){
				logger.error("ERROR : "+e.getMessage());
				throw new Exception(e.getMessage());
			}catch(Exception e){
				logger.error("ERROR : "+e.getMessage());
				throw new Exception(e.getMessage());
			}
			
			model.addAttribute("dateOfBirth", newDate);
			model.addAttribute("sessionProfile",profile);
			model.addAttribute("profileQuestion", profileQuestion);
			model.addAttribute("userAnswer", userAnswer);
		}
		session.setAttribute(ApplicationConstants.PAGE_FROM, "questionsPage");
		
		return "questionsPage";
	}

	/*
	 * This method is used for loading/inserting/updating the values of
	 * ProfileQuestion into questionsPage
	 */
	@RequestMapping(value = "/questionsPage", method = RequestMethod.POST, params = "requestParam")
	public String saveUpdateQuestionsPage(
			@ModelAttribute("profileQuestion") ProfileQuestion profileQuestion,
			@RequestParam String requestParam) throws Exception {
		Profile profile = profileQuestion.getProfile();
		Profile sessionProfile = null;
		Profile createdProfile = null;
		
		int annualIncome = 0;
		int upperRange = 0;
		int lowerRange = 0;

		List<MultiplierRateDetails> contextMultiplierrateList = null;
		if (null != session.getAttribute("sessionProfile")) {
			sessionProfile = (Profile) session.getAttribute("sessionProfile");
			
			if ("back".equalsIgnoreCase(requestParam)) {
				return "landingPage.html?source="+
						sessionProfile.getSource();
			}
			try {
				
				contextMultiplierrateList = genericService.loadMultiplierrateList();
				// calculating age using date of birth
				int dobrange = Utils.getDiffInYearsInJodaTime(profile.getDateOfBirth());
				// getting upper range and lower range from db using age
				for (MultiplierRateDetails multiplierRateDetails : contextMultiplierrateList) {
					if (multiplierRateDetails.getAge() != 0
							&& multiplierRateDetails.getAge() == dobrange) {
						upperRange = multiplierRateDetails.getUpperRange();
						lowerRange = multiplierRateDetails.getLowerRange();

					}
				}
				// converting annualIncome integer to String and to add $ prefix
				// and to set commas
				if (profile.getStrAnnualIncome() != null
						&& !profile.getStrAnnualIncome().isEmpty()) {
					String strAnnualIncome = profile.getStrAnnualIncome();
					strAnnualIncome = strAnnualIncome.replace("$", "");
					strAnnualIncome = strAnnualIncome.replaceAll(",", "");
					profile.setAnnualIncome(Long.parseLong(strAnnualIncome));
				}
				// calculating upper and lower range based on annualIncome
				annualIncome = (int) profile.getAnnualIncome();
				annualIncome = (int) (1000*(Math.round(annualIncome/1000.0)));
				upperRange = (upperRange * annualIncome);
				lowerRange = (lowerRange * annualIncome);
				// return to callback page if annualIncome is out of boundries
				// b/w 100K to 5M
				if (upperRange < 0 || upperRange > 5000000 || lowerRange <= 100000) {
					session.setAttribute(ApplicationConstants.PAGE_FROM, "failurePage");
					return "redirect:"+ApplicationConstants.FAILURE_PAGE+".html";
				}
			} catch (ServiceException e) {
				logger.error(""+e.getMessage());
				throw new Exception(e.getMessage());
			}catch (Exception e) {
				logger.error(""+e.getMessage());
				throw new Exception(e.getMessage());
			}
			
			UserAnswer userAnswer = profileQuestion.getUserAnswer();

			// Validation for dob
			int differenceInYears = Utils.getDiffInYearsInJodaTime(profile.getDateOfBirth());
			if ((userAnswer.getSmokingStatus() == 1 && (differenceInYears < 20 || differenceInYears > 65))
					|| (userAnswer.getSmokingStatus() == 0 && (differenceInYears < 20 || differenceInYears > 70))) {
				session.setAttribute(ApplicationConstants.PAGE_FROM, "failurePage");
				return "redirect:"+ApplicationConstants.FAILURE_PAGE+".html";
			}
			try {
				sessionProfile.setDateOfBirth(profile.getDateOfBirth());
				sessionProfile.setGender(profile.getGender());
				sessionProfile.setAnnualIncome(profile.getAnnualIncome());
				sessionProfile.setZipCode(profile.getZipCode());
				sessionProfile.setState(profile.getState());
				
				if(sessionProfile.getProfileId() ==0){
					String encryptedId = Utils.encryptID(profile.getDateOfBirth().toString()
							+ System.currentTimeMillis());
					sessionProfile.setEncryptedId(encryptedId);
					//Saving the profile and setting it into session
					profileService.saveProfile(sessionProfile);
					
					//Load Profile with the the generated encrypted UID and store it in to the session
					createdProfile =  profileService.loadProfile(String.valueOf(sessionProfile.getEncryptedId()));
					session.setAttribute("sessionProfile", createdProfile);
				}else{
					profileService.updateProfile(sessionProfile);
					createdProfile = sessionProfile;
					session.setAttribute("sessionProfile", createdProfile);
				}
			} catch(ServiceException e){
				logger.error("ERROR : "+e.getMessage());
				throw new Exception(e.getMessage());
			}
			catch (Exception e) {
				logger.error("ERROR : "+e.getMessage());
				throw new Exception(e.getMessage());
			}
			profileQuestion.setProfile(createdProfile);
			try {
				// loading the UserAnswers data from db
				UserAnswer dbProfile = questionsService.loadUserAnswer(createdProfile
						.getProfileId());
				boolean dbStatus = dbProfile == null;
				// saving & updating UserAnswer data into db
				questionsService.saveUpdateUserAnswer(profileQuestion, dbStatus);
			}catch(ServiceException e){
				logger.error("ERROR : "+e.getMessage());
				throw new Exception(e.getMessage());
			}
			catch (Exception e) {
				logger.error("ERROR : "+e.getMessage());
				throw new Exception(e.getMessage());
			}
			try {
				if(!questionsService.validateFaceValuesWithEBIX(profileQuestion)) {
					session.setAttribute(ApplicationConstants.PAGE_FROM, "failurePage");
					return "redirect:"+ApplicationConstants.FAILURE_PAGE+".html";
				}
			} catch (Exception e) {
				throw new Exception(e.getMessage());
			}
			return "redirect:"+ApplicationConstants.SLIDER_PAGE+".html";
		}else{
			return "redirect:"+ApplicationConstants.ERROR+".html";
		}

	}

}
