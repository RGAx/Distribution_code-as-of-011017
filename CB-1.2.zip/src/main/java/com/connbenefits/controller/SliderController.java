package com.connbenefits.controller;

import java.util.Map;

import javax.servlet.http.HttpSession;

import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.connbenefits.common.logger.ExtJourneyLogger;
import com.connbenefits.common.logger.LogFactory;
import com.connbenefits.constants.ApplicationConstants;
import com.connbenefits.domain.Profile;
import com.connbenefits.domain.ProfileQuestion;
import com.connbenefits.domain.SliderFaceValue;
import com.connbenefits.domain.UserAnswer;
import com.connbenefits.exception.ServiceException;
import com.connbenefits.services.ProfileService;
import com.connbenefits.services.QuestionsService;
import com.connbenefits.services.SliderService;


/**
 * @author M1029563
 * This class is used to load the sliderPage by calculating the ideal Coverage Ranges and Minimum and Maximum FaceAmountValues for the Slider, displaying the Premium amount values from 
 * EBIX response from the map for the certain range of slider Points from MIN to MAX.
 *
 */

@Controller
public class SliderController {
	
	@Autowired
	private HttpSession session;
		
	@Autowired
	private SliderService sliderService;
	
	@Autowired
	private QuestionsService questionsService;
	
	@Autowired
	private ProfileService profileService;
	
	private static final ExtJourneyLogger LOGGER = LogFactory.getInstance(SliderController.class);
	
	/*
	 * This method is used to load premium amount values from the Map EBIX RESPONSE and refresh the value in the response for the specified Slider value.
	 * 
	 */
	@SuppressWarnings("unchecked")
	@RequestMapping(value="/slidervalue", method= RequestMethod.POST)
	public @ResponseBody String getSliderValue(String sliderValue) throws Exception{		
		
		JSONObject jsonObject = new JSONObject();
		Map<Integer, Double> premiumfacevalueMap = null;
		String premiumAmount ="";
		
		try{
			if(null != session.getAttribute("sessionFaceValues")){
				premiumfacevalueMap = (Map<Integer, Double>) session.getAttribute("sessionFaceValues");
				
				if(null != sliderValue && !sliderValue.isEmpty() && premiumfacevalueMap.containsKey(Integer.parseInt(sliderValue))){
					premiumAmount = String.valueOf(premiumfacevalueMap.get(Integer.parseInt(sliderValue)));
				}
			}
		}catch(Exception e){
			LOGGER.error("ERROR: " + e.getMessage());
			throw new Exception(e.getMessage());
		}
		
		jsonObject.put("premiumvalue", premiumAmount);
		
		return jsonObject.toJSONString();
	}
	
	/*
	 * This method is used to load Slider Page loadSliderPage() returning the model object to ModelandView of SliderPage.
	 * 
	 */
	@RequestMapping(value="/"+ApplicationConstants.SLIDER_PAGE)
	public ModelAndView loadSliderPage() throws Exception{
		
		SliderFaceValue sliderFaceValue = null;
		Profile sessionProfile = null;
		UserAnswer userAnswer =null;
		
		ModelAndView model = new ModelAndView(ApplicationConstants.SLIDER_PAGE);
		
		try {	
			if(null != session.getAttribute("sessionProfile")){
				sessionProfile = (Profile) session.getAttribute("sessionProfile");
				sliderFaceValue = sliderService.loadSliderPage();
				userAnswer = questionsService.loadUserAnswer(sessionProfile.getProfileId());
				if(null != session.getAttribute(ApplicationConstants.SLIDER_PAGEFROM) && session.getAttribute(ApplicationConstants.SLIDER_PAGEFROM).equals(ApplicationConstants.CALLBACK_PAGE)){
					if(sessionProfile.getCoverage() != 0){
						model.addObject("selectedCoverage", (int)sessionProfile.getCoverage());
					}
				}				
			}else {
				return new ModelAndView("redirect:"+ApplicationConstants.ERROR+".html");
			}	

		}catch(ServiceException e){
			LOGGER.error("ERROR: " + e.getMessage());
			throw new Exception(e.getMessage());
		}
		catch(Exception ex){
			LOGGER.error("ERROR: " + ex.getMessage());
			throw new Exception(ex.getMessage());
		}

		session.setAttribute(ApplicationConstants.PAGE_FROM, ApplicationConstants.SLIDER_PAGE);
		session.setAttribute(ApplicationConstants.SLIDER_PAGEFROM, ApplicationConstants.SLIDER_PAGE);
		
		model.addObject("slidervalues", sliderFaceValue);
		model.addObject("useranswer", userAnswer);
		
		return model;
	}
	
	/*
	 * This method is used to update the Profile table Coverage and EbixmonthlyEstimate columns.
	 * @param profileQuestion
	 * @param param
	 * @return callbackpage
	 * @throws ServiceException,Exception
	 */
	@RequestMapping(value="/"+ApplicationConstants.SLIDER_PAGE,params={"requestParam"},method = RequestMethod.POST)
	public String SaveUpdateCoverageandEbixMonthlyEstimate(@ModelAttribute("profilequestion") ProfileQuestion profileQuestion,@RequestParam("requestParam")String param) throws Exception{
		
		Profile profile = null;
		Profile sessionProfile = null;
		try{
			if(null != profileQuestion){
				profile = profileQuestion.getProfile();
			}
			if(null != session.getAttribute("sessionProfile")){
				sessionProfile = (Profile) session.getAttribute("sessionProfile");
				sessionProfile.setCoverage(profile.getCoverage());
				sessionProfile.setEbixMonthlyEstimate(profile.getEbixMonthlyEstimate());
				profileService.updateProfileEbixMonthlyEstimate(sessionProfile);
				session.setAttribute("sessionProfile", sessionProfile);
			}else {
				return "redirect:"+ApplicationConstants.ERROR+".html";
			}
			
		}catch(ServiceException e){
			LOGGER.error("ERROR: " + e.getMessage());
			throw new Exception(e.getMessage());
		}
		catch(Exception ex){
			LOGGER.error("ERROR: " + ex.getMessage());
			throw new Exception(ex.getMessage());
		}		
		
		return "redirect:"+ApplicationConstants.CALLBACK_PAGE+".html";
	}

}
