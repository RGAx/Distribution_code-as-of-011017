package com.connbenefits.pinney.services.impl;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.connbenefits.common.logger.ExtJourneyLogger;
import com.connbenefits.common.logger.LogFactory;
import com.connbenefits.common.utils.Utils;
import com.connbenefits.domain.CustomerCallback;
import com.connbenefits.domain.Profile;
import com.connbenefits.domain.UserAnswer;
import com.connbenefits.domain.pinney.Address;
import com.connbenefits.domain.pinney.Client;
import com.connbenefits.domain.pinney.Contact_info;
import com.connbenefits.domain.pinney.Email;
import com.connbenefits.domain.pinney.Financial_info;
import com.connbenefits.domain.pinney.Health_info;
import com.connbenefits.domain.pinney.Phone;
import com.connbenefits.domain.pinney.PinneyClient;
import com.connbenefits.domain.pinney.Policies;
import com.connbenefits.domain.pinney.Policy_details;
import com.connbenefits.exception.ServiceException;
import com.connbenefits.services.QuestionsService;
import com.connbenefits.domain.pinney.NotesAttribute;
import com.google.gson.Gson;

/**
 * This class has been used for loading the user answer from the database
 * corresponding to the user and constructing the json request using that user
 * answer.
 * 
 * @author M1030133
 *
 */
@Service
public class PinneyRequestProcessor {
	private static final ExtJourneyLogger LOGGER = LogFactory.getInstance(PinneyRequestProcessor.class);
	
	@Autowired
	private QuestionsService questionsService;

	@Autowired
	HttpSession session;

	@Value("${pinney.user.id}")
	private int pinneyUserID;

	@Value("${pinney.response.type}")
	private String responseType;
	
	@Value("${pinney.profile.id}")
	private int pinneyProfileId;

	private SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
	private static String BANNER = "Banner Life Ins. Co.";
	private static String WILLIAM = "William Penn Life Ins. Co of NY";

	/*
	 * This method has been used for loading the question answer from the DB
	 * based on the current user.
	 */
	public UserAnswer loadUserAnswer(Profile profile) throws ServiceException {
		long startTime = LOGGER.logMethodEntry();
		UserAnswer userAnswer;
		try {
			userAnswer = (UserAnswer) questionsService.loadUserAnswer(profile
					.getProfileId());
		} catch (ServiceException e) {
			throw new ServiceException(e.getMessage());
		}
		LOGGER.logMethodExit(startTime);
		return userAnswer;

	}

	/*
	 * This method has been used for constructing the json request by using the
	 * question answers and the user details which can be used for getting the
	 * json response after passing to Pinney.
	 */
	public String constructJsonRequest(UserAnswer userAnswer, Profile profile, CustomerCallback customerCallback)
			throws Exception {
		long startTime = LOGGER.logMethodEntry();
		String json = null;
		try {
			PinneyClient crm_connection_Client = new PinneyClient();

			//crm_connection_Client.setUserId(pinneyUserID);
			Client crm_connection = new Client();
			crm_connection.setActive(true);
			if(profile.getDateOfBirth()!=null){
				crm_connection
						.setBirth(dateFormat.format(profile.getDateOfBirth()));
			}
			crm_connection.setCases_attributes(this.constructCaseAttributes(
					profile, userAnswer, customerCallback));
			crm_connection.setContact_info_attributes(this
					.constructContactInfo(profile, customerCallback));

			Financial_info financial_info = new Financial_info();
			financial_info.setAnnual_income((int) profile.getAnnualIncome());
			crm_connection.setFinancial_info_attributes(financial_info);
			crm_connection.setFirst_name(profile.getFirstName());
			if(StringUtils.isNotEmpty(profile.getGender())){
				crm_connection.setGender(profile.getGender());
			}
			

			crm_connection.setHealth_info_attributes(this
					.constructHealthInfoAttributes(profile, userAnswer));
			
			crm_connection.setLast_name(profile.getLastName());
			crm_connection.setProfile_id(pinneyProfileId);
			crm_connection.setSource(profile.getSource());
			crm_connection_Client.setResponse(responseType);

			crm_connection_Client.setCrm_connection(crm_connection);

			json = new Gson().toJson(crm_connection_Client);
		} catch (Exception e) {
			LOGGER.error("ERROR: " + e.getMessage());
			throw new ServiceException(e.getMessage());
		}
		LOGGER.logMethodExit(startTime);
		return json;
	}

	private Health_info constructHealthInfoAttributes(Profile profile,
			UserAnswer userAnswer) {
		Health_info health_info_attribues = new Health_info();
		if(profile.getDateOfBirth()!=null){
			health_info_attribues.setBirth(profile.getDateOfBirth().toString());
		}
		if(StringUtils.isNotEmpty(profile.getGender())){
			health_info_attribues.setGender("Male".equalsIgnoreCase(profile.getGender()) ? true : false);
		}
		if(userAnswer.getSmokingStatus()!=0){
			health_info_attribues.setSmoker(userAnswer.getSmokingStatus() == 1);
		}
		return health_info_attribues;
	}

	private List<Policies> constructCaseAttributes(Profile profile,
			UserAnswer userAnswer, CustomerCallback customerCallback) throws ParseException {
		List<Policies> cases_attributes = new ArrayList<Policies>();
		Policies cases_attribute = new Policies();
		cases_attribute.setFace_amount(profile.getCoverage());

		Policy_details quoted_details_attributes = new Policy_details();
		quoted_details_attributes.setFace_amount(profile.getCoverage());
		if(profile.getEbixMonthlyEstimate() != null) {
			quoted_details_attributes.setMonthly_premium(Double.parseDouble(profile
					.getEbixMonthlyEstimate()));
		}
		quoted_details_attributes.setPremium_mode_name("Monthly");
		
		//Added extra fields to capture Carrier
		if(StringUtils.isNotEmpty(profile.getState())){
			if(profile.getState().equalsIgnoreCase("NY")){
				quoted_details_attributes.setCarrier_id(39);
				quoted_details_attributes.setCarrier_name(WILLIAM);
			}else{
				quoted_details_attributes.setCarrier_id(2);
				quoted_details_attributes.setCarrier_name(BANNER);
			}
	
			quoted_details_attributes.setCategory_name("20 years");
		}
		List<NotesAttribute> notes_attributes = new ArrayList<NotesAttribute>();
		NotesAttribute note_attribute = new NotesAttribute();
		note_attribute.setConfidential(true);
		note_attribute.setNote_type_id(1);
		
		String notesText = "";
		if(customerCallback != null) {
			if(customerCallback.getCallbackDate() != null)
				notesText += "callbackDate?"+Utils.getFormattedDate(customerCallback
						.getCallbackDate());
			if(customerCallback.getCallbackTime() != null)
				notesText += ", callbackTime?"+customerCallback.getCallbackTime();
		}
		note_attribute.setText(notesText);
		notes_attributes.add(note_attribute);

		cases_attribute.setQuoted_details_attributes(quoted_details_attributes);
		cases_attribute.setNotes_attributes(notes_attributes);
		cases_attributes.add(cases_attribute);

		return cases_attributes;
	}

	private Contact_info constructContactInfo(Profile profile, CustomerCallback customerCallback) throws Exception {
		// contact_info_attributes starts here
		Contact_info contact_info_attributes;
		try {
			contact_info_attributes = new Contact_info();
			if(StringUtils.isNotEmpty(profile.getZipCode())){
				
				List<Address> addresses_attributes = new ArrayList<Address>();
				Address address = new Address();
				address.setAddress_type_id(2);
				address.setZip(profile.getZipCode());
				
				Map<String, Integer> stateIdsMap = Utils.loadStateIds();
				if (stateIdsMap != null && !stateIdsMap.isEmpty() && profile.getState() != null)
					address.setState_id(stateIdsMap.get(profile.getState()));
				if(StringUtils.isNotEmpty(profile.getCity())){
					address.setCity(profile.getCity());
				}	
				addresses_attributes.add(address);
				if (addresses_attributes != null && !addresses_attributes.isEmpty()) {
					contact_info_attributes
							.setAddresses_attributes(addresses_attributes);
				}
			}
			List<Email> emails_attributes = new ArrayList<Email>();
			Email email = new Email();
			email.setValue(profile.getEmailAddress());

			emails_attributes.add(email);
			if (emails_attributes != null && !emails_attributes.isEmpty()) {
				contact_info_attributes.setEmails_attributes(emails_attributes);
			}

			List<Phone> phones_attributes = new ArrayList<Phone>();
			Phone phone = new Phone();
			phone.setPhone_type_id(2);
			if(customerCallback != null && customerCallback.getPhoneNumber() != null 
					&& !customerCallback.getPhoneNumber().isEmpty()) {
				phone.setValue(customerCallback.getPhoneNumber() + "");
			} else {
				phone.setValue(profile.getPhoneNumber() + "");
			}
			
			phones_attributes.add(phone);
			if (phones_attributes != null && !phones_attributes.isEmpty()) {
				contact_info_attributes.setPhones_attributes(phones_attributes);
			}
		} catch (Exception e) {
			LOGGER.error("ERROR: " + e.getMessage());
			throw new Exception(e.getMessage());
		}
		return contact_info_attributes;
	}
}
