package com.connbenefits.domain;

import java.io.Serializable;

/**
 * Defines ProfileQuestion represents Profile and UserAnswer records
 * 
 * @author m1033511
 */
public class ProfileQuestion implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 2551446582602765857L;
	
	private Profile profile;//Represents Profile details
	private UserAnswer userAnswer;//Represents UserAnswer details

	public Profile getProfile() {
		return profile;
	}

	public UserAnswer getUserAnswer() {
		return userAnswer;
	}

	public void setProfile(Profile profile) {
		this.profile = profile;
	}

	public void setUserAnswer(UserAnswer userAnswer) {
		this.userAnswer = userAnswer;
	}

}
