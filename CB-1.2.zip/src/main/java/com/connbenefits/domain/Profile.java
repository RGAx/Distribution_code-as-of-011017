package com.connbenefits.domain;

import java.io.Serializable;
import java.util.Date;

/**
 * Defines the profile fields.
 * 
 * @author M1030133
 *
 */
public class Profile extends BaseDomain implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private int profileId; // Represents profile id
	private String encryptedId; // Represents encrypted id

	private String firstName; // Represents first name
	private String lastName; // Represents last name
	private String gender; // Represents gender
	private Date dateOfBirth; // Represents date of birth

	private String phoneNumber; // Represents the phone number
	private String zipCode; // Represents the zip code
	private String state; // Represents the state
	private String city; // Represents the city
	private String emailAddress; // Represents email address

	private long annualIncome; // Represents the annual income for user.
	private int pinneyStatusFlag; // Represents profile status flag
	private String ebixMonthlyEstimate; // Represents ebix monthly estimate
	private long coverage; // Represents coverage
	private int term; // Represents term
	private Date lastPinneyProcessedDate; // Represents last pinney processed
											// date
	private int restProfileId; // Represents rest profile id
	private String strAnnualIncome; // Represents annual income in string format
	private String source; //Represents Source in String format only for Connected Benefits

	public int getProfileId() {
		return profileId;
	}

	public void setProfileId(int profileId) {
		this.profileId = profileId;
	}

	public String getEncryptedId() {
		return encryptedId;
	}

	public void setEncryptedId(String encryptedId) {
		this.encryptedId = encryptedId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public Date getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getZipCode() {
		return zipCode;
	}

	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getEmailAddress() {
		return emailAddress;
	}

	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	public long getAnnualIncome() {
		return annualIncome;
	}

	public void setAnnualIncome(long annualIncome) {
		this.annualIncome = annualIncome;
	}

	public int getPinneyStatusFlag() {
		return pinneyStatusFlag;
	}

	public void setPinneyStatusFlag(int pinneyStatusFlag) {
		this.pinneyStatusFlag = pinneyStatusFlag;
	}

	public String getEbixMonthlyEstimate() {
		return ebixMonthlyEstimate;
	}

	public void setEbixMonthlyEstimate(String ebixMonthlyEstimate) {
		this.ebixMonthlyEstimate = ebixMonthlyEstimate;
	}

	public long getCoverage() {
		return coverage;
	}

	public void setCoverage(long coverage) {
		this.coverage = coverage;
	}

	public int getTerm() {
		return term;
	}

	public void setTerm(int term) {
		this.term = term;
	}

	public Date getLastPinneyProcessedDate() {
		return lastPinneyProcessedDate;
	}

	public void setLastPinneyProcessedDate(Date lastPinneyProcessedDate) {
		this.lastPinneyProcessedDate = lastPinneyProcessedDate;
	}

	public int getRestProfileId() {
		return restProfileId;
	}

	public void setRestProfileId(int restProfileId) {
		this.restProfileId = restProfileId;
	}

	public String getStrAnnualIncome() {
		return strAnnualIncome;
	}

	public void setStrAnnualIncome(String strAnnualIncome) {
		this.strAnnualIncome = strAnnualIncome;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	@Override
	public String toString() {
		return "Profile [profileId=" + profileId + ", encryptedId="
				+ encryptedId + ", firstName=" + firstName + ", lastName="
				+ lastName + ", gender=" + gender + ", dateOfBirth="
				+ dateOfBirth + ", phoneNumber=" + phoneNumber + ", zipCode="
				+ zipCode + ", state=" + state + ", city=" + city
				+ ", emailAddress=" + emailAddress + ", annualIncome="
				+ annualIncome + ", pinneyStatusFlag=" + pinneyStatusFlag
				+ ", ebixMonthlyEstimate=" + ebixMonthlyEstimate
				+ ", coverage=" + coverage + ", term=" + term
				+ ", lastPinneyProcessedDate=" + lastPinneyProcessedDate
				+ ", restProfileId=" + restProfileId + ", strAnnualIncome="
				+ strAnnualIncome + ", source=" + source + "]";
	}

}
