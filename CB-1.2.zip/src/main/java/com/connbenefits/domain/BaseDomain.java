package com.connbenefits.domain;

import java.util.Date;

/**
 * Defines the common attributes that can be extended from other domains.
 * 
 * @author M1030133
 *
 */
public class BaseDomain {
	private String createdBy; // Represents created by
	private Date createdDate; // Represents created date
	private String updatedBy; // Represents updated by
	private Date updatedDate; // Represents updated date

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public Date getUpdatedDate() {
		return updatedDate;
	}

	public void setUpdatedDate(Date updatedDate) {
		this.updatedDate = updatedDate;
	}
}
