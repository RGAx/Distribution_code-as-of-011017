package com.connbenefits.domain.rest;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;

/**
 * Defines connection details
 * 
 * @author M1030133
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class ExtJourney {
	private UserProfile userProfile; // Represents user infos

	public UserProfile getUserProfile() {
		return userProfile;
	}

	public void setUserProfile(UserProfile userProfile) {
		this.userProfile = userProfile;
	}

	@Override
	public String toString() {
		return "ExtJourney [userProfile=" + userProfile + "]";
	}

}
