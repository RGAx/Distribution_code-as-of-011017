package com.connbenefits.domain.rest;

/**
 * Defines the basic fields for json request.
 * 
 * @author M1030133
 *
 */
public class BasicInfo {
	private String firstName; // Represents first name
	private String lastName; // Represents last name
	private String gender; // Represents gender
	private String dateOfBirth; // Represents date of birth

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	@Override
	public String toString() {
		return "BasicInfo [firstName=" + firstName + ", lastName=" + lastName
				+ ", gender=" + gender + ", dateOfBirth=" + dateOfBirth + "]";
	}

}
