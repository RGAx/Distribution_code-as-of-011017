package com.connbenefits.domain.rest;

/**
 * Defines the contact attributes.
 * 
 * @author M1030133
 *
 */
public class ContactInfo {
	private String phoneNumber; // Represents the phone number
	private String zipCode; // Represents the zip code
	private String stateCode; // Represents the state
	private String city; // Represents the city
	private String emailAddress; // Represents email address

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getZipCode() {
		return zipCode;
	}

	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}

	public String getStateCode() {
		return stateCode;
	}

	public void setStateCode(String stateCode) {
		this.stateCode = stateCode;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getEmailAddress() {
		return emailAddress;
	}

	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	@Override
	public String toString() {
		return "ContactInfo [phoneNumber=" + phoneNumber + ", zipCode="
				+ zipCode + ", stateCode=" + stateCode + ", city=" + city
				+ ", emailAddress=" + emailAddress + "]";
	}

}
