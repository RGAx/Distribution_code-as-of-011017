package com.connbenefits.domain.rest;

/**
 * Defines the response scenario for the REST API for POST.
 * 
 * @author M1030133
 *
 */
public class SuccessResponse {
	private String status; // Defines the code value for JSON response
	private Payload payload; // Defines the content value for JSON response

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Payload getPayload() {
		return payload;
	}

	public void setPayload(Payload payload) {
		this.payload = payload;
	}

	public SuccessResponse(String status, Payload payload) {
		super();
		this.status = status;
		this.payload = payload;
	}

}
