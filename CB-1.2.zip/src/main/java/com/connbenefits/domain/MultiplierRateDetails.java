/**
 * 
 */
package com.connbenefits.domain;

/**
 * @author M1029563
 * This class is used to persist the MULTIPLIERRATETABLE data in to a LIST<MULTIPLIERRATEDETAILS> to place the LIST in the context.
 *
 */
public class MultiplierRateDetails {
	
	private int rateId;
	
	private int Age;
	
	private int recommendedRange;
	
	private int upperRange;
	
	private int lowerRange;
	
	private int scaleFactor;
	
	private int statusFlag;
	
	private String productUsed;

	public int getRateId() {
		return rateId;
	}

	public void setRateId(int rateId) {
		this.rateId = rateId;
	}

	public int getAge() {
		return Age;
	}

	public void setAge(int age) {
		Age = age;
	}

	public int getRecommendedRange() {
		return recommendedRange;
	}

	public void setRecommendedRange(int recommendedRange) {
		this.recommendedRange = recommendedRange;
	}

	public int getUpperRange() {
		return upperRange;
	}

	public void setUpperRange(int upperRange) {
		this.upperRange = upperRange;
	}

	public int getLowerRange() {
		return lowerRange;
	}

	public void setLowerRange(int lowerRange) {
		this.lowerRange = lowerRange;
	}

	public int getScaleFactor() {
		return scaleFactor;
	}

	public void setScaleFactor(int scaleFactor) {
		this.scaleFactor = scaleFactor;
	}

	public int getStatusFlag() {
		return statusFlag;
	}

	public void setStatusFlag(int statusFlag) {
		this.statusFlag = statusFlag;
	}

	public String getProductUsed() {
		return productUsed;
	}

	public void setProductUsed(String productUsed) {
		this.productUsed = productUsed;
	}

	@Override
	public String toString() {
		return "MultiplierRateDetails [rateId=" + rateId + ", Age=" + Age
				+ ", recommendedRange=" + recommendedRange + ", upperRange="
				+ upperRange + ", lowerRange=" + lowerRange + ", scaleFactor="
				+ scaleFactor + ", statusFlag=" + statusFlag + ", productUsed="
				+ productUsed + "]";
	}

}
