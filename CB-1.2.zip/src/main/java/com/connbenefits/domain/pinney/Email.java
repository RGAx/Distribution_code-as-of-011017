package com.connbenefits.domain.pinney;

/**
 * Used for pinney request construction
 * 
 * @author M1030133
 *
 */
public class Email {

	private String value;

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}
}
