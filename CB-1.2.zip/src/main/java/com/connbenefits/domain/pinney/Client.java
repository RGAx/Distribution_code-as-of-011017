package com.connbenefits.domain.pinney;

import java.util.List;

/**
 * Used for pinney request construction
 * 
 * @author M1030133
 *
 */
public class Client {

	private boolean active;
	private String birth;
	private List<Policies> cases_attributes;
	private Contact_info contact_info_attributes;
	private Financial_info financial_info_attributes;
	private String first_name;
	private String gender;// Male! Female
	private Health_info health_info_attributes;
	private String last_name;
	private int profile_id;
	private String source;

	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	public String getBirth() {
		return birth;
	}

	public void setBirth(String birth) {
		this.birth = birth;
	}

	public List<Policies> getCases_attributes() {
		return cases_attributes;
	}

	public void setCases_attributes(List<Policies> cases_attributes) {
		this.cases_attributes = cases_attributes;
	}

	public Contact_info getContact_info_attributes() {
		return contact_info_attributes;
	}

	public void setContact_info_attributes(Contact_info contact_info_attributes) {
		this.contact_info_attributes = contact_info_attributes;
	}

	public Financial_info getFinancial_info_attributes() {
		return financial_info_attributes;
	}

	public void setFinancial_info_attributes(
			Financial_info financial_info_attributes) {
		this.financial_info_attributes = financial_info_attributes;
	}

	public String getFirst_name() {
		return first_name;
	}

	public void setFirst_name(String first_name) {
		this.first_name = first_name;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public Health_info getHealth_info_attributes() {
		return health_info_attributes;
	}

	public void setHealth_info_attributes(Health_info health_info_attributes) {
		this.health_info_attributes = health_info_attributes;
	}

	public String getLast_name() {
		return last_name;
	}

	public void setLast_name(String last_name) {
		this.last_name = last_name;
	}

	public int getProfile_id() {
		return profile_id;
	}

	public void setProfile_id(int profile_id) {
		this.profile_id = profile_id;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

}
