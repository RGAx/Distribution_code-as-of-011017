package com.connbenefits.domain.pinney;

public class NotesAttribute {
	private boolean confidential = true;
	private int note_type_id = 1;
	private String text;
	
	/*private boolean snuff;
	private int tobacco_chew_per_day;
	private int tobacco_snuff_per_day;
	private int tobacco_smoke_per_day;
	private boolean test_negative;
	private String relationship;
	private boolean license_suspended_last_5_yrs;
	private boolean drunk_driving;
	private boolean reckless_driving;
	private boolean license_revoked;
	private boolean more_than_one_accident;
	private boolean moving_violations_last_5_yrs;
	private String alcohol_recent_treatment;
	private String drug_abuse_recent_treatment;
	private boolean drug_abuse;
	private String am_best_rating;
	private boolean multiple_sclerosis;
	private boolean alzheimer_disease;
	private boolean basel_cell_skin_cancer;
	private boolean cancer;*/

	public boolean isConfidential() {
		return confidential;
	}

	public void setConfidential(boolean confidential) {
		this.confidential = confidential;
	}

	public int getNote_type_id() {
		return note_type_id;
	}

	public void setNote_type_id(int note_type_id) {
		this.note_type_id = note_type_id;
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}
}