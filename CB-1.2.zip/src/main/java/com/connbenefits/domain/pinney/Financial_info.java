package com.connbenefits.domain.pinney;

/**
 * Used for pinney request construction
 * 
 * @author M1030133
 *
 */
public class Financial_info {
	private int annual_income;

	public int getAnnual_income() {
		return annual_income;
	}

	public void setAnnual_income(int annual_income) {
		this.annual_income = annual_income;
	}

}
