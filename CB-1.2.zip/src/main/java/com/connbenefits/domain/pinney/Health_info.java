package com.connbenefits.domain.pinney;


/**
 * Used for pinney request construction
 * 
 * @author M1030133
 *
 */
public class Health_info {

	private String birth;// String
	private boolean gender;// boolean
	private boolean smoker; // smoker

	public String getBirth() {
		return birth;
	}

	public void setBirth(String birth) {
		this.birth = birth;
	}

	public boolean isGender() {
		return gender;
	}

	public void setGender(boolean gender) {
		this.gender = gender;
	}

	public boolean isSmoker() {
		return smoker;
	}

	public void setSmoker(boolean smoker) {
		this.smoker = smoker;
	}

}
