/**
 * 
 */
package com.connbenefits.domain;

/**
 * @author M1029563
 * This class is used as domain class Object for Slider Page the MIN,MAX, Ideal Coverage Range values are mapped to Form SliderFaceValue object and returns a Model object to 
 * the View SliderPage.
 *
 */
public class SliderFaceValue {
	
	
	private int sliderMinValue;
	
	private int sliderMaxValue;
	
	private int lowercoverageRange;
	
	private int uppercoverageRange;
	
	private int recommCoverageRange;
	
	private int scaleFactor;
	
	private int multiplierlowerRange;
	
	private int multiplierupperRange;
	
	private int multiplierrecommRange;
	

	public int getSliderMinValue() {
		return sliderMinValue;
	}

	public void setSliderMinValue(int sliderMinValue) {
		this.sliderMinValue = sliderMinValue;
	}

	public int getSliderMaxValue() {
		return sliderMaxValue;
	}

	public void setSliderMaxValue(int sliderMaxValue) {
		this.sliderMaxValue = sliderMaxValue;
	}

	public int getLowercoverageRange() {
		return lowercoverageRange;
	}

	public void setLowercoverageRange(int lowercoverageRange) {
		this.lowercoverageRange = lowercoverageRange;
	}

	public int getUppercoverageRange() {
		return uppercoverageRange;
	}

	public void setUppercoverageRange(int uppercoverageRange) {
		this.uppercoverageRange = uppercoverageRange;
	}

	public int getRecommCoverageRange() {
		return recommCoverageRange;
	}

	public void setRecommCoverageRange(int recommCoverageRange) {
		this.recommCoverageRange = recommCoverageRange;
	}

	public int getScaleFactor() {
		return scaleFactor;
	}

	public void setScaleFactor(int scaleFactor) {
		this.scaleFactor = scaleFactor;
	}

	public int getMultiplierlowerRange() {
		return multiplierlowerRange;
	}

	public void setMultiplierlowerRange(int multiplierlowerRange) {
		this.multiplierlowerRange = multiplierlowerRange;
	}

	public int getMultiplierupperRange() {
		return multiplierupperRange;
	}

	public void setMultiplierupperRange(int multiplierupperRange) {
		this.multiplierupperRange = multiplierupperRange;
	}

	public int getMultiplierrecommRange() {
		return multiplierrecommRange;
	}

	public void setMultiplierrecommRange(int multiplierrecommRange) {
		this.multiplierrecommRange = multiplierrecommRange;
	}

	@Override
	public String toString() {
		return "SliderFaceValue [sliderMinValue=" + sliderMinValue
				+ ", sliderMaxValue=" + sliderMaxValue
				+ ", lowercoverageRange=" + lowercoverageRange
				+ ", uppercoverageRange=" + uppercoverageRange
				+ ", recommCoverageRange=" + recommCoverageRange
				+ ", scaleFactor=" + scaleFactor + ", multiplierlowerRange="
				+ multiplierlowerRange + ", multiplierupperRange="
				+ multiplierupperRange + ", multiplierrecommRange="
				+ multiplierrecommRange + "]";
	}

}
