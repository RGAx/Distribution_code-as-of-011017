package com.connbenefits.constants;

/**
 * Used to define the constant fields.
 * 
 * @author M1030133
 *
 */
public class ApplicationConstants {
	public static final int SUCCESS_CODE = 200;
	public static final String SUCCESS_STATUS = "SUCCESS";

	public static final String FAILED_STATUS = "FAILED";
	public static final int FALIURE_CODE_404 = 404;

	public static final int REST_PROFILE_ID = 545;

	public static final String PROFILE_NOT_VALID_CODE = "CODE500";
	public static final String PROFILE_NOT_VALID_MESSAGE = "The profileId is not valid!";

	public static final String ALL_MANDATORY_FIELDS_EMPTY_CODE = "CODE501";
	public static final String ALL_MANDATORY_FIELDS_EMPTY_MESSAGE = "The mandatory fields firstName, lastName, emailAddress, phoneNumber and stateCode are missing!";

	public static final String FIRSTNAME_LASTNAME_EMAILADDRESS_PHONENUMBER_EMPTY_CODE = "CODE502";
	public static final String FIRSTNAME_LASTNAME_EMAILADDRESS_PHONENUMBER_EMPTY_MESSAGE = "The mandatory fields firstName, lastName, emailAddress and phoneNumber are missing!";

	public static final String FIRSTNAME_LASTNAME_PHONENUMBER_STATECODE_EMPTY_CODE = "CODE503";
	public static final String FIRSTNAME_LASTNAME_PHONENUMBER_STATECODE_EMPTY_MESSAGE = "The mandatory fields firstName, lastName, phoneNumber and stateCode are missing!";

	public static final String FIRSTNAME_LASTNAME_EMAILADDRESS_STATECODE_EMPTY_CODE = "CODE504";
	public static final String FIRSTNAME_LASTNAME_EMAILADDRESS_STATECODE_EMPTY_MESSAGE = "The mandatory fields firstName, lastName, emailAddress and stateCode are missing!";

	public static final String FIRSTNAME_EMAILADDRESS_PHONENUMBER_STATECODE_EMPTY_CODE = "CODE505";
	public static final String FIRSTNAME_EMAILADDRESS_PHONENUMBER_STATECODE_EMPTY_MESSAGE = "The mandatory fields firstName, emailAddress, phoneNumber and stateCode are missing!";

	public static final String LASTNAME_EMAILADDRESS_PHONENUMBER_STATECODE_EMPTY_CODE = "CODE506";
	public static final String LASTNAME_EMAILADDRESS_PHONENUMBER_STATECODE_EMPTY_MESSAGE = "The mandatory fields lastName, emailAddress, phoneNumber and stateCode are missing!";

	public static final String FIRSTNAME_LASTNAME_EMAILADDRESS_EMPTY_CODE = "CODE507";
	public static final String FIRSTNAME_LASTNAME_EMAILADDRESS_EMPTY_MESSAGE = "The mandatory fields firstName, lastName and emailAddress are missing!";

	public static final String FIRSTNAME_LASTNAME_PHONENUMBER_EMPTY_CODE = "CODE508";
	public static final String FIRSTNAME_LASTNAME_PHONENUMBER_EMPTY_MESSAGE = "The mandatory fields firstName, lastName and phoneNumber are missing!";

	public static final String FIRSTNAME_LASTNAME_STATECODE_EMPTY_CODE = "CODE509";
	public static final String FIRSTNAME_LASTNAME_STATECODE_EMPTY_MESSAGE = "The mandatory fields firstName, lastName and stateCode are missing!";

	public static final String FIRSTNAME_EMAILADDRESS_PHONENUMBER_EMPTY_CODE = "CODE510";
	public static final String FIRSTNAME_EMAILADDRESS_PHONENUMBER_EMPTY_MESSAGE = "The mandatory fields firstName, emailAddress and phoneNumber are missing!";

	public static final String FIRSTNAME_EMAILADDRESS_STATECODE_EMPTY_CODE = "CODE511";
	public static final String FIRSTNAME_EMAILADDRESS_STATECODE_EMPTY_MESSAGE = "The mandatory fields firstName, emailAddress and stateCode are missing!";

	public static final String FIRSTNAME_PHONENUMBER_STATECODE_EMPTY_CODE = "CODE512";
	public static final String FIRSTNAME_PHONENUMBER_STATECODE_EMPTY_MESSAGE = "The mandatory fields firstName, phoneNumber and stateCode are missing!";

	public static final String LASTNAME_EMAILADDRESS_PHONENUMBER_EMPTY_CODE = "CODE513";
	public static final String LASTNAME_EMAILADDRESS_PHONENUMBER_EMPTY_MESSAGE = "The mandatory fields lastName, emailAddress and phoneNumber are missing!";

	public static final String LASTNAME_EMAILADDRESS_STATECODE_EMPTY_CODE = "CODE514";
	public static final String LASTNAME_EMAILADDRESS_STATECODE_EMPTY_MESSAGE = "The mandatory fields lastName, emailAddress and stateCode are missing!";

	public static final String LASTNAME_PHONENUMBER_STATECODE_EMPTY_CODE = "CODE515";
	public static final String LASTNAME_PHONENUMBER_STATECODE_EMPTY_MESSAGE = "The mandatory fields lastName, phoneNumber and stateCode are missing!";

	public static final String EMAILADDRESS_PHONENUMBER_STATECODE_EMPTY_CODE = "CODE516";
	public static final String EMAILADDRESS_PHONENUMBER_STATECODE_EMPTY_MESSAGE = "The mandatory fields emailAddress, phoneNumber and stateCode are missing!";

	public static final String FIRSTNAME_LASTNAME_EMPTY_CODE = "CODE517";
	public static final String FIRSTNAME_LASTNAME_EMPTY_MESSAGE = "The mandatory fields firstName and lastName are missing!";

	public static final String FIRSTNAME_EMAILADDRESS_EMPTY_CODE = "CODE518";
	public static final String FIRSTNAME_EMAILADDRESS_EMPTY_MESSAGE = "The mandatory fields firstName and emailAddress are missing!";

	public static final String FIRSTNAME_PHONENUMBER_EMPTY_CODE = "CODE519";
	public static final String FIRSTNAME_PHONENUMBER_EMPTY_MESSAGE = "The mandatory fields firstName and phoneNumber are missing!";

	public static final String FIRSTNAME_STATECODE_EMPTY_CODE = "CODE520";
	public static final String FIRSTNAME_STATECODE_EMPTY_MESSAGE = "The mandatory fields firstName and stateCode are missing!";

	public static final String LASTNAME_EMAILADDRESS_EMPTY_CODE = "CODE521";
	public static final String LASTNAME_EMAILADDRESS_EMPTY_MESSAGE = "The mandatory fields lastName and emailAddress are missing!";

	public static final String LASTNAME_PHONENUMBER_EMPTY_CODE = "CODE522";
	public static final String LASTNAME_PHONENUMBER_EMPTY_MESSAGE = "The mandatory fields lastName and phoneNumber are missing!";

	public static final String LASTNAME_STATECODE_EMPTY_CODE = "CODE523";
	public static final String LASTNAME_STATECODE_EMPTY_MESSAGE = "The mandatory fields lastName and stateCode are missing!";

	public static final String EMAILADDRESS_PHONENUMBER_EMPTY_CODE = "CODE524";
	public static final String EMAILADDRESS_PHONENUMBER_EMPTY_MESSAGE = "The mandatory fields emailAddress and phoneNumber are missing!";

	public static final String EMAILADDRESS_STATECODE_EMPTY_CODE = "CODE525";
	public static final String EMAILADDRESS_STATECODE_EMPTY_MESSAGE = "The mandatory fields emailAddress and stateCode are missing!";

	public static final String PHONENUMBER_STATECODE_EMPTY_CODE = "CODE526";
	public static final String PHONENUMBER_STATECODE_EMPTY_MESSAGE = "The mandatory fields phoneNumber and stateCode are missing!";

	public static final String EMAIL_EMPTY_CODE = "CODE527";
	public static final String EMAIL_EMPTY_MESSAGE = "The mandatory field emailAddress is missing!";

	public static final String FIRST_NAME_EMPTY_CODE = "CODE528";
	public static final String FIRST_NAME_EMPTY_MESSAGE = "The mandatory field firstName is missing!";

	public static final String LAST_NAME_EMPTY_CODE = "CODE529";
	public static final String LAST_NAME_EMPTY_MESSAGE = "The mandatory field lastName is missing!";

	public static final String PHONE_NUMBER_EMPTY_CODE = "CODE530";
	public static final String PHONE_NUMBER_EMPTY_MESSAGE = "The mandatory field phoneNumber is missing!";

	public static final String STATE_CODE_EMPTY_CODE = "CODE531";
	public static final String STATE_CODE_EMPTY_MESSAGE = "The mandatory field stateCode is missing!";

	public static final String EMAIL_NOT_VALID_CODE = "CODE532";
	public static final String EMAIL_NOT_VALID_MESSAGE = "The emailAddress is not valid!";

	public static final String PHONE_NUMBER_NOT_VALID_CODE = "CODE533";
	public static final String PHONE_NUMBER_NOT_VALID_MESSAGE = "The phoneNumber is not valid!";

	public static final String ZIP_CODE_NOT_VALID_CODE = "CODE534";
	public static final String ZIP_CODE_NOT_VALID_MESSAGE = "The zipCode is not valid!";

	public static final String DOB_NOT_VALID_CODE = "CODE535";
	public static final String DOB_NOT_VALID_MESSAGE = "The dateOfBirth is not valid!";

	public static final String GENDER_NOT_VALID_CODE = "CODE536";
	public static final String GENDER_NOT_VALID_MESSAGE = "The gender is not valid!";

	public static final String REQUEST_NOT_VALID_CODE = "CODE345";
	public static final String REQUEST_NOT_VALID_MESSAGE = "Invalid json request!";

	public static final String PAGE_FROM = "pageFrom";

	// EBIX service
	public static final boolean BreakDownPremiums = false;
	public static final boolean CalcToPenny = true;
	public static final boolean DisplayProductClasses = false;
	public static final boolean GetCompanyInfo = true;
	public static final boolean ShowCurrentRates = false;
	public static final boolean ShowRemovedProducts = true;
	public static final boolean ShowProdInfoOnRemoval = true;
	public static final boolean ShowProdInfoOnly = false;
	public static final boolean ShowPremiumsOnly = false;
	public static final boolean Calc1StYearModal = true;
	
	public static final String REQUEST_CALLBACK = "requestCallback";
	public static final String CALLBACK_PAGE = "callbackPage";
	public static final String FAILURE_PAGE = "failurePage";
	public static final String ERROR = "error";
	public static final String SLIDER_PAGE = "sliderPage";
	public static final String SLIDER_PAGEFROM = "sliderPageFrom";
	public static final String SOURCE_ERROR = "sourceerror";
	
}
