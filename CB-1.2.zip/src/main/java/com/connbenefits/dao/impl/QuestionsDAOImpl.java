package com.connbenefits.dao.impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.connbenefits.common.logger.ExtJourneyLogger;
import com.connbenefits.common.logger.LogFactory;
import com.connbenefits.constants.QueryConstants;
import com.connbenefits.dao.QuestionsDAO;
import com.connbenefits.domain.ProfileQuestion;
import com.connbenefits.domain.UserAnswer;
import com.connbenefits.exception.DAOException;

/**
 * used for implementing the dao like loading & updating the userAnswer, updating the profile 
 * 
 * @author m1033511
 */
@Repository
public class QuestionsDAOImpl implements QuestionsDAO {

	private static final ExtJourneyLogger logger = LogFactory
			.getInstance(QuestionsDAOImpl.class);
	
	@Autowired
	private JdbcTemplate jdbcTemplate;

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	/*
	 * implemented for saving/updating the profile in database
	 * 
	 * @see
	 * com.connbenefits.services.QuestionsDAO#saveUpdateUserAnswer(com.connbenefits
	 * .domain.ProfileQuestion)
	 */
	@Override
	public int saveUpdateUserAnswer(ProfileQuestion profileQuestion,boolean flag)
			throws DAOException {

		UserAnswer userAnswer = profileQuestion.getUserAnswer();
		int profileId = profileQuestion.getProfile().getProfileId();
		userAnswer.setProfileId(profileId);

		int count = 0;

		if (flag) {
			try {
				Object[] args = new Object[] { userAnswer.getProfileId(),
						userAnswer.getSmokingStatus(),
						userAnswer.getDependentsStatus(),
						userAnswer.getDependentsCount(),
						userAnswer.getHealthStatus(),
						new java.sql.Timestamp(new Date().getTime()),
						profileQuestion.getProfile().getFirstName(), new java.sql.Timestamp(new Date().getTime())};
				jdbcTemplate.update(QueryConstants.SAVE_USER_ANSWER, args);
			} catch (DataAccessException e) {
				logger.error("ERROR : " + e.getMessage());
				throw new DAOException(e.getMessage());
			}
			

		} else {
			try {
				Object[] args = new Object[] { userAnswer.getSmokingStatus(),
						userAnswer.getDependentsStatus(),
						userAnswer.getDependentsCount(),
						userAnswer.getHealthStatus(),
						new java.sql.Timestamp(new Date().getTime()),
						profileQuestion.getProfile().getFirstName(),
						userAnswer.getProfileId() };
				jdbcTemplate.update(QueryConstants.UPDATE_USER_ANSWER, args);
			} catch (DataAccessException e) {
				logger.error("ERROR : " + e.getMessage());
				throw new DAOException(e.getMessage());
			}
		}

		return count;
	}

	/*
	 * implemented for saving/updating the profile in database
	 * 
	 * @see
	 * com.connbenefits.services.QuestionsDAO#loadUserAnswer(com.connbenefits.domain
	 * .ProfileQuestion)
	 */
	@Override
	public UserAnswer loadUserAnswer(int profileId) throws DAOException {
		
		UserAnswer userAnswer;
		try{
			
			userAnswer = jdbcTemplate.queryForObject(QueryConstants.LOAD_USER_ANSWER, new Object[] {profileId}, new RowMapper<UserAnswer>(){

				@Override
				public UserAnswer mapRow(ResultSet rs, int rowNum) throws SQLException {
					UserAnswer userAnswer = new UserAnswer();
					
					userAnswer.setUserAnswerId(rs.getInt("USER_ANSWER_ID"));
					userAnswer.setProfileId(rs.getInt("PROFILE_ID"));
					userAnswer.setSmokingStatus(rs.getInt("SMOKING_STATUS"));
					userAnswer.setDependentsStatus(rs.getInt("DEPENDENTS_STATUS"));
					userAnswer.setDependentsCount(rs.getInt("DEPENDENTS_COUNT"));
					userAnswer.setHealthStatus(rs.getString("HEALTH_STATUS"));
					userAnswer.setCreatedDate(rs.getDate("CREATED_DATE"));
					userAnswer.setCreatedBy(rs.getString("CREATED_BY"));
					userAnswer.setUpdatedDate(rs.getDate("UPDATED_DATE"));
					userAnswer.setUpdatedBy(rs.getString("UPDATED_BY"));
				
					return userAnswer;
				}
				
			});
		} catch (EmptyResultDataAccessException e) {
			logger.error("ERROR : " + e.getMessage());
			return null;
		} catch (DataAccessException e) {
			logger.error("ERROR : " + e.getMessage());
			throw new DAOException(e.getMessage());
		}
		
		return userAnswer;
		}
	}
