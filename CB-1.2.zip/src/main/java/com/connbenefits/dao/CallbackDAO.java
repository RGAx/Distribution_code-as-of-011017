package com.connbenefits.dao;

import com.connbenefits.domain.Profile;
import com.connbenefits.domain.ProfileCustomerCallback;
import com.connbenefits.exception.DAOException;

/**
 * Used for defining the operations such as saving the ProfileCustomerCallback,
 * into the db
 * 
 * @author m1033511
 */
public interface CallbackDAO {

	public int saveCallbackDetails(ProfileCustomerCallback profileCustomerCallback,Profile profile) throws DAOException;
}
