/**
 * 
 */
package com.connbenefits.dao;

import java.util.List;

import com.connbenefits.domain.MultiplierRateDetails;
import com.connbenefits.exception.DAOException;

/**
 * @author M1029563
 *
 */
public interface GenericDAO {
	
	public List<MultiplierRateDetails> loadMultiplierrateDetails() throws DAOException;

}
