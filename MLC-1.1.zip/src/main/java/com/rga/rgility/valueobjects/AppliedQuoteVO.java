/**
 * 
 */
package com.rga.rgility.valueobjects;

import java.util.List;

/**
 * @author M1030133
 *
 */
public class AppliedQuoteVO implements java.io.Serializable {

	private static final long serialVersionUID = 1L;

	private int profileId;
	private int quoteId;
	private double coverage;
	private int term;
	private double bestPremiumPerMonth;
	private double standardPremiumPerMonth;
	private String systemInFocus;
	private String appliedStatus;
	private double standardCoverage;
	private List<PremiumsInfoVO> productPremiumsCoveragesList;
	
	public List<PremiumsInfoVO> getProductPremiumsCoveragesList() {
		return productPremiumsCoveragesList;
	}

	public void setProductPremiumsCoveragesList(List<PremiumsInfoVO> productPremiumsCoveragesList) {
		this.productPremiumsCoveragesList = productPremiumsCoveragesList;
	}

	public double getStandardCoverage() {
		return standardCoverage;
	}

	public void setStandardCoverage(double standardCoverage) {
		this.standardCoverage = standardCoverage;
	}

	public int getProfileId() {
		return profileId;
	}

	public void setProfileId(int profileId) {
		this.profileId = profileId;
	}

	public int getQuoteId() {
		return quoteId;
	}

	public void setQuoteId(int quoteId) {
		this.quoteId = quoteId;
	}

	public double getCoverage() {
		return coverage;
	}

	public void setCoverage(double coverage) {
		this.coverage = coverage;
	}

	public int getTerm() {
		return term;
	}

	public void setTerm(int term) {
		this.term = term;
	}

	public double getBestPremiumPerMonth() {
		return bestPremiumPerMonth;
	}

	public void setBestPremiumPerMonth(double bestPremiumPerMonth) {
		this.bestPremiumPerMonth = bestPremiumPerMonth;
	}

	public double getStandardPremiumPerMonth() {
		return standardPremiumPerMonth;
	}

	public void setStandardPremiumPerMonth(double standardPremiumPerMonth) {
		this.standardPremiumPerMonth = standardPremiumPerMonth;
	}

	public String getSystemInFocus() {
		return systemInFocus;
	}

	public void setSystemInFocus(String systemInFocus) {
		this.systemInFocus = systemInFocus;
	}

	public String getAppliedStatus() {
		return appliedStatus;
	}

	public void setAppliedStatus(String appliedStatus) {
		this.appliedStatus = appliedStatus;
	}

}
