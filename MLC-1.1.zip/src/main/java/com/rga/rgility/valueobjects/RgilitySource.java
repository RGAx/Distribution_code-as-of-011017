/**
 * 
 */
package com.rga.rgility.valueobjects;

import java.util.List;

/**
 * @author M1029563
 * 
 */
public class RgilitySource {

	private String riskClass;
	
	public String getRiskClass() {
		return riskClass;
	}

	public void setRiskClass(String riskClass) {
		this.riskClass = riskClass;
	}

	private String premiumQuote;

	private String productName;

	private String term;

	private String carrier;

	private String coverageAmount;

	private String issueState;

	private String primaryEmail;

	private String branding;

	private String birthDate;

	private String birthState;

	private String firstName;

	private String lastName;

	private String middleName;

	private String gender;

	private CurrentAddress currentAddress;

	private String phoneNumber;

	private String ssn;

	private String maritalStatus;

	private String smokerStatus;

	private String usCitizen;

	private String driversLicenseNumber;

	private String noDriverLicense;

	private String isInsuredAPolicyOwner;

	private String existingInsurance;

	private String riderAccident;

	private int riderAccidentAmount;

	private String riderOther;

	private String riderOtherAmount;

	private String riderWOP;

	private String employerName;

	private String income;

	private String netWorth;

	private String distributionPartner;
	
	private String theme;
	
	private String beaconVendor;

	public String getTheme() {
		return theme;
	}

	public void setTheme(String theme) {
		this.theme = theme;
	}

	private List<PrimaryBeneficiaries> primaryBeneficiaries;

	private List<ContingentBeneficiaries> contingentBeneficiaries;

	private String recommendationEngineLeadId;

	public String getRecommendationEngineLeadId() {
		return recommendationEngineLeadId;
	}

	public void setRecommendationEngineLeadId(String recommendationEngineLeadId) {
		this.recommendationEngineLeadId = recommendationEngineLeadId;
	}

	public String getPremiumQuote() {
		return premiumQuote;
	}

	public void setPremiumQuote(String premiumQuote) {
		this.premiumQuote = premiumQuote;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getTerm() {
		return term;
	}

	public void setTerm(String term) {
		this.term = term;
	}

	public String getCarrier() {
		return carrier;
	}

	public void setCarrier(String carrier) {
		this.carrier = carrier;
	}

	public String getCoverageAmount() {
		return coverageAmount;
	}

	public void setCoverageAmount(String coverageAmount) {
		this.coverageAmount = coverageAmount;
	}

	public String getIssueState() {
		return issueState;
	}

	public void setIssueState(String issueState) {
		this.issueState = issueState;
	}

	public String getPrimaryEmail() {
		return primaryEmail;
	}

	public void setPrimaryEmail(String primaryEmail) {
		this.primaryEmail = primaryEmail;
	}

	public String getBranding() {
		return branding;
	}

	public void setBranding(String branding) {
		this.branding = branding;
	}

	public String getBirthDate() {
		return birthDate;
	}

	public void setBirthDate(String birthDate) {
		this.birthDate = birthDate;
	}

	public String getBirthState() {
		return birthState;
	}

	public void setBirthState(String birthState) {
		this.birthState = birthState;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getMiddleName() {
		return middleName;
	}

	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public CurrentAddress getCurrentAddress() {
		return currentAddress;
	}

	public void setCurrentAddress(CurrentAddress currentAddress) {
		this.currentAddress = currentAddress;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getSsn() {
		return ssn;
	}

	public void setSsn(String ssn) {
		this.ssn = ssn;
	}

	public String getMaritalStatus() {
		return maritalStatus;
	}

	public void setMaritalStatus(String maritalStatus) {
		this.maritalStatus = maritalStatus;
	}

	public String getSmokerStatus() {
		return smokerStatus;
	}

	public void setSmokerStatus(String smokerStatus) {
		this.smokerStatus = smokerStatus;
	}

	public String getUsCitizen() {
		return usCitizen;
	}

	public void setUsCitizen(String usCitizen) {
		this.usCitizen = usCitizen;
	}

	public String getDriversLicenseNumber() {
		return driversLicenseNumber;
	}

	public void setDriversLicenseNumber(String driversLicenseNumber) {
		this.driversLicenseNumber = driversLicenseNumber;
	}

	public String getNoDriverLicense() {
		return noDriverLicense;
	}

	public void setNoDriverLicense(String noDriverLicense) {
		this.noDriverLicense = noDriverLicense;
	}

	public String getIsInsuredAPolicyOwner() {
		return isInsuredAPolicyOwner;
	}

	public void setIsInsuredAPolicyOwner(String isInsuredAPolicyOwner) {
		this.isInsuredAPolicyOwner = isInsuredAPolicyOwner;
	}

	public String getExistingInsurance() {
		return existingInsurance;
	}

	public void setExistingInsurance(String existingInsurance) {
		this.existingInsurance = existingInsurance;
	}

	public String getRiderAccident() {
		return riderAccident;
	}

	public void setRiderAccident(String riderAccident) {
		this.riderAccident = riderAccident;
	}

	public int getRiderAccidentAmount() {
		return riderAccidentAmount;
	}

	public void setRiderAccidentAmount(int riderAccidentAmount) {
		this.riderAccidentAmount = riderAccidentAmount;
	}

	public String getRiderOther() {
		return riderOther;
	}

	public void setRiderOther(String riderOther) {
		this.riderOther = riderOther;
	}

	public String getRiderOtherAmount() {
		return riderOtherAmount;
	}

	public void setRiderOtherAmount(String riderOtherAmount) {
		this.riderOtherAmount = riderOtherAmount;
	}

	public String getRiderWOP() {
		return riderWOP;
	}

	public void setRiderWOP(String riderWOP) {
		this.riderWOP = riderWOP;
	}

	public String getEmployerName() {
		return employerName;
	}

	public void setEmployerName(String employerName) {
		this.employerName = employerName;
	}

	public String getIncome() {
		return income;
	}

	public void setIncome(String income) {
		this.income = income;
	}

	public String getNetWorth() {
		return netWorth;
	}

	public void setNetWorth(String netWorth) {
		this.netWorth = netWorth;
	}

	public List<PrimaryBeneficiaries> getPrimaryBeneficiaries() {
		return primaryBeneficiaries;
	}

	public void setPrimaryBeneficiaries(
			List<PrimaryBeneficiaries> primaryBeneficiaries) {
		this.primaryBeneficiaries = primaryBeneficiaries;
	}

	public List<ContingentBeneficiaries> getContingentBeneficiaries() {
		return contingentBeneficiaries;
	}

	public void setContingentBeneficiaries(
			List<ContingentBeneficiaries> contingentBeneficiaries) {
		this.contingentBeneficiaries = contingentBeneficiaries;
	}

	public String getDistributionPartner() {
		return distributionPartner;
	}

	public void setDistributionPartner(String distributionPartner) {
		this.distributionPartner = distributionPartner;
	}

	public String getBeaconVendor() {
		return beaconVendor;
	}

	public void setBeaconVendor(String beaconVendor) {
		this.beaconVendor = beaconVendor;
	}
	@Override
	public String toString() {
		return "RgilitySource [premiumQuote=" + premiumQuote + ", productName="
				+ productName + ", term=" + term + ", carrier=" + carrier
				+ ", coverageAmount=" + coverageAmount + ", issueState="
				+ issueState + ", primaryEmail=" + primaryEmail + ", branding="
				+ branding + ", birthDate=" + birthDate + ", birthState="
				+ birthState + ", firstName=" + firstName + ", lastName="
				+ lastName + ", middleName=" + middleName + ", gender="
				+ gender + ", currentAddress=" + currentAddress
				+ ", phoneNumber=" + phoneNumber + ", ssn=" + ssn
				+ ", maritalStatus=" + maritalStatus + ", smokerStatus="
				+ smokerStatus + ", usCitizen=" + usCitizen
				+ ", driversLicenseNumber=" + driversLicenseNumber
				+ ", noDriverLicense=" + noDriverLicense
				+ ", isInsuredAPolicyOwner=" + isInsuredAPolicyOwner
				+ ", existingInsurance=" + existingInsurance
				+ ", riderAccident=" + riderAccident + ", riderAccidentAmount="
				+ riderAccidentAmount + ", riderOther=" + riderOther
				+ ", riderOtherAmount=" + riderOtherAmount + ", riderWOP="
				+ riderWOP + ", employerName=" + employerName + ", income="
				+ income + ", netWorth=" + netWorth + ", distributionPartner="
				+ distributionPartner + ", primaryBeneficiaries="
				+ primaryBeneficiaries + ", contingentBeneficiaries="
				+ contingentBeneficiaries + ", beaconVendor=" + beaconVendor
				+ "]";
	}

}
