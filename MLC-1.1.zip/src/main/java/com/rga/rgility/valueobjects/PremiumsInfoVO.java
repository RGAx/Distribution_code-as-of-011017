package com.rga.rgility.valueobjects;
/**
 * @author M1036367
 * This VO object will used to store more than one product list from appliedquote or profile.
 * specifically for multicarriers.
 */
public class PremiumsInfoVO implements java.io.Serializable{

	private static final long serialVersionUID = 1L;
	
	private String productName;
	private int profileId;
	private double bestPremiumPerMonth;
	private double standardPremiumPerMonth;
	private double bestCoverage;
	private double standardCoverage;
	private int term;
	private int indexOfProduct;
	
	
	public int getIndexOfProduct() {
		return indexOfProduct;
	}
	public void setIndexOfProduct(int indexOfProduct) {
		this.indexOfProduct = indexOfProduct;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public int getProfileId() {
		return profileId;
	}
	public void setProfileId(int profileId) {
		this.profileId = profileId;
	}
	public double getBestPremiumPerMonth() {
		return bestPremiumPerMonth;
	}
	public void setBestPremiumPerMonth(double bestPremiumPerMonth) {
		this.bestPremiumPerMonth = bestPremiumPerMonth;
	}
	public double getStandardPremiumPerMonth() {
		return standardPremiumPerMonth;
	}
	public void setStandardPremiumPerMonth(double standardPremiumPerMonth) {
		this.standardPremiumPerMonth = standardPremiumPerMonth;
	}
	public double getBestCoverage() {
		return bestCoverage;
	}
	public void setBestCoverage(double bestCoverage) {
		this.bestCoverage = bestCoverage;
	}
	public double getStandardCoverage() {
		return standardCoverage;
	}
	public void setStandardCoverage(double standardCoverage) {
		this.standardCoverage = standardCoverage;
	}
	public int getTerm() {
		return term;
	}
	public void setTerm(int term) {
		this.term = term;
	}
}
