/**
 * 
 */
package com.rga.rgility.valueobjects;

/**
 * @author M1030133
 *
 */
public class Path implements java.io.Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private int pathId;
	private String pathDescription;

	public int getPathId() {
		return pathId;
	}

	public void setPathId(int pathId) {
		this.pathId = pathId;
	}

	public String getPathDescription() {
		return pathDescription;
	}

	public void setPathDescription(String pathDescription) {
		this.pathDescription = pathDescription;
	}

}
