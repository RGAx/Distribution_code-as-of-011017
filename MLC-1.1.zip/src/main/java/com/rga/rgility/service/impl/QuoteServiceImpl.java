/**
 * 
 */
package com.rga.rgility.service.impl;

import org.springframework.beans.factory.annotation.Autowired;

import com.rga.rgility.dao.QuoteDAO;
import com.rga.rgility.exception.DAOException;
import com.rga.rgility.exception.ServiceException;
import com.rga.rgility.model.UserCoverage;
import com.rga.rgility.service.QuoteService;
import com.rga.rgility.valueobjects.AppliedQuoteVO;
import com.rga.rgility.valueobjects.ProfileVO;

/**
 * @author M1029563
 *
 */
public class QuoteServiceImpl implements QuoteService{
	
	@Autowired
	private QuoteDAO quoteDAO;
	
	/* (non-Javadoc)
	 * @see com.rga.rgility.service.QuoteService#savequoteinfoVO(com.rga.rgility.valueobjects.ProfileVO, com.rga.rgility.model.UserCoverage)
	 */
	@Override
	public void savequoteinfoVO(ProfileVO profileVO, AppliedQuoteVO appliedQuoteVO) throws ServiceException {
			
		if(null != profileVO){
			appliedQuoteVO.setProfileId(profileVO.getProfileId());
			try {
				quoteDAO.savequoteDetailsVO(appliedQuoteVO);
			} catch (DAOException e) {
				e.printStackTrace();
				throw new ServiceException(e.getMessage());
			}
		}
	}
	
	/* (non-Javadoc)
	 * @see com.rga.rgility.service.QuoteService#constructAppliedQuoteVO(com.rga.rgility.model.UserCoverage)
	 */
	@Override
	public AppliedQuoteVO constructAppliedQuoteVO(UserCoverage user) throws ServiceException{
		
		AppliedQuoteVO appliedQuoteVO = new AppliedQuoteVO();
		try{			
			if(null != user){
				if(user.getSelectedCoverageAmnt() != null && !user.getSelectedCoverageAmnt().isEmpty()){
					appliedQuoteVO.setCoverage(Double.parseDouble(user.getSelectedCoverageAmnt()));
				}
				if(user.getSelectedPolicyTerm() != null && !user.getSelectedPolicyTerm().isEmpty()){
					appliedQuoteVO.setTerm(Integer.parseInt(user.getSelectedPolicyTerm()));
				}
				if(user.getBestPremiumPerMonth()!= null && !user.getBestPremiumPerMonth().isEmpty()){
					appliedQuoteVO.setBestPremiumPerMonth(Double.parseDouble(user.getBestPremiumPerMonth()));
				}
				if(user.getStandardPremiumPerMonth()!= null && !user.getStandardPremiumPerMonth().isEmpty()){
					appliedQuoteVO.setStandardPremiumPerMonth(Double.parseDouble(user.getStandardPremiumPerMonth()));
				}
				if(user.getStandardCoverageAmnt()!= null && !user.getStandardCoverageAmnt().isEmpty()){
					appliedQuoteVO.setStandardCoverage(Double.parseDouble(user.getStandardCoverageAmnt()));
				}
				appliedQuoteVO.setSystemInFocus(user.isUSCitizen() == true ? "P" : "R");
				appliedQuoteVO.setAppliedStatus("Y");		
				
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		
		return appliedQuoteVO;
		
	}

}
