/**
 * 
 */
package com.rga.rgility.service;

import java.util.List;

import com.rga.rgility.exception.ServiceException;
import com.rga.rgility.model.UserCoverage;
import com.rga.rgility.valueobjects.AppliedQuoteVO;
import com.rga.rgility.valueobjects.DemographicInfoVO;
import com.rga.rgility.valueobjects.Path;
import com.rga.rgility.valueobjects.ProfileVO;

/**
 * @author M1030133
 *
 */
public interface MyLifeCoveredService {

	public ProfileVO getQuote(ProfileVO profileVO) throws ServiceException;

	/**
	 * @param profileVO
	 * @return
	 */
	public ProfileVO calculateInsuranceNeeds(ProfileVO profileVO)
			throws ServiceException;

	public ProfileVO getPremiumPerMonth(ProfileVO profileVO)
			throws ServiceException;

	/**
	 * @param profileVO
	 */
	public ProfileVO saveProfile(ProfileVO profileVO) throws ServiceException;

	public List<Path> loadPaths() throws ServiceException;

	/**
	 * @param profileVO
	 */
	public ProfileVO saveProfileAndChild(ProfileVO profileVO)
			throws ServiceException;

	/**
	 * @param profileVO
	 * @return
	 * @throws ServiceException
	 */
	public void updateProfile(ProfileVO profileVO) throws ServiceException;
	
	/**
	 * @return
	 * @throws ServiceException
	 */
	public String constructRgilityserviceRequest(ProfileVO profileVO,AppliedQuoteVO appliedQuoteVO) throws ServiceException;
			
	/**
	 * 	 * @param sliderVisit
	 */
	public void updateSliderVisitFlag(ProfileVO profileVO,final boolean sliderVisit);
	
	public List<DemographicInfoVO> getSliderVisitsThreeAttempts();
	
	public List<DemographicInfoVO> getSliderVisitsGrtThreeAttempts();
	
	public void incrementEmailCount(DemographicInfoVO demoVO);
	
	public void updateSliderVisitFlagThruJob(ProfileVO profileVO,final boolean sliderVisit);
	
	public void saveContactUsDetails(UserCoverage user,ProfileVO userProfileFromSession) throws ServiceException;
	
	public int updateUnsubscribeEmail(String email) throws ServiceException;
	
	public List<ProfileVO> getAbandonQuotes() throws ServiceException;
	
}
