/**
 * 
 */
package com.rga.rgility.service.impl;

import java.util.Arrays;

import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import com.rga.rgility.common.logger.LogFactory;
import com.rga.rgility.common.logger.MyLifeCoveredLogger;
import com.rga.rgility.exception.ServiceException;
import com.rga.rgility.service.RgilityService;

/**
 * @author M1029563
 *
 */
public class RgilityServiceImpl implements RgilityService{
	
	private static final MyLifeCoveredLogger Logger = LogFactory.getInstance(RgilityServiceImpl.class);

	@Value("${rgilityWebService.rgility.endpointURL}")
	private String rgilityendPointURL;
	
	@Value("${rgilityWebService.rgility.accessToken}")
	private String rgilityaccessToken;
	
	
	/* (non-Javadoc)
	 * @see com.rga.rgility.service.RgilityService#postRgilityRequestJson(java.lang.String)
	 */
	@Override
	public String postRgilityRequestJson(String rgilityreqJson)
			throws ServiceException {
		Logger.info("In Executing Rgiltiy Webservice URL");
		String jsonResponse="";
		JSONObject responseObject;
		try{
			Logger.info("Rgility RequestJSON ["+rgilityreqJson+"]");
			RestTemplate restTemplate = new RestTemplate();	
			
			HttpHeaders requestHeaders = new HttpHeaders();			
			if(null != rgilityaccessToken && !rgilityaccessToken.isEmpty()){
				requestHeaders.add("Authorization", "Bearer "+rgilityaccessToken);
			}
			requestHeaders.setContentType(new MediaType("application","json"));
			requestHeaders.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
			HttpEntity<String> reqJson = new HttpEntity<String>(rgilityreqJson,requestHeaders);
			
			responseObject = restTemplate.postForObject(rgilityendPointURL, reqJson, JSONObject.class);
			jsonResponse = responseObject.toString();
			jsonResponse = jsonResponse.replace("\\", "");
			
		}catch (RestClientException e) {
			throw new ServiceException(e.getMessage());
		}catch(Exception e){
			Logger.info("Got Exception while executing endpointurl"+e.getMessage());
			throw new ServiceException(e.getMessage());
		}	
		Logger.info("Rgility ResponseJSON ["+jsonResponse+"]");
		return jsonResponse;
	}
	
	
}
