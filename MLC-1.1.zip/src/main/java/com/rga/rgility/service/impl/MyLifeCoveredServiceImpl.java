/**
 * 
 */
package com.rga.rgility.service.impl;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import com.google.gson.Gson;
import com.rga.rgility.common.constants.ApplicationConstants;
import com.rga.rgility.common.logger.LogFactory;
import com.rga.rgility.common.logger.MyLifeCoveredLogger;
import com.rga.rgility.common.utilities.MyLifeCoveredUtils;
import com.rga.rgility.dao.MyLifeCoveredDAO;
import com.rga.rgility.exception.BaseException;
import com.rga.rgility.exception.DAOException;
import com.rga.rgility.exception.ServiceException;
import com.rga.rgility.model.UserCoverage;
import com.rga.rgility.service.EBIXService;
import com.rga.rgility.service.HealthIQService;
import com.rga.rgility.service.MyLifeCoveredService;
import com.rga.rgility.valueobjects.AppliedQuoteVO;
import com.rga.rgility.valueobjects.Children;
import com.rga.rgility.valueobjects.DemographicInfoVO;
import com.rga.rgility.valueobjects.Path;
import com.rga.rgility.valueobjects.PremiumsInfoVO;
import com.rga.rgility.valueobjects.ProfileVO;
import com.rga.rgility.valueobjects.RgilitySource;

/**
 * @author M1030133
 *
 */
@Service
public class MyLifeCoveredServiceImpl implements MyLifeCoveredService {
	
	private static final MyLifeCoveredLogger LOGGER = LogFactory.getInstance(MyLifeCoveredServiceImpl.class);
	
	@Autowired
	private MyLifeCoveredDAO myLifeCoveredDAO;
	
	@Autowired
	private EBIXService eBixService;
	
	@SuppressWarnings("unused")
	@Autowired
	private HealthIQService healthService;
		
	@Override
	@Transactional (rollbackFor=Exception.class)
	public ProfileVO getQuote(ProfileVO profileVO) throws ServiceException {
		DemographicInfoVO demographicInfoVO = null;
		Map<String,Double> premiumMap = null;
		Map<String,Double> premiumMapStd = null;
		int index = 1;
		List<PremiumsInfoVO> listPremiumsInfoVO = new ArrayList<PremiumsInfoVO>();
		AppliedQuoteVO appliedQuoteVO = new AppliedQuoteVO();
		try {
			if(profileVO.getProfileId() == 0){
				profileVO = myLifeCoveredDAO.saveProfile(profileVO);
			}else {
				myLifeCoveredDAO.updateProfile(profileVO);
			}
			
			demographicInfoVO = myLifeCoveredDAO.saveDemographicInfo(profileVO);
			profileVO.setDemographicVO(demographicInfoVO);
			
			if(profileVO.getPathId() == ApplicationConstants.TWENTY_FIVE_DOLLARS) {
				/*these code is redirecting ebix for affordablity to need flow , if it is not redirecting please comment these code and enable the below commented code for affordability*/
				profileVO.setPathId(1);
				premiumMap = eBixService.getMonthlyPremium(profileVO);
				System.out.println(premiumMap.size());
				/*these commented code work for getting coverage for affordability of selected monthly premium*/
				/*these code commented because RGA told, even affordability also need to show premium only*/
				/*
				Preferred Class here
				profileVO.setAffordableClassCheck(1);
				premiumMap = eBixService.getMonthlyPremium(profileVO);
				Standerd Class here
				profileVO.setAffordableClassCheck(5);
				premiumMapStd = eBixService.getMonthlyPremium(profileVO);

				for (Entry<String, Double> entry : premiumMapStd.entrySet()) {
					premiumMap.put(entry.getKey(), entry.getValue());
				}*/
			}else {
				premiumMap = eBixService.getMonthlyPremium(profileVO);
				System.out.println(premiumMap.size());
			}
			/*Map<String,Double> premiumMap = new HashMap<String,Double>();
			premiumMap.put("Preferred_premium", 11.0);
			premiumMap.put("Standard_premium", 15.0);*/
			
			// 1. Convert Map to List of Map
	        List<Map.Entry<String, Double>> list =  new LinkedList<Map.Entry<String, Double>>(premiumMap.entrySet());
	        // 2. Sort list with Collections.sort(), provide a custom Comparator Try switch the o1 o2 position for a different order
	        Collections.sort(list, new Comparator<Map.Entry<String, Double>>() {
	            public int compare(Map.Entry<String, Double> o1,
	                               Map.Entry<String, Double> o2) {
	                return (o1.getValue()).compareTo(o2.getValue());
	            }
	        });
	        // 3. Loop the sorted list and put it into a new insertion order Map LinkedHashMap
	        Map<String, Double> sortedMap = new LinkedHashMap<String, Double>();
	        for (Map.Entry<String, Double> entry : list) {
	            sortedMap.put(entry.getKey(), entry.getValue());
	        }
	        
	        //only for display purpose later can remove the code 
	        for (Entry<String, Double> entry : sortedMap.entrySet()) {
	    				System.out.println("Key = " + entry.getKey() + ", Value = " + entry.getValue());
	        }
	        
	        for (Entry<String, Double> entry : sortedMap.entrySet()) {
				System.out.println("Key = " + entry.getKey() + ", Value = " + entry.getValue());
				
			    String productDetails[] = StringUtils.split(entry.getKey(), "|");
			    
			    if(productDetails[1].equalsIgnoreCase("Preferred_Premium")) {
			    	PremiumsInfoVO premiumsCoveragesInfoVO = new PremiumsInfoVO();
					
					premiumsCoveragesInfoVO.setProfileId(profileVO.getProfileId());
					premiumsCoveragesInfoVO.setProductName(productDetails[0]);
					premiumsCoveragesInfoVO.setTerm(profileVO.getTerm());
					premiumsCoveragesInfoVO.setIndexOfProduct(index);
					  
					if(null != sortedMap.get(productDetails[0]+"|Preferred_Premium"))
					  premiumsCoveragesInfoVO.setBestPremiumPerMonth(sortedMap.get(productDetails[0]+"|Preferred_Premium"));
					if(null != sortedMap.get(productDetails[0]+"|Standard_Premium"))
					  premiumsCoveragesInfoVO.setStandardPremiumPerMonth(sortedMap.get(productDetails[0]+"|Standard_Premium"));
					if(null != sortedMap.get(productDetails[0]+"|Preferred_Coverage"))
					  premiumsCoveragesInfoVO.setBestCoverage(sortedMap.get(productDetails[0]+"|Preferred_Coverage"));
					if(null != sortedMap.get(productDetails[0]+"|Standard_Coverage"))
					  premiumsCoveragesInfoVO.setStandardCoverage(sortedMap.get(productDetails[0]+"|Standard_Coverage"));
					  
					listPremiumsInfoVO.add(premiumsCoveragesInfoVO);
					index++;
			    }
			    	
			}
	        
			/*for (Entry<String, Double> entry : premiumMap.entrySet()) {
				System.out.println("Key = " + entry.getKey() + ", Value = " + entry.getValue());
				
			    String productDetails[] = StringUtils.split(entry.getKey(), "|");
			    
			    if(productDetails[1].equalsIgnoreCase("Preferred_Premium")) {
			    	PremiumsInfoVO premiumsCoveragesInfoVO = new PremiumsInfoVO();
					
					premiumsCoveragesInfoVO.setProfileId(profileVO.getProfileId());
					premiumsCoveragesInfoVO.setProductName(productDetails[0]);
					premiumsCoveragesInfoVO.setTerm(profileVO.getTerm());
					  
					if(null != premiumMap.get(productDetails[0]+"|Preferred_Premium"))
					  premiumsCoveragesInfoVO.setBestPremiumPerMonth(premiumMap.get(productDetails[0]+"|Preferred_Premium"));
					if(null != premiumMap.get(productDetails[0]+"|Standard_Premium"))
					  premiumsCoveragesInfoVO.setStandardPremiumPerMonth(premiumMap.get(productDetails[0]+"|Standard_Premium"));
					if(null != premiumMap.get(productDetails[0]+"|Preferred_Coverage"))
					  premiumsCoveragesInfoVO.setBestCoverage(premiumMap.get(productDetails[0]+"|Preferred_Coverage"));
					if(null != premiumMap.get(productDetails[0]+"|Standard_Coverage"))
					  premiumsCoveragesInfoVO.setStandardCoverage(premiumMap.get(productDetails[0]+"|Standard_Coverage"));
					  
					listPremiumsInfoVO.add(premiumsCoveragesInfoVO);
			    }
			    	
			}*/
			appliedQuoteVO.setProductPremiumsCoveragesList(listPremiumsInfoVO);
			profileVO.setAppliedQuoteVO(appliedQuoteVO);
		} catch (BaseException e) {
			e.printStackTrace();
			throw new ServiceException(e.getMessage());
		}
		return profileVO;
	}

	/* (non-Javadoc)
	 * @see com.rga.rgility.service.MyLifeCoveredService#calculateInsuranceNeeds(com.rga.rgility.valueobjects.ProfileVO)
	 */
	@Override
	public ProfileVO calculateInsuranceNeeds(ProfileVO profileVO)
			throws ServiceException {
		profileVO.setTotalIncomeToBeProvided(profileVO.getAnnualIncome()
				* profileVO.getYearsIncomeProvided());
		profileVO.setTotalIncomeNeeds(profileVO.getOtherSavings()
				+ profileVO.getRetirementSavings()
				+ profileVO.getExistingLifeInsurance());
		
		profileVO.setChildCount(profileVO.getChildren().size() != 0 ? profileVO.getChildren().size() - 1 : 0);
		int privateCollgeCount = 0;
		int publicCollgeCount = 0;
		for(int i = 0; i < profileVO.getChildren().size(); i ++) {
			if(ApplicationConstants.PUBLIC.equalsIgnoreCase(profileVO.getChildren().get(i).getSchoolType())) {
				publicCollgeCount ++;
			} else if(ApplicationConstants.PRIVATE.equalsIgnoreCase(profileVO.getChildren().get(i).getSchoolType())) {
				privateCollgeCount ++;
			}
		}
		profileVO.setPrivateChildrenCount(privateCollgeCount);
		profileVO.setPublicChildrenCount(publicCollgeCount);
		profileVO.setEstimatedPublicCollegeExpenses(publicCollgeCount * 112000);
		profileVO.setEstimatedPrivateCollegeExpenses(privateCollgeCount *235000);
		profileVO.setTotalCollegeExpenses(publicCollgeCount * 112000 + privateCollgeCount *235000);
		
		profileVO.setTotalOneTimeNeeds(profileVO.getFinalExpenses() + profileVO.getOutstandingMortgage()
				+ profileVO.getOtherOutstandingDebt());
		
		double totalPayoffs = profileVO.getFinalExpenses() + profileVO.getOtherOutstandingDebt()
				+ profileVO.getOutstandingMortgage();
		
		double survivorsIncomeShortfall = profileVO.getAnnualIncome();
		double annualIncomeNeed = survivorsIncomeShortfall * profileVO.getYearsIncomeProvided();
		
		int actualAnnualReturn = profileVO.getEstimatedInvestmentReturn() - profileVO.getEstimatedInflationRate() ;
		
		double currentCoverageNeededToSatisfySurvivorsIncomeShortfall = (annualIncomeNeed/12) * 
				((1 - Math.pow((1 + actualAnnualReturn), (-profileVO.getYearsIncomeProvided())))
				/ (Math.pow(1 + actualAnnualReturn, (double)1/12) - 1)) * (Math.pow(1 + actualAnnualReturn, (double)1/12));
		
		double totalNeed = totalPayoffs + profileVO.getTotalCollegeExpenses() 
				+ currentCoverageNeededToSatisfySurvivorsIncomeShortfall;
		
		double totalProtection = profileVO.getOtherSavings() + profileVO.getRetirementSavings() 
				+ profileVO.getExistingLifeInsurance();
		
		double coverage = totalNeed - totalProtection;
		profileVO.setCoverage(MyLifeCoveredUtils.convertToNearestCoverage((int)coverage));
		profileVO.setTerm(MyLifeCoveredUtils.convertToNearestFiveMuliplier(profileVO.getYearsIncomeProvided()));
		
		return profileVO;
	}

	/* (non-Javadoc)
	 * @see com.rga.rgility.service.MyLifeCoveredService#saveProfile(com.rga.rgility.valueobjects.ProfileVO)
	 */
	@Override
	public ProfileVO saveProfile(ProfileVO profileVO) throws ServiceException {
		try {
			return myLifeCoveredDAO.saveProfile(profileVO);
		} catch (BaseException e) {
			e.printStackTrace();
			throw new ServiceException(e.getMessage());
		}
	}
	
	@Override
	public void updateProfile(ProfileVO profileVO) throws ServiceException {
		try {
			myLifeCoveredDAO.updateProfile(profileVO);
		} catch (BaseException e) {
			e.printStackTrace();
			throw new ServiceException(e.getMessage());
		}
	}

	@Override
	public ProfileVO getPremiumPerMonth(ProfileVO profileVO)
			throws ServiceException {
		Map<String,Double> premiumMap = null;
		Map<String,Double> premiumMapStd = null;
		int index = 1;
		List<PremiumsInfoVO> listPremiumsInfoVO = new ArrayList<PremiumsInfoVO>();
		try {
			
			
			if(profileVO.getPathId() == ApplicationConstants.TWENTY_FIVE_DOLLARS) {
				/*Preferred Class here*/
				profileVO.setAffordableClassCheck(1);
				premiumMap = eBixService.getMonthlyPremium(profileVO);
				/*Standerd Class here*/
				profileVO.setAffordableClassCheck(5);
				premiumMapStd = eBixService.getMonthlyPremium(profileVO);
				
				for (Entry<String, Double> entry : premiumMapStd.entrySet()) {
					premiumMap.put(entry.getKey(), entry.getValue());
				}
			}else {
				premiumMap = eBixService.getMonthlyPremium(profileVO);
			}
			// 1. Convert Map to List of Map
	        List<Map.Entry<String, Double>> list =  new LinkedList<Map.Entry<String, Double>>(premiumMap.entrySet());
	        // 2. Sort list with Collections.sort(), provide a custom Comparator Try switch the o1 o2 position for a different order
	        Collections.sort(list, new Comparator<Map.Entry<String, Double>>() {
	            public int compare(Map.Entry<String, Double> o1,
	                               Map.Entry<String, Double> o2) {
	                return (o1.getValue()).compareTo(o2.getValue());
	            }
	        });
	        // 3. Loop the sorted list and put it into a new insertion order Map LinkedHashMap
	        Map<String, Double> sortedMap = new LinkedHashMap<String, Double>();
	        for (Map.Entry<String, Double> entry : list) {
	        	sortedMap.put(entry.getKey(), entry.getValue());
	        }
	        
			for (Entry<String, Double> entry : sortedMap.entrySet()) {
				System.out.println("Key = " + entry.getKey() + ", Value = " + entry.getValue());
			    String productDetails[] = StringUtils.split(entry.getKey(), "|");
			    
			    if(productDetails[1].equalsIgnoreCase("Preferred_Premium")) {
			    	//productsList.add(productDetails[0]);
			    	PremiumsInfoVO premiumsCoveragesInfoVO = new PremiumsInfoVO();
					
					premiumsCoveragesInfoVO.setProfileId(profileVO.getProfileId());
					premiumsCoveragesInfoVO.setProductName(productDetails[0]);
					premiumsCoveragesInfoVO.setTerm(profileVO.getTerm());
					premiumsCoveragesInfoVO.setIndexOfProduct(index);
					  
					if(null != sortedMap.get(productDetails[0]+"|Preferred_Premium"))
					  premiumsCoveragesInfoVO.setBestPremiumPerMonth(sortedMap.get(productDetails[0]+"|Preferred_Premium"));
					if(null != sortedMap.get(productDetails[0]+"|Standard_Premium"))
					  premiumsCoveragesInfoVO.setStandardPremiumPerMonth(sortedMap.get(productDetails[0]+"|Standard_Premium"));
					if(null != sortedMap.get(productDetails[0]+"|Preferred_Coverage"))
					  premiumsCoveragesInfoVO.setBestCoverage(sortedMap.get(productDetails[0]+"|Preferred_Coverage"));
					if(null != sortedMap.get(productDetails[0]+"|Standard_Coverage"))
					  premiumsCoveragesInfoVO.setStandardCoverage(sortedMap.get(productDetails[0]+"|Standard_Coverage"));
					  
					listPremiumsInfoVO.add(premiumsCoveragesInfoVO);
					index++;
			    }
			    	
			}
			profileVO.getAppliedQuoteVO().setProductPremiumsCoveragesList(listPremiumsInfoVO);
		} catch (Exception e) {
			e.printStackTrace();
			throw new ServiceException(e.getMessage());
		}
		return profileVO;
	}

	/* (non-Javadoc)
	 * @see com.rga.rgility.service.MyLifeCoveredService#loadPaths()
	 */
	@Override
	public List<Path> loadPaths() throws ServiceException {
		try {
			return myLifeCoveredDAO.loadPaths();
		} catch (Exception e) {
			e.printStackTrace();
			throw new ServiceException(e.getMessage());
		}
	}

	/* (non-Javadoc)
	 * @see com.rga.rgility.service.MyLifeCoveredService#saveProfileAndChild(com.rga.rgility.valueobjects.ProfileVO)
	 */
	@Override
	@Transactional (rollbackFor=Exception.class)
	public ProfileVO saveProfileAndChild(ProfileVO profileVO)
			throws ServiceException {
		try {
			if(profileVO.getProfileId() <= 0) {
				profileVO = this.saveProfile(profileVO);
			} else {
				this.updateProfile(profileVO);
			}
			myLifeCoveredDAO.deleteChildren(profileVO.getProfileId());
			
			List<Children> children = profileVO.getChildren();
			int count = 0;
			for(Children child : children) {
				child.setChildIndex(count++);
				child.setProfileId(profileVO.getProfileId());
			}
			profileVO.setChildren(children);
			myLifeCoveredDAO.saveChildren(children);
			return profileVO;
		} catch (Exception e) {
			e.printStackTrace();
			throw new ServiceException(e.getMessage());
		}
	}

	/* (non-Javadoc)
	 * @see com.rga.rgility.service.MyLifeCoveredService#constructRgilityserviceRequest()
	 */
	@Override
	public String constructRgilityserviceRequest(ProfileVO profileVO,AppliedQuoteVO appliedQuoteVO)
			throws ServiceException {
		
		DemographicInfoVO demographicInfoVO = null; 
		String birthDate = "",rgilityJson="";
		RgilitySource rgilitySource =  new RgilitySource();
		String gender = null;
		String stateName = null;
		Map<String,String> stateMap = new HashMap<String,String>();
		constructStateMap(stateMap);
		try{
			if(null != profileVO && null != profileVO.getDemographicVO() && null != appliedQuoteVO){
				
				demographicInfoVO = profileVO.getDemographicVO();
				rgilitySource.setFirstName(profileVO.getFirstName());
				rgilitySource.setPremiumQuote(String.valueOf(appliedQuoteVO.getBestPremiumPerMonth()));
				rgilitySource.setProductName("Trendsetter Super");
				rgilitySource.setTerm(String.valueOf(appliedQuoteVO.getTerm()));
				rgilitySource.setCarrier("Transamerica");
				if(appliedQuoteVO.getCoverage()>2000000){
					rgilitySource.setCoverageAmount(String.valueOf(2000000));
				}else{
					rgilitySource.setCoverageAmount(String.valueOf(appliedQuoteVO.getCoverage()));
				}
				stateName = stateMap.get(demographicInfoVO.getState());
				LOGGER.info("The state name is "+stateName);
				rgilitySource.setIssueState(stateName);
				rgilitySource.setPrimaryEmail(demographicInfoVO.getEmailAddress());
				
				
				if (demographicInfoVO.getGender() != null) {
					if (demographicInfoVO.getGender().equalsIgnoreCase("M")) {
						gender = "Male";
					}
					else if (demographicInfoVO.getGender().equalsIgnoreCase("F")) {
						gender = "Female";
					}
				}
				LOGGER.info("The Gender is "+gender);
				rgilitySource.setGender(gender);
				
				if(demographicInfoVO.getSmokerStatus() != null){
					if(demographicInfoVO.getSmokerStatus().equals("1")){
						rgilitySource.setSmokerStatus("current");
					}else{
						rgilitySource.setSmokerStatus("never");
					}
				}if(demographicInfoVO.getIsUsCitizen() != null){
					if(demographicInfoVO.getIsUsCitizen().equals("1")){
						rgilitySource.setUsCitizen("True");
					}else{
						rgilitySource.setUsCitizen("False");
					}
				}if(demographicInfoVO.getIsPolicyOwner() != null){
					if(demographicInfoVO.getIsPolicyOwner().equals("1")){
						rgilitySource.setIsInsuredAPolicyOwner("True");
					}else{
						rgilitySource.setIsInsuredAPolicyOwner("False");
					}
				}
				DecimalFormat decimalFormat = new DecimalFormat(".");
				decimalFormat.setGroupingUsed(false);
				decimalFormat.setDecimalSeparatorAlwaysShown(false);
				String income = decimalFormat.format(profileVO.getAnnualIncome());
				rgilitySource.setIncome(income);
				LOGGER.info("The income is "+income);
				if(null != demographicInfoVO.getDateOfBirth()){
					
					Date dob = demographicInfoVO.getDateOfBirth();
					birthDate = MyLifeCoveredUtils.convertDateToString("yyyy-MM-dd", dob);
					rgilitySource.setBirthDate(birthDate);
				}
				//rgilitySource.setLastName("Test");
				rgilitySource.setDistributionPartner("mylifecovered");
				rgilitySource.setTheme("metcon");
				rgilitySource.setRecommendationEngineLeadId(String.valueOf(profileVO.getProfileId()));
				rgilitySource.setRiskClass("preferredPlus");
				rgilitySource.setPhoneNumber(profileVO.getDemographicVO().getQuotePhone());
				rgilitySource.setBeaconVendor("PlusMedia");
				rgilityJson = new Gson().toJson(rgilitySource);
			}
		}catch(Exception e){
			LOGGER.info("Got An Exception while Constructing Rgility Request"+e.getMessage());
			throw new ServiceException(e.getMessage());
		}
		
		LOGGER.info("RGILITY request JSON:"+rgilityJson);
		return rgilityJson;
	}
	
	/**
	 * Construct state map.
	 * @param stateMap
	 */
	private void constructStateMap(Map<String,String> stateMap) {
		stateMap.put("AL","Alabama");
        stateMap.put("AK","Alaska");
        stateMap.put("AZ","Arizona");
        stateMap.put("AR","Arkansas");
        stateMap.put("CA","California");
        stateMap.put("CO","Colorado");
        stateMap.put("CT","Connecticut");
        stateMap.put("DE","Delaware");
        stateMap.put("DC","District of Columbia");
        stateMap.put("FL","Florida");
        stateMap.put("GA","Georgia");
        stateMap.put("HI","Hawaii");
        stateMap.put("ID","Idaho");
        stateMap.put("IL","Illinois");
        stateMap.put("IN","Indiana");
        stateMap.put("IA","Iowa");
        stateMap.put("KS","Kansas");
        stateMap.put("KY","Kentucky");
        stateMap.put("LA","Louisiana");
        stateMap.put("ME","Maine");
        stateMap.put("MD","Maryland");
        stateMap.put("MA","Massachusetts");
        stateMap.put("MI","Michigan");
        stateMap.put("MN","Minnesota");
        stateMap.put("MS","Mississippi");
        stateMap.put("MO","Missouri");
        stateMap.put("MT","Montana");
        stateMap.put("NE","Nebraska");
        stateMap.put("NV","Nevada");
        stateMap.put("NH","New Hampshire");
        stateMap.put("NJ","New Jersey");
        stateMap.put("NM","New Mexico");
        stateMap.put("NY","New York");
        stateMap.put("NC","North Carolina");
        stateMap.put("ND","North Dakota");
        stateMap.put("OH","Ohio");
        stateMap.put("OK","Oklahoma");
        stateMap.put("OR","Oregon");
        stateMap.put("PA","Pennsylvania");
        stateMap.put("RI","Rhode Island");
        stateMap.put("SC","South Carolina");
        stateMap.put("SD","South Dakota");
        stateMap.put("TN","Tennessee");
        stateMap.put("TX","Texas");
        stateMap.put("UT","Utah");
        stateMap.put("VT","Vermont");
        stateMap.put("VA","Virginia");
        stateMap.put("WA","Washington");
        stateMap.put("WV","West Virginia");
        stateMap.put("WI","Wisconsin");
        stateMap.put("WY","Wyoming");
	}
	
	public void updateSliderVisitFlag(ProfileVO profileVO,final boolean sliderVisit) {
		try {
			myLifeCoveredDAO.updateSliderVisitFlag(profileVO,sliderVisit);
		} catch (DAOException e) {
			e.printStackTrace();
		}
	}
	
	
	public List<DemographicInfoVO> getSliderVisitsThreeAttempts() {
		return myLifeCoveredDAO.getSliderVisitsThreeAttempts();
	}
	
	public List<DemographicInfoVO> getSliderVisitsGrtThreeAttempts() {
		return myLifeCoveredDAO.getSliderVisitsGrtThreeAttempts();
	}
	
	public void incrementEmailCount(DemographicInfoVO demoVO) {
		 myLifeCoveredDAO.incrementEmailCount(demoVO);
	}
	
	public void updateSliderVisitFlagThruJob(ProfileVO profileVO,final boolean sliderVisit) {
		try {
			myLifeCoveredDAO.updateSliderVisitFlagThruJob(profileVO,sliderVisit);
		} catch (DAOException e) {
			e.printStackTrace();
		}
	}
	
	@Override
	public void saveContactUsDetails(UserCoverage user,ProfileVO userProfileFromSession) throws ServiceException {
		try {
			myLifeCoveredDAO.saveContactUsDetails(user,userProfileFromSession);
//			healthService.postToHealthIQ(user, userProfileFromSession);
		} catch (DAOException e) {
			e.printStackTrace();
			throw new ServiceException(e.getMessage());
		}
	}

	@Override
	public int updateUnsubscribeEmail(String email) throws ServiceException {
		int updateCount = 0;
		try {
			updateCount = myLifeCoveredDAO.updateUnsubscribeEmail(email);
		} catch (DAOException e) {
			e.printStackTrace();
		}
		return updateCount;
	}
	
}

