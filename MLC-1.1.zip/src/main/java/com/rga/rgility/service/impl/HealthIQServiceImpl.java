package com.rga.rgility.service.impl;

import java.util.Arrays;

import org.apache.commons.codec.binary.Base64;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import com.google.gson.Gson;
import com.rga.rgility.common.logger.LogFactory;
import com.rga.rgility.common.logger.MyLifeCoveredLogger;
import com.rga.rgility.exception.ServiceException;
import com.rga.rgility.model.UserCoverage;
import com.rga.rgility.service.HealthIQService;
import com.rga.rgility.valueobjects.ContactSource;
import com.rga.rgility.valueobjects.ProfileVO;

public class HealthIQServiceImpl implements HealthIQService {
	
	@Value("#{'${healthIQ.END_POINT_URL}'}")
	private String healthIQEndPointURL;
	
	@Value("#{'${healthIQ.USER_ID}'}")
	private String healthIQUserID;
	
	@Value("#{'${healthIQ.PASSWORD}'}")
	private String healthIQPassword;
	
	private static final MyLifeCoveredLogger Logger = LogFactory.getInstance(HealthIQServiceImpl.class);

	@Override
	public String postToHealthIQ(final UserCoverage user, final ProfileVO profile) throws ServiceException {
		
		Logger.info("Integrating with Health IQ service");
		JSONObject responseObject = null;
		String phoneNumber = null; 
		String jsonResponse="";
		try {
			String plainCreds = healthIQUserID + ":" + healthIQPassword;
			byte[] plainCredsBytes = plainCreds.getBytes();
			byte[] base64CredsBytes = Base64.encodeBase64(plainCredsBytes);
			String base64Creds = new String (base64CredsBytes);
			
			
			ContactSource contactSource = new ContactSource();
			contactSource.setName(user.getName());
			phoneNumber = user.getPhone();
			phoneNumber = phoneNumber.replace("(", "").replace(")", "-").replace(" ", "");
			contactSource.setPhone_number(phoneNumber);
			contactSource.setEmail(user.getEmail());			
			if(null == profile) {
				//dob, coverage, tobacco				
			}
			
			String contactRequestJSON = new Gson().toJson(contactSource);
			
			RestTemplate restTemplate = new RestTemplate();	
			HttpHeaders requestHeaders = new HttpHeaders();
			requestHeaders.add("Authorization","Basic "+base64Creds);
			requestHeaders.setContentType(new MediaType("application","json"));
			requestHeaders.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
			HttpEntity<String> reqJson = new HttpEntity<String>(contactRequestJSON,requestHeaders);
	
			Logger.debug("Health IQ - JSON Request - "+reqJson.toString());
			responseObject = restTemplate.postForObject(healthIQEndPointURL, reqJson, JSONObject.class);
			jsonResponse = responseObject.toString();
			jsonResponse = jsonResponse.replace("\\", "");
			Logger.debug("Health IQ - JSON response - "+jsonResponse);
		} catch (RestClientException e) {
			throw new ServiceException(e.getMessage());
		}catch(Exception e){
			Logger.info("Got Exception while executing HealthIQservice"+e.getMessage());
			throw new ServiceException(e.getMessage());
		}	
		return jsonResponse;
	}

}
