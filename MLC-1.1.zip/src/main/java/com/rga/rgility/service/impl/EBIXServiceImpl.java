package com.rga.rgility.service.impl;

import java.io.StringWriter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletContext;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;

import org.apache.commons.lang.StringEscapeUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import com.ebix.lifelink.client.ApplicantType;
import com.ebix.lifelink.client.ClientType;
import com.ebix.lifelink.client.DisplayedInformationType;
import com.ebix.lifelink.client.ErrorType;
import com.ebix.lifelink.client.ErrorTypeType;
import com.ebix.lifelink.client.InterfaceTypeType;
import com.ebix.lifelink.client.LLType;
import com.ebix.lifelink.client.LifeLinkType;
import com.ebix.lifelink.client.LifelinkXMLsvc;
import com.ebix.lifelink.client.LifelinkXMLsvcSoap;
import com.ebix.lifelink.client.LlXMLResponse.LlXMLResult;
import com.ebix.lifelink.client.ModalValueType;
import com.ebix.lifelink.client.ObjectFactory;
import com.ebix.lifelink.client.OutputTypeType;
import com.ebix.lifelink.client.ProdScenarioType;
import com.ebix.lifelink.client.ProductListsType;
import com.ebix.lifelink.client.ProductScenariosType;
import com.ebix.lifelink.client.ProductTypeType;
import com.ebix.lifelink.client.ProductsType;
import com.ebix.lifelink.client.ReturnType;
import com.ebix.lifelink.client.ScenarioType;
import com.ebix.lifelink.client.SexType;
import com.ebix.lifelink.client.ToolType;
import com.ebix.lifelink.client.ToolTypeName;
import com.ebix.lifelink.client.UWClassInfoType;
import com.ebix.lifelink.client.UserInformationType;
import com.ebix.lifelink.client.VTProductOptionsType;
import com.ebix.lifelink.client.VTProductType;
import com.ebix.lifelink.client.VitalTermNetType;
import com.rga.rgility.common.constants.ApplicationConstants;
import com.rga.rgility.common.logger.LogFactory;
import com.rga.rgility.common.logger.MyLifeCoveredLogger;
import com.rga.rgility.common.utilities.MyLifeCoveredUtils;
import com.rga.rgility.exception.ServiceException;
import com.rga.rgility.service.EBIXService;
import com.rga.rgility.valueobjects.ProfileVO;

public class EBIXServiceImpl implements EBIXService {
	
	private static final MyLifeCoveredLogger LOGGER = LogFactory.getInstance(EBIXServiceImpl.class);

	@Value("${service.ebix.username}")
	private String SERVICE_EBIX_USERNAME;

	@Value("${service.ebix.password}")
	private String SERVICE_EBIX_PASSWORD;

	@Value("#{'${service.ebix.stateCodes}'.split(',')}")
	private List<String> stateCodes;

	@Value("${service.ebix.carrier}")
	private String SERVICE_EBIX_CARRIER;

	@Autowired
	private ServletContext context;

	@Override
	public Map<String,Double> getMonthlyPremium(ProfileVO profileVO) throws ServiceException {
		String requestXML = constructXMLRequest(profileVO);
//		System.out.println(requestXML);
		return getPremiumFromEBIX(requestXML,profileVO);
	}

	/**
	 * Method to construct the request XML for EBIX.
	 * 
	 * @param profileVO
	 * @param demographicInfoVO
	 * @return String
	 */
	private String constructXMLRequest(final ProfileVO profileVO) {
		String encodedXML = null;
		try {
			LifeLinkType lifeLinkType = this.initializeLifeLinkType();
			this.loadUserClientInfo(lifeLinkType, profileVO);
			VitalTermNetType vitalTermNet = new VitalTermNetType();
			
			/*if (profileVO.getDemographicVO().getIsUsCitizen().equals("1")) {
				ClassDeterminationType classDetType = new ClassDeterminationType();
				DetermiatorAnswerXMLType detAnsType = new DetermiatorAnswerXMLType();
				
				DetQuestionType question = new DetQuestionType();
				question.setQuesType("US_PRESIDENT");
				question.setQuesId(12);
				
				DetAnswersType answer = new DetAnswersType();
				List<DetControlsType> controls = new ArrayList<DetControlsType>();
				DetControlsType control1 = new DetControlsType();
				DetControlsType control2 = new DetControlsType();
				control1.setId(56);
				control1.setControlValueType("ABSOLUTE");
				control1.setAnswer("1");
				
				control2.setId(57);
				control2.setControlValueType("MINIMUM");
				control2.setAnswer("");
				
				controls.add(control1);
				controls.add(control2);
				
				answer.setControl(controls);
				question.setAnswers(answer);
				
				detAnsType.getQuestion().add(question);
				
				classDetType.setDeterminatorAnswerXML(detAnsType);
				vitalTermNet.setUWClassDetermination(classDetType);
			}
			else if (profileVO.getDemographicVO().getIsUsCitizen().equals("0")) {
				ClassDeterminationType classDetType = new ClassDeterminationType();
				DetermiatorAnswerXMLType detAnsType = new DetermiatorAnswerXMLType();
				
				DetQuestionType question = new DetQuestionType();
				question.setQuesType("US_PRESIDENT");
				question.setQuesId(12);
				
				DetAnswersType answer = new DetAnswersType();
				List<DetControlsType> controls = new ArrayList<DetControlsType>();
				DetControlsType control1 = new DetControlsType();
				DetControlsType control2 = new DetControlsType();
				control1.setId(56);
				control1.setControlValueType("ABSOLUTE");
				control1.setAnswer("0");
				
				control2.setId(57);
				control2.setControlValueType("MINIMUM");
				control2.setAnswer("");
				
				controls.add(control1);
				controls.add(control2);
				
				answer.setControl(controls);
				question.setAnswers(answer);
				
				detAnsType.getQuestion().add(question);
				
				classDetType.setDeterminatorAnswerXML(detAnsType);
				vitalTermNet.setUWClassDetermination(classDetType);
			}*/
			vitalTermNet.setProducts(this.constructProductType(profileVO));
			lifeLinkType.setVitalTermNet(vitalTermNet);
			ObjectFactory objectFactory = new ObjectFactory();
			JAXBElement<LifeLinkType> jaxbObject = objectFactory
					.createLifeLink(lifeLinkType);
			encodedXML = this.marshalXMLRequest(jaxbObject, encodedXML);

		} catch (Exception e) {

		}
		return encodedXML;
	}

	/**
	 * Method to initialize LifeLinkType.
	 * 
	 * @return LifeLinkType
	 */
	private LifeLinkType initializeLifeLinkType() {
		LifeLinkType lifeLinkType = new LifeLinkType();
		LLType llType = new LLType();
		llType.setUserName(SERVICE_EBIX_USERNAME);
		llType.setUserPassword(SERVICE_EBIX_PASSWORD);
		InterfaceTypeType interfaceType = InterfaceTypeType.NO_GUI;
		llType.setInterfaceType(interfaceType);
		OutputTypeType outputType = OutputTypeType.XML;
		llType.setOutputType(outputType);
		llType.setLogout(false);
		ToolType toolType = new ToolType();
		toolType.setName(ToolTypeName.VITAL_TERM_NET);
		llType.getTool().add(toolType);
		lifeLinkType.setLL(llType);
		return lifeLinkType;
	}

	/**
	 * Method to load the client information.
	 * 
	 * @param lifeLinkType
	 * @param profileVO
	 * @param demographicInfoVO
	 */
	private void loadUserClientInfo(LifeLinkType lifeLinkType,
			ProfileVO profileVO) {
		// User Information
		UserInformationType userInformationType = new UserInformationType();
		userInformationType.setFirstName(profileVO.getFirstName());
		lifeLinkType.setUserInformation(userInformationType);

		// Client information
		ClientType clientType = new ClientType();
		ApplicantType applicantType = new ApplicantType();
		applicantType.setAge(MyLifeCoveredUtils
				.getDiffInYearsInJodaTime(profileVO.getDemographicVO().getDateOfBirth()));
		SexType sexType = "M".equals(profileVO.getDemographicVO().getGender()) ? SexType.MALE
				: SexType.FEMALE;
		applicantType.setSex(sexType);
		clientType.setApplicant(applicantType);

		String stateCode = profileVO.getDemographicVO().getState();
		if (stateCode != null && !stateCode.isEmpty() && stateCodes != null
				&& !stateCodes.isEmpty()
				&& !stateCodes.contains(stateCode.toUpperCase())) {
			stateCode = "NY";
		}
		clientType.setStateOfIssue(stateCode);
		lifeLinkType.setClient(clientType);
	}

	/**
	 * Method to construct the Products type.
	 * 
	 * @param profileVO
	 * @param demographicInfoVO
	 * @return ProductsType
	 */
	private ProductsType constructProductType(ProfileVO profileVO) {
		// Product
		ProductsType productType = new ProductsType();
		VTProductOptionsType vtProductOptions = this.initializeProductOptions();
		productType.setProductOptions(vtProductOptions);

		// ProductLists
		ProductListsType productList = new ProductListsType();
		productList.setListName(SERVICE_EBIX_CARRIER);
		productList.getYearsLevel().add(profileVO.getTerm());
		productList.getProductType().add(ProductTypeType.TERM);
		productType.setProductLists(productList);

		// Product Scenario Type
		productType.setProductScenarios(this.loadProductScenarios(profileVO));
		return productType;
	}

	/**
	 * Method to initialize product options.
	 * 
	 * @return VTProductOptionsType
	 */
	private VTProductOptionsType initializeProductOptions() {
		// Product Options
		VTProductOptionsType vtProductOptions = new VTProductOptionsType();
		vtProductOptions
				.setBreakDownPremiums(ApplicationConstants.BreakDownPremiums);
		vtProductOptions.setCalcToPenny(ApplicationConstants.CalcToPenny);
		vtProductOptions
				.setDisplayProductClasses(ApplicationConstants.DisplayProductClasses);
		vtProductOptions.setGetCompanyInfo(ApplicationConstants.GetCompanyInfo);
		vtProductOptions
				.setShowCurrentRates(ApplicationConstants.ShowCurrentRates);
		vtProductOptions
				.setShowRemovedProducts(ApplicationConstants.ShowRemovedProducts);
		vtProductOptions
				.setShowProdInfoOnRemoval(ApplicationConstants.ShowProdInfoOnRemoval);
		vtProductOptions
				.setShowProdInfoOnly(ApplicationConstants.ShowProdInfoOnly);
		vtProductOptions
				.setShowPremiumsOnly(ApplicationConstants.ShowPremiumsOnly);
		vtProductOptions
				.setCalc1StYearModal(ApplicationConstants.Calc1StYearModal);

		return vtProductOptions;
	}

	/**
	 * Method to load the product scenarios.
	 * 
	 * @param profileVO
	 * @param demographicInfoVO
	 * @return ProductScenariosType
	 */
	private ProductScenariosType loadProductScenarios(ProfileVO profileVO) {
		// Product Scenario Type
		ProductScenariosType productScenariosType = new ProductScenariosType();
		//Standard premium
		ProdScenarioType scenarioType = null;
		//Preferred premium.
		ProdScenarioType scenarioTypePref = null;
		
		if(profileVO.getPathId() == ApplicationConstants.TWENTY_FIVE_DOLLARS) { 
			// for all coverage range between 100000 to 2M
			for (int coverage = 100000; coverage<= 2000000 ; coverage+=50000) {
				/*if(profileVO.getAffordableClassCheck() == 5) {
					scenarioType = new ProdScenarioType();
					UWClassInfoType underWritingClassInfoType = new UWClassInfoType();
					scenarioType.setFaceAmount(coverage + "");
					scenarioType.setPaymentMode(0);
					underWritingClassInfoType.setType("VT");
					underWritingClassInfoType.setClazz(5);
					// In db smoking status 1 = Yes & 0 = No
					if (profileVO.getDemographicVO().getSmokerStatus().equals("1")) {
						underWritingClassInfoType.setSmokingStatus(3);
						// smoking status 3 = Yes
					} else {
						underWritingClassInfoType.setSmokingStatus(1);
						// smoking status 1 = No
					}
					scenarioType.setUnderwritingClassInfo(underWritingClassInfoType);
					productScenariosType.getScenario().add(scenarioType);
				} */
				/*if(profileVO.getAffordableClassCheck() == 1) {*/
					scenarioTypePref = new ProdScenarioType();
					UWClassInfoType underWritingClassInfoTypePref = new UWClassInfoType();
					scenarioTypePref.setFaceAmount(coverage + "");
					scenarioTypePref.setPaymentMode(0);
					underWritingClassInfoTypePref.setType("VT");
					underWritingClassInfoTypePref.setClazz(profileVO.getAffordableClassCheck());
					// In db smoking status 1 = Yes & 0 = No
					if (profileVO.getDemographicVO().getSmokerStatus().equals("1")) {
						underWritingClassInfoTypePref.setSmokingStatus(3);
						// smoking status 3 = Yes
					} else {
						underWritingClassInfoTypePref.setSmokingStatus(1);
						// smoking status 1 = No
					}
					scenarioTypePref.setUnderwritingClassInfo(underWritingClassInfoTypePref);
					productScenariosType.getScenario().add(scenarioTypePref);	
				}
			/*}		*/
		
		} else {
			scenarioType = new ProdScenarioType();
			UWClassInfoType underWritingClassInfoType = new UWClassInfoType();
			scenarioType.setFaceAmount(Math.round(profileVO.getCoverage()) + "");
			scenarioType.setPaymentMode(0);
			underWritingClassInfoType.setType("VT");
			underWritingClassInfoType.setClazz(5);
			// In db smoking status 1 = Yes & 0 = No
			if (profileVO.getDemographicVO().getSmokerStatus().equals("1")) {
				underWritingClassInfoType.setSmokingStatus(3);
				// smoking status 3 = Yes
			} else {
				underWritingClassInfoType.setSmokingStatus(1);
				// smoking status 1 = No
			}
			scenarioType.setUnderwritingClassInfo(underWritingClassInfoType);
			productScenariosType.getScenario().add(scenarioType);
			
			scenarioTypePref = new ProdScenarioType();
			UWClassInfoType underWritingClassInfoTypePref = new UWClassInfoType();
			scenarioTypePref.setFaceAmount(Math.round(profileVO.getCoverage()) + "");
			scenarioTypePref.setPaymentMode(0);
			underWritingClassInfoTypePref.setType("VT");
			underWritingClassInfoTypePref.setClazz(1);
			// In db smoking status 1 = Yes & 0 = No
			if (profileVO.getDemographicVO().getSmokerStatus().equals("1")) {
				underWritingClassInfoTypePref.setSmokingStatus(3);
				// smoking status 3 = Yes
			} else {
				underWritingClassInfoTypePref.setSmokingStatus(1);
				// smoking status 1 = No
			}
			scenarioTypePref.setUnderwritingClassInfo(underWritingClassInfoTypePref);
			productScenariosType.getScenario().add(scenarioTypePref);
		}
		return productScenariosType;
	}

	/**
	 * Method to marshal the XML request.
	 * 
	 * @param jaxbObject
	 * @param encodedXML
	 * @return String
	 */
	private String marshalXMLRequest(JAXBElement<LifeLinkType> jaxbObject,
			String encodedXML) {
		try {
			JAXBContext jc = JAXBContext.newInstance(ObjectFactory.class);
			Marshaller marshaller = jc.createMarshaller();
			marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
			StringWriter stringWriter = new StringWriter();
			marshaller.marshal(jaxbObject, stringWriter);
			String requestXML = stringWriter.toString();
			// logger.debug("EBIX Request XML"+requestXML);
			encodedXML = StringEscapeUtils.escapeXml(requestXML);
			// logger.debug("Encoded XML :" + encodedXML);
		} catch (JAXBException e) {
		}
		return encodedXML;
	}

	/*
	 * Used for getting the Quotes from EBIX Webservice
	 */
	@SuppressWarnings("rawtypes")
	private Map<String,Double> getPremiumFromEBIX(String encodedXML, ProfileVO profileVO) throws ServiceException {
		// Map<Integer, Double> faceAmountPremiumMap = new HashMap<Integer,
		// Double>();
		Map<String,Double> premiumMap = new HashMap<String,Double>();
		Integer finalScenario = 0;
		double premiumValue = 0.0;
		LifelinkXMLsvc llService = null;
		LlXMLResult result = null;
				
		try {
			long startTime = System.currentTimeMillis();	
			LOGGER.debug("getPremiumFromEBIX Start Time " +  startTime);
			if (null == context.getAttribute("ebixService")) {
				llService = new LifelinkXMLsvc();
				context.setAttribute("ebixService", llService);
			} else {
				llService = (LifelinkXMLsvc) context
						.getAttribute("ebixService");
			}

			LifelinkXMLsvcSoap soapPort = llService.getLifelinkXMLsvcSoap();
			
			//LOGGER.debug("EBIX Request in XML: " + encodedXML);
			
			result = soapPort.llXML(encodedXML);
			JAXBElement jaxbObject = (JAXBElement) result.getContent().get(0);
			/*ebix result printing code here*/
			/*JAXBContext jc = JAXBContext.newInstance(ObjectFactory.class);
			Marshaller marshaller = jc.createMarshaller();
			marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
			StringWriter stringWriter = new StringWriter();
			marshaller.marshal(jaxbObject, stringWriter);
			System.out.println(stringWriter);*/
			/*ends here*/
			
			LifeLinkType lifelinkType = (LifeLinkType) jaxbObject.getValue();
			ErrorType error = lifelinkType.getError().get(0);
			
			if (error.getType().equals(ErrorTypeType.ERROR)) {
			} else if (error.getType().equals(ErrorTypeType.MESSAGE)) {
				ProductsType productType = lifelinkType.getVitalTermNet()
						.getProducts();
				List<VTProductType> productList = productType.getProduct();
				long endTime = System.currentTimeMillis();
				LOGGER.debug("Total time taken by EBIX: " + (endTime - startTime));
				/*Algorithm for get premium and coverage value*/ 
				if (productList != null && !productList.isEmpty()) {
					
					@SuppressWarnings("unused")
					int count = 0;
					/*Coverage specific to preselected premium*/
					if(profileVO.getPathId() == ApplicationConstants.TWENTY_FIVE_DOLLARS) { 
						Map<String,Double> productsNameMap= new HashMap<String,Double>();
						for (VTProductType products : productList) {
						/*	if(products.getScenario().getRequest().getUnderwritingClassInfo().getClazz() == 1) {*/
								ScenarioType scenarioType = products.getScenario();
								ReturnType returnType = scenarioType.getReturn();
								DisplayedInformationType displayedInformation = returnType.getDisplayedInformation();
								
								if (null != displayedInformation) {
									List<ModalValueType> premiumList = displayedInformation.getPremiumInformation().getFirstYearModalPremiums().getPremium();
								
								if (premiumList != null) {
									
									if (premiumList.get(3) != null && products.getScenario().getRequest().getUnderwritingClassInfo().getClazz() == 1) {
										String premValue = premiumList.get(3).getValue();
										premValue = premValue.replace("$", "");
										premValue = premValue.replace(",", "");
										premValue = premValue.replace(",", "");
										if(null == productsNameMap.get(displayedInformation.getProductInformation().getDisplayName().replaceAll("[(0-9)_ -]",""))) {
											LOGGER.debug("Initial preferred class  premValue is--> "+premValue +" FaceAmount "+products.getScenario().getRequest().getFaceAmount()+" Difference is==> "+Math.abs((profileVO.getAffordablePremium() - Double.parseDouble(premValue))) +" For "+displayedInformation.getProductInformation().getDisplayName().replaceAll("[(0-9)_ -]",""));
											//tempPremiumValue = profileVO.getAffordablePremium() - Double.parseDouble(premValue);
											finalScenario = Integer.parseInt(products.getScenario().getRequest().getFaceAmount());
											premiumValue = Double.parseDouble(premValue);
											premiumMap.put(displayedInformation.getProductInformation().getDisplayName().replaceAll("[(0-9)_ -]","")+"|"+"Preferred_Coverage", finalScenario.doubleValue());
											premiumMap.put(displayedInformation.getProductInformation().getDisplayName().replaceAll("[(0-9)_ -]","")+"|"+"Preferred_Premium", premiumValue);
											productsNameMap.put(displayedInformation.getProductInformation().getDisplayName().replaceAll("[(0-9)_ -]",""), Math.abs(profileVO.getAffordablePremium() - Double.parseDouble(premValue)));
										} else {
											LOGGER.debug("Later preferred class  premValue is--> "+premValue +" FaceAmount "+products.getScenario().getRequest().getFaceAmount()+" Difference is==> "+Math.abs((profileVO.getAffordablePremium() - Double.parseDouble(premValue))) +" For "+displayedInformation.getProductInformation().getDisplayName().replaceAll("[(0-9)_ -]",""));
											if(Math.abs((profileVO.getAffordablePremium() - Double.parseDouble(premValue))) <= productsNameMap.get(displayedInformation.getProductInformation().getDisplayName().replaceAll("[(0-9)_ -]",""))) {
												//tempPremiumValue = Math.abs(profileVO.getAffordablePremium() - Double.parseDouble(premValue));
												productsNameMap.put(displayedInformation.getProductInformation().getDisplayName().replaceAll("[(0-9)_ -]",""), Math.abs(profileVO.getAffordablePremium() - Double.parseDouble(premValue)));
												finalScenario = Integer.parseInt(products.getScenario().getRequest().getFaceAmount());
												premiumValue = Double.parseDouble(premValue);
												premiumMap.put(displayedInformation.getProductInformation().getDisplayName().replaceAll("[(0-9)_ -]","")+"|"+"Preferred_Coverage", finalScenario.doubleValue());
												premiumMap.put(displayedInformation.getProductInformation().getDisplayName().replaceAll("[(0-9)_ -]","")+"|"+"Preferred_Premium", premiumValue);
											}
										}
									} else {
										String premValue = premiumList.get(3).getValue();
										premValue = premValue.replace("$", "");
										premValue = premValue.replace(",", "");
										premValue = premValue.replace(",", "");
										
										if(null == productsNameMap.get(displayedInformation.getProductInformation().getDisplayName().replaceAll("[(0-9)_ -]",""))) {
											LOGGER.debug("Initial standard class premValue is--> "+premValue +" FaceAmount "+products.getScenario().getRequest().getFaceAmount()+" Difference is==> "+Math.abs((profileVO.getAffordablePremium() - Double.parseDouble(premValue)))+" For "+displayedInformation.getProductInformation().getDisplayName().replaceAll("[(0-9)_ -]",""));
											//tempPremiumValue = profileVO.getAffordablePremium() - Double.parseDouble(premValue);
											finalScenario = Integer.parseInt(products.getScenario().getRequest().getFaceAmount());
											premiumValue = Double.parseDouble(premValue);
											premiumMap.put(displayedInformation.getProductInformation().getDisplayName().replaceAll("[(0-9)_ -]","")+"|"+"Standard_Coverage", finalScenario.doubleValue());
											premiumMap.put(displayedInformation.getProductInformation().getDisplayName().replaceAll("[(0-9)_ -]","")+"|"+"Standard_Premium", premiumValue);
											productsNameMap.put(displayedInformation.getProductInformation().getDisplayName().replaceAll("[(0-9)_ -]",""), Math.abs(profileVO.getAffordablePremium() - Double.parseDouble(premValue)) );
										} else { 
											LOGGER.debug("Later standard class premValue is--> "+premValue +" FaceAmount "+products.getScenario().getRequest().getFaceAmount()+" Difference is==> "+Math.abs((profileVO.getAffordablePremium() - Double.parseDouble(premValue)))+" For "+displayedInformation.getProductInformation().getDisplayName().replaceAll("[(0-9)_ -]",""));
											if(Math.abs((profileVO.getAffordablePremium() - Double.parseDouble(premValue))) <= productsNameMap.get(displayedInformation.getProductInformation().getDisplayName().replaceAll("[(0-9)_ -]",""))) {
												//tempPremiumValue = Math.abs(profileVO.getAffordablePremium() - Double.parseDouble(premValue));
												productsNameMap.put(displayedInformation.getProductInformation().getDisplayName().replaceAll("[(0-9)_ -]",""), Math.abs(profileVO.getAffordablePremium() - Double.parseDouble(premValue)));
												finalScenario = Integer.parseInt(products.getScenario().getRequest().getFaceAmount());
												premiumValue = Double.parseDouble(premValue);
												premiumMap.put(displayedInformation.getProductInformation().getDisplayName().replaceAll("[(0-9)_ -]","")+"|"+"Standard_Coverage", finalScenario.doubleValue());
												premiumMap.put(displayedInformation.getProductInformation().getDisplayName().replaceAll("[(0-9)_ -]","")+"|"+"Standard_Premium", premiumValue);
											}
										}
									
									}
								}
						}
						}
					} else {
						for (VTProductType products : productList) {
							count++;
							ScenarioType scenarioType = products.getScenario();

							ReturnType returnType = scenarioType.getReturn();
							DisplayedInformationType displayedInformation = returnType
									.getDisplayedInformation();
							String type = null;
							if (null != displayedInformation && null != displayedInformation.getPremiumInformation()) {
								List<ModalValueType> premiumList = displayedInformation
										.getPremiumInformation()
										.getFirstYearModalPremiums().getPremium();
								if (premiumList != null) {
									if (premiumList.get(3) != null) {
										String premValue = premiumList.get(3)
												.getValue();
										premValue = premValue.replace("$", "");
										premValue = premValue.replace(",", "");
										premValue = premValue.replace(",", "");

										premiumValue = Double
												.parseDouble(premValue);
										if (products.getScenario().getRequest().getUnderwritingClassInfo().getClazz() == 1) {
											type=displayedInformation.getProductInformation().getDisplayName().replaceAll("[(0-9)_ -]","")+"|"+"Preferred_Premium";
										} 
										else if (products.getScenario().getRequest().getUnderwritingClassInfo().getClazz() == 5) {
											type=displayedInformation.getProductInformation().getDisplayName().replaceAll("[(0-9)_ -]","")+"|"+"Standard_Premium";
										}
										LOGGER.debug("type name ====>>>"+type);
										premiumMap.put(type, premiumValue);
									}
								}
							}
						}
					}
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
			throw new ServiceException(e.getMessage());
		}
		return premiumMap;
	}

}
