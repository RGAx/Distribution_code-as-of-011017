package com.rga.rgility.service.impl;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.mail.Address;
import javax.mail.Message.RecipientType;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.FileSystemResource;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;

import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Chunk;
import com.itextpdf.text.Document;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.pdf.ColumnText;
import com.itextpdf.text.pdf.PdfContentByte;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import com.rga.rgility.common.logger.LogFactory;
import com.rga.rgility.common.logger.MyLifeCoveredLogger;
import com.rga.rgility.common.utilities.RedBorder;
import com.rga.rgility.exception.ServiceException;
import com.rga.rgility.model.UserCoverage;
import com.rga.rgility.service.EmailService;
import com.rga.rgility.valueobjects.AppliedQuoteVO;
import com.rga.rgility.valueobjects.DemographicInfoVO;
import com.rga.rgility.valueobjects.PremiumsInfoVO;
import com.rga.rgility.valueobjects.ProfileVO;

@Service
public class EmailServiceImpl implements EmailService {
	private static final MyLifeCoveredLogger LOGGER = LogFactory
			.getInstance(EmailServiceImpl.class);
	 private static final String[] numNames = {
		    "",
		    "One",
		    "Two",
		    "Three",
		    "Four",
		    "Five",
		    "Six",
		    "Seven",
		    "Eight",
		    "Nine",
		    "Ten",
		  };

	
	@Autowired
	private JavaMailSender mailSender;

	@Value("#{'${email.pdf.from}'}")
	private String emailFrom;

	@Value("#{'${email.pdf.subject}'}")
	private String subject;

	@Value("#{'${email.pdf.filename}'}")
	private String fileName;
	
	@Value("#{'${email.rgility.to}'}")
	private String rgilityEmailId;
	
	@Value("#{'${email.applynow.cc}'}")
	private String applyNowCC;
	
	@Value("#{'${context}'}")
	private String context;
	
	public void setMailSender(JavaMailSender mailSender) {
		this.mailSender = mailSender;
	}

	/**
	 * Generates the PDF report
	 * 
	 * @param emailAddress
	 * @param fileName
	 * @param insuranceNeeds
	 * @throws Exception
	 */
	public void generatePDF(Document document,PdfWriter writer,
			ProfileVO profileVO) throws Exception {
		
		try {
			LOGGER.debug("Entered Generate PDF method for profile: "+profileVO.getProfileId());
			NumberFormat formatter = NumberFormat.getCurrencyInstance();
			RedBorder event = new RedBorder();
	        writer.setPageEvent(event); 
			document.open();
			
			
		     	Font basefontOswald = FontFactory.getFont("oswald");
		     	Font basefontLato = FontFactory.getFont("lato");
	            basefontLato.setColor(BaseColor.BLACK); 
		        Font font3 = new Font(basefontOswald);
	            font3.setStyle(Font.BOLD);
	            font3.setSize(20);
	            Font font2 = new Font(basefontLato);
	            font2.setStyle(Font.BOLD);
	            font2.setColor(BaseColor.WHITE);
	            font2.setSize(11);
	            
	                       
	            PdfContentByte canvas = writer.getDirectContent();
	             Rectangle rect = new Rectangle(90, 140, 520, 660);
	             rect.setBorder(Rectangle.BOX);
	             rect.setBorderWidth(0.5f);
	             rect.setBackgroundColor(BaseColor.WHITE);
	             canvas.rectangle(rect);
	             
	              Rectangle rect1 = new Rectangle(197, 585, 440, 625);
	             ColumnText ct = new ColumnText(canvas);
	             ct.setSimpleColumn(rect1);
	             ct.addElement(new Paragraph(new Chunk("CONTINUING INCOME NEEDS",font3)));
	             ct.go();
	             canvas.rectangle(rect1);
	            Rectangle rect2 = new Rectangle(244, 375, 380, 405);
	             ColumnText ct2 = new ColumnText(canvas);
	             ct2.setSimpleColumn(rect2);
	             Chunk oneTimeNeeds = new Chunk("ONE TIME NEEDS",font3);
	             oneTimeNeeds=oneTimeNeeds.setTextRenderMode(PdfContentByte.TEXT_RENDER_MODE_STROKE, 4.0F, BaseColor.BLACK);
	             ct2.addElement(oneTimeNeeds);
	             ct2.go();
	             canvas.rectangle(rect2);
	             
	             Rectangle rect3 = new Rectangle(220, 647, 393, 673);
	             //rect3.setBorder(Rectangle.BOX);
	             rect3.setBorderWidth(0.5f);
	             rect3.setBackgroundColor(new BaseColor(255, 62, 62));
	            
	             canvas.rectangle(rect3);
	             
	             Rectangle rect4 = new Rectangle(230, 650, 380, 672);
	            // rect4.setBorder(Rectangle.BOX);
	             rect4.setBorderWidth(0.5f);
	             ColumnText ct3 = new ColumnText(canvas);
	             ct3.setSimpleColumn(rect4);
	             Paragraph paragraph = new Paragraph(new Chunk("RECOMMENDED COVERAGE",font2));
	             paragraph.setAlignment(Element.ALIGN_CENTER);
	             ct3.addElement(paragraph);
	             ct3.go();
	             canvas.rectangle(rect4);
	            
	           //Heading
	            Font fontHeading  = new Font(basefontLato); 
	           // fontHeading.setStyle(Font.BOLD);
	            
	            fontHeading.setSize(25);
	            fontHeading.setColor(BaseColor.WHITE);
	            Font fontHeadingBold  = new Font(fontHeading); 
	            fontHeadingBold.setStyle(Font.BOLD);
	           document.add(new Paragraph(new Chunk("\n")));
	            Paragraph header = null;
	           header = new Paragraph();
	           header.setAlignment(Element.ALIGN_CENTER);
	           header.add(new Chunk("MY LIFE ",fontHeading));
	           header.add(new Chunk("COVERED",fontHeadingBold));
	            
	            document.add(header);
	            document.add(new Paragraph(new Chunk("\n\n\n\n\n")));
	            document.add(new Paragraph(new Chunk("\n")));
	            
	           
	            //Recommended Coverage
	            Paragraph paragraph3 = new Paragraph(new Chunk("CONTINUING INCOME NEEDS",font3));
	            paragraph3.setAlignment(Rectangle.ALIGN_CENTER);
	            document.add(paragraph3);
	            document.add(new Paragraph(new Chunk("\n")));
	            
	            Font font4 = new Font(basefontLato);
	            font4.setSize(11);
	            
	            Font font5 = new Font(font4);
	            font5.setStyle(Font.BOLD);
	            
	            PdfPTable table2 = new PdfPTable(2); // 2 columns.
	            table2.setWidthPercentage(70);
	            PdfPCell table2Cell1 = getCell("Annual Income",font4,false,false);
	            PdfPCell table2Cell2 = getCell(getdecimal(formatter.format(profileVO.getAnnualIncome())),font4,true,false);
	            PdfPCell table2Cell3 = getCell("Years Income to be Provided",font4,false,false);
	            PdfPCell table2Cell4 = getCell("x "+profileVO.getYearsIncomeProvided(),font4,true,false);
	            PdfPCell table2Cell5 = getCell("Total Income to be Provided",font5,false,true);
	            PdfPCell table2Cell6 = getCell(getdecimal(formatter.format(profileVO.getTotalIncomeToBeProvided())),font5,true,true);
	            
	            
	            table2.addCell(table2Cell1);
	            table2.addCell(table2Cell2);
	            table2.addCell(table2Cell3);
	            table2.addCell(table2Cell4);
	            table2.addCell(table2Cell5);
	            table2.addCell(table2Cell6);
	            document.add(table2);
	            document.add(new Paragraph(new Chunk("\n")));
	            
	            //To set the column width
	            float[] columnWidths = {5, 3};
	            PdfPTable table3 = new PdfPTable(columnWidths); // 2 columns.
	            table3.setWidthPercentage(70);
	            PdfPCell table3Cell1 = getCell("Current Savings",font4,false,false);
	            PdfPCell table3Cell2 = getCell(getdecimal(formatter.format(profileVO.getOtherSavings())),font4,true,false);
	            PdfPCell table3Cell3 = getCell("Retirement Savings",font4,false,false);
	            PdfPCell table3Cell4 = getCell("+ "+getdecimal(formatter.format(profileVO.getRetirementSavings())),font4,true,false);
	            PdfPCell table3Cell5 = getCell("Deduct Your Existing Life Insurance Coverage",font4,false,false);
	            PdfPCell table3Cell6 = getCell("+ "+getdecimal(formatter.format(profileVO.getExistingLifeInsurance())),font4,true,false);
	            PdfPCell table3Cell7 = getCell("Less other sources of income/savings",font5,false,true);
	            String totalIncomeNeeds = getdecimal(formatter.format(profileVO.getTotalIncomeNeeds()));
	            if(totalIncomeNeeds.contains("(")){
	            	totalIncomeNeeds = totalIncomeNeeds.replace('(', '-');
	            }
	            PdfPCell table3Cell8 = getCell(totalIncomeNeeds,font5,true,true);
	            
	            table3.addCell(table3Cell1);
	            table3.addCell(table3Cell2);
	            table3.addCell(table3Cell3);
	            table3.addCell(table3Cell4);
	            table3.addCell(table3Cell5);
	            table3.addCell(table3Cell6);
	            table3.addCell(table3Cell7);
	            table3.addCell(table3Cell8);
	            
	            document.add(table3);
	            document.add(new Paragraph(new Chunk("\n\n")));
	            
	            Paragraph paragraph4 = new Paragraph(oneTimeNeeds);
	            paragraph4.setAlignment(Rectangle.ALIGN_CENTER);
	            document.add(paragraph4);
	            document.add(new Paragraph(new Chunk("\n")));
	            
	            if(profileVO.getChildCount()!=0){
		            PdfPTable table4 = new PdfPTable(columnWidths); // 2 columns.
		            table4.setWidthPercentage(70);
		            /*PdfPCell table4Cell1 = getCell("Children Requiring College Funding",font4,false,false);
		            PdfPCell table4Cell2 = getCell(String.valueOf(profileVO.getChildCount()),font4,true,false);*/
		            if(profileVO.getPrivateChildrenCount()!=0){
		            PdfPCell table4Cell3 = getCell(numNames[profileVO.getPrivateChildrenCount()]+(profileVO.getPrivateChildrenCount()==1 ? " Child":" Children")+" - Private College Expense",font4,false,false);
		            PdfPCell table4Cell4 = getCell(getdecimal(formatter.format(profileVO.getEstimatedPrivateCollegeExpenses())),font4,true,false);
		            table4.addCell(table4Cell3);
		            table4.addCell(table4Cell4);
		            }
		            if(profileVO.getPublicChildrenCount()!=0){
		            PdfPCell table4Cell5 = getCell(numNames[profileVO.getPublicChildrenCount()]+(profileVO.getPublicChildrenCount()==1? " Child":" Children")+" - Public College Expense",font4,false,false);
		            PdfPCell table4Cell6 = getCell(getdecimal(formatter.format(profileVO.getEstimatedPublicCollegeExpenses())),font4,true,false);
		            table4.addCell(table4Cell5);
		            table4.addCell(table4Cell6);
		            }
		            PdfPCell table4Cell7 = getCell("Total College Expense",font5,false,true);
		            PdfPCell table4Cell8 = getCell(getdecimal(formatter.format(profileVO.getTotalCollegeExpenses())),font5,true,true);
		           
		            
		          /*  table4.addCell(table4Cell1);
		            table4.addCell(table4Cell2);*/
		            
		            /*table4.addCell(table4Cell5);
		            table4.addCell(table4Cell6);*/
		            table4.addCell(table4Cell7);
		            table4.addCell(table4Cell8);
		            
		            document.add(table4);
		            document.add(new Paragraph(new Chunk("\n")));
	            }
	            
	            
	            
	            PdfPTable table5 = new PdfPTable(2); // 2 columns.
	            table5.setWidthPercentage(70);
	            PdfPCell table5Cell1 = getCell("Funeral Expenses",font4,false,false);
	            PdfPCell table5Cell2 = getCell(getdecimal(formatter.format(profileVO.getFinalExpenses())),font4,true,false);
	            PdfPCell table5Cell3 = getCell("Outstanding Debts",font4,false,false);
	            PdfPCell table5Cell4 = getCell("+ "+getdecimal(formatter.format(profileVO.getOtherOutstandingDebt())),font4,true,false);
	            PdfPCell table5Cell5 = getCell("Outstanding Mortgage",font4,false,false);
	            PdfPCell table5Cell6 = getCell("+ "+getdecimal(formatter.format(profileVO.getOutstandingMortgage())),font4,true,false);
	            PdfPCell table5Cell7 = getCell("Total One Time Needs",font5,false,true);
	            PdfPCell table5Cell8 = getCell(getdecimal(formatter.format(profileVO.getTotalOneTimeNeeds())),font5,true,true);
	            
	            table5.addCell(table5Cell1);
	            table5.addCell(table5Cell2);
	            table5.addCell(table5Cell3);
	            table5.addCell(table5Cell4);
	            table5.addCell(table5Cell5);
	            table5.addCell(table5Cell6);
	            table5.addCell(table5Cell7);
	            table5.addCell(table5Cell8);
	            
	            document.add(table5);
	            if(profileVO.getChildCount()!=0){
	            	 if(profileVO.getPrivateChildrenCount()==0 ||  profileVO.getPublicChildrenCount()==0){
	            		 document.add(new Paragraph(new Chunk("\n\n\n"))); 
	            	 }else{
	            		 document.add(new Paragraph(new Chunk("\n\n")));
	            	 }
	            	
	            }else{
	            	document.add(new Paragraph(new Chunk("\n\n\n\n\n\n")));
	            }
	            document.add(new Paragraph(new Chunk("\n\n\n")));
	            
	            Font fontT = new Font(basefontOswald);
	            fontT.setSize(10);
	            fontT.setColor(BaseColor.WHITE);
	            Paragraph paragraphT = new Paragraph(new Chunk("After the adjustment of inflation and investment return",fontT));
	            paragraphT.setAlignment(Rectangle.ALIGN_CENTER);
	            document.add(paragraphT);
	            
	            Font font6 = new Font(basefontOswald);
	            //font6.setStyle(Font.BOLD);
	            font6.setColor(BaseColor.WHITE);
	            font6.setSize(20);
	            
	            Font font7 = new Font(font6);
	            font7.setColor(new BaseColor(255, 62, 62));
	            Paragraph para = new Paragraph(new Phrase("TOTAL COVERAGE: ",font6));
	            if(profileVO.getCoverage()>0){
	            para.add(new Phrase(getdecimal(formatter.format(profileVO.getCoverage())),font7));
	            }
	            else{
	            	String coverage = getdecimal(formatter.format(profileVO.getCoverage()));
	            	coverage = coverage.replace('(', '-');
	            	 para.add(new Phrase(coverage,font7));
	            }
	            para.setAlignment(Paragraph.ALIGN_CENTER);
	            
	            document.add(para);
	            
	          //  document.close();
	        } catch(Exception e){
	       	 	throw new Exception(e.getMessage());
	        }

	}

	/**
	 * Send email without attachment
	 */
	public void sendMail(String from, String to, String subject, String msg)
			throws ServiceException {
		long startTime = LOGGER.logMethodEntry();
		LOGGER.debug("from: " + from + ", to: " + to);
		try {
			MimeMessage message = mailSender.createMimeMessage();
			message.setSubject(subject);
			//message.setContent(message,"text/html");
			//message.setContent(message,"multipart/mixed");
			
			if(to != null) {
				Address[] addresses = new InternetAddress[to.split(",").length];
				for(int i = 0; i < to.split(",").length; i++) {
					addresses[i] = new InternetAddress(to.split(",")[i].trim());
				}
				message.addRecipients(RecipientType.TO, addresses);
			}
			MimeMessageHelper helper;
			helper = new MimeMessageHelper(message, true);
			helper.setFrom(from);
			//helper.setTo(to);
			helper.setText(msg, true);
			mailSender.send(message);

			LOGGER.logMethodExit(startTime);
		} catch (Exception e) {
			LOGGER.error("ERROR : " + e.getMessage());
			throw new ServiceException(e.getMessage());
		}

	}

	/**
	 * Send mail with attachment
	 * 
	 * @param from
	 * @param to
	 * @param subject
	 * @param msg
	 * @param fileName
	 * @throws ServiceException
	 */
	private void sendMailWithAttachment(String from, String to, String subject,
			String msg, String fileName) throws ServiceException {
		long startTime = LOGGER.logMethodEntry();
		LOGGER.debug("from: " + from + ", to: " + to);
		try {
			MimeMessage message = mailSender.createMimeMessage();
			message.setSubject(subject);
			message.setContent(message,"text/plain");
			message.setContent(message,"multipart/mixed");
			MimeMessageHelper helper;
			helper = new MimeMessageHelper(message, true);
			helper.setFrom(from);
			helper.setTo(to);
			helper.setText(msg, true);
			FileSystemResource file = new FileSystemResource(fileName);
			helper.addAttachment(file.getFilename(), file);
			mailSender.send(message);

			LOGGER.logMethodExit(startTime);
		} catch (Exception e) {
			LOGGER.error("ERROR : " + e.getMessage());
			throw new ServiceException(e.getMessage());
		}
	}

	/* (non-Javadoc)
	 * @see com.rga.rgility.service.EmailService#sendemailtoUser(com.rga.rgility.valueobjects.ProfileVO, com.rga.rgility.valueobjects.AppliedQuoteVO)
	 */
	@Override
	public String sendemailtoUser(ProfileVO profileVO,AppliedQuoteVO appliedQuoteVO) throws ServiceException {
		
		String subject = "", msg="";
		
		try{
			if(null != profileVO && null != profileVO.getDemographicVO()){
				DemographicInfoVO demographicInfoVO = profileVO.getDemographicVO();
				
				if(null != demographicInfoVO){
					if(null != demographicInfoVO.getIsUsCitizen() && 
							!demographicInfoVO.getIsUsCitizen().isEmpty() && demographicInfoVO.getIsUsCitizen().equals("1") ){
						subject += "US-CITIZEN-";
					}if(null != demographicInfoVO.getIsPolicyOwner() && 
							!demographicInfoVO.getIsPolicyOwner().isEmpty() && demographicInfoVO.getIsPolicyOwner().equals("1") ){
						subject += "POLICYOWNER-";
					}if(null != demographicInfoVO.getIsConsentReplacementPolicy() && 
							!demographicInfoVO.getIsConsentReplacementPolicy().isEmpty() && demographicInfoVO.getIsConsentReplacementPolicy().equals("1") ){
						subject += "CONSENTREPLACEMENTPOLICY";
					}
					
				}					
				msg += "HI TODD,<br><br>"
						+ "User has Submitted below details for Insurance needs.<br>";
				msg += "<table>";
				msg += "<br/><tr colspan='2'><td align='center'> <b>Application Details:</b></td></tr>";
				if(null != profileVO.getFirstName()){
					msg += "<tr ><td align='right'>FIRST NAME:</td><td align='left'>"+profileVO.getFirstName()+"</td></tr>";
				}if(null != demographicInfoVO.getDateOfBirth() ){
					msg += "<tr ><td align='right'>DATE OF BIRTH:</td><td align='left'>"+demographicInfoVO.getDateOfBirth()+"</td></tr>";
				}if(null != demographicInfoVO.getEmailAddress()){
					msg += "<tr ><td align='right'>EMAIL ADDRESS:</td><td align='left'>"+demographicInfoVO.getEmailAddress()+"</td></tr>";
				}
				msg += "<tr ><td align='right'>ANNUAL INCOME:</td><td align='left'> $"+profileVO.getAnnualIncome()+"</td></tr>";
				if(null != demographicInfoVO.getSmokerStatus()){
					msg += "<tr ><td align='right'>SMOKER STATUS:</td><td align='left'>";
					msg	+= null != demographicInfoVO.getSmokerStatus() && demographicInfoVO.getSmokerStatus().equals("1") ? "Yes": "No"+"</td></tr>";
				}if(null != demographicInfoVO.getGender()){
					msg += "<tr ><td align='right'>GENDER:</td><td align='left'>";
					msg += null != demographicInfoVO.getGender() && demographicInfoVO.getGender().equalsIgnoreCase("M") ? "Male":"Female"+"</td></tr>";
				}if(null != demographicInfoVO.getState()){
					msg += "<tr ><td align='right'>STATE CODE:</td><td align='left'>"+demographicInfoVO.getState()+"</td></tr>";
				}if(null != demographicInfoVO.getIsUsCitizen()){
					msg	+= "<tr ><td align='right'>IS US CITIZEN:</td><td align='left'>";
					msg	+= null != demographicInfoVO.getIsUsCitizen() && demographicInfoVO.getIsUsCitizen().equals("1") ? "Y":"N"+"</td></tr>";
				}if(null != demographicInfoVO.getIsPolicyOwner()){
					msg += "<tr ><td align='right'>IS POLICY OWNER:</td><td align='left'>";
					msg	+= null != demographicInfoVO.getIsPolicyOwner() && demographicInfoVO.getIsPolicyOwner().equals("1") ? "Y":"N"+"</td></tr>";
				}if(null != demographicInfoVO.getIsConsentReplacementPolicy()){
					msg	+= "<tr ><td align='right'>IS CONSENT REPLACEMENT POLICY:</td><td align='left'>";
					msg	+= null != demographicInfoVO.getIsConsentReplacementPolicy() && demographicInfoVO.getIsConsentReplacementPolicy().equals("1") ? "Y":"N" +"</td></tr>";
				}
				msg += "<tr ><td align='right'>COVERAGE:</td><td align='left'> $"+appliedQuoteVO.getCoverage()+"</td></tr>";
				msg += "<tr ><td align='right'>TERM:</td><td align='left'>"+appliedQuoteVO.getTerm()+" Years </td></tr>";
				msg += "<tr ><td align='right'>BEST PREMIUM PERMONTH:</td><td align='left'> $"+appliedQuoteVO.getBestPremiumPerMonth()+"</td></tr>";
				msg += "<tr ><td align='right'>STANDARD PREMIUM PERMONTH:</td><td align='left'> $"+appliedQuoteVO.getStandardPremiumPerMonth()+"</td></tr>";
				if(null != appliedQuoteVO.getSystemInFocus()){
					msg += "<tr ><td align='right'>SUBMITTED STATUS:</td><td align='left'>";
					msg += null != appliedQuoteVO.getSystemInFocus() && appliedQuoteVO.getSystemInFocus().equalsIgnoreCase("P")? "EMail": "Rgility"+"</td></tr>";
				}
				msg += "<tr ><td align='right'>RETIREMENT SAVINGS:</td><td align='left'> $"+profileVO.getRetirementSavings()+"</td></tr>";
				msg += "<tr ><td align='right'>OTHER SAVINGS:</td><td align='left'> $"+profileVO.getOtherSavings()+"</td></tr>";
				msg += "<tr ><td align='right'>EXISTING LIFE INSURANCE:</td><td align='left'> $"+profileVO.getExistingLifeInsurance()+"</td></tr>";
				msg += "<tr ><td align='right'>YEARS INCOME PROVIDED:</td><td align='left'>"+profileVO.getYearsIncomeProvided()+" Years </td></tr>";
				msg += "<tr ><td align='right'>CURRENT RETIREMENT SAVINGS:</td><td align='left'> $"+profileVO.getRetirementSavings()+"</td></tr>";
				msg += "<tr ><td align='right'>FUNERAL EXPENSES:</td><td align='left'> $"+profileVO.getFinalExpenses()+"</td></tr>";
				msg += "<tr ><td align='right'>OUTSTANDING MORTGAGE:</td><td align='left'> $"+profileVO.getOutstandingMortgage()+"</td></tr>";
				msg += "<tr ><td align='right'>OTHER OUTSTANDING DEBT:</td><td align='left'> $"+profileVO.getOtherOutstandingDebt()+"</td></tr>";
				msg += "<tr ><td align='right'>ESTIMATED INFLATION RATE:</td><td align='left'>"+profileVO.getEstimatedInflationRate()+"</td></tr>";
				msg += "<tr ><td align='right'>ESTIMATED INVESTMENT RETURN:</td><td align='left'>"+profileVO.getEstimatedInvestmentReturn()+"</td></tr>";
				msg += "<tr ><td align='right'>TOTAL INCOME TO BE PROVIDED:</td><td align='left'> $"+profileVO.getTotalIncomeToBeProvided()+"</td></tr>";
				msg += "<tr ><td align='right'>Less other sources of income/savings:</td><td align='left'> $"+profileVO.getTotalIncomeNeeds()+"</td></tr>";
				msg += "<tr ><td align='right'>TOTAL COLLEGE EXPENSES:</td><td align='left'> $"+profileVO.getTotalCollegeExpenses()+"</td></tr>";
				msg += "<tr ><td align='right'>TOTAL ONE TIME NEEDS:</td><td align='left'> $"+profileVO.getTotalOneTimeNeeds()+"</td></tr></table><br/><br/>";
				/*msg += "Regards,<br>Rgility";*/
			}
			
			this.sendMail(emailFrom, rgilityEmailId, subject, msg);
		}catch(ServiceException se){
			LOGGER.error("ERROR : " + se.getMessage());
			throw new ServiceException(se.getMessage());
		}
		
		return "success";
	}
	
	/**
	 * Method to construct Body Content.
	 * @param email
	 * @param phoneNumber
	 * @param bestTimeTocall
	 * @param comments
	 * @return String
	 * @throws ServiceException 
	 */
	public void sendContactUsEmail(UserCoverage user,ProfileVO profileVO,String phoneNumber,String src) throws ServiceException {
		sendConsumerContactUsEmail(user.getName(),user.getEmail(),phoneNumber,src);
		
		StringBuffer msg;
		String subject;
		try {
			msg = new StringBuffer();
			boolean noRows = false;
			subject = "MY LIFE COVERED - Insurance Inquiry";
			msg.append("Hi,<br/><br/>User has visited MY LIFE COVERED application and has requested for a call back. Please see below for more details:<br/><br/>");
			msg.append("<table>");
			
			msg.append("<tr>");
			msg.append("<td colspan=\"2\">");
			msg.append("<b>CONTACT INFORMATION</b>");
			msg.append("</td>");
			msg.append("</tr>");
			
			msg.append("<tr>");
			msg.append("<td>");
			msg.append("Email Address: ");
			msg.append("</td>");
			msg.append("<td>");
			msg.append(user.getEmail());
			msg.append("</td>");
			msg.append("</tr>");
			
			if (user.getName() != null) {
				msg.append("<tr>");
				msg.append("<td>");
				msg.append("Name: ");
				msg.append("</td>");
				msg.append("<td>");
				msg.append(user.getName());
				msg.append("</td>");
				msg.append("</tr>");
			}
			
			if (user.getPhone() != null) {
				msg.append("<tr>");
				msg.append("<td>");
				msg.append("Phone Number: ");
				msg.append("</td>");
				msg.append("<td>");
				msg.append(user.getPhone());
				msg.append("</td>");
				msg.append("</tr>");
			}	

			if (user.getBestTimeToCall() != null) {
				msg.append("<tr>");
				msg.append("<td>");
				msg.append("Best Time To Call: ");
				msg.append("</td>");
				msg.append("<td>");
				msg.append(user.getBestTimeToCall());
				msg.append("</td>");
				msg.append("</tr>");
			}	
			if (user.getComments() != null) {
				msg.append("<tr>");
				msg.append("<td>");
				msg.append("Comments: ");
				msg.append("</td>");
				msg.append("<td>");
				msg.append(user.getComments());
				msg.append("</td>");
				msg.append("</tr>");
			}
			
			msg.append("</table><br/>");
			
			//User Information
			msg.append("<table>");
			
			msg.append("<tr>");
			msg.append("<td colspan=\"2\">");
			msg.append("<b>INFORMATION CAPTURED BY MY LIFE COVERED</b>");
			msg.append("</td>");
			msg.append("</tr>");
			
			if(null != profileVO && null != profileVO.getAppliedQuoteVO()){
				
				if(null != profileVO.getAppliedQuoteVO().getProductPremiumsCoveragesList()){
					
					for(PremiumsInfoVO premiums: profileVO.getAppliedQuoteVO().getProductPremiumsCoveragesList()) {
						if(premiums.getProductName().equalsIgnoreCase("TransamericaTrendsetterSuper")) {
							if(profileVO.getCoverage() != 0.0 && premiums.getBestPremiumPerMonth() != 0.0 && premiums.getStandardPremiumPerMonth() != 0.0){
								noRows = true;
								msg.append("<tr>");
								msg.append("<td>");
								msg.append("Coverage : ");
								msg.append("</td>");
								msg.append("<td>");
								msg.append(profileVO.getCoverage());
								msg.append("</td>");
								msg.append("</tr>");
								
								msg.append("<tr>");
								msg.append("<td>");
								msg.append("Best Premium : ");
								msg.append("</td>");
								msg.append("<td>");
								msg.append(premiums.getBestPremiumPerMonth());
								msg.append("</td>");
								msg.append("</tr>");
								
								msg.append("<tr>");
								msg.append("<td>");
								msg.append("Standard Premium : ");
								msg.append("</td>");
								msg.append("<td>");
								msg.append(premiums.getStandardPremiumPerMonth());
								msg.append("</td>");
								msg.append("</tr>");
							}
							break;
						}
					
					}
					
				}
				
				if (profileVO != null) {
					
					if (profileVO.getFirstName() != null) {
						noRows = true;
						msg.append("<tr>");
						msg.append("<td>");
						msg.append("First Name: ");
						msg.append("</td>");
						msg.append("<td>");
						msg.append(profileVO.getFirstName());
						msg.append("</td>");
						msg.append("</tr>");
					}
					
					if (profileVO.getDemographicVO() != null ) {
						
						if(profileVO.getDemographicVO().getDateOfBirth() != null) {
							SimpleDateFormat sdf1 = new SimpleDateFormat("MMddyyyy");
							SimpleDateFormat sdf2 = new SimpleDateFormat("MM/dd/yyyy");
							Date dob = profileVO.getDemographicVO().getDateOfBirth();
							try {
								noRows = true;
								msg.append("<tr>");
								msg.append("<td>");
								msg.append("Date Of Birth: ");
								msg.append("</td>");
								msg.append("<td>");
								msg.append(sdf2.format(dob));
								msg.append("</td>");
								msg.append("</tr>");
							} catch (Exception e) {
								LOGGER.error("ERROR: " + e.getMessage());
								e.printStackTrace();
							}
						}
						
						if (profileVO.getDemographicVO().getEmailAddress() != null) {
							noRows = true;
							msg.append("<tr>");
							msg.append("<td>");
							msg.append("Email address: ");
							msg.append("</td>");
							msg.append("<td>");
							msg.append(profileVO.getDemographicVO().getEmailAddress());
							msg.append("</td>");
							msg.append("</tr>");
						}
						
						if (profileVO.getDemographicVO().getSmokerStatus() != null) {
							noRows = true;
							String smokingStatus = (profileVO.getDemographicVO().getSmokerStatus() == "1")?"Yes":"No";
							msg.append("<tr>");
							msg.append("<td>");
							msg.append("Smoker Or Non-smoker: ");
							msg.append("</td>");
							msg.append("<td>");
							msg.append(smokingStatus);
							msg.append("</td>");
							msg.append("</tr>");
						}
						
						if (profileVO.getDemographicVO().getGender() != null) {
							noRows = true;
							String gender = (profileVO.getDemographicVO().getGender().equalsIgnoreCase("M"))?"Male":"Female";
							msg.append("<tr>");
							msg.append("<td>");
							msg.append("Biological Gender: ");
							msg.append("</td>");
							msg.append("<td>");
							msg.append(gender);
							msg.append("</td>");
							msg.append("</tr>");
						}
						
						if (profileVO.getDemographicVO().getState() != null) {
							noRows = true;
							msg.append("<tr>");
							msg.append("<td>");
							msg.append("State: ");
							msg.append("</td>");
							msg.append("<td>");
							msg.append(profileVO.getDemographicVO().getState());
							msg.append("</td>");
							msg.append("</tr>");
						}
						
						if (profileVO.getDemographicVO().getIsUsCitizen() != null) {
							noRows = true;
							String value = (profileVO.getDemographicVO().getIsUsCitizen().equalsIgnoreCase("true"))?"Yes":"No";
							msg.append("<tr>");
							msg.append("<td>");
							msg.append("US Citizen: ");
							msg.append("</td>");
							msg.append("<td>");
							msg.append(value);
							msg.append("</td>");
							msg.append("</tr>");
						}
						
						if (profileVO.getDemographicVO().getIsPolicyOwner() != null) {
							noRows = true;
							String value = (profileVO.getDemographicVO().getIsPolicyOwner().equalsIgnoreCase("true"))?"Yes":"No";
							msg.append("<tr>");
							msg.append("<td>");
							msg.append("Policy Owner: ");
							msg.append("</td>");
							msg.append("<td>");
							msg.append(value);
							msg.append("</td>");
							msg.append("</tr>");
						}
						
						if (profileVO.getDemographicVO().getIsConsentReplacementPolicy() != null) {
							noRows = true;
							String value = (profileVO.getDemographicVO().getIsConsentReplacementPolicy().equalsIgnoreCase("true"))?"Yes":"No";
							msg.append("<tr>");
							msg.append("<td>");
							msg.append("Replacement Existing Policy: ");
							msg.append("</td>");
							msg.append("<td>");
							msg.append(value);
							msg.append("</td>");
							msg.append("</tr>");
						}
					}
						
					
					noRows = true;
					msg.append("<tr>");
					msg.append("<td>");
					msg.append("Current Annual Income: ");
					msg.append("</td>");
					msg.append("<td>");
					msg.append("$" + profileVO.getAnnualIncome());
					msg.append("</td>");
					msg.append("</tr>");				
					
					noRows = true;
					msg.append("<tr>");
					msg.append("<td>");
					msg.append("Retirement Savings: ");
					msg.append("</td>");
					msg.append("<td>");
					msg.append("$"+profileVO.getRetirementSavings());
					msg.append("</td>");
					msg.append("</tr>");
					
					msg.append("<tr>");
					msg.append("<td>");
					msg.append("Other Savings: ");
					msg.append("</td>");
					msg.append("<td>");
					msg.append("$"+profileVO.getOtherSavings());
					msg.append("</td>");
					msg.append("</tr>");
					
					msg.append("<tr>");
					msg.append("<td>");
					msg.append("Existing Life Insurance: ");
					msg.append("</td>");
					msg.append("<td>");
					msg.append("$"+profileVO.getExistingLifeInsurance());
					msg.append("</td>");
					msg.append("</tr>");
					
					msg.append("<tr>");
					msg.append("<td>");
					msg.append("Years Income Provided: ");
					msg.append("</td>");
					msg.append("<td>");
					msg.append(profileVO.getYearsIncomeProvided()+" years");
					msg.append("</td>");
					msg.append("</tr>");
					
					msg.append("<tr>");
					msg.append("<td>");
					msg.append("Funeral Expenses: ");
					msg.append("</td>");
					msg.append("<td>");
					msg.append("$"+profileVO.getFinalExpenses());
					msg.append("</td>");
					msg.append("</tr>");
					
					msg.append("<tr>");
					msg.append("<td>");
					msg.append("Outstanding Mortgage: ");
					msg.append("</td>");
					msg.append("<td>");
					msg.append("$"+profileVO.getOutstandingMortgage());
					msg.append("</td>");
					msg.append("</tr>");

					msg.append("<tr>");
					msg.append("<td>");
					msg.append("Other Outstanding Debt: ");
					msg.append("</td>");
					msg.append("<td>");
					msg.append("$"+profileVO.getOtherOutstandingDebt());
					msg.append("</td>");
					msg.append("</tr>");

					msg.append("<tr>");
					msg.append("<td>");
					msg.append("Estimated Inflation Rate: ");
					msg.append("</td>");
					msg.append("<td>");
					msg.append(profileVO.getEstimatedInflationRate());
					msg.append("</td>");
					msg.append("</tr>");


					msg.append("<tr>");
					msg.append("<td>");
					msg.append("Estimated Investment Return: ");
					msg.append("</td>");
					msg.append("<td>");
					msg.append(profileVO.getEstimatedInvestmentReturn());
					msg.append("</td>");
					msg.append("</tr>");


					msg.append("<tr>");
					msg.append("<td>");
					msg.append("Total Income to be Provided: ");
					msg.append("</td>");
					msg.append("<td>");
					msg.append("$"+profileVO.getTotalIncomeToBeProvided());
					msg.append("</td>");
					msg.append("</tr>");

					msg.append("<tr>");
					msg.append("<td>");
					msg.append("Less other sources of income/savings: ");
					msg.append("</td>");
					msg.append("<td>");
					msg.append("$"+profileVO.getTotalIncomeNeeds());
					msg.append("</td>");
					msg.append("</tr>");

					msg.append("<tr>");
					msg.append("<td>");
					msg.append("Total College Expenses: ");
					msg.append("</td>");
					msg.append("<td>");
					msg.append("$"+profileVO.getTotalCollegeExpenses());
					msg.append("</td>");
					msg.append("</tr>");

					msg.append("<tr>");
					msg.append("<td>");
					msg.append("Total One Time Needs: ");
					msg.append("</td>");
					msg.append("<td>");
					msg.append("$"+profileVO.getTotalOneTimeNeeds());
					msg.append("</td>");
					msg.append("</tr>");
					
				}
			}else{
				if (!noRows) {
					msg.append("<tr>");
					msg.append("<td colspan=\"2\">");
					msg.append("None ");
					msg.append("</td>");
					msg.append("</tr>");
				}
			}
			msg.append("</table><br/>");
			msg.append("Regards,<br/>Rgility");
			this.sendMail(emailFrom, rgilityEmailId, subject, msg.toString());
		} catch (Exception e) {
			LOGGER.error("ERROR: " + e.getMessage());
			throw new ServiceException(e.getMessage());
		}
	}
	
	private static PdfPCell getCell(String phrase, Font font,Boolean alignRight ,Boolean border){
		PdfPCell cell= new PdfPCell();
		cell.setBorder(PdfPCell.NO_BORDER);
		cell.setPaddingBottom(4f);
		Paragraph paragraph = new Paragraph(11f,phrase,font);
		if(alignRight){
			paragraph.setAlignment(Element.ALIGN_RIGHT);
		}
		cell.addElement(paragraph);
		//cell.setFixedHeight(17f);
		if(border){
			cell.setBorder(PdfPCell.TOP);
			cell.setBorderWidth(1.5f);
			
			
		}
		return cell;
	}
	
	private static String getdecimal(String decimalNo){
   	 String newDecimal = decimalNo.substring(0, decimalNo.indexOf('.'));
   	 return newDecimal;
   	 
   }
	
	
	public void sendApplyNowEmail(ProfileVO profileVO, AppliedQuoteVO appliedQuoteVO) {
		MimeMessage message = mailSender.createMimeMessage();
		StringBuffer msg = new StringBuffer();
		try{
			MimeMessageHelper helper = new MimeMessageHelper(message, true);
			helper.setFrom("admin@asgyes.com");
			helper.setTo(profileVO.getDemographicVO().getEmailAddress());
			helper.setCc(applyNowCC);
			helper.setSubject("Thanks for applying Life Insurance using MY LIFE COVERED.");
			msg.append("Dear Consumer,<br/><br/> Thanks for applying Life Insurance using MY LIFE COVERED.<br/> Please check the attached spreadsheet for your request details.<br/> We will contact you as soon as possible.<br/><br/>");
			msg.append("<strong>Note:</strong> This is a system generated email. Please do not respond to this email.");
			helper.setText(msg.toString(), true);
			constructExcelContent(profileVO,appliedQuoteVO);
			FileSystemResource file = new FileSystemResource("C:\\Temp\\MYLIFECOVERED_request_details.xls");
			helper.addAttachment(file.getFilename(), file);
			mailSender.send(message);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * Method to construct excel sheet content and write to a file.
	 * @param profileVO
	 * @param appliedQuoteVO
	 */
	private void constructExcelContent(ProfileVO profileVO, AppliedQuoteVO appliedQuoteVO) {
		XSSFWorkbook workbook = new XSSFWorkbook();
		XSSFSheet sheet = workbook.createSheet("Request Details");
		
		XSSFCellStyle style = workbook.createCellStyle();
        style.setBorderTop(HSSFCellStyle.BORDER_THICK); 
        style.setBorderBottom(HSSFCellStyle.BORDER_THICK); 
        style.setBorderLeft(HSSFCellStyle.BORDER_THICK);
        style.setBorderRight(HSSFCellStyle.BORDER_THICK);
        style.setFillForegroundColor(HSSFColor.YELLOW.index);
        style.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);

        
        XSSFFont font = workbook.createFont();
        font.setFontHeightInPoints((short) 12);
        font.setBoldweight(XSSFFont.BOLDWEIGHT_BOLD);
        style.setFont(font); 
        
        
        XSSFCellStyle datastyle = workbook.createCellStyle();
        datastyle.setBorderTop(HSSFCellStyle.BORDER_MEDIUM); 
        datastyle.setBorderBottom(HSSFCellStyle.BORDER_MEDIUM); 
        datastyle.setBorderLeft(HSSFCellStyle.BORDER_MEDIUM);
        datastyle.setBorderRight(HSSFCellStyle.BORDER_MEDIUM);
        datastyle.setAlignment(datastyle.ALIGN_LEFT);
        XSSFFont datafont = workbook.createFont();
        datafont.setFontHeightInPoints((short) 11);
        datafont.setBoldweight(XSSFFont.BOLDWEIGHT_NORMAL);
        datastyle.setFont(datafont);
        
        XSSFCellStyle datestyle = workbook.createCellStyle();
        datestyle.setBorderTop(HSSFCellStyle.BORDER_MEDIUM); 
        datestyle.setBorderBottom(HSSFCellStyle.BORDER_MEDIUM); 
        datestyle.setBorderLeft(HSSFCellStyle.BORDER_MEDIUM);
        datestyle.setBorderRight(HSSFCellStyle.BORDER_MEDIUM);
        datestyle.setAlignment(datestyle.ALIGN_LEFT);
        datestyle.setDataFormat(workbook.createDataFormat().getFormat("MM/dd/yyyy"));
        
        
		Row row0 = sheet.createRow(0);
		
		Cell cell0 = row0.createCell(0);
		cell0.setCellValue("Field Name");
		cell0.setCellStyle(style);
		
		Cell cell01 = row0.createCell(1);
		cell01.setCellValue("Value");
		cell01.setCellStyle(style);
		
		Row row = sheet.createRow(1);
		
		Cell cell = row.createCell(0);
		cell.setCellValue("First Name");
		cell.setCellStyle(datastyle);
		
		Cell cell1 = row.createCell(1);
		cell1.setCellValue(profileVO.getFirstName());
		cell1.setCellStyle(datastyle);
		
		Row row2 = sheet.createRow(2);
		
		Cell cell21 = row2.createCell(0);
		cell21.setCellValue("Date Of Birth");
		cell21.setCellStyle(datastyle);
		
		Cell cell22 = row2.createCell(1);
		cell22.setCellValue(profileVO.getDemographicVO().getDateOfBirth());
		cell22.setCellStyle(datestyle);
		
		Row row3 = sheet.createRow(3);
		
		Cell cell31 = row3.createCell(0);
		cell31.setCellValue("Email address");
		cell31.setCellStyle(datastyle);
		
		Cell cell32 = row3.createCell(1);
		cell32.setCellValue(profileVO.getDemographicVO().getEmailAddress());
		cell32.setCellStyle(datastyle);
		
		Row row4 = sheet.createRow(4);
		
		Cell cell41 = row4.createCell(0);
		cell41.setCellValue("Current Annual Income");
		cell41.setCellStyle(datastyle);
		
		Cell cell42 = row4.createCell(1);
		cell42.setCellValue(formatAmount(profileVO.getAnnualIncome()));
		cell42.setCellStyle(datastyle);
		
		Row row5 = sheet.createRow(5);
		
		Cell cell51 = row5.createCell(0);
		cell51.setCellValue("Smoker or Non Smoker");
		cell51.setCellStyle(datastyle);
		
		Cell cell52 = row5.createCell(1);
		cell52.setCellValue(profileVO.getDemographicVO().getSmokerStatus().equals("1")?"Yes":"No");
		cell52.setCellStyle(datastyle);
		
		Row row6 = sheet.createRow(6);
		
		Cell cell61 = row6.createCell(0);
		cell61.setCellValue("Biological Gender");
		cell61.setCellStyle(datastyle);
		
		Cell cell62 = row6.createCell(1);
		cell62.setCellValue(profileVO.getDemographicVO().getGender().equals("M")?"Male":"Female");
		cell62.setCellStyle(datastyle);
		
		Row row7 = sheet.createRow(7);
		
		Cell cell71 = row7.createCell(0);
		cell71.setCellValue("State");
		cell71.setCellStyle(datastyle);
		
		Cell cell72 = row7.createCell(1);
		cell72.setCellValue(profileVO.getDemographicVO().getState());
		cell72.setCellStyle(datastyle);
		
		Row row8 = sheet.createRow(8);
		
		Cell cell81 = row8.createCell(0);
		cell81.setCellValue("US Citizen");
		cell81.setCellStyle(datastyle);
		
		Cell cell82 = row8.createCell(1);
		cell82.setCellValue(profileVO.getDemographicVO().getIsUsCitizen().equals("1")?"Y":"N");
		cell82.setCellStyle(datastyle);
		
		Row row9 = sheet.createRow(9);
		
		Cell cell91 = row9.createCell(0);
		cell91.setCellValue("Policy Owner");
		cell91.setCellStyle(datastyle);
		
		Cell cell92 = row9.createCell(1);
		cell92.setCellValue(profileVO.getDemographicVO().getIsPolicyOwner().equals("1")?"Y":"N");
		cell92.setCellStyle(datastyle);
		
		Row row10 = sheet.createRow(10);
		
		Cell cell101 = row10.createCell(0);
		cell101.setCellValue("Replacement Existing Policy");
		cell101.setCellStyle(datastyle);
		
		Cell cell102 = row10.createCell(1);
		cell102.setCellValue(profileVO.getDemographicVO().getIsConsentReplacementPolicy().equals("1")?"Y":"N");
		cell102.setCellStyle(datastyle);
		
		Row row11 = sheet.createRow(11);
		
		Cell cell111 = row11.createCell(0);
		cell111.setCellValue("Retirement Savings");
		cell111.setCellStyle(datastyle);
		
		Cell cell112 = row11.createCell(1);
		cell112.setCellValue(formatAmount(profileVO.getRetirementSavings()));
		cell112.setCellStyle(datastyle);
		
		Row row12 = sheet.createRow(12);
		
		Cell cell121 = row12.createCell(0);
		cell121.setCellValue("Other Savings");
		cell121.setCellStyle(datastyle);
		
		Cell cell122 = row12.createCell(1);
		cell122.setCellValue(formatAmount(profileVO.getOtherSavings()));
		cell122.setCellStyle(datastyle);
		
		Row row13 = sheet.createRow(13);
		
		Cell cell131 = row13.createCell(0);
		cell131.setCellValue("Existing Life Insurance");
		cell131.setCellStyle(datastyle);
		
		Cell cell132 = row13.createCell(1);
		cell132.setCellValue(formatAmount(profileVO.getExistingLifeInsurance()));
		cell132.setCellStyle(datastyle);
		
		Row row14 = sheet.createRow(14);
		
		Cell cell141 = row14.createCell(0);
		cell141.setCellValue("Years Income Provided");
		cell141.setCellStyle(datastyle);
		
		Cell cell142 = row14.createCell(1);
		cell142.setCellValue(profileVO.getYearsIncomeProvided()+" Years");
		cell142.setCellStyle(datastyle);
		
		
		
		Row row15 = sheet.createRow(15);
		
		Cell cell151 = row15.createCell(0);
		cell151.setCellValue("Funeral Expenses");
		cell151.setCellStyle(datastyle);
		
		Cell cell152 = row15.createCell(1);
		cell152.setCellValue(formatAmount(profileVO.getFinalExpenses()));
		cell152.setCellStyle(datastyle);
		
		Row row16 = sheet.createRow(16);
		
		Cell cell161 = row16.createCell(0);
		cell161.setCellValue("Outstanding Mortgage");
		cell161.setCellStyle(datastyle);
		
		Cell cell162 = row16.createCell(1);
		cell162.setCellValue(formatAmount(profileVO.getOutstandingMortgage()));
		cell162.setCellStyle(datastyle);
		
		
		Row row17 = sheet.createRow(17);
		
		Cell cell171 = row17.createCell(0);
		cell171.setCellValue("Other Outstanding Debt");
		cell171.setCellStyle(datastyle);
		
		Cell cell172 = row17.createCell(1);
		cell172.setCellValue(formatAmount(profileVO.getOtherOutstandingDebt()));
		cell172.setCellStyle(datastyle);
		
		
		Row row18 = sheet.createRow(18);
		
		Cell cell181 = row18.createCell(0);
		cell181.setCellValue("Estimated Inflation Rate");
		cell181.setCellStyle(datastyle);
		Cell cell182 = row18.createCell(1);
		cell182.setCellValue(profileVO.getEstimatedInflationRate()+" %");
		cell182.setCellStyle(datastyle);
		
		Row row19 = sheet.createRow(19);
		
		Cell cell191 = row19.createCell(0);
		cell191.setCellValue("Estimated Investment Return");
		cell191.setCellStyle(datastyle);
		
		Cell cell192 = row19.createCell(1);
		cell192.setCellValue(profileVO.getEstimatedInvestmentReturn()+" %");
		cell192.setCellStyle(datastyle);
		
		Row row20 = sheet.createRow(20);
		
		Cell cell201 = row20.createCell(0);
		cell201.setCellValue("Total Income to be Provided");
		cell201.setCellStyle(datastyle);
		
		Cell cell202 = row20.createCell(1);
		cell202.setCellValue(formatAmount(profileVO.getTotalIncomeToBeProvided()));
		cell202.setCellStyle(datastyle);
		
		
		Row row21 = sheet.createRow(21);
		
		Cell cell211 = row21.createCell(0);
		cell211.setCellValue("Less other sources of income/savings");
		cell211.setCellStyle(datastyle);
		
		Cell cell212 = row21.createCell(1);
		cell212.setCellValue(formatAmount(profileVO.getTotalIncomeNeeds()));
		cell212.setCellStyle(datastyle);
		
		Row row22 = sheet.createRow(22);
		
		Cell cell221 = row22.createCell(0);
		cell221.setCellValue("Total College Expenses");
		cell221.setCellStyle(datastyle);
		
		Cell cell222 = row22.createCell(1);
		cell222.setCellValue(formatAmount(profileVO.getTotalCollegeExpenses()));
		cell222.setCellStyle(datastyle);
		
		Row row23 = sheet.createRow(23);
		
		Cell cell231 = row23.createCell(0);
		cell231.setCellValue("Total One Time Needs");
		cell231.setCellStyle(datastyle);
		
		Cell cell232 = row23.createCell(1);
		cell232.setCellValue(formatAmount(profileVO.getTotalOneTimeNeeds()));
		cell232.setCellStyle(datastyle);
		
		Row row24 = sheet.createRow(24);
		
		Cell cell241 = row24.createCell(0);
		cell241.setCellValue("Requested Coverage");
		cell241.setCellStyle(datastyle);
		
		Cell cell242 = row24.createCell(1);
		cell242.setCellValue(formatAmount(profileVO.getCoverage()));
		cell242.setCellStyle(datastyle);
		
		Row row25 = sheet.createRow(25);
		
		Cell cell251 = row25.createCell(0);
		cell251.setCellValue("Requested Term");
		cell251.setCellStyle(datastyle);
		
		Cell cell252 = row25.createCell(1);
		cell252.setCellValue(appliedQuoteVO.getTerm()+" Years");
		cell252.setCellStyle(datastyle);
		
		Row row26 = sheet.createRow(26);
		
		Cell cell261 = row26.createCell(0);
		cell261.setCellValue("Best Premium per month");
		cell261.setCellStyle(datastyle);
		
		Cell cell262 = row26.createCell(1);
		cell262.setCellValue(formatAmount(appliedQuoteVO.getBestPremiumPerMonth()));
		cell262.setCellStyle(datastyle);
		
		Row row27 = sheet.createRow(27);
		
		Cell cell271 = row27.createCell(0);
		cell271.setCellValue("Standard Premium per month");
		cell271.setCellStyle(datastyle);
		
		Cell cell272 = row27.createCell(1);
		cell272.setCellValue(formatAmount(appliedQuoteVO.getStandardPremiumPerMonth()));
		cell272.setCellStyle(datastyle);
		
		try {
			FileOutputStream fos = new FileOutputStream("C:\\Temp\\MYLIFECOVERED_request_details.xls");
			try {
				workbook.write(fos);
			} catch (IOException e) {
				e.printStackTrace();
			}
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
	}
	

	/**
	 * To format the amount.
	 * @param amount
	 * @return formattedamount
	 */
	private String formatAmount(double amount) {
		NumberFormat defaultFormat = NumberFormat.getCurrencyInstance();
		return defaultFormat.format(amount);
	}
	
	/**
	 * Method for sending consumer contact email.
	 * @param consumerEmailAddress
	 * @throws ServiceException 
	 */
	private void sendConsumerContactUsEmail(String name,String consumerEmailAddress,String phoneNumber,String src) throws ServiceException {
		
		String imageapplyNow = context+"/resources/images/applynow.jpg";
		String unsubscribeLink = context+"/unsubscribe.do?unsubscribeMail="+consumerEmailAddress;
		String applyNowLink = context+"/welcome.do?phoneNo="+phoneNumber+"&src="+src;
		String privacy = context+"/privacypolicy.do";
		String termsAndConditions = context+"/terms.do";
		String legalPolicy = context+"/legalInformation.do";
		String arialFont = "<p style='font-size: 16px;font-family: arial;'>";
		String calibriFont = "<p style='font-size: 13.5px;font-family: calibri;'>";
		
		StringBuffer msg = new StringBuffer();
		
		msg.append("<html>");
		msg.append("<body>");
		msg.append(arialFont+name+"</p>");
		msg.append(arialFont+"Thank you for contacting us and for your interest in MY LIFE COVERED<sup style='font-size: 14.5px;'>TM</sup>.</p>");
		msg.append(arialFont+"We look forward to speaking with you and answering any questions that may keep you from starting your application.</p>");
		msg.append(arialFont+"As you may remember, healthy and fit individuals may qualify for lower insurance premiums. Why not get a quote and see for yourself if you are eligible for a lower rate under our coverage. Call our toll-free number &#8210; <u>1-888-443-7512</u> &#8210; today to receive your no-obligation rate quote.</p>");
		msg.append(arialFont+"In the meantime, go hit the gym and we&rsquo;ll talk soon!</p>");
		msg.append(arialFont+"Sincerely</p>");
		msg.append(arialFont+"Todd Seabaugh"
				+ "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"
				+ "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"
				+ "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"
				+ "<a href="+applyNowLink+"><img src="+imageapplyNow+"></a></p>");
		msg.append(calibriFont+"This e-mail was sent by MyLifeCovered Agency. MY LIFE COVERED<sup style='font-size: 13.5px;'>TM</sup> is a digital life insurance sales site of the MyLifeCovered Agency, a wholly-owned subsidiary of RGAx. Any products offered through MY LIFE COVERED are openly issued through the issuing carrier. Not all of the products or services described are available in all states. Insurance eligibility and premiums are subject to underwriting. MyLifeCovered Agency reserves the right to determine eligibility for all products and services as permitted by law. �2016 RGAx LLC. All Rights Reserved.</p>");
		msg.append(calibriFont+"To stop receiving further e-mail messages, please click on the unsubscribe link. <a href="+unsubscribeLink+"><u>Click here to unsubscribe</u></a></p>");
		msg.append(calibriFont+"<a href="+privacy+"><u>Privacy</u></a> &bull; <a href="+termsAndConditions+"><u>Terms and Conditions</u></a> &bull; <a href="+legalPolicy+"><u>Legal Policy</u></a>");
		msg.append(calibriFont+"<b>MyLifeCovered Agency</b> 16600 Swingley Ridge Road Chesterfield, MO 63017</p>");
		msg.append("</body>");
		msg.append("</html>");
		
		this.sendMail(emailFrom, consumerEmailAddress, "THANKS FOR YOUR INTEREST!", msg.toString());	
	}
	
	public void sendQuoteFollowUpEmail(DemographicInfoVO demoVO) throws ServiceException {
		String imageSrc = context + "/resources/images/email_quote_followup.jpg";
		String unsubscribeLink = context+"/unsubscribe.do?unsubscribeMail="+demoVO.getEmailAddress();
		String calibriFont = "<p style='font-size: 13.5px;font-family: calibri;'>";
		String privacy = context+"/privacypolicy.do";
		String termsAndConditions = context+"/terms.do";
		String legalPolicy = context+"/legalInformation.do";
		StringBuffer msg = new StringBuffer();
		msg.append("<html>");
		msg.append("<body>");
		msg.append("<table style=\"background:rgba(40, 44, 49, .95)\">");
		msg.append("<tr>");
		msg.append("<td colspan=\"3\"><img src=\"");
		msg.append(imageSrc);
		msg.append("\"></td>");
		msg.append("</tr>");
		
		//added for Go back to MY LIFE COVERED hyperlink-start
		msg.append("<tr>");
		msg.append("<td>");
		msg.append("<a href=\"https://www.mylifecovered.net\">");
		msg.append("Go back to MY LIFE COVERED");
		msg.append("</a>");
		msg.append("</td>");
		msg.append("</tr>");
		//added for Go back to MY LIFE COVERED hyperlink-end
		msg.append("</table>");
		msg.append(calibriFont+"To stop receiving further e-mail messages, please click on the unsubscribe link. <a href="+unsubscribeLink+"><u>Click here to unsubscribe</u></a></p>");
		msg.append(calibriFont+"<a href="+privacy+"><u>Privacy</u></a> &bull; <a href="+termsAndConditions+"><u>Terms and Conditions</u></a> &bull; <a href="+legalPolicy+"><u>Legal Policy</u></a>");
		msg.append(calibriFont+"<b>MyLifeCovered Agency</b> 16600 Swingley Ridge Road Chesterfield, MO 63017</p>");
		msg.append("</body>");
		msg.append("</html>");
		this.sendMail(emailFrom, demoVO.getEmailAddress(), "MUSCLE DOWN AND GET IT DONE!", msg.toString());	
		
	}
	
}
