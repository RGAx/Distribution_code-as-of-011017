package com.rga.rgility.service;

import com.rga.rgility.exception.ServiceException;
import com.rga.rgility.model.UserCoverage;
import com.rga.rgility.valueobjects.ProfileVO;

/**
 * @author M1031076
 *
 */

public interface HealthIQService {
	
	/**
	 * @param user
	 * @return String
	 */
	public String postToHealthIQ(final UserCoverage user, final ProfileVO profile) throws ServiceException;

}
