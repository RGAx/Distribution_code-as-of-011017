/**
 * 
 */
package com.rga.rgility.controller;


import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.net.URL;
import java.text.DecimalFormat;
import java.util.Calendar;

import javax.servlet.ServletContext;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.Image;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.pdf.PdfContentByte;
import com.itextpdf.text.pdf.PdfGState;
import com.itextpdf.text.pdf.PdfWriter;
import com.rga.rgility.common.constants.ApplicationConstants;
import com.rga.rgility.common.logger.LogFactory;
import com.rga.rgility.common.logger.MyLifeCoveredLogger;
import com.rga.rgility.common.utilities.MyLifeCoveredUtils;
import com.rga.rgility.exception.BaseException;
import com.rga.rgility.exception.ServiceException;
import com.rga.rgility.model.UserCoverage;
import com.rga.rgility.service.EmailService;
import com.rga.rgility.service.MyLifeCoveredService;
import com.rga.rgility.service.QuoteService;
import com.rga.rgility.service.RgilityService;
import com.rga.rgility.valueobjects.AppliedQuoteVO;
import com.rga.rgility.valueobjects.DemographicInfoVO;
import com.rga.rgility.valueobjects.ProfileVO;

/**
 * @author M1030133
 * 
 */
@Controller
public class MyLifeCoveredController {

	private static final MyLifeCoveredLogger LOGGER = LogFactory.getInstance(MyLifeCoveredController.class);
	
	private static final String CHECKBOX_SELECTED = "1";
	private static final String CHECKBOX_DESELECTED = "0";
	private static final int MIN_AGE = 18;
	private static final int MAX_AGE = 80;
	
	@Autowired
	private MyLifeCoveredService myLifeCoveredService;

	
	@Autowired
	private QuoteService quoteService;
	
	@Autowired
	private EmailService emailService;
	
	@Autowired
	private HttpSession session;
	
	@Autowired
	private RgilityService rgilityService;
	
	@Value("#{'${pdf.font.lato.path}'}")
	private String fontLato;
	
	@Value("#{'${pdf.font.oswald.path}'}")
	private String fontOswald;
	
	@Value("#{'${pdf.background.image.path}'}")
	private String imagePath;

	@RequestMapping("/calculateCoverageNeeds.do")
	@ResponseBody
	public void resetSessionOnEachClick() {
		session.invalidate();
	}
	
	@RequestMapping("welcome.do")
	public String loadWelcomePage(Model model,@RequestParam("phoneNo") String phoneNo, @RequestParam("src") String source) {
		
		UserCoverage user = new UserCoverage();
		model.addAttribute("userForm", user);
		user.setCoverageAmount("500000");
		user.setPolicyTerm("20");
				
		session.setAttribute("src", source);
		session.setAttribute("srcHome", source);
		session.setAttribute("phoneNumber", phoneNo);
		
		/*if(phoneNo.equalsIgnoreCase("888-423-1968"))
			session.setAttribute("sesCat", "mylif006");
		else if(phoneNo.equalsIgnoreCase("888-423-1950"))
			session.setAttribute("sesCat", "mylif005");
		else if(phoneNo.equalsIgnoreCase("888-519-1495"))
			session.setAttribute("sesCat", "mylif004");
		else if(phoneNo.equalsIgnoreCase("888-423-1982"))
			session.setAttribute("sesCat", "mylif009");
		else if(phoneNo.equalsIgnoreCase("888-423-1976"))
			session.setAttribute("sesCat", "mylif007");
		else if(phoneNo.equalsIgnoreCase("888-519-1497"))
			session.setAttribute("sesCat", "mylif008");
		else if(phoneNo.equalsIgnoreCase("866-353-8995"))
			session.setAttribute("sesCat", "mylif0");
		else if(phoneNo.equalsIgnoreCase("888-519-1486"))
			session.setAttribute("sesCat", "mylif00");
		else if(phoneNo.equalsIgnoreCase("888-423-1936"))
			session.setAttribute("sesCat", "mylif000");
		else if(phoneNo.equalsIgnoreCase("844-688-3464"))
			session.setAttribute("sesCat", "mylif003");
		else if(phoneNo.equalsIgnoreCase("888-423-1889"))
			session.setAttribute("sesCat", "mylif002");
		else if(phoneNo.equalsIgnoreCase("888-519-1485"))
			session.setAttribute("sesCat", "mylif001");
		else if(phoneNo.equalsIgnoreCase("888-423-1993"))
			session.setAttribute("sesCat", "mylif00-");
		else if(phoneNo.equalsIgnoreCase("888-423-2060"))
			session.setAttribute("sesCat", "mylif00a");
		else if(phoneNo.equalsIgnoreCase("888-423-2103"))
			session.setAttribute("sesCat", "mylif00c");
		else if(phoneNo.equalsIgnoreCase("888-423-2074"))
			session.setAttribute("sesCat", "mylif00b");	
		else if(phoneNo.equalsIgnoreCase("866-357-8990"))
			session.setAttribute("sesCat", "mylif010");	
		else if(phoneNo.equalsIgnoreCase("866-493-8991"))
			session.setAttribute("sesCat", "mylif011");
		else if(phoneNo.equalsIgnoreCase("866-358-8993"))
			session.setAttribute("sesCat", "mylif012");
		else if(phoneNo.equalsIgnoreCase("866-871-8994"))
			session.setAttribute("sesCat", "mylif013");	
		else if(phoneNo.equalsIgnoreCase("888-210-6017"))
			session.setAttribute("sesCat", "mylif014");	
		else if(phoneNo.equalsIgnoreCase("888-519-1480"))
			session.setAttribute("sesCat", "mylif015");
		else if(phoneNo.equalsIgnoreCase("888-519-1481"))
			session.setAttribute("sesCat", "mylif016");
		else if(phoneNo.equalsIgnoreCase("888-519-1482"))
			session.setAttribute("sesCat", "mylif017");
		else if(phoneNo.equalsIgnoreCase("844-867-3481"))
			session.setAttribute("sesCat", "mylif018");
		else if(phoneNo.equalsIgnoreCase("888-519-1483"))
			session.setAttribute("sesCat", "mylif019");
		else if(phoneNo.equalsIgnoreCase("888-248-6081"))
			session.setAttribute("sesCat", "mylif00d");
		else if(phoneNo.equalsIgnoreCase("888-210-5206"))
			session.setAttribute("sesCat", "mylif00e");	
		else if(phoneNo.equalsIgnoreCase("888-210-5273"))
			session.setAttribute("sesCat", "mylif00f");	
		else if(phoneNo.equalsIgnoreCase("888-284-5743"))
			session.setAttribute("sesCat", "mylif00+");
		else if(phoneNo.equalsIgnoreCase("888-210-5971"))
			session.setAttribute("sesCat", "mylif00g");
		else if(phoneNo.equalsIgnoreCase("888-248-5991"))
			session.setAttribute("sesCat", "mylif00h");
		else if(phoneNo.equalsIgnoreCase("888-248-6011"))
			session.setAttribute("sesCat", "mylif00i");
		else if(phoneNo.equalsIgnoreCase("888-248-6037"))
			session.setAttribute("sesCat", "mylif0000");
		else
			session.setAttribute("sesCat","unlisted");*/
		
		if (source.equalsIgnoreCase(ApplicationConstants.CALCULATE_NEED))
			return "welcomeCalculateNeed";
		else if (source.equalsIgnoreCase(ApplicationConstants.AFFORDABILITY))
			return "welcomeTwentyFiveDollars";
		else if (source.equalsIgnoreCase(ApplicationConstants.I_KNOW_WHAT_I_WANT))
			return "welcomeDropdown";
		else if(source.equalsIgnoreCase(ApplicationConstants.MLC_MAIN))
			return "welcome";
			
		return "welcome";
	}
	
	@RequestMapping("everplans.do")
	public String loadEverPlans(Model model) {
		return "everPlans";
	}
	
	@RequestMapping("basics.do")
	public String loadBasicsPage(Model model) {
		return "basics";
	}
	
	@RequestMapping("misconceptions.do")
	public String loadMisconceptionPage(Model model) {
		return "misconceptions";
	}
	
	@RequestMapping("aboutus.do")
	public String loadAboutusPage(Model model) {
		return "about";
	}
	
	@RequestMapping("privacypolicy.do")
	public String loadPrivacyPolicyPage(Model model) {
		return "privacy";
	}
	
	@RequestMapping("blood.do")
	public String loadBloodPage(Model model) {
		return "blood";
	}
	/*This is direct landing page from myLifeCovered.net/blog*/
	@RequestMapping("direct-help-page.do")
	public ModelAndView loadLifeHelpDirectionPage(Model model,@RequestParam("phoneNo") String phoneNo, @RequestParam("src") String source) {
		session.setAttribute("src", source);
		session.setAttribute("srcHome", source);
		session.setAttribute("phoneNumber", phoneNo);
		return new ModelAndView("life-help");
	}
	
	@RequestMapping("life-help.do")
	public String loadLifeHelpPage(Model model) {
		return "life-help";
	}
	
	@RequestMapping("life-need.do")
	public String loadLifeNeedPage(Model model) {
		return "life-need";
	}
	
	@RequestMapping("life-afford.do")
	public String loadLifeAffordPage(Model model) {
		return "life-afford";
	}
	
	@RequestMapping("terms.do")
	public String loadTermsPage(Model model) {
		return "terms";
	}
	
	@RequestMapping("calculator.do")
	public String loadCalculatorPage(Model model) {
		return "calculator";
	}
	/* This method for mlc main determine coverage flow.
	 * 
	 */	
	@RequestMapping("calculatorForMain.do")
	public ModelAndView loadCalculatorFromMainPage(@ModelAttribute("mainDetermineCoverageForm") UserCoverage user,Model model) {
		ModelAndView modelView = new ModelAndView("calculatorForMain");
		ProfileVO profileVO = new ProfileVO();
				try {
					profileVO.setPathId(1);
					profileVO.setAnnualIncome(Double.parseDouble(user.getAnnualIncome().replace(",", "")));
					profileVO = myLifeCoveredService.calculateInsuranceNeeds(profileVO);
					if(profileVO.getAnnualIncome()>0)
						profileVO.setCoverage(MyLifeCoveredUtils.convertToNearestCoverage((int)profileVO.getAnnualIncome()*10));
					
					ProfileVO sessionProfile = this.getUserProfileFromSession();
					if(sessionProfile != null) {
						profileVO.setProfileId(sessionProfile.getProfileId());
					}
					profileVO = myLifeCoveredService.saveProfileAndChild(profileVO);
					if(profileVO.getCoverage()>2000000) {
						if (profileVO != null) {
							if(profileVO.getCoverage() > 2000000) {
								String msg = "Our calculations indicate that your need is for "+formatAmount(profileVO.getCoverage())+". Our online process offers a maximum coverage amount of $2,000,000. You can contact us to assist you with a larger amounts";
								model.addAttribute("contactusintrotext", msg);			
							} else if (profileVO.getCoverage() > 20 * profileVO.getAnnualIncome()) {
								String msg = "Well this is rare! Your request for coverage exceeds our online processing boundaries. If you would like, you can reduce your coverage request to 16-18x your income and proceed. If you really feel that you need the coverage you requested, please complete this form and we will be in touch shortly to assist you in getting this protection.";
								model.addAttribute("contactusintrotext", msg);
							}
						}	
						modelView = new ModelAndView("contact");
					}
					session.setAttribute("src", ApplicationConstants.CALCULATE_NEED);
					setUserProfileToSession(profileVO);
					//model.addObject("profileVO", profileVO);
				} catch (Exception e) {
					e.printStackTrace();
				}
		return modelView;
	}
	
	@RequestMapping("contactus.do")
	public String loadContactusPage(Model model) {
		return "contact";
	}
	
	@RequestMapping("loadNYContactus.do")
	public String loadNYContactusPage(Model model) {
		model.addAttribute("contactuscommentstext", "I live in NY and would like to have someone contact me.");
		return "contact";
	}
	@RequestMapping("quote.do")
	public String loadQuotePage(Model model) {
		session.setAttribute("src", ApplicationConstants.I_KNOW_WHAT_I_WANT);
		return "quote";
	}
	/*affordability flow to show coverage*/
/*	@RequestMapping("quoteForTwentyFiveDollars.do")
	public String loadQquoteForTwentyFiveDollarsPage(Model model) {
		if(null == session.getAttribute("affordablePremium"))
			session.setAttribute("affordablePremium", 25);
		
		session.setAttribute("src", ApplicationConstants.AFFORDABILITY);
		return "quoteForTwentyFiveDollars";
	}*/
	/*affordability flow to show coverage*/
/*	@RequestMapping("mainPageForTwentyFiveDollars.do")
	public String mainPageQquoteForTwentyFiveDollarsPage(Model model,@RequestParam("affordablePremium") String affordablePremium) {
		if(affordablePremium.equalsIgnoreCase("twentyfive"))
			session.setAttribute("affordablePremium", 25);
		else if(affordablePremium.equalsIgnoreCase("fifty"))
			session.setAttribute("affordablePremium", 50);
		else if(affordablePremium.equalsIgnoreCase("onehundred"))
			session.setAttribute("affordablePremium", 100);
		else
			session.setAttribute("affordablePremium", 25);
		
		session.setAttribute("src", ApplicationConstants.AFFORDABILITY);
		return "quoteForTwentyFiveDollars";
	}*/
	/*affordability flow to show monthly premium*/
	@RequestMapping("twentyFiveDollarsToNeedFlow.do")
	public String twentyFiveDollarsToQuoteCoveragePage(Model model,@RequestParam("affordablePremium") String affordablePremium, @RequestParam("totalCoverage") String coverage,@RequestParam("affordableGender") String gender) {
		session.setAttribute("coverage", coverage);
		session.setAttribute("gender", gender);
		/*if(affordablePremium.equalsIgnoreCase("twentyfive"))
			session.setAttribute("affordablePremium", 25);
		else if(affordablePremium.equalsIgnoreCase("fifty"))
			session.setAttribute("affordablePremium", 50);
		else if(affordablePremium.equalsIgnoreCase("onehundred"))
			session.setAttribute("affordablePremium", 100);
		else
			session.setAttribute("affordablePremium", 25);*/
		
		session.setAttribute("src", ApplicationConstants.AFFORDABILITY);
		return "quoteForAffordability";
	}
	@RequestMapping("twentyFiveDollarsLanding.do")
	public ModelAndView loadTwentyFiveDollarsPage(Model model) {
		return new ModelAndView("welcomeTwentyFiveDollars");
	}
	@RequestMapping(value="mainQuote.do",method = RequestMethod.POST)
	public ModelAndView mainPageQuotePage(@ModelAttribute("maincoverageform") UserCoverage user,Model model) throws Exception {
		ProfileVO profileVO = new ProfileVO();
		profileVO.setCoverage(Double.parseDouble(user.getCoverageAmount()));
		profileVO.setPathId(1);
		ModelAndView modelView = new ModelAndView("quote");
		session.setAttribute("src", ApplicationConstants.I_KNOW_WHAT_I_WANT);
		setUserProfileToSession(profileVO);
		return modelView;
	}
	
	@RequestMapping("findPath.do")
	public ModelAndView loadFindPage(Model model) {
		if (session.getAttribute("src").toString().equalsIgnoreCase(ApplicationConstants.CALCULATE_NEED))
			return new ModelAndView("calculatorForMain");
		else if (session.getAttribute("src").toString().equalsIgnoreCase(ApplicationConstants.AFFORDABILITY)) {
		//	session.setAttribute("affordablePremium", affordablePremium);
			return new ModelAndView("quoteForAffordability");
		} else if (session.getAttribute("src").toString().equalsIgnoreCase(ApplicationConstants.I_KNOW_WHAT_I_WANT))
			return new ModelAndView("quote");
		else if(session.getAttribute("src").toString().equalsIgnoreCase(ApplicationConstants.MLC_MAIN))
			return new ModelAndView("welcome");
			
		return new ModelAndView("life-help");
	}
		
	/**
	 * @param profileVO
	 * @return
	 * @throws Exception
	 *//*
	@RequestMapping(value="/main10X.do", method=RequestMethod.POST)
	@ResponseBody
	public String calculateInsuranceNeedsForMain(@ModelAttribute("profileVO")ProfileVO profileVO) throws Exception {
		//ModelAndView model = new ModelAndView("insuranceNeeds");
		try {
			profileVO.setPathId(1);
			profileVO = myLifeCoveredService.calculateInsuranceNeeds(profileVO);
			if(profileVO.getAnnualIncome()>0)
				profileVO.setCoverage(MyLifeCoveredUtils.convertToNearestCoverage((int)profileVO.getAnnualIncome()*10));
			
			ProfileVO sessionProfile = this.getUserProfileFromSession();
			if(sessionProfile != null) {
				profileVO.setProfileId(sessionProfile.getProfileId());
			}
			profileVO = myLifeCoveredService.saveProfileAndChild(profileVO);
			
			this.setUserProfileToSession(profileVO);
			//model.addObject("profileVO", profileVO);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "calculatorForMain";
	}
	*/
	
	/**
	 * 
	 * @param unsubscribeMail
	 * @return
	 */
	@RequestMapping("unsubscribe.do")
	public ModelAndView loadUnsubscribePage(@RequestParam("unsubscribeMail") String unsubscribeMail){
		ModelAndView model = new ModelAndView("unsubscribe");
		model.addObject("unsubscribeMail",unsubscribeMail);
		return model;
	}
	
	@RequestMapping("twomillioncontact.do")
	public String load2MContactusPage(Model model) {
		ProfileVO profileVO = getUserProfileFromSession();
		if (profileVO != null) {
			if(profileVO.getCoverage() > 2000000) {
				String msg = "Our calculations indicate that your need is for "+formatAmount(profileVO.getCoverage())+". Our online process offers a maximum coverage amount of $2,000,000. You can contact us to assist you with a larger amounts";
				model.addAttribute("contactusintrotext", msg);			
			} else if (profileVO.getCoverage() > 20 * profileVO.getAnnualIncome()) {
				String msg = "Well this is rare! Your request for coverage exceeds our online processing boundaries. If you would like, you can reduce your coverage request to 16-18x your income and proceed. If you really feel that you need the coverage you requested, please complete this form and we will be in touch shortly to assist you in getting this protection.";
				model.addAttribute("contactusintrotext", msg);
			}
		}		
		return "contact";
	}
	
	@RequestMapping("noproductsfound.do")
	public String noProductsFoundContactusPage(Model model) {
		String msg = "Here's great news. You definitely have protection needs and we can help you. We cannot do this online. Please complete this form and we will be in touch shortly to assist you in getting the needed coverage";
		model.addAttribute("contactusintrotext", msg);
		return "contact";
	}
	
	@RequestMapping("affordabledifference.do")
	public String affordableDifferenceContactusPage(Model model) {
		String msg = "Here's great news. You definitely have protection needs and we can help you. We cannot do this online. Please complete this form and we will be in touch shortly to assist you in getting the needed coverage";
		model.addAttribute("contactusintrotext", msg);
		return "contact";
	}
	
	@RequestMapping(value="/application.do",  method=RequestMethod.POST)
	public String loadApplication(Model model,HttpServletRequest request) {
		ProfileVO profileVO = getUserProfileFromSession();
		
		UserCoverage user = new UserCoverage();
		model.addAttribute("userForm", user);
		
		String pathId = request.getParameter("pathId");
		int path = Integer.parseInt(pathId);
		
		user.setSelectedPath(pathId);
		
		if(!MyLifeCoveredUtils.isEmpty(profileVO)){
			setProfileVOToUserCoverage(profileVO, user);
			
			if(!MyLifeCoveredUtils.isEmpty(profileVO.getDemographicVO())){
				setDemographicInfoVOToUserCoverage(profileVO.getDemographicVO(), user);
			}
		}
		
		if(ApplicationConstants.IDONT_KNOW_PATH_ID == path) {
			
		} else if(ApplicationConstants.IKNOW_PATH_ID == path) {
			
		}
		return "application";
	}

	/**
	 * @param profileVO
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/insuranceNeeds.do", method=RequestMethod.POST)
	@ResponseBody
	public String calculateInsuranceNeeds(@ModelAttribute("profileVO")ProfileVO profileVO) throws Exception {
		try {
			ModelAndView model = new ModelAndView("insuranceNeeds");
			profileVO.setPathId(1);
			profileVO = myLifeCoveredService.calculateInsuranceNeeds(profileVO);
			
			ProfileVO sessionProfile = this.getUserProfileFromSession();
			if(sessionProfile != null) {
				profileVO.setProfileId(sessionProfile.getProfileId());
			}
			if(null == profileVO.getVanityPhoneNo()){
				profileVO.setVanityPhoneNo(session.getAttribute("phoneNumber").toString());
			}
			profileVO = myLifeCoveredService.saveProfileAndChild(profileVO);
			session.setAttribute("src", ApplicationConstants.CALCULATE_NEED);
			this.setUserProfileToSession(profileVO);
			model.addObject("profileVO", profileVO);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return new Gson().toJson(profileVO);
	}

	/**
	 * 
	 * @param request
	 * @throws Exception
	 */
	@RequestMapping(value="sendEmailWithPDF.do", method=RequestMethod.POST)
	public void sendEmailWithPDF(HttpServletRequest request) throws Exception{
		@SuppressWarnings("unused")
		String emailAddress = request.getParameter("emailAddress");
		
		@SuppressWarnings("unused")
		ProfileVO profileVO = getUserProfileFromSession();
		//emailService.sendPdfReport(emailAddress,profileVO);
	}
	
	/**
	 * 
	 * @param user
	 * @param result
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/getQuote.do", method = RequestMethod.POST)
	@ResponseBody
	public String getQuote(
			@ModelAttribute("userForm") UserCoverage user,
			BindingResult result, Model model) {
		ProfileVO profileVO = null;
		Gson gson = new Gson();
		JsonObject jsonObject = new JsonObject();
		try {
			
			if(Integer.parseInt(user.getSelectedPath()) == ApplicationConstants.IKNOW_PATH_ID ){
				profileVO = new ProfileVO();
				setUserCoverageToProfileVO(user,profileVO, 2);
				profileVO.setPathId(Integer.parseInt(user.getSelectedPath()));
			}else if(Integer.parseInt(user.getSelectedPath()) == ApplicationConstants.TWENTY_FIVE_DOLLARS) {
				profileVO = new ProfileVO();
				setUserCoverageToProfileVO(user,profileVO, 2);
				profileVO.setCoverage(MyLifeCoveredUtils.convertToNearestCoverage(Integer.parseInt(user.getCoverageAmount())));
				profileVO.setPathId(Integer.parseInt(user.getSelectedPath()));
			}else{
				profileVO = getUserProfileFromSession();
				setUserCoverageToProfileVO(user,profileVO, 1);
			}
			
			DemographicInfoVO infoVO = setUserCoverageToDemographicInfoVO(user);
			profileVO.setDemographicVO(infoVO);
			profileVO.setVanityPhoneNo((String)session.getAttribute("phoneNumber"));
			
			int startAge = MyLifeCoveredUtils.getStartDateDiffYears(infoVO.getDateOfBirth(), Calendar.getInstance().getTime());
			int endAge = MyLifeCoveredUtils.getEndDateDiffYears(infoVO.getDateOfBirth(), Calendar.getInstance().getTime());
			if(startAge < MIN_AGE){
				jsonObject.addProperty("errorMessage", "You must be at least 18 years of age in order to get a quote.");
			} else if(endAge > MAX_AGE){
				jsonObject.addProperty("errorMessage", "You must be under 80 years old in order to get a quote.");
			} /*else if(profileVO.getCoverage() > 20 * profileVO.getAnnualIncome()){
				jsonObject.addProperty("errorMessage", "You cannot apply online for a coverage amount exceeding 20 times your current income. To apply for this amount, <a href='twomillioncontact.do' class='open-contact-form secondary'>contact us.</a>");
			} */else if(MyLifeCoveredUtils.isEmpty(infoVO.getState())){
				jsonObject.addProperty("errorMessage", "Please select a state.");
			} else{
				profileVO = myLifeCoveredService.getQuote(profileVO);
				jsonObject.addProperty("profileVO", gson.toJson(profileVO));
				jsonObject.addProperty("errorMessage", "");
				
				setUserProfileToSession(profileVO);
				myLifeCoveredService.updateSliderVisitFlag(profileVO, true);
			}
		} catch (BaseException e) {
			jsonObject.addProperty("errorMessage", "Please try again.");
			e.printStackTrace();
		}
		return gson.toJson(jsonObject);
	}
	
	/**
	 * 
	 * @param user
	 * @param result
	 * @param model
	 * @return
	 */
	@RequestMapping(value = "/getUpdatedQuote.do", method = RequestMethod.POST)
	@ResponseBody
	public String getUpdatedQuote(@ModelAttribute("userForm") UserCoverage user,
			BindingResult result, Model model) {
		Gson gson = new Gson();
		ProfileVO profileVO = null;
		try {
			profileVO = getUserProfileFromSession();
			if(!MyLifeCoveredUtils.isEmpty(user.getSelectedCoverageAmnt())){
				profileVO.setCoverage(Long.parseLong(user.getSelectedCoverageAmnt()));
			}
			if(!MyLifeCoveredUtils.isEmpty(user.getSelectedPolicyTerm())){
				profileVO.setTerm(Integer.parseInt(user.getSelectedPolicyTerm()));
			}
			if(null != user.getSelectedPath()) {
				if(Integer.parseInt(user.getSelectedPath()) == ApplicationConstants.TWENTY_FIVE_DOLLARS){
					profileVO.setAffordablePremium(Integer.parseInt(user.getAffordablePremium()));
				}
			}
			profileVO = myLifeCoveredService.getPremiumPerMonth(profileVO);
		} catch (BaseException e) {
			e.printStackTrace();
		}
		return gson.toJson(profileVO.getAppliedQuoteVO());
	}
	
	/**
	 * 
	 * @param user
	 * @param profileVO
	 * @return
	 */
	private ProfileVO setUserCoverageToProfileVO(UserCoverage user,ProfileVO profileVO, int pathId){
		if(!MyLifeCoveredUtils.isEmpty(user.getCoverageAmount())){
			long coverageAmount = Long.parseLong(user.getCoverageAmount());
			if (coverageAmount >= 2000000) {
				profileVO.setCoverage(2000000);
			} else {
				profileVO.setCoverage(Long.parseLong(user.getCoverageAmount()));
			}	
		}
		LOGGER.debug("Term selected: "+user.getNoOfYearsToMaintainCoverage());
		if(!MyLifeCoveredUtils.isEmpty(user.getNoOfYearsToMaintainCoverage())){
			profileVO.setTerm(Integer.parseInt(user.getNoOfYearsToMaintainCoverage()));
		}
		if(!MyLifeCoveredUtils.isEmpty(user.getFirstName())){
			profileVO.setFirstName(user.getFirstName());
		}
		/*if(!MyLifeCoveredUtils.isEmpty(user.getCurrentSavings())){
			profileVO.setOtherSavings(Long.parseLong(user.getCurrentSavings()));
		}*/
		if(pathId == ApplicationConstants.IKNOW_PATH_ID && !MyLifeCoveredUtils.isEmpty(user.getCurrentIncome())){
			profileVO.setAnnualIncome(Long.parseLong(user.getCurrentIncome()));
		}
		/*if(!MyLifeCoveredUtils.isEmpty(user.getYearsIncomeProvided())){
			profileVO.setYearsIncomeProvided(Integer.parseInt(user.getYearsIncomeProvided()));
		}
		if(!MyLifeCoveredUtils.isEmpty(user.getCurrentRetirementSavings())){
			profileVO.setRetirementSavings(Long.parseLong(user.getCurrentRetirementSavings()));
		}
		if(!MyLifeCoveredUtils.isEmpty(user.getFinalExpenses())){
			profileVO.setFinalExpenses(Long.parseLong(user.getFinalExpenses()));
		}
		if(!MyLifeCoveredUtils.isEmpty(user.getOutstandingMortgage())){
			profileVO.setOutstandingMortgage(Integer.parseInt(user.getOutstandingMortgage()));
		}
		if(!MyLifeCoveredUtils.isEmpty(user.getChildCount())){
			profileVO.setChildCount(user.getChildCount());
		}
		if(!MyLifeCoveredUtils.isEmpty(user.getOutstandingDebt())){
			profileVO.setOtherOutstandingDebt(Long.parseLong(user.getOutstandingDebt()));
		}*/
		if(!MyLifeCoveredUtils.isEmpty(user.getAffordablePremium())){
			profileVO.setAffordablePremium(Integer.parseInt(user.getAffordablePremium()));
		}
		return profileVO;
	}
	
	/**
	 * 
	 * @param profileVO
	 * @param user
	 * @return
	 */
	private UserCoverage setProfileVOToUserCoverage(ProfileVO profileVO,UserCoverage user){
		if(!MyLifeCoveredUtils.isZero(profileVO.getCoverage())){
			user.setCoverageAmount(""+(int)profileVO.getCoverage());
		}
		if(!MyLifeCoveredUtils.isZero(profileVO.getTerm())){
			user.setPolicyTerm(""+(int)profileVO.getTerm());
		}
		
		if(!MyLifeCoveredUtils.isEmpty(profileVO.getFirstName())){
			user.setFirstName(profileVO.getFirstName());
		}
		if(!MyLifeCoveredUtils.isEmpty(profileVO.getAnnualIncome())){
			user.setCurrentIncome(""+(int)profileVO.getAnnualIncome());
		}
		/*if(!MyLifeCoveredUtils.isZero(profileVO.getOtherSavings())){
			user.setCurrentSavings(""+(int)profileVO.getOtherSavings());
		}
		if(!MyLifeCoveredUtils.isZero(profileVO.getYearsIncomeProvided())){
			user.setYearsIncomeProvided(""+(int)profileVO.getYearsIncomeProvided());
		}
		if(!MyLifeCoveredUtils.isZero(profileVO.getRetirementSavings())){
			user.setCurrentRetirementSavings(""+(int)profileVO.getRetirementSavings());
		}
		if(!MyLifeCoveredUtils.isZero(profileVO.getFinalExpenses())){
			user.setFinalExpenses(""+(int)profileVO.getFinalExpenses());
		}
		if(!MyLifeCoveredUtils.isZero(profileVO.getOutstandingMortgage())){
			user.setOutstandingMortgage(""+(int)profileVO.getOutstandingMortgage());
		}
		if(!MyLifeCoveredUtils.isZero(profileVO.getChildCount())){
			user.setChildCount(profileVO.getChildCount());
		}
		if(!MyLifeCoveredUtils.isZero(profileVO.getOtherOutstandingDebt())){
			user.setOutstandingDebt(""+(int)profileVO.getOtherOutstandingDebt());
		}*/
		return user;
	}
	
	/**
	 * 
	 * @param user
	 * @return
	 * @throws BaseException 
	 */
	private DemographicInfoVO setUserCoverageToDemographicInfoVO(UserCoverage user) throws BaseException{
		DemographicInfoVO infoVO = new DemographicInfoVO();
		if(!MyLifeCoveredUtils.isEmpty(user.getBirthDate())){
			infoVO.setDateOfBirth(MyLifeCoveredUtils.convertStringToDate(ApplicationConstants.DATE_PATTERN, user.getBirthDate()));
		}
		if(!MyLifeCoveredUtils.isEmpty(user.getGender())){
			infoVO.setGender(user.getGender());
		}
		if(!MyLifeCoveredUtils.isEmpty(user.getSmoker())){
			infoVO.setSmokerStatus(user.getSmoker());
		}
		if(!MyLifeCoveredUtils.isEmpty(user.getEmailAddress())){
			infoVO.setEmailAddress(user.getEmailAddress());
		}
		if(!MyLifeCoveredUtils.isEmpty(user.getState())){
			infoVO.setState(user.getState());
		}
		if(user.isUSCitizen()){
			infoVO.setIsUsCitizen(CHECKBOX_SELECTED);
		}else{
			infoVO.setIsUsCitizen(CHECKBOX_DESELECTED);
		}
		
		if(user.isPolicyOwner()){
			infoVO.setIsPolicyOwner(CHECKBOX_SELECTED);
		}else{
			infoVO.setIsPolicyOwner(CHECKBOX_DESELECTED);
		}
		
		if(user.isReplacementPolicy()){
			infoVO.setIsConsentReplacementPolicy(CHECKBOX_SELECTED);
		}else{
			infoVO.setIsConsentReplacementPolicy(CHECKBOX_DESELECTED);
		}
		
		if(user.isAllowMarketing()){
			infoVO.setIsAllowMarketing(CHECKBOX_SELECTED);
		}else{
			infoVO.setIsAllowMarketing(CHECKBOX_DESELECTED);
		}
		
		if(!MyLifeCoveredUtils.isEmpty(user.getQuotePhone())){
			infoVO.setQuotePhone(user.getQuotePhone());
		}
		
		return infoVO;
	}

	/**
	 * 
	 * @param infoVO
	 * @param user
	 * @return
	 */
	private UserCoverage setDemographicInfoVOToUserCoverage(DemographicInfoVO infoVO, UserCoverage user) {
		
		if(!MyLifeCoveredUtils.isEmpty(infoVO.getDateOfBirth())){
			user.setBirthDate(MyLifeCoveredUtils.convertDateToString(ApplicationConstants.DATE_PATTERN, infoVO.getDateOfBirth()));
		}
		if(!MyLifeCoveredUtils.isEmpty(infoVO.getGender())){
			user.setGender(infoVO.getGender());
		}
		if(!MyLifeCoveredUtils.isEmpty(infoVO.getSmokerStatus())){
			user.setSmoker(infoVO.getSmokerStatus());
		}
		if(!MyLifeCoveredUtils.isEmpty(infoVO.getEmailAddress())){
			user.setEmailAddress(infoVO.getEmailAddress());
		}
		if(!MyLifeCoveredUtils.isEmpty(infoVO.getState())){
			user.setState(infoVO.getState());
		}
		if(CHECKBOX_SELECTED.equals(infoVO.getIsUsCitizen())){
			user.setUSCitizen(true);
		}else{
			user.setUSCitizen(false);
		}
		if(CHECKBOX_SELECTED.equals(infoVO.getIsPolicyOwner())){
			user.setPolicyOwner(true);
		}else{
			user.setPolicyOwner(false);
		}
		if(CHECKBOX_SELECTED.equals(infoVO.getIsConsentReplacementPolicy())){
			user.setReplacementPolicy(true);
		}else{
			user.setReplacementPolicy(false);
		}
		return user;
	}
	
	/**
	 * 
	 * @param user
	 * @param model
	 * @return
	 */
	@RequestMapping(value="/applyKnowCoverage.do",method = RequestMethod.POST)
	public @ResponseBody String applyquoteCoverage(@ModelAttribute("userForm") UserCoverage user,Model model){
		
		String response = "";
		try{
			@SuppressWarnings("unused")
			DemographicInfoVO demographicInfoVO = null;
			ProfileVO profileVO = getUserProfileFromSession();
			AppliedQuoteVO appliedQuoteVO = null;
			if(null != profileVO && null != profileVO.getDemographicVO()){
				
				demographicInfoVO = profileVO.getDemographicVO();
				appliedQuoteVO = quoteService.constructAppliedQuoteVO(user);
				
				quoteService.savequoteinfoVO(profileVO,appliedQuoteVO);
				
				/*if((null != demographicInfoVO.getIsUsCitizen() && demographicInfoVO.getIsUsCitizen().equals("1"))
						|| (null != demographicInfoVO.getIsPolicyOwner() && demographicInfoVO.getIsPolicyOwner().equals("1")) 
						|| (null != demographicInfoVO.getIsConsentReplacementPolicy() && demographicInfoVO.getIsConsentReplacementPolicy().equals("1"))){
					try {
						LOGGER.info("Sending Email to StakeHolder with Application details");
						emailService.sendemailtoUser(profileVO,appliedQuoteVO);
						response = "success";
					} catch (Exception e) {
						LOGGER.error("Got an Exception while Triggering email with application details"+e.getMessage());
						//e.printStackTrace();
						response = "failure";
						throw new ServiceException(e.getMessage());
					}
				}else{*/
					LOGGER.info("Consuming the Rgility Webservice ENDPoint URL");
					try{
						String jsonrgilitySource = myLifeCoveredService.constructRgilityserviceRequest(profileVO, appliedQuoteVO);
						if(null != jsonrgilitySource && !jsonrgilitySource.isEmpty()){
							response = rgilityService.postRgilityRequestJson(jsonrgilitySource);
							myLifeCoveredService.updateSliderVisitFlag(profileVO, false);
							session.removeAttribute("sessionProfile");
						}
					}catch(Exception e){
						LOGGER.error("Got an Exception while Consuming Rgility Webservice. Sending an email to consumer and Todd. "+e.getMessage());
						//throw new ServiceException(e.getMessage());
						emailService.sendApplyNowEmail(profileVO,appliedQuoteVO);
					}
				}
			//}
		}catch(ServiceException e){
			LOGGER.error("Got an Exception while Applying Quote and Sending Email or COnsuming webservice"+e.getMessage());			
		}
	
		return response;
	}
	
	/**
	 * Method to send a email to Rgility.
	 * @param user
	 * @param model
	 * @return String
	 */
	@RequestMapping(value="/submitContactInfo.do",method = RequestMethod.POST)
	public @ResponseBody String contactUs(@ModelAttribute("contactForm") UserCoverage user) throws Exception {
		try {
			
			String phoneNumber = (String)session.getAttribute("phoneNumber");
			String src = (String)session.getAttribute("src");
			//Method to save contact us details-yet to implement
			myLifeCoveredService.saveContactUsDetails(user,getUserProfileFromSession());
			emailService.sendContactUsEmail(user,getUserProfileFromSession(),phoneNumber,src);
			return "success";
		} catch (ServiceException e) {
			LOGGER.error("ERROR while sending email: "+e.getMessage());
			throw new Exception(e.getMessage());
		}
	}
	
	/**
	 * 
	 * @param user
	 * @param redirectAttributes
	 * @return
	 */
	@RequestMapping(value="/emailUnsubscribe.do",method=RequestMethod.POST)
	public String unsubscribeEmail(@ModelAttribute("unsubscribeMail") UserCoverage user,RedirectAttributes redirectAttributes){
		try {
			int count = myLifeCoveredService.updateUnsubscribeEmail(user.getEmail());
			if (count > 0) {
				redirectAttributes.addFlashAttribute(ApplicationConstants.SUCCESS, "Unsubscribed Successfully!");
				LOGGER.info("EMAIL_ID : "+user.getEmail()+", EMAIL_COUNT is updated Successfully");
			} else {
				LOGGER.error("Email not exist in DB : "+user.getEmail());
				redirectAttributes.addFlashAttribute(ApplicationConstants.FAILED, "Unsubscribde Failed!");
			}
		} catch (ServiceException e) {
			e.printStackTrace();
		}
		return "redirect:unsubscribe.do?unsubscribeMail="+user.getEmail();
	}
		
	@RequestMapping(value="/downloadPdf.do")
	@ResponseBody
	public void downloadPdf(HttpServletRequest request, HttpServletResponse  response) throws Exception {
		 try {
	           
	            // step 1
			 	Rectangle pageSize = new Rectangle(612,792);
			   // pageSize.setBackgroundColor(BaseColor.DARK_GRAY);
				Document document = new Document(pageSize);
				ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
				PdfWriter writer = PdfWriter.getInstance(document, byteArrayOutputStream);
				ServletContext servletContext = request.getSession().getServletContext();
				
				//Registering Fonts for PDF
				String oswaldPath = servletContext.getRealPath(fontOswald);
				FontFactory.register(oswaldPath,"oswald");
				String latoPath = servletContext.getRealPath(fontLato);
				FontFactory.register(latoPath,"lato");
				
	            // step 2
	            if(null != getUserProfileFromSession()){
	            	emailService.generatePDF(document,writer,getUserProfileFromSession());
	            }
	          //set background image to pdf
				URL url = servletContext.getResource(imagePath);
				//document.open();
				PdfContentByte canvas2 = writer.getDirectContentUnder();
	            Image image = //new ImageIcon(url).getImage();
	            		Image.getInstance(url);
	            image.scaleAbsolute(new Rectangle(792,792));
	            image.setAbsolutePosition(0, 0);
	            canvas2.saveState();
	            PdfGState state = new PdfGState();
	            state.setFillOpacity(1.5f);
	           // canvas2.setGState(state);
	            canvas2.addImage(image);
	            canvas2.restoreState();
	            document.close();
	            response.setHeader("Expires", "0");
	            response.setHeader("Cache-Control","must-revalidate, post-check=0, pre-check=0");
	            response.setHeader("Pragma", "public");
	            response.setContentType("application/pdf");
	            response.addHeader("Content-Disposition", "attachment; filename=InsuranceNeeds.pdf");
	            response.setContentLength(byteArrayOutputStream.size());
	            ServletOutputStream outputStream = response.getOutputStream();
	            byteArrayOutputStream.writeTo(outputStream);
	            outputStream.flush();
	            outputStream.close();
	        }
	        catch(DocumentException e) {
	            throw new IOException(e.getMessage());
	        }catch (Exception e) {
				throw new Exception(e.getMessage());
			}
		 
	    }
	
	/**
	 * 
	 * @return
	 */
	private ProfileVO getUserProfileFromSession(){
		ProfileVO infoVO = null;
		if(null != session.getAttribute("sessionProfile") && !"".equals(session.getAttribute("sessionProfile"))){
			infoVO = (ProfileVO)session.getAttribute("sessionProfile");
		}	
		return infoVO;
	}

	/**
	 * 
	 * @param infoVO
	 */
	private void setUserProfileToSession(ProfileVO profileVO){
		session.setAttribute("sessionProfile", profileVO);
	}

	
	/**
	 * Method to return the formatted amount.
	 * @param amount
	 * @return String
	 */
	private static String formatAmount(final double amount) {
		DecimalFormat format = new DecimalFormat("#0,000,000");
		String formattedNumber = format.format(amount);
		return "$"+formattedNumber;
	}
	
	/**
	 * Method for Vanity Dropdown flow.
	 * @param user
	 * @param model
	 * @return String
	 */
	@RequestMapping(value="selectedCoverage.do",method = RequestMethod.POST)
	public ModelAndView saveSelectedCoverage(@ModelAttribute("selectcoverageform") UserCoverage user,Model model) throws Exception {
		ProfileVO profileVO = new ProfileVO();
		profileVO.setCoverage(Double.parseDouble(user.getCoverageAmount()));
		profileVO.setPathId(1);
		String vanityPhoneNo=(String)session.getAttribute("phoneNumber");
		profileVO.setVanityPhoneNo(vanityPhoneNo);
		//myLifeCoveredService.saveProfile(profileVO);
		ModelAndView modelView = new ModelAndView("quote");
		setUserProfileToSession(profileVO);
		return modelView;
	}
	
	@RequestMapping("legalInformation.do")
	public String loadLegalInformationPage(Model model) {
		return "legalInformation";
	}
	
	@RequestMapping("policyForms.do")
	public String loadPolicyFormsPage(Model model) {
		return "policyForms";
	}
	
	@RequestMapping("financialRatings.do")
	public String loadFinancialRatingsPage(Model model) {
		return "financialRatings";
	}
}