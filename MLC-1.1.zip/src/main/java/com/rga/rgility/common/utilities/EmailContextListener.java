package com.rga.rgility.common.utilities;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;

import com.rga.rgility.common.logger.LogFactory;
import com.rga.rgility.common.logger.MyLifeCoveredLogger;
import com.rga.rgility.service.EmailService;
import com.rga.rgility.service.MyLifeCoveredService;
import com.rga.rgility.service.HealthIQService;
import com.rga.rgility.valueobjects.DemographicInfoVO;
import com.rga.rgility.valueobjects.ProfileVO;

public class EmailContextListener {

	private static final MyLifeCoveredLogger LOGGER = LogFactory.getInstance(EmailContextListener.class);
	@Autowired
	private MyLifeCoveredService myLifeCoveredService;
	
	@Autowired
	private EmailService emailService;
	
	@Autowired
	private HealthIQService healthService;
	
		
	@Scheduled(cron="0 0 0/12 * * ?")
	public void jobTask() {
		LOGGER.debug("Job started");
		// Check all records with SLIDER_VISIT=Y and EMAIL_COUNT <= 3
		try {
			List<DemographicInfoVO> demoList = myLifeCoveredService
					.getSliderVisitsThreeAttempts();
			if (demoList != null) {
				if (demoList.size() > 0) {
					LOGGER.debug("Slider abandons found: " + demoList.size());
					for (DemographicInfoVO demo : demoList) {
						LOGGER.debug("Slider abandons : Trigger emails : "
								+ demo.getEmailAddress());
						emailService.sendQuoteFollowUpEmail(demo);
						myLifeCoveredService.incrementEmailCount(demo);
					}
				}
			}
			// Check all records with SLIDER_VISIT=Y and EMAIL_COUNT > 3
			List<DemographicInfoVO> demoGrtList = myLifeCoveredService
					.getSliderVisitsGrtThreeAttempts();
			if (demoGrtList != null) {
				if (demoGrtList.size() > 0) {
					LOGGER.debug("Slider abandons:3 attempts exceeded: "
							+ demoGrtList.size());
					for (DemographicInfoVO demo : demoGrtList) {
						ProfileVO profileVO = new ProfileVO();
						profileVO.setProfileId(demo.getProfileId());
						profileVO.setDemographicVO(demo);
						LOGGER.debug("Slider abandons:3 attempts exceeded: sliderflag set to N ");
						myLifeCoveredService.updateSliderVisitFlagThruJob(
								profileVO, false);
						LOGGER.debug("Slider abandons:3 attempts exceeded: post to Health IQ ");
//						healthService.postToHealthIQ(demo);
					}
				}
			}
		} catch(Exception e) {
			e.printStackTrace();
		}

	}
}
