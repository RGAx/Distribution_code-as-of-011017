/**
 * 
 */
package com.rga.rgility.common.utilities;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.Map;

import org.joda.time.LocalDate;
import org.joda.time.Period;
import org.joda.time.PeriodType;

import com.rga.rgility.exception.BaseException;

/**
 * @author M1030133
 * 
 */
/**
 * @author M1030133
 *
 */
@SuppressWarnings("rawtypes")
public class MyLifeCoveredUtils {

	public static boolean isEmpty(Object object) {
		return object == null ? true : false;
	}

	public static boolean isEmpty(String string) {
		return (string == null || string.isEmpty()) ? true : false;
	}

	public static boolean isEmpty(Collection collection) {
		return (collection == null || collection.size() > 0) ? true : false;
	}

	public static boolean isEmpty(Map map) {
		return (map == null || map.size() > 0) ? true : false;
	}

	public static boolean isZero(long number) {
		return (number == 0) ? true : false;
	}
	
	public static boolean isZero(double number) {
		return (number == 0.0) ? true : false;
	}
	
	public static Date convertStringToDate(String pattern, String date) throws BaseException {
		Date dateFormat = null;
		try {
			SimpleDateFormat formatter = new SimpleDateFormat(pattern);
			dateFormat = formatter.parse(date);
		} catch (ParseException e) {
			throw new BaseException(e.getMessage());
		}
		return dateFormat;
	}

	public static int getDiffInYearsInJodaTime(Date dob) {
		LocalDate now = new LocalDate();
		LocalDate date = new LocalDate(dob);
		Period period = new Period(date, now, PeriodType.yearMonthDay());
		
		int years = period.getYears();
		if(period.getMonths() >= 6) {
			years++;
		}
		return years;
	}
	
	/**
	 * @param date
	 * @return
	 */
	public static String formatToFileFormatDate(Date date) {
		SimpleDateFormat format = new SimpleDateFormat("MM_dd_yyyy_HH_mm_ss");
		return format.format(date);
	}
	
	/**
	 * 
	 * @param pattern
	 * @param date
	 * @return
	 */
	public static String convertDateToString(String pattern, Date date) {
		SimpleDateFormat formatter = new SimpleDateFormat(pattern);
		String dateFormat = formatter.format(date);
		return dateFormat;
	}
	
	/**
	 * @param value
	 * @return
	 */
	public static int convertToNearestFiveMuliplier(int value) {
		if(value >= 0 && value <= 10) {
			return 10;
		} else if(value % 5 != 0) {
			int tempValue = value % 5;
			if(tempValue >= 3) {
				value = value + (5 - tempValue);
			} else {
				value = value - tempValue;
			}
		}
		return value;
	}
	
	/**
	 * @param value
	 * @return
	 */
	public static int convertToNearestCoverage(int value) {
		if(value < 0) {
			value = 0;
		} else if(value > 0 && value < 100000) { 
			value = 100000;
		} else if(value > 100000 && value < 500000) {
			int tempValue = value % 25000;
			if(tempValue >= 12500) {
				value = value + (25000 - tempValue);
			} else {
				value = value - tempValue;
			}
		} else if(value > 500000 && value < 1000000) {
			int tempValue = value % 50000;
			if(tempValue >= 25000) {
				value = value + (50000 - tempValue);
			} else {
				value = value - tempValue;
			}
		} else if(value > 1000000 && value < 2000000) {
			int tempValue = value % 100000;
			if(tempValue >= 50000) {
				value = value + (100000 - tempValue);
			} else {
				value = value - tempValue;
			}
		}
		return value;
	}
	
	public static int getStartDateDiffYears(Date first, Date last) {
	    Calendar start = Calendar.getInstance();
	    Calendar end = Calendar.getInstance();
	    start.setTime(first);
	    end.setTime(last);
	    
	    int diff = end.get(Calendar.YEAR) - start.get(Calendar.YEAR);
	    if (start.get(Calendar.MONTH) > end.get(Calendar.MONTH)) {
	        diff--;
	    }else if(start.get(Calendar.DAY_OF_MONTH) > end.get(Calendar.DAY_OF_MONTH)){
	    	diff--;
    	}
	    return diff;
	}
	
	public static int getEndDateDiffYears(Date first, Date last) {
	    Calendar start = Calendar.getInstance();
	    Calendar end = Calendar.getInstance();
	    start.setTime(first);
	    end.setTime(last);
	    
	    int diff = end.get(Calendar.YEAR) - start.get(Calendar.YEAR);
	    if (end.get(Calendar.MONTH) > start.get(Calendar.MONTH)) {
	        diff++;
	    }else if(end.get(Calendar.DAY_OF_MONTH) > start.get(Calendar.DAY_OF_MONTH)){
	    	diff++;
    	}
	    return diff;
	}
	
}
