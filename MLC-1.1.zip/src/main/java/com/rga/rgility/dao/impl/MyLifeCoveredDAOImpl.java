/**
 * 
 */
package com.rga.rgility.dao.impl;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.rga.rgility.common.constants.QueryConstants;
import com.rga.rgility.common.logger.LogFactory;
import com.rga.rgility.common.logger.MyLifeCoveredLogger;
import com.rga.rgility.dao.MyLifeCoveredDAO;
import com.rga.rgility.exception.DAOException;
import com.rga.rgility.model.UserCoverage;
import com.rga.rgility.valueobjects.Children;
import com.rga.rgility.valueobjects.DemographicInfoVO;
import com.rga.rgility.valueobjects.Path;
import com.rga.rgility.valueobjects.ProfileVO;

/**
 * @author M1030133
 * 
 */
@Repository
public class MyLifeCoveredDAOImpl implements MyLifeCoveredDAO {


	private static final MyLifeCoveredLogger LOGGER = LogFactory.getInstance(MyLifeCoveredDAOImpl.class);
	
	private static final String CREATED_BY = "APPLICATION";

	@Autowired
	private JdbcTemplate jdbcTemplate;

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	/**
	 * 
	 */
	@Override
	public ProfileVO saveProfile(ProfileVO profileVO) throws DAOException {
		try {
			Object[] args = new Object[] { profileVO.getPathId(),
					profileVO.getFirstName(), profileVO.getCoverage(), profileVO.getTerm(),
					profileVO.getRetirementSavings(), profileVO.getOtherSavings(),
					profileVO.getAnnualIncome(), profileVO.getExistingLifeInsurance(),
					profileVO.getYearsIncomeProvided(), profileVO.getFinalExpenses(),
					profileVO.getOutstandingMortgage(), profileVO.getOtherOutstandingDebt(),
					profileVO.getEstimatedInflationRate(), profileVO.getEstimatedInvestmentReturn(),
					profileVO.getTotalIncomeToBeProvided(), profileVO.getTotalIncomeNeeds(),
					profileVO.getTotalCollegeExpenses(), profileVO.getTotalOneTimeNeeds(), 
					new java.sql.Timestamp(new Date().getTime()), CREATED_BY , 
					profileVO.getVanityPhoneNo(), profileVO.getAffordablePremium()};
			jdbcTemplate.update(QueryConstants.INSERT_PROFILE, args);
			int profileId = jdbcTemplate.queryForObject(
					QueryConstants.PROFILE_MAX_ID, Integer.class);
			profileVO.setProfileId(profileId);
		} catch (Exception e) {
			e.printStackTrace();
			throw new DAOException(e.getMessage());
		}
		
		return profileVO;
	}

	/**
	 * 
	 */
	@Override
	public DemographicInfoVO saveDemographicInfo(ProfileVO profileVO)
			throws DAOException {
		DemographicInfoVO infoVO = profileVO.getDemographicVO();
		try {
			Object[] args = new Object[] { infoVO.getDateOfBirth(),
					infoVO.getGender(), infoVO.getSmokerStatus(),
					infoVO.getIsUsCitizen(), infoVO.getIsPolicyOwner(),
					infoVO.getIsConsentReplacementPolicy(),
					profileVO.getProfileId(), infoVO.getEmailAddress(),
					infoVO.getState(), CREATED_BY,new java.sql.Date(Calendar.getInstance().getTimeInMillis()),infoVO.getIsAllowMarketing(),infoVO.getQuotePhone()};
			jdbcTemplate.update(QueryConstants.INSERT_DEMOGRAPHIC_INFO, args);
			int demographicId = jdbcTemplate.queryForObject(
					QueryConstants.DEMOGRAPHIC_INFO_MAX_ID, Integer.class);
			infoVO.setDemographicInfoId(demographicId);
		} catch (Exception e) {
			e.printStackTrace();
			throw new DAOException(e.getMessage());
		}
		return infoVO;
	}

	/* (non-Javadoc)
	 * @see com.rga.rgility.dao.MyLifeCoveredDAO#loadPaths()
	 */
	@Override
	public List<Path> loadPaths() throws DAOException {
		List<Path> paths = new ArrayList<Path>();
		try {
			List<Map<String, Object>> records = jdbcTemplate.queryForList(QueryConstants.LOAD_PATHS);
			for(Map<String, Object> record : records) {
				Path path = new Path(); 
				path.setPathId(Integer.parseInt(String.valueOf(record.get("PATH_ID"))));
				path.setPathDescription(String.valueOf(record.get("PATH_DESCRIPTION")));
				paths.add(path);
			}
		} catch(Exception e) {
			
		}
		return paths;
	}

	/* (non-Javadoc)
	 * @see com.rga.rgility.dao.MyLifeCoveredDAO#saveChildren(java.util.List)
	 */
	@Override
	public void saveChildren(List<Children> children) throws DAOException {
		try {
			for(int i = 1; i < children.size(); i++) {
				Children child = children.get(i);
				Object[] args = new Object[] { child.getProfileId(),
						child.getChildIndex(), child.getSchoolType(),
						new java.sql.Timestamp(new Date().getTime()), CREATED_BY };
				jdbcTemplate.update(QueryConstants.INSERT_CHILD_INFO, args);
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw new DAOException(e.getMessage());
		}
	}
	
	/* (non-Javadoc)
	 * @see com.rga.rgility.dao.MyLifeCoveredDAO#deleteChildren(int)
	 */
	@Override
	public void deleteChildren(int profileId) throws DAOException {
		try {
			Object[] args = new Object[]{profileId};
			jdbcTemplate.update(QueryConstants.DELETE_CHILDREN_PER_PROFILE, args);
		} catch (Exception e) {
			e.printStackTrace();
			throw new DAOException(e.getMessage());
		}
	}

	/* (non-Javadoc)
	 * @see com.rga.rgility.dao.MyLifeCoveredDAO#updateProfile(com.rga.rgility.valueobjects.ProfileVO)
	 */
	@Override
	public void updateProfile(ProfileVO profileVO) throws DAOException {
		try {
			Object[] args = new Object[] { profileVO.getCoverage(), profileVO.getTerm(),
					profileVO.getRetirementSavings(), profileVO.getOtherSavings(),
					profileVO.getAnnualIncome(), profileVO.getExistingLifeInsurance(),
					profileVO.getYearsIncomeProvided(), profileVO.getFinalExpenses(),
					profileVO.getOutstandingMortgage(), profileVO.getOtherOutstandingDebt(),
					profileVO.getEstimatedInflationRate(), profileVO.getEstimatedInvestmentReturn(),
					profileVO.getTotalIncomeToBeProvided(), profileVO.getTotalIncomeNeeds(),
					profileVO.getTotalCollegeExpenses(), profileVO.getTotalOneTimeNeeds(), 
					profileVO.getFirstName(),profileVO.getVanityPhoneNo(), 
					profileVO.getAffordablePremium(), profileVO.getProfileId()};
			jdbcTemplate.update(QueryConstants.UPDATE_PROFILE, args);
		} catch (Exception e) {
			e.printStackTrace();
			throw new DAOException(e.getMessage());
		}
	}
	
	public void updateSliderVisitFlag(ProfileVO profileVO,final boolean sliderVisit) throws DAOException {
		String temp = null;
		if (sliderVisit) {
			temp = "Y";
		} else {
			temp = "N";
		}
		// Update the current record.
		Object[] args = new Object[] {temp, profileVO.getProfileId()};
		jdbcTemplate.update(QueryConstants.UPDATE_SLIDER_FLAG, args);
		
		if (temp.equals("N")) {
		// Update old profile records as completed.
			Object[] args1 = new Object[] {temp, profileVO.getDemographicVO().getEmailAddress()};
			jdbcTemplate.update(QueryConstants.UPDATE_SLIDER_FLAG_OLD, args1);
		}	
	}
	
	public List<DemographicInfoVO> getSliderVisitsThreeAttempts() {
		List<Map<String, Object>> records = jdbcTemplate.queryForList(QueryConstants.SELECT_SLIDER_FLAG_3);
		Map<String, DemographicInfoVO>  distinctEmailsMap = new HashMap<String, DemographicInfoVO>();
		LOGGER.debug("In Dao:getSliderVisitsThreeAttempts");
		for(Map<String, Object> record : records) {
			DemographicInfoVO demoVO = new DemographicInfoVO();
			demoVO.setFirstName(String.valueOf(record.get("FIRST_NAME")));
			demoVO.setProfileId(Integer.parseInt(String.valueOf(record.get("PROFILE_ID"))));
			demoVO.setEmailAddress(String.valueOf(record.get("EMAIL_ADDRESS")));
			/*The below line of commented because we need distinct emails only irrespective of first name*/
			//demoList.add(demoVO);
			/*Using Map to store the key as email and value as object finally those objects is distinct*/
			distinctEmailsMap.put(String.valueOf(record.get("EMAIL_ADDRESS")), demoVO);
		}
		/*converted Map values as List and return*/
		return new ArrayList<DemographicInfoVO>(distinctEmailsMap.values());
	}
	
	
	public List<DemographicInfoVO> getSliderVisitsGrtThreeAttempts() {
		List<DemographicInfoVO> demoList = new ArrayList<DemographicInfoVO>();
		LOGGER.debug("In Dao:getSliderVisitsGrtThreeAttempts");
		List<Map<String, Object>> records = jdbcTemplate.queryForList(QueryConstants.SELECT_SLIDER_FLAG_GRT_3);
		for(Map<String, Object> record : records) {
			DemographicInfoVO demoVO = new DemographicInfoVO();
			demoVO.setFirstName(String.valueOf(record.get("FIRST_NAME")));
			demoVO.setProfileId(Integer.parseInt(String.valueOf(record.get("PROFILE_ID"))));
			demoVO.setPhone(String.valueOf(record.get("PHONE")));
			demoList.add(demoVO);
		}
		return demoList;
		
	}
	
	public void incrementEmailCount(DemographicInfoVO demoVO) {
		Object[] args1 = new Object[] {demoVO.getProfileId()};
		jdbcTemplate.update(QueryConstants.INCREMENT_EMAIL_COUNT, args1);
	}
	
	public void updateSliderVisitFlagThruJob(ProfileVO profileVO,final boolean sliderVisit) throws DAOException {
		String temp = null;
		if (sliderVisit) {
			temp = "Y";
		} else {
			temp = "N";
		}
		// Update the current record.
		Object[] args = new Object[] {temp, profileVO.getProfileId()};
		jdbcTemplate.update(QueryConstants.UPDATE_SLIDER_FLAG, args);
		
		if (temp.equals("N")) {
		// Update old profile records as completed.
			Object[] args1 = new Object[] {temp, profileVO.getDemographicVO().getEmailAddress()};
			jdbcTemplate.update(QueryConstants.UPDATE_SLIDER_FLAG_OLD, args1);
		}	
	}
	
	@Override
	public void saveContactUsDetails(UserCoverage user,ProfileVO userProfileFromSession) throws DAOException {
		int profileId=0;
		try {
			if(null != userProfileFromSession && userProfileFromSession.getProfileId() != 0) {
				profileId = userProfileFromSession.getProfileId();	
			}
								
			Object[] args = new Object[] {profileId,
					user.getName(),
					user.getPhone(),
					user.getEmail(),
					user.getComments(),
					user.getBestTimeToCall(),
					new java.sql.Timestamp(new Date().getTime()), CREATED_BY,
					user.getTimeZone()};
			System.out.println("before query execute");
			jdbcTemplate.update(QueryConstants.CUSTOMER_CALLBACK, args);			
			System.out.println("after query executed");
		} catch (Exception e) {
			e.printStackTrace();
			throw new DAOException(e.getMessage());
		}
	}

	@Override
	public int updateUnsubscribeEmail(String email) throws DAOException {
		int updateCount = 0;
		try {
			Object[] args = new Object[] {email};
			updateCount = jdbcTemplate.update(QueryConstants.UPDATE_UNSUBSCRIBE_EMAIL,args);
			LOGGER.info("No.of rows updated_EMAIL_COUNT value : "+updateCount);
		} catch (DataAccessException e) {
			e.printStackTrace();
			throw new DAOException(e.getMessage());
		}
		return updateCount;
	}
	

}
