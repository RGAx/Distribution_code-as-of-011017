package com.connbenefits.common.logger;

/**
 * Used to implement logger.
 * 
 * @author M1030133
 *
 */
@SuppressWarnings("rawtypes")
public class LogFactory {
	public static ExtJourneyLogger getInstance() {
		return new ExtJourneyLoggerImpl();
	}

	public static ExtJourneyLogger getInstance(String className) {
		return new ExtJourneyLoggerImpl(className);
	}

	public static ExtJourneyLogger getInstance(Class clazz) {
		return new ExtJourneyLoggerImpl(clazz.getCanonicalName());
	}
}