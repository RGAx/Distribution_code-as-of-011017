package com.connbenefits.common.utils;

import java.io.IOException;
import java.io.InputStream;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.joda.time.LocalDate;
import org.joda.time.Period;
import org.joda.time.PeriodType;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.connbenefits.common.logger.ExtJourneyLogger;
import com.connbenefits.common.logger.LogFactory;
import com.connbenefits.exception.ServiceException;

/**
 * Used for operations such as generating encrypted id, getting difference in
 * years between two dates etc.
 * 
 * @author M1030133
 *
 */
public class Utils {
	private static final ExtJourneyLogger LOGGER = LogFactory.getInstance(Utils.class);
	
	public static String encryptID(String encryptedID) {
		return new BCryptPasswordEncoder().encode(encryptedID);
	}

	/*
	 * Getting the date difference in years
	 */
	public static int getDiffYears(Date first, Date last) {
		Calendar a = getCalendar(first);
		Calendar b = getCalendar(last);
		int diff = b.get(Calendar.YEAR) - a.get(Calendar.YEAR);
		if (a.get(Calendar.MONTH) > b.get(Calendar.MONTH)
				|| (a.get(Calendar.MONTH) == b.get(Calendar.MONTH) && a
						.get(Calendar.DATE) > b.get(Calendar.DATE))) {
			diff--;
		}
		return diff;
	}

	public static Calendar getCalendar(Date date) {
		Calendar cal = Calendar.getInstance(Locale.US);
		cal.setTime(date);
		return cal;
	}

	/*
	 * Getting the date in yyyy-mm-dd format.
	 */
	public static Date getFormattedDate(String source) throws ParseException {
		return new SimpleDateFormat("yyyy-MM-dd").parse(source);
	}
	
	/*
	 * Getting the date in mm-dd-yyyy format.
	 */
	public static String getFormattedDate(Date source) throws ParseException {
		return DateFormat.getDateInstance(DateFormat.LONG).format(source);
	}
	
	/*
	 * Used to load the state Id based on State code.
	 */
	public static Map<String, Integer> loadStateIds() throws Exception {
		Map<String, Integer> statesIdMap = new HashMap<String, Integer>();
		try {
			DocumentBuilder dBuilder = DocumentBuilderFactory.newInstance()
					.newDocumentBuilder();
			
			InputStream is = Utils.class.getResourceAsStream("/PinneyStates.xml");
			Document doc = dBuilder.parse(is);
			NodeList nList = doc.getElementsByTagName("state");
			
			for (int temp = 0; temp < nList.getLength(); temp++) {
				Node nNode = nList.item(temp);
				if (nNode.getNodeType() == Node.ELEMENT_NODE) {
					Element eElement = (Element) nNode;
					statesIdMap.put(eElement.getAttribute("code"), Integer.parseInt(eElement.getAttribute("id")));
				}
			}
		} catch (SAXException e) {
			LOGGER.error("ERROR: " + e.getMessage());
			throw new ServiceException(e.getMessage());
		} catch (IOException e) {
			LOGGER.error("ERROR: " + e.getMessage());
			throw new ServiceException(e.getMessage());
		}
		return statesIdMap;
	}
	
	/*
	 * Getting the date difference in years
	 */
	public static int getDiffYears(Date date) {
		Calendar calDate = getCalendar(date);
		int year = calDate.get(Calendar.YEAR);
		int month = calDate.get(Calendar.MONTH);
		int day = calDate.get(Calendar.DATE);
		
		Calendar currDate = getCalendar(new Date());
		int currYear = currDate.get(Calendar.YEAR);
		int currMonth = currDate.get(Calendar.MONTH);
		int currDay = currDate.get(Calendar.DATE);
		
		int diff = currYear - year;
		
		if(diff > 30) {
			if(currMonth > month) {
				diff ++;
			}
			if(month == currMonth && day <= currDay) {
				diff ++;
			}
		} else {
			if(currMonth < month) {
				diff --;
			}
			if(month == currMonth && day - 1 > currDay) {
				diff --;
			}
		}
		return diff;
	}
	
	public static boolean isNumeric(String str) {
		try {
			Double.parseDouble(str);
		} catch (NumberFormatException nfe) {
			return false;
		}
		return true;
	}
	
	public static int getDiffInYearsInJodaTime(Date dob) {
		LocalDate now = new LocalDate();
		LocalDate date = new LocalDate(dob);
		Period period = new Period(date, now, PeriodType.yearMonthDay());
		
		int years = period.getYears();
		if(period.getMonths() >= 6) {
			years++;
		}
		return years;
	}
	
	/*
	 * This method is used to get the yesterdays date with the current date in MMddyyyy format.
	 */
	public static String getyesterdaysDate(Date date) throws ParseException{
		
		DateFormat dateFormat = Utils.getDateInstance("MMddyyyy");
		String newDate = null;
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DATE, -1);
        newDate = dateFormat.format(cal.getTime());
        
        return newDate;
        
	}
	/*
	 * This methoed is used to get the Date Instance of Mentioned format
	 * 
	 * i.e MMddyyyy/YYYY-MM-DD/MM-dd-YYYY 
	 */
	public static DateFormat getDateInstance(String format) throws ParseException{
		return new SimpleDateFormat(format);
	}
	
	/**
	 * This method returns ordinal suffix of the date
	 * @param day
	 * @return
	 */
	public static String getDayNumberSuffix(int day) {
	    if (day >= 11 && day <= 13) {
	        return "th";
	    }
	    switch (day % 10) {
	    case 1:
	        return "st";
	    case 2:
	        return "nd";
	    case 3:
	        return "rd";
	    default:
	        return "th";
	    }
	}
	
	
	/**
	 * This method is used to get the yesterdays date in [MMM dd suffix  yyyy] format.
	 * Ex: Feb 29th 2016
	 * @return
	 * @throws Exception
	 */
	public static String getYesterdayDateWithSuffix() throws Exception{
		Calendar cal = Calendar.getInstance();
	    cal.add(Calendar.DATE, -1);
	    String dayNumberSuffix = getDayNumberSuffix(cal.get(Calendar.DAY_OF_MONTH));
	    Date date =cal.getTime();
	    DateFormat formatter = new SimpleDateFormat("MMM d'" + dayNumberSuffix + "' yyyy");
		return formatter.format(date);
    
	}
}
