/**
 * 
 */
package com.connbenefits.services;

import java.util.List;

import com.connbenefits.domain.MultiplierRateDetails;
import com.connbenefits.exception.ServiceException;

/**
 * @author M1029563
 *
 */
public interface GenericService {
	
	
	public List<MultiplierRateDetails> loadMultiplierrateList() throws ServiceException;

}
