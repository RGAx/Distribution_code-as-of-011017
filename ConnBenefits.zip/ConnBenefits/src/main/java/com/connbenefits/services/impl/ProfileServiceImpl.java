package com.connbenefits.services.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.connbenefits.dao.ProfileDAO;
import com.connbenefits.domain.ErrorLog;
import com.connbenefits.domain.ExcelReport;
import com.connbenefits.domain.Profile;
import com.connbenefits.domain.rest.ErrorDetails;
import com.connbenefits.exception.DAOException;
import com.connbenefits.exception.ServiceException;
import com.connbenefits.services.ProfileService;

/**
 * Used for implementing the services like loading /saving profile, errorlog
 * etc.
 * 
 * @author M1030133
 *
 */
@Service
public class ProfileServiceImpl implements ProfileService {
	@Autowired
	private ProfileDAO profileDao;

	/*
	 * Used for saving the profile into the db.
	 * 
	 * @see
	 * com.connbenefits.services.ProfileService#saveProfile(com.connbenefits.domain.Profile
	 * )
	 */
	@Override
	public Profile saveProfile(Profile profile) throws ServiceException {
		try {
			return profileDao.saveProfile(profile);
		} catch (DAOException e) {
			throw new ServiceException(e.getMessage());
		}
	}

	/*
	 * Used for updating the profile into the db.
	 * 
	 * @see
	 * com.connbenefits.services.ProfileService#updateProfile(com.connbenefits.domain.
	 * Profile)
	 */
	@Override
	public void updateProfile(Profile profile) throws ServiceException {
		try {
			profileDao.updateProfile(profile);
		} catch (DAOException e) {
			throw new ServiceException(e.getMessage());
		}
	}

	/*
	 * Used for loading the profile from the db.
	 * 
	 * @see com.connbenefits.services.ProfileService#loadProfile(java.lang.String)
	 */
	@Override
	public Profile loadProfile(String encryptedId) throws ServiceException {
		try {
			return profileDao.loadProfile(encryptedId);
		} catch (DAOException e) {
			throw new ServiceException(e.getMessage());
		}
	}

	/*
	 * Used for saving the error log details
	 * 
	 * @see
	 * com.connbenefits.services.ProfileService#saveErrorLog(com.connbenefits.domain.ErrorLog
	 * )
	 */
	@Override
	public void saveErrorLog(ErrorLog errorLog) throws ServiceException {
		try {
			profileDao.saveErrorLog(errorLog);
		} catch (DAOException e) {
			throw new ServiceException(e.getMessage());
		}
	}

	/*
	 * used for loading the errorlog object from the profile.
	 * 
	 * @see
	 * com.connbenefits.services.ProfileService#loadErrorLogFromProfile(com.connbenefits
	 * .domain.Profile, com.connbenefits.domain.rest.ErrorDetails)
	 */
	@Override
	public ErrorLog loadErrorLogFromProfile(Profile profile, ErrorDetails error)
			throws ServiceException {
		ErrorLog errorLog = new ErrorLog();
		if (profile != null) {
			errorLog.setFirstName(profile.getFirstName());
			errorLog.setLastName(profile.getLastName());
			errorLog.setGender(profile.getGender());
			errorLog.setState(profile.getState());
			errorLog.setCity(profile.getCity());
			errorLog.setEmailAddress(profile.getEmailAddress());
			errorLog.setDateOfBirth(profile.getDateOfBirth());
			errorLog.setAnnualIncome(profile.getAnnualIncome());
			errorLog.setPhoneNumber(profile.getPhoneNumber());
			errorLog.setZipCode(profile.getZipCode());
			errorLog.setErrorCode(error.getCode());
			errorLog.setErrorMessage(error.getMessage());
		}
		return errorLog;
	}

	/*
	 * (non-Javadoc) Used for updating the Profile Table Coverage and
	 * EbixMonthlyEstimate Columns
	 * 
	 * @see
	 * com.connbenefits.services.ProfileService#updateProfileEbixMonthlyEstimate(
	 * com.connbenefits.domain.Profile)
	 */
	@Override
	public void updateProfileEbixMonthlyEstimate(Profile profile)
			throws ServiceException {

		try {
			profileDao.updateProfileEbixMonthlyEstimate(profile);
		} catch (DAOException e) {
			throw new ServiceException(e.getMessage());
		}

	}

	/*
	 * Used for updating the pinney status of profile.
	 * 
	 * @see
	 * com.connbenefits.services.ProfileService#updateProfileWithPinneyStatus(com
	 * .connbenefits.domain.Profile)
	 */
	@Override
	public void updateProfileWithPinneyStatus(Profile profile)
			throws ServiceException {
		try {
			profileDao.updateProfileWithPinneyStatus(profile);
		} catch (DAOException e) {
			throw new ServiceException(e.getMessage());
		}
	}

	@Override
	public void updateProfileWithDetails(Profile profile)
			throws ServiceException {
		try {
			profileDao.updateProfileWithDetails(profile);
		} catch (DAOException e) {
			throw new ServiceException(e.getMessage());
		}
		
	}

	@Override
	public Profile saveProfileWithDetails(Profile profile) throws ServiceException {
		try {
			return profileDao.saveProfileWithDetails(profile);
		} catch (DAOException e) {
			throw new ServiceException(e.getMessage());
		}
		
	}
	/*
	 * (non-Javadoc)
	 * @see com.connbenefits.services.ProfileService#fetchuserSavedDetails()
	 */
	@Override
	public List<ExcelReport> fetchuserSavedDetails() throws ServiceException {
		try{
			return profileDao.fetchuserDetailsForExcelReport();
		}catch(DAOException e){
			throw new ServiceException(e.getMessage());
		}
	}

	@Override
	public void updateProfilesWithCBSubmittedStatus(List<Integer> profileIds)
			throws ServiceException {
		try{
			profileDao.updateProfilesWithCBSubmittedStatus(profileIds);
		}catch(DAOException e){
			throw new ServiceException(e.getMessage());
		}
	}

}
