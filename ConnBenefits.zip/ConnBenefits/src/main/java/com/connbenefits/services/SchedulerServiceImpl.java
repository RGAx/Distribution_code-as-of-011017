
package com.connbenefits.services;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import com.connbenefits.common.logger.ExtJourneyLogger;
import com.connbenefits.common.logger.LogFactory;
import com.connbenefits.exception.DAOException;
import com.connbenefits.exception.ServiceException;

/**
 * @author M1029563
 * This class is used to Trigger the Task Scheduler at Mid Night 12
 */
@Service
public class SchedulerServiceImpl {

	private static final ExtJourneyLogger logger = LogFactory.getInstance(SchedulerServiceImpl.class);
	
	@Autowired
	@Qualifier("syncExcelReportSchedulerJobs")
	private ScheduleJob scheduleJob;
	
	/*
	 * This method is used to trigger the scheduler @Mid Night 12
	 * @throws Exception
	 */
	@Scheduled(cron="0 5 0 * * ?")
	public synchronized void doexcelReportSchedule() throws Exception{
		
		logger.info("Start Excel Report scheduling"+new Date());
		try{
			scheduleJob.shedulerexcelReportJob();
		}catch(DAOException e){
			logger.error("Error:"+e.getMessage());
			throw new ServiceException();
		}
		logger.info("End schedule");
	}
	
} 
