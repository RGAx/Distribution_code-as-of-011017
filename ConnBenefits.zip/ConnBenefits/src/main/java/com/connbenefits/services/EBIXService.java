package com.connbenefits.services;

import java.util.List;
import java.util.Map;

import com.connbenefits.domain.ProfileQuestion;
import com.connbenefits.exception.ServiceException;

/**
 * This class has been used for defining the operations such as loading the user
 * question answer, getting the best quote etc which have been implemented in
 * EBIXServiceImpl class.
 * 
 * @author M1033511
 *
 */
public interface EBIXService extends BaseService {

	public Map<Integer, Double> getMonthlyPremium(
			ProfileQuestion profileQuestion, List<Integer> faceAmountList)
			throws ServiceException;

}
