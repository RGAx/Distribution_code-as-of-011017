package com.connbenefits.services;

import com.connbenefits.domain.Profile;
import com.connbenefits.domain.rest.ErrorDetails;
import com.connbenefits.domain.rest.ExtJourney;
import com.connbenefits.exception.ServiceException;

/**
 * Used for defining the operations such as loading, validating the rest profile
 * etc.
 * 
 * @author M1030133
 *
 */
public interface RestService {
	public Profile loadRestProfile(ExtJourney extJourney)
			throws ServiceException;

	public ErrorDetails validateRestProfile(Profile profile)
			throws ServiceException;

	public ErrorDetails validateDateOfBirth(ExtJourney extJourney)
			throws ServiceException;
}
