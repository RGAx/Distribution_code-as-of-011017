package com.connbenefits.services;

import org.springframework.web.servlet.ModelAndView;

import com.connbenefits.domain.Profile;
import com.connbenefits.domain.ProfileCustomerCallback;
import com.connbenefits.exception.ServiceException;

/**
 * used for defining the operations such as saving the profileCustomerCallback,
 *  
 * @author m1033511
 */
public interface CallbackService {

	public int saveCallbackDetails(ProfileCustomerCallback profileCustomerCallback,Profile profile) throws ServiceException;

	public ModelAndView loadCallbackPage(ModelAndView model, Profile profile) throws ServiceException;
}
