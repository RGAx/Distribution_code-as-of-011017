package com.connbenefits.services.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;

import com.connbenefits.common.logger.ExtJourneyLogger;
import com.connbenefits.common.logger.LogFactory;
import com.connbenefits.common.utils.Utils;
import com.connbenefits.domain.MultiplierRateDetails;
import com.connbenefits.domain.Profile;
import com.connbenefits.domain.SliderFaceValue;
import com.connbenefits.exception.ServiceException;
import com.connbenefits.services.GenericService;
import com.connbenefits.services.SliderService;


/**
 * @author M1029563
 * This class will be used as a ServiceLevel implementation for SliderPage by overriding the unimplemented methods of com.connbenefits.services.SliderService#loadSliderFaceValues and 
 * com.connbenefits.services.SliderService#loadSliderPage() from SliderService Interface returning LIST<Facevalues> and SliderFaceValue Object to respective view SliderPage.
 *
 */
public class SliderServiceImpl implements SliderService {
	
	@Autowired
	private HttpSession session;	
	
	@Autowired
	private GenericService genericService;
	
	private static final ExtJourneyLogger LOGGER = LogFactory.getInstance(SliderServiceImpl.class);
	
	/*
	 * This method has been used for calculating the facevalues for the slider
	 * based on the inputs provided.
	 * 
	 * @see com.connbenefits.services.SliderService#loadSliderFaceValues(int, int,
	 * int, int)
	 */
	public List<Integer> loadSliderFaceValues(int idealMinFaceValue,
			int idealMaxFaceValue, int recommendedFaceVale, int scaleUnit) {
		long startTime = LOGGER.logMethodEntry();

		/*LOGGER.debug("idealMinFaceValue: " + idealMinFaceValue
				+ ", idealMaxFaceValue: " + idealMaxFaceValue
				+ ", recommendedFaceVale: " + recommendedFaceVale
				+ ", scaleUnit:" + scaleUnit);*/
		
		Profile sessionProfile = null;
		int minFaceValue = 0, maxFaceValue = 2000000;
		
		if(null != session.getAttribute("sessionProfile")){
			sessionProfile =  (Profile) session.getAttribute("sessionProfile");
		}
		if(sessionProfile.getSource().equalsIgnoreCase("CB")) {
			minFaceValue = 100000;
		} else {
			minFaceValue = 200000;
		}
			
		if(null != session.getAttribute("dependentsCount")) {
			int dependentsCount = (Integer) session.getAttribute("dependentsCount");
			if(dependentsCount < 1) minFaceValue = 250000;
		}
				
		List<Integer> faceValues = new ArrayList<Integer>();
		/*if(idealMinFaceValue > 0 && idealMaxFaceValue > 0 && scaleUnit > 0 && recommendedFaceVale > 0) {
			int allowedMinFaceValue = idealMinFaceValue - 30 * scaleUnit;
			int allowedMaxFaceValue = idealMaxFaceValue + 15 * scaleUnit;
	
			int totalSliderPoints = ((allowedMaxFaceValue - allowedMinFaceValue) / scaleUnit) + 1;
			LOGGER.debug("allowedMinFaceValue: " + allowedMinFaceValue
					+ ", allowedMaxFaceValue: " + allowedMaxFaceValue
					+ ", totalSliderPoints: " + totalSliderPoints);
	
			if (allowedMinFaceValue >= minFaceValue && allowedMinFaceValue <= maxFaceValue) {
					faceValues.add(allowedMinFaceValue);
			}
		
			for (int count = 1; count < totalSliderPoints; count++) {
				int faceValue = allowedMinFaceValue + count * scaleUnit;
				if (faceValue >= minFaceValue && faceValue <= maxFaceValue) {
					faceValues.add(faceValue);
				}
			}
		}*/
		for (int i =  minFaceValue; i<= maxFaceValue; i+=50000) {
			faceValues.add(i);
		}
		
		LOGGER.debug("faceValues: " +faceValues.toString() );
		LOGGER.logMethodExit(startTime);
		return faceValues;
	}

	
	/* This mehod is used for loading sliderpage by calculating the Slider MIN and MAX facevalues, Ideal Coverage MIN,MAX
	 * and RECOMMENDED Values and Scale Factor
	 * (non-Javadoc)
	 * @see com.connbenefits.services.SliderService#loadSliderPage()
	 */
	@Override
	public SliderFaceValue loadSliderPage() throws ServiceException {
		
		long startTime = LOGGER.logMethodEntry();
		
		int annualIncome =0;
		int upperRange = 0;
		int lowerRange=0;
		int recommendedRange = 0;
		int scaleFactor = 0;
		int scaleUnit = 0;
		
		int sliderfacevalueSize = 0;
		
		Profile sessionProfile = null;

		List<MultiplierRateDetails> contextMultiplierrateList = null;
		SliderFaceValue sliderFaceValue = new SliderFaceValue();
		List<Integer> sliderFaceValuesList = null;
		
		if(null != session.getAttribute("sessionProfile")){
			sessionProfile =  (Profile) session.getAttribute("sessionProfile");
		}
		try {
			/*contextMultiplierrateList = genericService.loadMultiplierrateList(); 
			if(null != contextMultiplierrateList){
				int dobrange = Utils.getDiffInYearsInJodaTime(sessionProfile.getDateOfBirth());
				for(MultiplierRateDetails multiplierRateDetails : contextMultiplierrateList){
					if(multiplierRateDetails.getAge() != 0 && multiplierRateDetails.getAge()==dobrange){
						upperRange = multiplierRateDetails.getUpperRange();
						lowerRange  = multiplierRateDetails.getLowerRange();
						scaleFactor = multiplierRateDetails.getScaleFactor();
						recommendedRange = multiplierRateDetails.getRecommendedRange();
						
						sliderFaceValue.setMultiplierlowerRange(lowerRange);
						sliderFaceValue.setMultiplierupperRange(upperRange);
						sliderFaceValue.setMultiplierrecommRange(recommendedRange);
					}
				}
	
				annualIncome = (int) sessionProfile.getAnnualIncome();
				annualIncome = (int) (1000*(Math.round(annualIncome/1000.0)));
				
				upperRange = (upperRange * annualIncome);
				lowerRange = (lowerRange * annualIncome);	
				recommendedRange = (recommendedRange * annualIncome);
				
				scaleUnit = (upperRange - lowerRange)/scaleFactor;
				scaleUnit = (int) (1000*(Math.round(scaleUnit/1000.0)));
				
				upperRange = (int) (Math.round(upperRange/(double)scaleUnit)) * scaleUnit;
				lowerRange = (int) (Math.round(lowerRange/(double)scaleUnit)) * scaleUnit;
				recommendedRange = (int) (Math.round(recommendedRange/(double)scaleUnit)) * scaleUnit;
				
				sliderFaceValuesList = this.loadSliderFaceValues(lowerRange, upperRange, recommendedRange, scaleUnit);
				sliderfacevalueSize = sliderFaceValuesList.size();
				
				if(null != sliderFaceValuesList && !sliderFaceValuesList.isEmpty()){
					
					sliderFaceValue.setSliderMinValue(sliderFaceValuesList.get(0));
					sliderFaceValue.setSliderMaxValue(sliderFaceValuesList.get(sliderfacevalueSize-1));
				}				
				sliderFaceValue.setLowercoverageRange(lowerRange);
				sliderFaceValue.setUppercoverageRange(upperRange);
				sliderFaceValue.setRecommCoverageRange(recommendedRange);
				
				sliderFaceValue.setScaleFactor(scaleUnit);
				
			}*/
			
			annualIncome = (int) sessionProfile.getAnnualIncome();
			if(annualIncome < 100000) {
				annualIncome = 100000;
			}
			annualIncome = (int) (1000*(Math.round(annualIncome/1000.0)));
			
			upperRange = (5 * annualIncome);
			lowerRange = (3 * annualIncome);	
			recommendedRange = (4 * annualIncome);
			scaleUnit = 50000;
			
			sliderFaceValue.setMultiplierlowerRange(3);
			sliderFaceValue.setMultiplierupperRange(5);
			sliderFaceValue.setMultiplierrecommRange(4);
			sliderFaceValue.setScaleFactor(scaleUnit);
			
			sliderFaceValuesList = this.loadSliderFaceValues(lowerRange, upperRange, recommendedRange, scaleUnit);
			
			sliderfacevalueSize = sliderFaceValuesList.size();
			
			if(null != sliderFaceValuesList && !sliderFaceValuesList.isEmpty()){
				
				sliderFaceValue.setSliderMinValue(sliderFaceValuesList.get(0));
				sliderFaceValue.setSliderMaxValue(sliderFaceValuesList.get(sliderfacevalueSize-1));
			}				
			if(null != session.getAttribute("dependentsCount")) {
				int dependentsCount = (Integer) session.getAttribute("dependentsCount");
				if(dependentsCount < 1) {
					sliderFaceValue.setLowercoverageRange(250000);
					sliderFaceValue.setUppercoverageRange(250000);
					sliderFaceValue.setRecommCoverageRange(250000);
				} else {
					sliderFaceValue.setLowercoverageRange(lowerRange);
					sliderFaceValue.setUppercoverageRange(upperRange);
					sliderFaceValue.setRecommCoverageRange(recommendedRange);
				}
			}

		} catch (Exception e) {
			throw new ServiceException(e.getMessage());
		}
		LOGGER.logMethodExit(startTime);
		return sliderFaceValue;
	}
}
