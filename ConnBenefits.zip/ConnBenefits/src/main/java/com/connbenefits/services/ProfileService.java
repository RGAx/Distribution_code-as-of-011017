package com.connbenefits.services;

import java.util.List;

import com.connbenefits.domain.ErrorLog;
import com.connbenefits.domain.ExcelReport;
import com.connbenefits.domain.Profile;
import com.connbenefits.domain.rest.ErrorDetails;
import com.connbenefits.exception.ServiceException;

/**
 * Used for defining the services like loading/saving profile, error log etc.
 * 
 * @author M1030133
 *
 */
public interface ProfileService {
	public Profile loadProfile(String encryptedId) throws ServiceException;

	public Profile saveProfile(Profile profile) throws ServiceException;

	public void updateProfile(Profile profile) throws ServiceException;

	public ErrorLog loadErrorLogFromProfile(Profile profile, ErrorDetails error)
			throws ServiceException;

	public void saveErrorLog(ErrorLog errorLog) throws ServiceException;
	
	public void updateProfileEbixMonthlyEstimate(Profile profile) throws ServiceException;

	public void updateProfileWithPinneyStatus(Profile profile) throws ServiceException;

	public void updateProfileWithDetails(Profile profile) throws ServiceException;

	public Profile saveProfileWithDetails(Profile profile)throws ServiceException;
	
	public List<ExcelReport> fetchuserSavedDetails() throws ServiceException;
	
	public void updateProfilesWithCBSubmittedStatus(List<Integer> profileIds) throws ServiceException;
}
