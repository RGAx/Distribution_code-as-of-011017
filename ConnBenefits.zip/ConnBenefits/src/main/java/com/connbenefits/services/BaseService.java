package com.connbenefits.services;

/**
 * Defines base service.
 * @author M1033511
 *
 */
public interface BaseService {

}
