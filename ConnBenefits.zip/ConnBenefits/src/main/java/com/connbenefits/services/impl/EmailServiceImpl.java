package com.connbenefits.services.impl;

import java.util.Date;

import javax.mail.internet.MimeMessage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.FileSystemResource;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;

import com.connbenefits.common.logger.ExtJourneyLogger;
import com.connbenefits.common.logger.LogFactory;
import com.connbenefits.common.utils.Utils;
import com.connbenefits.domain.CustomerCallback;
import com.connbenefits.domain.Profile;
import com.connbenefits.exception.ServiceException;
import com.connbenefits.services.EmailService;

/**
 * Used for email communication.
 * 
 * @author M1030133
 *
 */
@Service
public class EmailServiceImpl implements EmailService {
	private static final ExtJourneyLogger LOGGER = LogFactory
			.getInstance(EmailServiceImpl.class);

	@Value("#{'${callback.email.from}'}")
	private String emailFrom;

	@Value("#{'${callback.email.subject}'}")
	private String emailSubject;
	
	@Value("#{'${confirmation.email.to}'}")
	private String emailTo;
	
	@Value("#{'${cb.ext.journey.folderpath}'}")
	private String folderPath;
	
	@Autowired
	private JavaMailSender mailSender;

	public void setMailSender(JavaMailSender mailSender) {
		this.mailSender = mailSender;
	}

	/*
	 * Used to send email.
	 * 
	 * @see com.connbenefits.services.EmailService#sendMail(java.lang.String,
	 * java.lang.String, java.lang.String, java.lang.String)
	 */
	@Override
	public void sendMail(String from, String to, String subject, String msg)
			throws ServiceException {
		long startTime = LOGGER.logMethodEntry();
		LOGGER.debug("from: " + from +", to: " + to);
		try {
			MimeMessage message = mailSender.createMimeMessage();
			message.setSubject(subject);
			message.setContent(message,"text/plain");
			message.setContent(message,"multipart/mixed");
			MimeMessageHelper helper;
			helper = new MimeMessageHelper(message, true);
			helper.setFrom(from);
			helper.setTo(to);
			helper.setText(msg, true);
			mailSender.send(message);

			LOGGER.logMethodExit(startTime);
		} catch (Exception e) {
			LOGGER.error("ERROR : " + e.getMessage());
			throw new ServiceException(e.getMessage());
		}
	}
	
	public void sendMailWithAttachment(String from, String to, String subject, String msg, String fileName)
			throws ServiceException {
		long startTime = LOGGER.logMethodEntry();
		LOGGER.debug("from: " + from +", to: " + to);
		try {
			MimeMessage message = mailSender.createMimeMessage();
			message.setSubject(subject);
			message.setContent(message,"text/plain");
			message.setContent(message,"multipart/mixed");
			MimeMessageHelper helper;
			helper = new MimeMessageHelper(message, true);
			helper.setFrom(from);
			helper.setTo(to);
			helper.setText(msg, true);
			FileSystemResource file = new FileSystemResource(fileName);
			helper.addAttachment(file.getFilename(), file);
			mailSender.send(message);

			LOGGER.logMethodExit(startTime);
		} catch (Exception e) {
			LOGGER.error("ERROR : " + e.getMessage());
			throw new ServiceException(e.getMessage());
		}
	}

	/*
	 * used to send email on click of call me back from application.
	 * 
	 * @see
	 * com.connbenefits.services.EmailService#sendCallbackMail(com.connbenefits.domain
	 * .Profile, com.connbenefits.domain.CustomerCallback)
	 */
	@Override
	public void sendCallbackMail(Profile profile,
			CustomerCallback customerCallback) throws ServiceException {
		long startTime = LOGGER.logMethodEntry();
		LOGGER.debug("customerCallback : " + customerCallback);
		try {
			if (customerCallback.getCallbackDate() != null) {
				String formattedDate = Utils.getFormattedDate(customerCallback
						.getCallbackDate());
				String input = profile.getFirstName();
				String output = input.substring(0, 1).toUpperCase() + input.substring(1); //Capitalize first character of the name
				String msg = "Hi "
						+ output
						+ ",<br><br>"
						+ "Thank you for your interest in learning more&nbsp;about the benefits of personal life insurance.<br>"
						+ "This is to remind you that an experienced insurance agent will be calling you on "
						+ formattedDate
						+ " at "
						+ customerCallback.getCallbackTime()
						+ "."
						+ "<br><br>If your plans change or if you need further information&nbsp;please&nbsp;call us toll free at 1-855-764-5433 between 7am - 7pm ET.<br><br>"
						+ "Your friends at,<br>" + "Connected Benefits";

				this.sendMail(this.emailFrom, profile.getEmailAddress(),
						this.emailSubject, msg);
			}
			LOGGER.logMethodExit(startTime);
		} catch (Exception e) {
			LOGGER.error("ERROR: " + e.getMessage());
			throw new ServiceException(e.getMessage());
		}
	}

	@Override
	public void sendConfirmationEmailWithAttachment(int noOfRecords) throws ServiceException {
		try {
			String msg = "Hi,"
						+ "<br><br>"
						+ "Please find the attachment in the email with "+noOfRecords+" records."
						+ "<br><br>"
						+ "Regards,<br>" + "Connected Benefits";
			String subject = noOfRecords+" records for "+Utils.getYesterdayDateWithSuffix();
			String filename= "ConnectedBenefits_DATA_REPORT_"+Utils.getyesterdaysDate(new Date());
			String fileAbsolutePath = folderPath+"\\"+filename+".xls";
			this.sendMailWithAttachment(this.emailFrom, this.emailTo,
						subject, msg, fileAbsolutePath);
			}
			catch (Exception e) {
			LOGGER.error("ERROR: " + e.getMessage());
			throw new ServiceException(e.getMessage());
		}
		
	}

	@Override
	public void sendConfirmationEmailWithoutAttachment()
			throws ServiceException {
		try {
			String msg = "Hi,"
						+ "<br><br>"
						+ "Sorry for there is no attachment in the email for today ."
						+ "<br><br>"
						+ "Regards,<br>" + "Connected Benefits";
			String subject = "No records for "+Utils.getYesterdayDateWithSuffix();
				this.sendMail(this.emailFrom, this.emailTo,
						subject, msg);
			}
			catch (Exception e) {
			LOGGER.error("ERROR: " + e.getMessage());
			throw new ServiceException(e.getMessage());
		}
		
	}
}
