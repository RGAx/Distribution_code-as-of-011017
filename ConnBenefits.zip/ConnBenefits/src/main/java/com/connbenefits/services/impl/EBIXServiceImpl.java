package com.connbenefits.services.impl;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.connbenefits.common.logger.ExtJourneyLogger;
import com.connbenefits.common.logger.LogFactory;
import com.connbenefits.domain.ProfileQuestion;
import com.connbenefits.exception.ServiceException;
import com.connbenefits.services.EBIXService;
import com.connbenefits.ws.service.EBIXWebServiceImpl;

/**
 * This class has been used for implementing the operations such as loading the
 * user question answer, getting the best premium etc.
 * 
 * @author M1033511
 *
 */
@Service
public class EBIXServiceImpl implements EBIXService {
	private static final ExtJourneyLogger logger = LogFactory
			.getInstance(EBIXServiceImpl.class);

	@Autowired
	private EBIXWebServiceImpl ebixWebService;

	/*
	 * Getting the best premium.
	 * 
	 * @see com.asg.selfservice.services.EBIXService#getMonthlyPremium(int)
	 */
	public Map<Integer, Double> getMonthlyPremium(
			ProfileQuestion profileQuestion, List<Integer> faceAmountList)
			throws ServiceException {
		final long startTime = logger.logMethodEntry();
		Map<Integer, Double> faceAmountPremiumMap = null;

		try {
			faceAmountPremiumMap = ebixWebService.getMonthlyPremium(
					profileQuestion, faceAmountList);
		} catch (ServiceException e) {
			logger.error("ERROR : " + e.getMessage());
			throw new ServiceException(e.getMessage());
		}
		logger.logMethodExit(startTime);
		return faceAmountPremiumMap;
	}
}