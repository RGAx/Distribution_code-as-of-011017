package com.connbenefits.services.impl;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import com.connbenefits.common.logger.ExtJourneyLogger;
import com.connbenefits.common.logger.LogFactory;
import com.connbenefits.common.utils.ExcelBuilder;
import com.connbenefits.domain.ExcelReport;
import com.connbenefits.exception.DAOException;
import com.connbenefits.exception.ServiceException;
import com.connbenefits.services.EmailService;
import com.connbenefits.services.ProfileService;
import com.connbenefits.services.ScheduleJob;

/**
 * @author M1029563
 * This class is used to define method implementation of implemented Interface
 */
@Component("syncExcelReportSchedulerJobs")
public class ExcelEmailSchedulerServiceImpl implements ScheduleJob{
	
	private static final ExtJourneyLogger logger = LogFactory.getInstance(ExcelEmailSchedulerServiceImpl.class);
	
	@Autowired
	private ProfileService profileService;
	
	@Autowired
	@Qualifier("excelbuild")
	private ExcelBuilder excelBuilder;
	
	@Autowired
	private HttpSession session;
	
	@Autowired
	private EmailService emailService;
	
	@Override
	public void shedulerexcelReportJob() throws ServiceException, DAOException {
		
		String currentThread = Thread.currentThread().getName();
		
		logger.info("Current Thread"+currentThread+" started Executing");
		
		synchronized (this) {
			
			try{
				List<ExcelReport> userDetailReport = profileService.fetchuserSavedDetails();
				if(userDetailReport!=null && userDetailReport.size()!=0){
					//build excel and send email with attachment 
					excelBuilder.buildExcelDocument(userDetailReport);
					emailService.sendConfirmationEmailWithAttachment(userDetailReport.size());
					//Update Database 
					List<Integer> profileIds = new ArrayList<Integer>();
					for (ExcelReport report : userDetailReport) {
					   profileIds.add(Integer.parseInt(report.getProfile_id()));
					}
					profileService.updateProfilesWithCBSubmittedStatus(profileIds);
				}else{
					//Send only notification email
					emailService.sendConfirmationEmailWithoutAttachment();
				}
			
				
			}catch(ServiceException e){
				logger.error("ERROR"+e.getMessage());
				throw new DAOException();
			}catch(Exception e){
				logger.error("ERROR"+e.getMessage());
				throw new ServiceException();
			}
		}
		
	}

}
