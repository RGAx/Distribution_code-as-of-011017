package com.connbenefits.services.impl;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.connbenefits.common.logger.ExtJourneyLogger;
import com.connbenefits.common.logger.LogFactory;
import com.connbenefits.dao.QuestionsDAO;
import com.connbenefits.domain.ProfileQuestion;
import com.connbenefits.domain.SliderFaceValue;
import com.connbenefits.domain.UserAnswer;
import com.connbenefits.exception.DAOException;
import com.connbenefits.exception.ServiceException;
import com.connbenefits.services.EBIXService;
import com.connbenefits.services.QuestionsService;
import com.connbenefits.services.SliderService;

/**
 * used for implementing the services like loading & updating the userAnswer,
 * updating the profile
 * 
 * @author m1033511
 */
@Service
public class QuestionsServiceImpl implements QuestionsService {

	private static final ExtJourneyLogger LOGGER = LogFactory.getInstance(QuestionsServiceImpl.class);
	
	@Autowired
	private QuestionsDAO questionsDao;

	@Autowired
	private EBIXService ebixService;

	@Autowired
	private SliderService sliderService;
	
	@Autowired
	private HttpSession session;
	
	@Value("#{'${ebix.service.band.values}'.split(',')}")
	private List<Integer> bandAmounts;
	
	@Value("#{'${ebix.principal.band.values}'.split(',')}")
	private List<Integer> principalBandAmounts;

	/*
	 * used for saving/updating the profile in database
	 * 
	 * @see
	 * com.connbenefits.services.QuestionsService#saveUpdateUserAnswer(com.connbenefits
	 * .domain.ProfileQuestion)
	 */
	@Override
	public int saveUpdateUserAnswer(ProfileQuestion ProfileQuestion,
			boolean flag) throws ServiceException {
		try {
			return questionsDao.saveUpdateUserAnswer(ProfileQuestion, flag);
		} catch (DAOException e) {
			throw new ServiceException(e.getMessage());
		}
	}

	/*
	 * used for saving/updating the profile in database
	 * 
	 * @see
	 * com.connbenefits.services.QuestionsService#loadUserAnswer(com.connbenefits.domain
	 * .ProfileQuestion)
	 */
	@Override
	public UserAnswer loadUserAnswer(int profileId) throws ServiceException {
		try {
			return questionsDao.loadUserAnswer(profileId);
		} catch (DAOException e) {
			throw new ServiceException(e.getMessage());
		}
	}

	/*
	 * Used to validate for all the premiums if we r getting premium value or
	 * not.
	 * 
	 * @see
	 * com.connbenefits.services.QuestionsService#validateEbixPremiums(com.connbenefits
	 * .domain.ProfileQuestion)
	 */
	@Override
	public boolean validateFaceValuesWithEBIX(ProfileQuestion profileQuestion)
			throws ServiceException {
		long startTime = LOGGER.logMethodEntry();
		int dependentsCount = profileQuestion.getUserAnswer().getDependentsCount();
		LOGGER.info("DependentsCount ::"+dependentsCount);
		session.setAttribute("dependentsCount", dependentsCount);
		
		if(profileQuestion.getProfile().getSource().equalsIgnoreCase("")) {			
			LOGGER.debug("bandAmounts: " + bandAmounts);
			
			try {
				Map<Integer, Double> premiumMap = ebixService.getMonthlyPremium(
						profileQuestion, bandAmounts);
				LOGGER.debug("premiumMap: " + premiumMap);
				
				SliderFaceValue sliderFaceValue = sliderService.loadSliderPage();
				LOGGER.debug("sliderFaceValue: " + sliderFaceValue);
				
				if (sliderFaceValue == null || premiumMap == null
						|| premiumMap.isEmpty()
						|| sliderFaceValue.getLowercoverageRange() <= 0
						|| sliderFaceValue.getUppercoverageRange() <= 0
						|| sliderFaceValue.getRecommCoverageRange() <= 0
						|| sliderFaceValue.getScaleFactor() <= 0) {
					return false;
				}
				for (int i = 0; i < bandAmounts.size(); i++) {
					if(bandAmounts.get(i) != null) {
					int premiumValue = premiumMap.get(bandAmounts.get(i)).intValue();
						if (premiumValue <= 0) {
							return false;
						}
					}
				}
				List<Integer> faceAmountList = sliderService.loadSliderFaceValues(
						sliderFaceValue.getLowercoverageRange(),
						sliderFaceValue.getUppercoverageRange(),
						sliderFaceValue.getRecommCoverageRange(),
						sliderFaceValue.getScaleFactor());
				if(faceAmountList == null || faceAmountList.isEmpty()) {
					return false;
				}
				DecimalFormat decimalFormat = new DecimalFormat("#.00");
				Map<Integer, String> faceValues = new HashMap<Integer, String>();
				
				for (int i = 0; i < faceAmountList.size(); i++) {
					int faceAmount = faceAmountList.get(i);
					LOGGER.debug("faceAmount: " + faceAmount);
					double premiumValue = 0.0;
	
					if (faceAmount >= bandAmounts.get(0)
							&& faceAmount < bandAmounts.get(1)) {
						premiumValue = premiumMap.get(bandAmounts.get(0));
						premiumValue = (premiumValue / bandAmounts.get(0)) * faceAmount;
	
					} else if (faceAmount >= bandAmounts.get(1)
							&& faceAmount < bandAmounts.get(2)) {
						premiumValue = premiumMap.get(bandAmounts.get(1));
						premiumValue = (premiumValue / bandAmounts.get(1)) * faceAmount;
	
					} else if (faceAmount >= bandAmounts.get(2)
							&& faceAmount < bandAmounts.get(3)) {
						premiumValue = premiumMap.get(bandAmounts.get(2));
						premiumValue = (premiumValue / bandAmounts.get(2)) * faceAmount;
	
					} else if (faceAmount >= bandAmounts.get(3)) {
						premiumValue = premiumMap.get(bandAmounts.get(3));
						premiumValue = (premiumValue / bandAmounts.get(3)) * faceAmount;
					}
					LOGGER.debug("premiumValue: " + decimalFormat.format(premiumValue));
					faceValues.put(faceAmount, decimalFormat.format(premiumValue));
				}
				session.setAttribute("sessionFaceValues", faceValues);
			} catch (Exception e) {
				LOGGER.error("ERROR: " + e.getMessage());
				return false;
			}
		} else {
			
			SliderFaceValue sliderFaceValue = sliderService.loadSliderPage();
			LOGGER.debug("sliderFaceValue: " + sliderFaceValue);
			
			/*if (sliderFaceValue == null 
					|| sliderFaceValue.getLowercoverageRange() <= 0
					|| sliderFaceValue.getUppercoverageRange() <= 0
					|| sliderFaceValue.getRecommCoverageRange() <= 0
					|| sliderFaceValue.getScaleFactor() <= 0) {
				return false;
			}*/
			
			List<Integer> faceAmountList = sliderService.loadSliderFaceValues(
					sliderFaceValue.getLowercoverageRange(),
					sliderFaceValue.getUppercoverageRange(),
					sliderFaceValue.getRecommCoverageRange(),
					sliderFaceValue.getScaleFactor());
			if(faceAmountList == null || faceAmountList.isEmpty()) {
				return false;
			}
			
			try {
				Map<Integer, Double> premiumMap = ebixService.getMonthlyPremium(
						profileQuestion, faceAmountList);
				
				LOGGER.debug("premiumMap: " + premiumMap);
				
				DecimalFormat decimalFormat = new DecimalFormat("#.00");
				Map<Integer, String> faceValues = new HashMap<Integer, String>();
				
				for (int i = 0; i < faceAmountList.size(); i++) {
					int faceAmount = faceAmountList.get(i);
					LOGGER.debug("faceAmount: " + faceAmount);
					double premiumValue = premiumMap.get(faceAmountList.get(i));
					LOGGER.debug("premiumValue: " +  decimalFormat.format(premiumValue));
					faceValues.put(faceAmount, decimalFormat.format(premiumValue));
				}
				session.setAttribute("sessionFaceValues", faceValues);
				
			} catch (Exception e) {
				LOGGER.error("ERROR: " + e.getMessage());
				return false;
			}		
		}
		
		LOGGER.logMethodExit(startTime);
		return true;
	}
}