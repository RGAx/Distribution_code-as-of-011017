package com.connbenefits.dao;

import com.connbenefits.domain.ProfileQuestion;
import com.connbenefits.domain.UserAnswer;
import com.connbenefits.exception.DAOException;

/**
 * Used for defining the operations such as loading & updating the userAnswer,
 * updating the profile
 * 
 * @author m1033511
 */
public interface QuestionsDAO {
	public int saveUpdateUserAnswer(ProfileQuestion ProfileQuestion,
			boolean flag) throws DAOException;

	public UserAnswer loadUserAnswer(int profileId) throws DAOException;
}
