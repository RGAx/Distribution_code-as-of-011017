package com.connbenefits.dao;

import java.util.List;

import com.connbenefits.domain.ErrorLog;
import com.connbenefits.domain.ExcelReport;
import com.connbenefits.domain.Profile;
import com.connbenefits.exception.DAOException;

/**
 * Used for defining the opeartions related to profile such as saving, updating,
 * loading etc.
 * 
 * @author M1030133
 *
 */
public interface ProfileDAO {

	public Profile saveProfile(Profile profile) throws DAOException;

	public void updateProfile(Profile profile) throws DAOException;

	public Profile loadProfile(String encryptedId) throws DAOException;

	public void saveErrorLog(ErrorLog errorLog) throws DAOException;
	
	public void updateProfileEbixMonthlyEstimate(Profile profile) throws DAOException;

	public void updateProfileWithPinneyStatus(Profile profile) throws DAOException;

	public void updateProfileWithDetails(Profile profile) throws DAOException;

	public Profile saveProfileWithDetails(Profile profile)throws DAOException;
	
	public List<ExcelReport> fetchuserDetailsForExcelReport() throws DAOException;

	public void updateProfilesWithCBSubmittedStatus(List<Integer> profileIds) throws DAOException;

}
