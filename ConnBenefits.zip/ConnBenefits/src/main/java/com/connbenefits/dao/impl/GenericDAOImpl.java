/**
 * 
 */
package com.connbenefits.dao.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;

import com.connbenefits.common.logger.ExtJourneyLogger;
import com.connbenefits.common.logger.LogFactory;
import com.connbenefits.constants.QueryConstants;
import com.connbenefits.dao.GenericDAO;
import com.connbenefits.domain.MultiplierRateDetails;
import com.connbenefits.exception.DAOException;

/**
 * @author M1029563
 *
 */
public class GenericDAOImpl implements GenericDAO{
	
	private static final ExtJourneyLogger logger = LogFactory.getInstance(GenericDAOImpl.class);
	
	@Autowired
	private JdbcTemplate jdbcTemplate;

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}
	
	/* This method is used to query all the rows as list in the MULTIPLIERRATETABLE from DB and constructs LIST<MULTIPLIERRATEDETAILS>.
	 * @returns multiplierRateDetails
	 * @see com.connbenefits.dao.GenericDAO#loadMultiplierrateDetails()
	 */
	@Override
	public List<MultiplierRateDetails> loadMultiplierrateDetails() throws DAOException {
		
		final long startTime = logger.logMethodEntry();
		
		List<MultiplierRateDetails> multiplierRateDetails = new ArrayList<MultiplierRateDetails>();
		
		List<Map<String,Object>> ratetableRows;
		
		try {
			ratetableRows = jdbcTemplate.queryForList(QueryConstants.LOAD_MULTIPLIER_RATES);
		} catch (DataAccessException e) {
			logger.error("ERROR : " + e.getMessage());
			throw new DAOException(e.getMessage());
		}
		for(Map<String,Object> multiplierrow : ratetableRows){
			
			MultiplierRateDetails multRateDetails= new MultiplierRateDetails();
			
			multRateDetails.setRateId(Integer.parseInt(String.valueOf(multiplierrow.get("RATE_ID"))));
			multRateDetails.setAge(Integer.parseInt(String.valueOf(multiplierrow.get("AGE"))));
			multRateDetails.setRecommendedRange(Integer.parseInt(String.valueOf(multiplierrow.get("ANNUAL_INCOME"))));
			multRateDetails.setProductUsed(String.valueOf(multiplierrow.get("PRODUCT_USED")));
			multRateDetails.setLowerRange(Integer.parseInt(String.valueOf(multiplierrow.get("LOWER_RANGE"))));
			multRateDetails.setUpperRange(Integer.parseInt(String.valueOf(multiplierrow.get("UPPER_RANGE"))));
			multRateDetails.setScaleFactor(Integer.parseInt(String.valueOf(multiplierrow.get("SCALE_FACTOR"))));
			multRateDetails.setStatusFlag(Integer.parseInt(String.valueOf(multiplierrow.get("STATUS_FLAG"))));
			
			multiplierRateDetails.add(multRateDetails);
		}
		
		logger.logMethodExit(startTime);
		
		return multiplierRateDetails;
	}

}
