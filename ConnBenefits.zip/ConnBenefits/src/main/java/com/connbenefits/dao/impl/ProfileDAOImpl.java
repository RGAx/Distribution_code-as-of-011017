package com.connbenefits.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.springframework.dao.DataAccessException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCreator;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import com.connbenefits.common.logger.ExtJourneyLogger;
import com.connbenefits.common.logger.LogFactory;
import com.connbenefits.common.utils.Utils;
import com.connbenefits.constants.QueryConstants;
import com.connbenefits.dao.ProfileDAO;
import com.connbenefits.domain.ErrorLog;
import com.connbenefits.domain.ExcelReport;
import com.connbenefits.domain.Profile;
import com.connbenefits.exception.DAOException;

/**
 * Used for implementing the profile opeartions such as saving /
 * updating/loading the profile etc.
 * 
 * @author M1030133
 *
 */
@Repository
public class ProfileDAOImpl implements ProfileDAO {

	private static final ExtJourneyLogger LOGGER = LogFactory
			.getInstance(ProfileDAOImpl.class);

	private JdbcTemplate jdbcTemplate;

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	private static final String RESTAPI = "REST API";

	/*
	 * This method has been used for saving the profile into the DB.
	 * 
	 * @see com.connbenefits.dao.ProfileDAO#saveProfile(com.connbenefits.domain.Profile)
	 */
	@Override
	public Profile saveProfile(Profile profile) throws DAOException {
		final long startTime = LOGGER.logMethodEntry();
		int out = 0;
		try {
			Object[] args = new Object[] { profile.getEncryptedId(),
					(profile.getFirstName() != null ? profile.getFirstName():""), profile.getLastName(),
					profile.getGender(), new java.sql.Timestamp(profile.getDateOfBirth().getTime()),
					profile.getPhoneNumber(), profile.getZipCode(),
					profile.getState(), profile.getCity(),
					(profile.getEmailAddress() != null ? profile.getEmailAddress():""), profile.getAnnualIncome(),
					0,
					profile.getEbixMonthlyEstimate(), profile.getCoverage(),
					20, profile.getLastPinneyProcessedDate() != null ? new java.sql.Timestamp(profile.getLastPinneyProcessedDate().getTime()) : "",
					"AUTO", new java.sql.Timestamp(new Date().getTime()), new java.sql.Timestamp(new Date().getTime()) ,profile.getSource()};
			out = jdbcTemplate.update(QueryConstants.SAVE_PROFILE, args);
		} catch (DataAccessException e) {
			LOGGER.error("ERROR : " + e.getMessage());
			throw new DAOException(e.getMessage());
		}

		if (out != 0) {
			LOGGER.info("User profile with password updated with id="
					+ profile.getProfileId());
		} else {
			LOGGER.info("No user found with id=" + profile.getProfileId());
		}
		LOGGER.logMethodExit(startTime);
		return null;
	}

	/*
	 * This method has been used to update the profile fields in the db.
	 * 
	 * @see com.connbenefits.dao.ProfileDAO#updateProfile(com.connbenefits.domain.Profile)
	 */
	@Override
	public void updateProfile(Profile profile) throws DAOException {
		try {
			Object[] args = new Object[] { profile.getDateOfBirth(),
					profile.getGender(), profile.getZipCode(),
					profile.getAnnualIncome(),profile.getState(),profile.getProfileId() };
			jdbcTemplate.update(QueryConstants.UPDATE_PROFILE_QUESTIONS, args);
		} catch (DataAccessException e) {
			LOGGER.error("ERROR : " + e.getMessage());
			throw new DAOException(e.getMessage());
		}
	}

	/*
	 * This method has been used for loading the profile details from the db.
	 * 
	 * @see com.connbenefits.dao.ProfileDAO#loadProfile(java.lang.String)
	 */
	@Override
	public Profile loadProfile(String encryptedId) throws DAOException {
		final long startTime = LOGGER.logMethodEntry();
		Profile profile;
		try {
			profile = jdbcTemplate.queryForObject(QueryConstants.LOAD_PROFILE,
					new Object[] { encryptedId }, new RowMapper<Profile>() {

						public Profile mapRow(ResultSet rs, int rowNum)
								throws SQLException {
							Profile profile = new Profile();
							profile.setProfileId(rs.getInt("PROFILE_ID"));
							profile.setEncryptedId(rs.getString("ENCRYPTED_ID"));

							profile.setFirstName(rs.getString("FIRST_NAME"));
							profile.setLastName(rs.getString("LAST_NAME"));
							profile.setGender(rs.getString("GENDER"));
							profile.setDateOfBirth(rs.getDate("DATE_OF_BIRTH"));

							profile.setPhoneNumber(rs.getString("PHONE_NUMBER"));
							profile.setZipCode(rs.getString("ZIP_CODE"));
							profile.setState(rs.getString("STATE"));
							profile.setCity(rs.getString("CITY"));
							profile.setEmailAddress(rs
									.getString("EMAIL_ADDRESS"));

							profile.setAnnualIncome(rs.getLong("ANNUAL_INCOME"));
							profile.setPinneyStatusFlag(rs
									.getInt("PINNEY_STATUS_FLAG"));
							profile.setEbixMonthlyEstimate(rs
									.getString("EBIX_MONTHLY_ESTIMATE"));
							profile.setCoverage(rs.getLong("COVERAGE"));
							profile.setTerm(rs.getInt("TERM"));
							
							profile.setLastPinneyProcessedDate(rs
									.getTimestamp("LAST_PINNEY_PROCESSED_DATE"));
							profile.setSource(rs.getString("SOURCE"));
							profile.setCreatedBy(rs.getString("CREATED_BY"));
							profile.setCreatedDate(rs.getDate("CREATED_DATE"));
							profile.setUpdatedBy(rs.getString("UPDATED_BY"));
							profile.setUpdatedDate(rs.getDate("UPDATED_DATE"));
							

							return profile;
						}
					});
		} catch (EmptyResultDataAccessException e) {
			LOGGER.error("ERROR : " + e.getMessage());
			return null;
		} catch (DataAccessException e) {
			LOGGER.error("ERROR : " + e.getMessage());
			throw new DAOException(e.getMessage());
		}
		LOGGER.logMethodExit(startTime);
		return profile;
	}

	/*
	 * This method has been for saving the bad records into the db.
	 * 
	 * @see com.connbenefits.dao.ProfileDAO#saveErrorLog(com.connbenefits.domain.ErrorLog)
	 */
	@Override
	public void saveErrorLog(ErrorLog errorLog) throws DAOException {
		final long startTime = LOGGER.logMethodEntry();
		int out = 0;
		try {
			Object[] args = new Object[] { errorLog.getFirstName(),
					errorLog.getLastName(), errorLog.getGender(),
					errorLog.getDateOfBirth(), errorLog.getPhoneNumber(),
					errorLog.getZipCode(), errorLog.getState(),
					errorLog.getCity(), errorLog.getEmailAddress(),
					errorLog.getAnnualIncome(), RESTAPI,
					errorLog.getErrorCode(), errorLog.getErrorMessage(),
					new java.sql.Date(new Date().getTime()), null };
			out = jdbcTemplate.update(QueryConstants.SAVE_ERROR_LOG, args);
		} catch (DataAccessException e) {
			LOGGER.error("ERROR : " + e.getMessage());
			throw new DAOException(e.getMessage());
		}

		if (out != 0) {
			LOGGER.info("Profile updated with id=" + errorLog.getProfileId());
		} else {
			LOGGER.info("No profile found with id=" + errorLog.getProfileId());
		}
		LOGGER.logMethodExit(startTime);
	}

	/*
	 * (non-Javadoc) This method is used for updating the COVERAGE and
	 * EBIXMONTHLYESTIMATE COLUMNS in the PROFILE table for the respective
	 * PROFILE_ID
	 * 
	 * @see
	 * com.connbenefits.dao.ProfileDAO#updateProfileEbixMonthlyEstimate(com.connbenefits
	 * .domain.Profile)
	 */
	@Override
	public void updateProfileEbixMonthlyEstimate(Profile profile)
			throws DAOException {
		final long startTime = LOGGER.logMethodEntry();
		int out = 0;
		try {
			Object[] args = new Object[] { profile.getCoverage(),
					profile.getEbixMonthlyEstimate(), profile.getFirstName(),
					new java.sql.Timestamp(new Date().getTime()),
					profile.getProfileId() };
			out = jdbcTemplate.update(
					QueryConstants.UPDATE_COVERAGE_AND_EBIXMONTHLY_ESTIMATE,
					args);
		} catch (DataAccessException e) {
			LOGGER.error("ERROR : " + e.getMessage());
			throw new DAOException(e.getMessage());
		}
		if (out != 0) {
			LOGGER.info("Profile updated with id=" + profile.getProfileId());
		} else {
			LOGGER.info("No profile found with id=" + profile.getProfileId());
		}
		LOGGER.logMethodExit(startTime);
	}

	/*
	 * used for updating the pinney status into profile.
	 * 
	 * @see
	 * com.connbenefits.dao.ProfileDAO#updateProfileWithPinneyStatus(com.connbenefits.
	 * domain.Profile)
	 */
	@Override
	public void updateProfileWithPinneyStatus(Profile profile)
			throws DAOException {
		final long startTime = LOGGER.logMethodEntry();
		int out = 0;
		try {
			Object[] args = new Object[] { profile.getPinneyStatusFlag(),
					new java.sql.Timestamp(new Date().getTime()),
					profile.getFirstName(),
					new java.sql.Timestamp(new Date().getTime()),
					profile.getProfileId() };
			out = jdbcTemplate
					.update(QueryConstants.UPDATE_PINNEY_STATUS, args);
		} catch (DataAccessException e) {
			LOGGER.error("ERROR : " + e.getMessage());
			throw new DAOException(e.getMessage());
		}
		if (out != 0) {
			LOGGER.info("Profile updated with id=" + profile.getProfileId());
		} else {
			LOGGER.info("No profile found with id=" + profile.getProfileId());
		}
		LOGGER.logMethodExit(startTime);
	}
	
/*	Used to update the Profile details from Call back page when profile is available in the 
 * session
 * 
 * (non-Javadoc)
 * @see com.connbenefits.dao.ProfileDAO#updateProfileWithDetails(com.connbenefits.domain.Profile)
 */
	@Override
	public void updateProfileWithDetails(Profile profile) throws DAOException {
		String phoneNumber = profile.getPhoneNumber();
		String newPhoneNumber = phoneNumber.replaceAll("[^\\d.]", "");
		profile.setPhoneNumber(newPhoneNumber);
		try {
			Object[] args = new Object[] { profile.getFirstName(),
					profile.getLastName(), profile.getEmailAddress(),profile.getFirstName(),new java.sql.Date(new Date().getTime()),
					profile.getPhoneNumber(),profile.getProfileId() };
			jdbcTemplate.update(QueryConstants.UPDATE_PROFILE_DETAILS, args);
			LOGGER.info("User Profile details updated Successfully");
		} catch (DataAccessException e) {
			LOGGER.error("ERROR : " + e.getMessage());
			throw new DAOException(e.getMessage());
		}
		
	}
	
	/**
	 * Used to insert the profile details from the call Back page when Profile is not available in
	 * the session
	 */
	@Override
	public Profile saveProfileWithDetails(final Profile profile) throws DAOException {
		final long startTime = LOGGER.logMethodEntry();
		String phoneNumber = profile.getPhoneNumber();
		String newPhoneNumber = phoneNumber.replaceAll("[^\\d.]", "");
		profile.setPhoneNumber(newPhoneNumber);
		int out = 0;
		try {
			String encryptedId = Utils.encryptID(profile.getEmailAddress()
					+ System.currentTimeMillis());
			profile.setEncryptedId(encryptedId);
			KeyHolder keyHolder = new GeneratedKeyHolder();
			jdbcTemplate.update(new PreparedStatementCreator()
		    {
		        public PreparedStatement createPreparedStatement(Connection connection) throws SQLException
		        {
		            PreparedStatement ps = connection.prepareStatement(QueryConstants.SAVE_PROFILE_DETAILS, PreparedStatement.RETURN_GENERATED_KEYS);
		            ps.setString(1, profile.getFirstName());
		            ps.setString(2, profile.getLastName());
		            ps.setString(3, profile.getEmailAddress());
		            ps.setDate(4, new java.sql.Date(new Date().getTime()));
		            ps.setString(5, profile.getEncryptedId());
		            ps.setString(6, profile.getPhoneNumber());
		            ps.setString(7, profile.getFirstName());
		            ps.setString(8, profile.getSource());
		            
		            return ps;
		        }
		    },keyHolder);
			
			out = keyHolder.getKey().intValue();
		} catch (DataAccessException e) {
			LOGGER.error("ERROR : " + e.getMessage());
			throw new DAOException(e.getMessage());
		}

		if (out != 0) {
			LOGGER.info("User profile details inserted with id="
					+ profile.getProfileId());
		} else {
			LOGGER.info("No user found with id=" + profile.getProfileId());
		}
		profile.setProfileId(out);
		LOGGER.logMethodExit(startTime);
		return profile;
	}
	/*
	 * Used to fetch the List<ExcelReport> from the tables CUSTOMER_CALLBACK,PROFILE,USER_ANSWER by joining all the tables
	 * the session
	 * (non-Javadoc)
	 * @see com.connbenefits.dao.ProfileDAO#fetchuserDetailsForExcelReport()
	 */
	@Override
	public List<ExcelReport> fetchuserDetailsForExcelReport()
			throws DAOException {
		final long startTime = LOGGER.logMethodEntry();
		
		List<ExcelReport> usersavedReport=new ArrayList<ExcelReport>();
		try{
			List<Map<String, Object>> userDataRows = jdbcTemplate.queryForList(QueryConstants.GET_EXCEL_REPORT);
			
			for(Map<String,Object> userData:userDataRows){
				
				ExcelReport excelReport = new ExcelReport();
				
				excelReport.setProfile_id(String.valueOf(userData.get("PROFILE_ID")));
				excelReport.setFirstName(String.valueOf(userData.get("FIRST_NAME")));
				excelReport.setLastName(String.valueOf(userData.get("LAST_NAME")));
				excelReport.setEmailAddress((String.valueOf(userData.get("EMAIL_ADDRESS"))));
				excelReport.setPhoneNumber(String.valueOf(userData.get("PHONE_NUMBER")));
				excelReport.setDateofBirth(String.valueOf(userData.get("DATE_OF_BIRTH")));
				excelReport.setGender(String.valueOf(userData.get("GENDER")));
				excelReport.setState(String.valueOf(userData.get("STATE")));
				excelReport.setAnnualIncome(String.valueOf(userData.get("ANNUAL_INCOME")));
				excelReport.setSmokingStatus(String.valueOf(userData.get("SMOKING_STATUS")));
				excelReport.setDependentsStatus(String.valueOf(userData.get("DEPENDENTS_STATUS")));
				excelReport.setDependentsCount(String.valueOf(userData.get("DEPENDENTS_COUNT")));
				excelReport.setHealthStatus(String.valueOf(userData.get("HEALTH_STATUS")));
				excelReport.setCoverage(String.valueOf(userData.get("COVERAGE")));
				excelReport.setTerm(String.valueOf(userData.get("TERM")));		
				excelReport.setEbix_monthlyEstimate(String.valueOf(userData.get("EBIX_MONTHLY_ESTIMATE")));		
				excelReport.setLastpinneyProcessedDate(String.valueOf(userData.get("LAST_PINNEY_PROCESSED_DATE")));
				excelReport.setSource(String.valueOf(userData.get("SOURCE")));
				excelReport.setCallbackDate(String.valueOf(userData.get("CALLBACK_DATE")));
				excelReport.setCallbackTime(String.valueOf(userData.get("CALLBACK_TIME")));
				
										
				usersavedReport.add(excelReport);
			}
		}catch(DataAccessException e){
			LOGGER.error("ERROR:"+e.getMessage());
			throw new DAOException();
		}
		LOGGER.logMethodExit(startTime);
       
		return usersavedReport;
	}

	@Override
	public void updateProfilesWithCBSubmittedStatus(List<Integer> profileIds)
			throws DAOException {
		try {
			StringBuilder items = new StringBuilder();
			for(int i: profileIds){
				items.append(","+i);
			}
			items.deleteCharAt(0);
			String query = QueryConstants.UPDATE_CB_SUBMITTED_STATUS+"("+items+")";
			jdbcTemplate.update(query);
		} catch (DataAccessException e) {
			LOGGER.error("ERROR : " + e.getMessage());
			throw new DAOException(e.getMessage());
		}
	}
}
