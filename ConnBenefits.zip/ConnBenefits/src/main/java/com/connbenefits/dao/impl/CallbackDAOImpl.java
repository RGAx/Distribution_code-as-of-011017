package com.connbenefits.dao.impl;

import java.util.Date;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.connbenefits.common.logger.ExtJourneyLogger;
import com.connbenefits.common.logger.LogFactory;
import com.connbenefits.constants.QueryConstants;
import com.connbenefits.dao.CallbackDAO;
import com.connbenefits.domain.CustomerCallback;
import com.connbenefits.domain.Profile;
import com.connbenefits.domain.ProfileCustomerCallback;
import com.connbenefits.exception.DAOException;

/**
 * used for implementing the dao like inserting the ProfileCustomerCallback into the db 
 * 
 * @author m1033511
 */
@Repository
public class CallbackDAOImpl implements CallbackDAO {

	private static final ExtJourneyLogger logger = LogFactory
			.getInstance(CallbackDAOImpl.class);
	
	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}
	/*
	 * implemented for saving the ProfileCustomerCallback in database
	 * 
	 * @see
	 * com.connbenefits.services.CallbackDAO#saveCallbackDetails(com.connbenefits
	 * .domain.ProfileCustomerCallback)
	 */
	@Override
	public int saveCallbackDetails(ProfileCustomerCallback profileCustomerCallback,Profile profile) throws DAOException {
		
		CustomerCallback customerCallback = profileCustomerCallback.getCustomerCallback();
		int count = 0;
			//replacing braces and hyphens and setting to customerPhoneNumber 
			String phoneNumber = profile.getPhoneNumber();
			String newPhoneNumber = phoneNumber.replaceAll("[^\\d.]", "");
			customerCallback.setPhoneNumber(newPhoneNumber);
			
			try{
				Object[] args = new Object[]{profile.getProfileId(),customerCallback.getPhoneNumber(),
						customerCallback.getCallbackDate(),customerCallback.getCallbackTime(),
						new java.sql.Timestamp(new Date().getTime()),profile.getFirstName()};
				count = jdbcTemplate.update(QueryConstants.SAVE_CUSTOMER_CALLBACK, args);
			}catch(DataAccessException e){
				logger.error("ERROR : "+e.getMessage());
				e.printStackTrace();				
			}
		return count;
	}

}
