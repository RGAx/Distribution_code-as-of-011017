package com.connbenefits.domain.pinney;

/**
 * Used for pinney request construction
 * 
 * @author M1030133
 *
 */
public class Policy_details {
	private long face_amount;
	private double monthly_premium;
	private String premium_mode_name;
	private int carrier_id;
	private String carrier_name;
	private String category_name;

	public long getFace_amount() {
		return face_amount;
	}

	public void setFace_amount(long face_amount) {
		this.face_amount = face_amount;
	}

	public double getMonthly_premium() {
		return monthly_premium;
	}

	public void setMonthly_premium(double monthly_premium) {
		this.monthly_premium = monthly_premium;
	}

	public String getPremium_mode_name() {
		return premium_mode_name;
	}

	public void setPremium_mode_name(String premium_mode_name) {
		this.premium_mode_name = premium_mode_name;
	}

	public int getCarrier_id() {
		return carrier_id;
	}

	public void setCarrier_id(int carrier_id) {
		this.carrier_id = carrier_id;
	}

	public String getCarrier_name() {
		return carrier_name;
	}

	public void setCarrier_name(String carrier_name) {
		this.carrier_name = carrier_name;
	}

	public String getCategory_name() {
		return category_name;
	}

	public void setCategory_name(String category_name) {
		this.category_name = category_name;
	}

}
