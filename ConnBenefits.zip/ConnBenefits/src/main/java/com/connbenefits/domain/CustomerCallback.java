package com.connbenefits.domain;

import java.io.Serializable;
import java.util.Date;

public class CustomerCallback implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -7005991947534255248L;
	
	private int custCallbackId;
	private int profileId;
	private String phoneNumber;
	private Date callbackDate;
	private String callbackTime;
	private Date createdDate;
	private String createdBy;
	private Date updatedDate;
	private String updatedBy;
	
	//setters and getters
	public int getCustCallbackId() {
		return custCallbackId;
	}
	public void setCustCallbackId(int custCallbackId) {
		this.custCallbackId = custCallbackId;
	}
	public int getProfileId() {
		return profileId;
	}
	public void setProfileId(int profileId) {
		this.profileId = profileId;
	}
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public Date getCallbackDate() {
		return callbackDate;
	}
	public void setCallbackDate(Date callbackDate) {
		this.callbackDate = callbackDate;
	}
	public String getCallbackTime() {
		return callbackTime;
	}
	public void setCallbackTime(String callbackTime) {
		this.callbackTime = callbackTime;
	}
	public Date getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public Date getUpdatedDate() {
		return updatedDate;
	}
	public void setUpdatedDate(Date updatedDate) {
		this.updatedDate = updatedDate;
	}
	public String getUpdatedBy() {
		return updatedBy;
	}
	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
}
