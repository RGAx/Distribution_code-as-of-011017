package com.connbenefits.domain.pinney;

import java.util.List;

import com.connbenefits.domain.pinney.NotesAttribute;

/**
 * Used for pinney request construction
 * 
 * @author M1030133
 *
 */
public class Policies {
	private long face_amount;
	private Policy_details quoted_details_attributes;
	private List<NotesAttribute> notes_attributes;

	public long getFace_amount() {
		return face_amount;
	}

	public void setFace_amount(long face_amount) {
		this.face_amount = face_amount;
	}

	public Policy_details getQuoted_details_attributes() {
		return quoted_details_attributes;
	}

	public void setQuoted_details_attributes(
			Policy_details quoted_details_attributes) {
		this.quoted_details_attributes = quoted_details_attributes;
	}

	public List<NotesAttribute> getNotes_attributes() {
		return notes_attributes;
	}

	public void setNotes_attributes(List<NotesAttribute> notes_attributes) {
		this.notes_attributes = notes_attributes;
	}

}
