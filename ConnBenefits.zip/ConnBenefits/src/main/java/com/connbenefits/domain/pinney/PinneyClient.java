package com.connbenefits.domain.pinney;

/**
 * Used for pinney request construction
 * 
 * @author M1030133
 *
 */
public class PinneyClient {

	private Client crm_connection;
	private String response;

	public Client getCrm_connection() {
		return crm_connection;
	}

	public void setCrm_connection(Client crm_connection) {
		this.crm_connection = crm_connection;
	}

	public String getResponse() {
		return response;
	}

	public void setResponse(String response) {
		this.response = response;
	}
}
