package com.connbenefits.domain.rest;

/**
 * Defines connection details
 * 
 * @author M1030133
 *
 */
public class UserProfile {
	private BasicInfo basicInfo; // Represents basic info details
	private ContactInfo contactInfo; // Represents contact details
	private IncomeInfo incomeInfo; // Represents income attributes
	private int profileId;

	public BasicInfo getBasicInfo() {
		return basicInfo;
	}

	public void setBasicInfo(BasicInfo basicInfo) {
		this.basicInfo = basicInfo;
	}

	public ContactInfo getContactInfo() {
		return contactInfo;
	}

	public void setContactInfo(ContactInfo contactInfo) {
		this.contactInfo = contactInfo;
	}

	public IncomeInfo getIncomeInfo() {
		return incomeInfo;
	}

	public void setIncomeInfo(IncomeInfo incomeInfo) {
		this.incomeInfo = incomeInfo;
	}

	public int getProfileId() {
		return profileId;
	}

	public void setProfileId(int profileId) {
		this.profileId = profileId;
	}

	@Override
	public String toString() {
		return "UserProfile [basicInfo=" + basicInfo + ", contactInfo="
				+ contactInfo + ", incomeInfo=" + incomeInfo + ", profileId="
				+ profileId + "]";
	}

}
