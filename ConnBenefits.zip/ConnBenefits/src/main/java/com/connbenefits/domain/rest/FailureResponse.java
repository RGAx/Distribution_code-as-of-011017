package com.connbenefits.domain.rest;

public class FailureResponse {
	private String status;
	private ErrorDetails error;
	private Payload payload;

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Payload getPayload() {
		return payload;
	}

	public void setPayload(Payload payload) {
		this.payload = payload;
	}

	public ErrorDetails getError() {
		return error;
	}

	public void setError(ErrorDetails error) {
		this.error = error;
	}

	public FailureResponse(String status, Payload payload, ErrorDetails error) {
		super();
		this.status = status;
		this.payload = payload;
		this.error = error;
	}

}
