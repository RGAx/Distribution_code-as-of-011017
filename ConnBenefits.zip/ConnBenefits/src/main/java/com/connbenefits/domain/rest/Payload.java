package com.connbenefits.domain.rest;

public class Payload {
	private String url;
	private ExtJourney inputData;

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public ExtJourney getInputData() {
		return inputData;
	}

	public void setInputData(ExtJourney inputData) {
		this.inputData = inputData;
	}

	public Payload(String url, ExtJourney inputData) {
		super();
		this.url = url;
		this.inputData = inputData;
	}

}
