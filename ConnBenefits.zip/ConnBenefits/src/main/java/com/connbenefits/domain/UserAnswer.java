package com.connbenefits.domain;

import java.io.Serializable;

/**
 * Defines the UserAnswer fields
 * 
 * @author m1033511
 */
public class UserAnswer extends BaseDomain implements Serializable{
	

	private static final long serialVersionUID = -7822178093908862928L;
	
	private int userAnswerId;//Represents user answer id
	private int profileId;//Represents profile id 
	
	private int smokingStatus;// Represents user smoking status
	private int dependentsStatus;// Represents user have any dependents
	private int dependentsCount;// Represents how many dependents user have 
	private String healthStatus;// Represents user health status 
	
	//getters and setters
	public int getUserAnswerId() {
		return userAnswerId;
	}
	public int getProfileId() {
		return profileId;
	}
	public int getSmokingStatus() {
		return smokingStatus;
	}
	public int getDependentsStatus() {
		return dependentsStatus;
	}
	public int getDependentsCount() {
		return dependentsCount;
	}
	public String getHealthStatus() {
		return healthStatus;
	}
	public void setUserAnswerId(int userAnswerId) {
		this.userAnswerId = userAnswerId;
	}
	public void setProfileId(int profileId) {
		this.profileId = profileId;
	}
	public void setSmokingStatus(int smokingStatus) {
		this.smokingStatus = smokingStatus;
	}
	public void setDependentsStatus(int dependentsStatus) {
		this.dependentsStatus = dependentsStatus;
	}
	public void setDependentsCount(int dependentsCount) {
		this.dependentsCount = dependentsCount;
	}
	public void setHealthStatus(String healthStatus) {
		this.healthStatus = healthStatus;
	}
	
}
