package com.connbenefits.domain;

/**
 * This class is used as Domain class to fecth the details of excel report from DB.
 * @author M1029563
 * 
 */
public class ExcelReport {
	
	private String profile_id;	
	private String firstName;	
	private String lastName;	
	private String ebix_monthlyEstimate;
	private String source;
	private String coverage;
	private String annualIncome;
	private String lastpinneyProcessedDate;
	private String phoneNumber;
	private String callbackDate;
	private String callbackTime;
	private String smokingStatus;
	private String dependentsStatus;
	private String dependentsCount;
	private String healthStatus;
	private String emailAddress;
	private String dateofBirth;
	private String gender;
	private String state;
	private String term;
	
	public String getProfile_id() {
		return profile_id;
	}
	public void setProfile_id(String profile_id) {
		this.profile_id = profile_id;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getEbix_monthlyEstimate() {
		return ebix_monthlyEstimate;
	}
	public void setEbix_monthlyEstimate(String ebix_monthlyEstimate) {
		this.ebix_monthlyEstimate = ebix_monthlyEstimate;
	}
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public String getCoverage() {
		return coverage;
	}
	public void setCoverage(String coverage) {
		this.coverage = coverage;
	}
	public String getAnnualIncome() {
		return annualIncome;
	}
	public void setAnnualIncome(String annualIncome) {
		this.annualIncome = annualIncome;
	}
	public String getLastpinneyProcessedDate() {
		return lastpinneyProcessedDate;
	}
	public void setLastpinneyProcessedDate(String lastpinneyProcessedDate) {
		this.lastpinneyProcessedDate = lastpinneyProcessedDate;
	}
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public String getCallbackDate() {
		return callbackDate;
	}
	public void setCallbackDate(String callbackDate) {
		this.callbackDate = callbackDate;
	}
	public String getCallbackTime() {
		return callbackTime;
	}
	public void setCallbackTime(String callbackTime) {
		this.callbackTime = callbackTime;
	}
	public String getSmokingStatus() {
		return smokingStatus;
	}
	public void setSmokingStatus(String smokingStatus) {
		this.smokingStatus = smokingStatus;
	}
	public String getDependentsStatus() {
		return dependentsStatus;
	}
	public void setDependentsStatus(String dependentsStatus) {
		this.dependentsStatus = dependentsStatus;
	}
	public String getDependentsCount() {
		return dependentsCount;
	}
	public void setDependentsCount(String dependentsCount) {
		this.dependentsCount = dependentsCount;
	}
	public String getHealthStatus() {
		return healthStatus;
	}
	public void setHealthStatus(String healthStatus) {
		this.healthStatus = healthStatus;
	}
	
	public String getEmailAddress() {
		return emailAddress;
	}
	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}
	public String getDateofBirth() {
		return dateofBirth;
	}
	public void setDateofBirth(String dateofBirth) {
		this.dateofBirth = dateofBirth;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	
	public String getTerm() {
		return term;
	}
	public void setTerm(String term) {
		this.term = term;
	}
	
	@Override
	public String toString() {
		return "ExcelReport [profile_id=" + profile_id + ", firstName="
				+ firstName + ", lastName=" + lastName
				+ ", ebix_monthlyEstimate=" + ebix_monthlyEstimate
				+ ", source=" + source + ", coverage=" + coverage
				+ ", annualIncome=" + annualIncome
				+ ", lastpinneyProcessedDate=" + lastpinneyProcessedDate
				+ ", phoneNumber=" + phoneNumber + ", callbackDate="
				+ callbackDate + ", callbackTime=" + callbackTime
				+ ", smokingStatus=" + smokingStatus + ", dependentsStatus="
				+ dependentsStatus + ", dependentsCount=" + dependentsCount
				+ ", healthStatus=" + healthStatus + ", emailAddress="
				+ emailAddress + ", dateofBirth=" + dateofBirth + ", gender="
				+ gender + ", state=" + state + ", term=" + term + "]";
	}
	
	

}
