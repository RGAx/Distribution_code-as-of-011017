package com.connbenefits.domain.pinney;

public class Address {
	private int address_type_id;
	private String zip;
	private int state_id;
	private String city;

	public int getAddress_type_id() {
		return address_type_id;
	}

	public void setAddress_type_id(int address_type_id) {
		this.address_type_id = address_type_id;
	}

	public String getZip() {
		return zip;
	}

	public void setZip(String zip) {
		this.zip = zip;
	}

	public int getState_id() {
		return state_id;
	}

	public void setState_id(int state_id) {
		this.state_id = state_id;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

}
