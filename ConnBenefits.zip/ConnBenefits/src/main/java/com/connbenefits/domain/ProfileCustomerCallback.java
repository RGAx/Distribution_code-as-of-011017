package com.connbenefits.domain;

public class ProfileCustomerCallback {

	private Profile profile;
	private CustomerCallback customerCallback;
	public Profile getProfile() {
		return profile;
	}
	public void setProfile(Profile profile) {
		this.profile = profile;
	}
	public CustomerCallback getCustomerCallback() {
		return customerCallback;
	}
	public void setCustomerCallback(CustomerCallback customerCallback) {
		this.customerCallback = customerCallback;
	}
	
	
}
