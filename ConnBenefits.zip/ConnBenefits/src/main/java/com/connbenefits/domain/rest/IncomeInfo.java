package com.connbenefits.domain.rest;

/**
 * Defines the annual income attribute.
 * 
 * @author M1030133
 *
 */
public class IncomeInfo {
	private long annualIncome; // Represents the annual income for user.

	public long getAnnualIncome() {
		return annualIncome;
	}

	public void setAnnualIncome(long annualIncome) {
		this.annualIncome = annualIncome;
	}

	@Override
	public String toString() {
		return "IncomeInfo [annualIncome=" + annualIncome + "]";
	}

}
