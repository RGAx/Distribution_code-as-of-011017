package com.connbenefits.domain.pinney;

/**
 * Used for pinney request construction
 * 
 * @author M1030133
 *
 */
public class Phone {
	private int phone_type_id;
	private String value;

	public int getPhone_type_id() {
		return phone_type_id;
	}

	public void setPhone_type_id(int phone_type_id) {
		this.phone_type_id = phone_type_id;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}
}
