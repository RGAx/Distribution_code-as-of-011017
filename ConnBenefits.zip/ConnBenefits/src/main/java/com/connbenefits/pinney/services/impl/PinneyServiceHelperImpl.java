package com.connbenefits.pinney.services.impl;

import java.util.Arrays;

import org.apache.commons.codec.binary.Base64;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import com.connbenefits.common.logger.ExtJourneyLogger;
import com.connbenefits.common.logger.LogFactory;
import com.connbenefits.domain.CustomerCallback;
import com.connbenefits.domain.Profile;
import com.connbenefits.domain.UserAnswer;
import com.connbenefits.exception.ServiceException;
import com.connbenefits.services.ProfileService;

/**
 * This class has been used for the operations such as constructing the pinney
 * request and execute the pinney request to get the json response object.
 * 
 * @author M1030133
 *
 */
@Service
public class PinneyServiceHelperImpl {
	
	private final static ExtJourneyLogger LOGGER = LogFactory.getInstance(PinneyServiceHelperImpl.class);

	@Autowired
	private PinneyRequestProcessor pinneyRequestProcessor;

	@Autowired
	private ProfileService profileService;

	private RestTemplate restTemplate = new RestTemplate();

	@Value("${pinney.connection.url}")
	private String pinneyConnectionURL;

	@Value("${pinney.profile.username}")
	private String pinneyProfileUsername;

	@Value("${pinney.profile.password}")
	private String pinneyProfilePassword;
	
	/*
	 * This method has been used for constructing the pinney request by using the profile details.
	 */
	public boolean pinneyRequest(Profile profile, CustomerCallback customerCallback) throws Exception {
		final long startTime = LOGGER.logMethodEntry();
		try {
			UserAnswer userAnswer = pinneyRequestProcessor.loadUserAnswer(profile);
			if(userAnswer == null) {
				userAnswer = new UserAnswer();
			}
			String json = pinneyRequestProcessor.constructJsonRequest(userAnswer, profile, customerCallback);
			LOGGER.debug("PINNEY REQUEST IN JSON: "+ json);
			
			JSONObject response  = executePinneyRequest(json);
			LOGGER.debug("PINNEY RESPONSE IN JSON: "+ response);
			LOGGER.logMethodExit(startTime);
		
			return true;
		} catch (ServiceException e) {
			LOGGER.error("ERROR : " + e.getMessage());
			return false;
		
		} catch (Exception e) {
			LOGGER.error("ERROR : " + e.getMessage());
			return false;
		}
	}

	/*
	 * This method has been for executing the pinney request after taking the
	 * constructed json string.
	 */
	public JSONObject executePinneyRequest(String json) throws Exception {

		HttpHeaders requestHeaders = new HttpHeaders();

		String plainCreds = pinneyProfileUsername + ":" + pinneyProfilePassword;
		byte[] plainCredsBytes = plainCreds.getBytes();
		byte[] base64CredsBytes = Base64.encodeBase64(plainCredsBytes);
		String base64Creds = new String(base64CredsBytes);
		requestHeaders.add("Authorization", "Basic " + base64Creds);

		requestHeaders.setContentType(new MediaType("application", "json"));
		requestHeaders.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));

		HttpEntity<String> requestEntity = new HttpEntity<String>(json,
				requestHeaders);

		JSONObject response;
		try {
			response = restTemplate.postForObject(pinneyConnectionURL,
					requestEntity, JSONObject.class);

		} catch (RestClientException e) {
			throw new Exception(e.getMessage());
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
		return response;
	}

}
