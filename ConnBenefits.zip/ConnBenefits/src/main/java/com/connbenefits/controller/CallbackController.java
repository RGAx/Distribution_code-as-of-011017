package com.connbenefits.controller;

import javax.servlet.http.HttpSession;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.connbenefits.common.logger.ExtJourneyLogger;
import com.connbenefits.common.logger.LogFactory;
import com.connbenefits.constants.ApplicationConstants;
import com.connbenefits.domain.CustomerCallback;
import com.connbenefits.domain.Profile;
import com.connbenefits.domain.ProfileCustomerCallback;
import com.connbenefits.pinney.services.impl.PinneyServiceHelperImpl;
import com.connbenefits.services.CallbackService;
import com.connbenefits.services.EmailService;
import com.connbenefits.services.ProfileService;

/**
 * This controller is used to handle the requests and calls methods to store
 * data in db
 * 
 * @author m1033511
 */
@Controller
public class CallbackController {
	
	private static final ExtJourneyLogger LOGGER = LogFactory.getInstance(CallbackController.class);

	@Autowired
	private HttpSession session;
	
	@Autowired
	private CallbackService callbackService;
	
	@Autowired
	private EmailService emailService;
	
	@Autowired
	private PinneyServiceHelperImpl pinneyService;
	
	@Autowired
	private ProfileService profileService;
	/*
	 * This method is used to get the callbackPage
	 */
	@RequestMapping(value="/"+ApplicationConstants.CALLBACK_PAGE)
	public ModelAndView loadCallbackPage() throws Exception {
		Profile profile  = null;
		
		if(session.getAttribute("sessionProfile") != null){
			profile = (Profile)session.getAttribute("sessionProfile");
		}		
		session.setAttribute(ApplicationConstants.SLIDER_PAGEFROM, ApplicationConstants.CALLBACK_PAGE);
		ModelAndView model = new ModelAndView(ApplicationConstants.CALLBACK_PAGE);
		return callbackService.loadCallbackPage(model, profile);
	}
	/*
	 * This method is used for inserting the values of 
	 * CustomerCallback value in db
	 */
	@RequestMapping(value="/"+ApplicationConstants.CALLBACK_PAGE, method=RequestMethod.POST)
	public String saveCallbackPage(@ModelAttribute("customerCallback") ProfileCustomerCallback profileCustomerCallback,Model model) throws Exception{
		long startTime = LOGGER.logMethodEntry();
		CustomerCallback customerCallback = profileCustomerCallback.getCustomerCallback();
		Profile profile  = null;
		try{
			if(session.getAttribute("sessionProfile") != null){
				profile = (Profile)session.getAttribute("sessionProfile");
			} else {
				return "redirect:"+ApplicationConstants.ERROR+".html";
			}
			//Save profile details
			if(profile.getProfileId()!=0){
				//update DB for existing profileId
				Profile profileDetails = profileCustomerCallback.getProfile();
				profileDetails.setProfileId(profile.getProfileId());
				profileService.updateProfileWithDetails(profileDetails);
				//Update session 
				profile.setFirstName(profileDetails.getFirstName());
				profile.setLastName(profileDetails.getLastName());
				profile.setEmailAddress(profileDetails.getEmailAddress());
				profile.setPhoneNumber(profileDetails.getPhoneNumber());
				/*session.setAttribute("sessionProfile", profile);*/
			}else{
				//Save with new profile Id
				if(StringUtils.isNotEmpty(profile.getSource())){
					profileCustomerCallback.getProfile().setSource(profile.getSource());
				}
				profile = profileService.saveProfileWithDetails(profileCustomerCallback.getProfile());
				//Update Session
				/*session.setAttribute("sessionProfile", profile);*/
				
			}
			callbackService.saveCallbackDetails(profileCustomerCallback,profile);
			if(profile != null) {
				boolean pinneyStatusFlag = pinneyService.pinneyRequest(profile, customerCallback);
				profile.setPinneyStatusFlag(pinneyStatusFlag ? 1 : 2);
				profileService.updateProfileWithPinneyStatus(profile);
				
				emailService.sendCallbackMail(profile, customerCallback);
			}
			if( null != profile.getSource()){
				model.addAttribute("source", profile.getSource());
			}
			session.removeAttribute("sessionProfile");
			session.removeAttribute(ApplicationConstants.PAGE_FROM);
			session.removeAttribute(ApplicationConstants.SLIDER_PAGEFROM);
			session.invalidate();
		}catch(Exception e){
			LOGGER.error("ERROR: " + e.getMessage());
			throw new Exception(e.getMessage());
		}
		LOGGER.logMethodExit(startTime);
		return "redirect:connectPage.html";
	}

	/* This method is used to load the failure page
	 * */
	@RequestMapping("/"+ApplicationConstants.FAILURE_PAGE)
	public ModelAndView loadCallbackPage2() throws Exception {
		
		Profile profile  = null;
		
		if(session.getAttribute("sessionProfile") != null){
			profile = (Profile)session.getAttribute("sessionProfile");
		}		
		
		ModelAndView model = new ModelAndView(ApplicationConstants.FAILURE_PAGE);
		return callbackService.loadCallbackPage(model, profile);
	}
	/* This method is used to load the requestcallbacpPage
	 * */
	@RequestMapping("/"+ApplicationConstants.REQUEST_CALLBACK)
	public ModelAndView loadRequestCallbackPage() throws Exception{
		
		Profile profile  = null;
		
		if(session.getAttribute("sessionProfile") != null){
			profile = (Profile)session.getAttribute("sessionProfile");
		}		
		session.setAttribute(ApplicationConstants.SLIDER_PAGEFROM, ApplicationConstants.CALLBACK_PAGE);
		ModelAndView model = new ModelAndView(ApplicationConstants.REQUEST_CALLBACK);
		return callbackService.loadCallbackPage(model, profile);
	}
	
}
