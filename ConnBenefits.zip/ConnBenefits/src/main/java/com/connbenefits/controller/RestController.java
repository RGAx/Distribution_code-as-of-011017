package com.connbenefits.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.gson.Gson;
import com.connbenefits.common.logger.ExtJourneyLogger;
import com.connbenefits.common.logger.LogFactory;
import com.connbenefits.common.utils.Utils;
import com.connbenefits.constants.ApplicationConstants;
import com.connbenefits.domain.ErrorLog;
import com.connbenefits.domain.Profile;
import com.connbenefits.domain.rest.ErrorDetails;
import com.connbenefits.domain.rest.ExtJourney;
import com.connbenefits.domain.rest.FailureResponse;
import com.connbenefits.domain.rest.Payload;
import com.connbenefits.domain.rest.SuccessResponse;
import com.connbenefits.services.ProfileService;
import com.connbenefits.services.RestService;

/**
 * This is a controller class which has been used for operations such as
 * consuming a json request from Maxwell and loading the data into session.
 * 
 * @author M1030133
 *
 */
@Controller
@RequestMapping("/rest")
public class RestController {
	private static final ExtJourneyLogger LOGGER = LogFactory.getInstance(RestController.class);

	@Autowired
	private HttpSession session;

	@Autowired
	private RestService restService;

	@Autowired
	private ProfileService profileService;
	
	@Value("#{'${ext.journey.response.url}'}")
	private String responseURL;

	/*
	 * This method has been used for consuming the maxwell data and loading into
	 * session.
	 */
	@RequestMapping(value = "/profile.json", method = RequestMethod.POST)
	public @ResponseBody String loadExtJourney(@RequestBody String json)
			throws Exception {
		final long startTime = LOGGER.logMethodEntry();
		ExtJourney extJourney = null;
		try {
			extJourney = new Gson().fromJson(json, ExtJourney.class);
			ErrorDetails dobError = restService.validateDateOfBirth(extJourney);
			if (dobError != null) {
				Payload payload = new Payload("", extJourney);
				return new Gson().toJson(new FailureResponse(
						ApplicationConstants.FAILED_STATUS, payload, dobError));
			}

			Profile profile = restService.loadRestProfile(extJourney);
			ErrorDetails error = restService.validateRestProfile(profile);

			if (error == null) {
				String encryptedId = Utils.encryptID(profile.getEmailAddress()
						+ System.currentTimeMillis());
				profile.setEncryptedId(encryptedId);
				profileService.saveProfile(profile);
				session.setAttribute("sessionProfile", profile);

				Payload payload = new Payload(responseURL + "?token"
								+ encryptedId, extJourney);
				SuccessResponse response = new SuccessResponse(
						ApplicationConstants.SUCCESS_STATUS, payload);

				String jsonResponse = new Gson().toJson(response);
				//jsonResponse = jsonResponse.replace("token", "token=");

				LOGGER.logMethodExit(startTime);
				return jsonResponse;
			} else {
				ErrorLog errorLog = profileService.loadErrorLogFromProfile(
						profile, error);
				try {
					profileService.saveErrorLog(errorLog);
				} catch (Exception e) {
					LOGGER.error("ERROR: " + e.getMessage());
				}

				Payload payload = new Payload("", extJourney);
				error = new ErrorDetails(error.getCode(), error.getMessage());

				LOGGER.logMethodExit(startTime);
				return new Gson().toJson(new FailureResponse(
						ApplicationConstants.FAILED_STATUS, payload, error));
			}
		} catch (Exception e) {
			LOGGER.error("ERROR: " + e.getMessage());
			Payload payload = new Payload("", extJourney);
			ErrorDetails error = new ErrorDetails(
					ApplicationConstants.REQUEST_NOT_VALID_CODE,
					ApplicationConstants.REQUEST_NOT_VALID_MESSAGE);
			return new Gson().toJson(new FailureResponse(
					ApplicationConstants.FAILED_STATUS, payload, error));
		}
	}
}
