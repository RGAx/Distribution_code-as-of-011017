package com.connbenefits.controller;

import javax.servlet.http.HttpSession;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.connbenefits.common.logger.ExtJourneyLogger;
import com.connbenefits.common.logger.LogFactory;
import com.connbenefits.constants.ApplicationConstants;
import com.connbenefits.domain.Profile;
import com.connbenefits.exception.ServiceException;
import com.connbenefits.services.GenericService;
import com.connbenefits.services.ProfileService;

/**
 * This controller has been used for the operations such as loading the landing
 * page, loading the iframe page etc.
 * 
 * @author M1030133
 *
 */
@Controller
public class WelcomeController {
	private static final ExtJourneyLogger LOGGER = LogFactory
			.getInstance(WelcomeController.class);

	@Autowired
	private HttpSession session;

	@Autowired
	private ProfileService profileService;

	@Autowired
	private GenericService genericService;
	
	@Value("${cb.ext.journey.source}")
	private String source_id_cb;
	
	@Value("${cb.ext.journey.source.fpa}")
	private String source_id_fpa;
	
	@Value("${cb.ext.journey.source.suaa}")
	private String source_id_suaa;
	/*
	 * This method has been used for loading the landing page which will take
	 * the token value as an input parameter.
	 */
	@RequestMapping("/landingPage")
	public ModelAndView loadLandingPage(@RequestParam("source") String source)
			throws Exception {
		final long startTime = LOGGER.logMethodEntry();
		Profile profile= null;
		try {	
			if(session.getAttribute(ApplicationConstants.PAGE_FROM) == "questionsPage" 
					&& session.getAttribute("sessionProfile") != null){
				profile = (Profile)session.getAttribute("sessionProfile");
			}else{
				profile = new Profile();
				if(StringUtils.isNotEmpty(source) && (source.equalsIgnoreCase(source_id_cb) || source.equalsIgnoreCase(source_id_fpa)
						|| source.equalsIgnoreCase(source_id_suaa))){
					profile.setSource(source);
				}else{
					return new ModelAndView(ApplicationConstants.SOURCE_ERROR);
				}
			}
			genericService.loadMultiplierrateList();

		} catch (ServiceException e) {
			LOGGER.error("ERROR: " + e.getMessage());
			throw new Exception(e.getMessage());

		} catch (Exception e) {
			LOGGER.error("ERROR: " + e.getMessage());
			throw new Exception(e.getMessage());
		}
			ModelAndView model = new ModelAndView("landingPage");

			session.setAttribute(ApplicationConstants.PAGE_FROM, "landingPage");
			session.setAttribute("sessionProfile", profile);
			
			LOGGER.logMethodExit(startTime);
			
			return model;
		
	}

}
