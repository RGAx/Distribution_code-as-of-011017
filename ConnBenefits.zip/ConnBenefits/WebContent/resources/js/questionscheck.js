   function validate(){
	    
	   var flag=false;
	   var num = /^[0-9]+$/;
	    var dateOfBirth=document.forms["myForm"]["profile.dateOfBirth"];
	    if(dateOfBirth.value == null || dateOfBirth.value == "" || !isValidDOB(dateOfBirth.value)){
	    	dateOfBirth.style.borderColor = "red";
	    	flag=true;
	    }else{
	    	dateOfBirth.style.borderColor = "";
	    }
	    
	    var gender=document.forms["myForm"]["profile.gender"];
	    if(gender.value == null || gender.value == ""){
	    	gender.style.borderColor = "red";
	    	flag=true;
	    }else{
	    	gender.style.borderColor = "";
	    }
	    
	    /*var zipCode=document.forms["myForm"]["profile.zipCode"];
	    if(zipCode.value == null || zipCode.value == "" || zipCode.value == 0 || !zipCode.value.match(num) || zipCode.value.length != 5){
	    	zipCode.style.borderColor = "red";
	    	flag=true;
	    }else{
	    	zipCode.style.borderColor = "";
	    }*/
	    
	    var annualIncome=document.forms["myForm"]["profile.strAnnualIncome"];
	    if(annualIncome.value == null || annualIncome.value == "" || annualIncome.value == 0){
	    	$("#annual").css({"background":"none"}); 
	    	annualIncome.style.borderColor = "red"; 
	    	flag=true;
	    }else{
	    	annualIncome.style.borderColor = "";
	    }
	    var smokingStatus = document.forms["myForm"]["userAnswer.smokingStatus"];
	    if(smokingStatus.value == null || smokingStatus.value == ""){
	    	smokingStatus.style.borderColor = "red";
	    	flag=true;
	    }else{
	    	smokingStatus.style.borderColor = "";
	    }
	    var dependentsStatus = document.forms["myForm"]["userAnswer.dependentsStatus"];
	    if(dependentsStatus.value == null || dependentsStatus.value == ""){
	    	dependentsStatus.style.borderColor = "red";
	    	flag=true;
	    }else{
	    	dependentsStatus.style.borderColor = "";
	    	var dependentsCount = document.forms["myForm"]["userAnswer.dependentsCount"];
		    if(dependentsStatus.value == 1 && (dependentsCount.value == null || dependentsCount.value == "" || dependentsCount.value == 0 || !dependentsCount.value.match(num) || dependentsCount.value.length > 2)){
		    	dependentsCount.style.borderColor = "red";
		    	flag=true;
		    }else{
		    	dependentsCount.style.borderColor = "";
		    }
		    if(dependentsStatus.value == 0){
		    	$("#count_input").val(0);
		    }
	    }	
	    var state = $('#state').val();
	    if(state==null || state=='' || state=="default"){
	    	$('#state').css({'borderColor':'red'});
	    	flag = true;
	    }else{
	    	$('#state').css({'borderColor':''});
	    }
	    
	   if(flag){
	    return false;
	   }else
		   return true;
	} 
   
   function isValidDOB(txtDate) {
	   var currVal = txtDate;
	   console.log(currVal);
	   if(currVal == '')
	     return false;
	   
	   //Declare Regex  
	   var rxDatePattern = /^(\d{1,2})(\/|-)(\d{1,2})(\/|-)(\d{4})$/; 
	   var dtArray = currVal.match(rxDatePattern); // is format OK?

	   if (dtArray == null)
	      return false;
	  
	   //Checks for mm/dd/yyyy format.
	   dtMonth = dtArray[1];
	   dtDay= dtArray[3];
	   dtYear = dtArray[5];

	   if (dtMonth < 1 || dtMonth > 12)
	       return false;
	   else if (dtDay < 1 || dtDay> 31)
	       return false;
	   else if ((dtMonth==4 || dtMonth==6 || dtMonth==9 || dtMonth==11) && dtDay ==31)
	       return false;
	   else if (dtMonth == 2)
	   {
	      var isleap = (dtYear % 4 == 0 && (dtYear % 100 != 0 || dtYear % 400 == 0));
	      if (dtDay> 29 || (dtDay ==29 && !isleap))
	           return false;
	   }
	   return true;
	}